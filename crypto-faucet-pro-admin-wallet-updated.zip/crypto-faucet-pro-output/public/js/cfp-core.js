/**
 * Crypto Faucet Pro — Core JS Utilities
 * Shared helpers used across all widget scripts.
 *
 * Requires: cfpAjax and cfpNonce to be localised by PHP (wp_localize_script).
 *
 * @package CryptoFaucetPro
 * @since   4.3.0
 */

/* global cfpAjax, cfpNonce, cfpSetSessionToken, cfpGetSessionToken */

'use strict';

window.CFP = window.CFP || {};

/* ============================================================
   AJAX HELPER
   ============================================================ */

/**
 * Send a POST request to admin-ajax.php.
 *
 * @param {string} action    WP AJAX action name.
 * @param {Object} data      Key/value pairs to send.
 * @returns {Promise<Object>} Parsed JSON response.
 */
CFP.ajax = async function (action, data = {}) {
  const fd = new FormData();
  fd.append('action', action);
  fd.append('nonce', typeof cfpNonce !== 'undefined' ? cfpNonce : '');
  fd.append('session_token', typeof cfpGetSessionToken === 'function' ? cfpGetSessionToken() : '');

  for (const [key, val] of Object.entries(data)) {
    fd.append(key, val);
  }

  const response = await fetch(typeof cfpAjax !== 'undefined' ? cfpAjax : '/wp-admin/admin-ajax.php', {
    method: 'POST',
    body: fd,
    credentials: 'same-origin',
  });

  if (!response.ok) {
    throw new Error(`HTTP ${response.status}`);
  }

  return response.json();
};

/* ============================================================
   MESSAGE HELPER
   ============================================================ */

/**
 * Render a success / error / info message into a container.
 *
 * @param {string|HTMLElement} container  Selector string or DOM element.
 * @param {string}             text       Message text (plain).
 * @param {'success'|'error'|'info'} type Message type.
 * @param {number}             [ttl=0]    Auto-clear after ms (0 = never).
 */
CFP.showMsg = function (container, text, type = 'info', ttl = 0) {
  const el = typeof container === 'string' ? document.querySelector(container) : container;
  if (!el) return;
  el.innerHTML = `<div class="cfp-msg ${type}">${CFP.escHtml(text)}</div>`;
  if (ttl > 0) setTimeout(() => { el.innerHTML = ''; }, ttl);
};

CFP.clearMsg = function (container) {
  const el = typeof container === 'string' ? document.querySelector(container) : container;
  if (el) el.innerHTML = '';
};

/* ============================================================
   COUNTDOWN TIMER
   ============================================================ */

const _timers = {};

/**
 * Start a countdown inside an element.
 *
 * @param {string} id         Unique timer key.
 * @param {number} seconds    Remaining seconds.
 * @param {string} displaySel CSS selector of the <span> showing HH:MM:SS.
 * @param {Function} [onDone] Callback when timer reaches zero.
 */
CFP.startTimer = function (id, seconds, displaySel, onDone) {
  CFP.stopTimer(id);
  const display = document.querySelector(displaySel);
  if (!display) return;

  _timers[id] = setInterval(() => {
    if (seconds <= 0) {
      CFP.stopTimer(id);
      display.textContent = '00:00:00';
      if (typeof onDone === 'function') onDone();
      return;
    }
    seconds--;
    const h = String(Math.floor(seconds / 3600)).padStart(2, '0');
    const m = String(Math.floor((seconds % 3600) / 60)).padStart(2, '0');
    const s = String(seconds % 60).padStart(2, '0');
    display.textContent = `${h}:${m}:${s}`;
  }, 1000);
};

CFP.stopTimer = function (id) {
  if (_timers[id]) {
    clearInterval(_timers[id]);
    delete _timers[id];
  }
};

/* ============================================================
   NUMBER FORMATTING
   ============================================================ */

/**
 * Format a satoshi integer with thousands separators.
 * @param {number|string} sat
 * @returns {string}
 */
CFP.formatSat = function (sat) {
  return Number(sat).toLocaleString('en-US');
};

/**
 * Format a multiplier to 2 decimal places with an 'x' suffix.
 * @param {number|string} mult
 * @returns {string}
 */
CFP.formatMult = function (mult) {
  return parseFloat(mult).toFixed(2) + 'x';
};

/* ============================================================
   STRING HELPERS
   ============================================================ */

/**
 * Escape HTML special chars to prevent XSS.
 * @param {string} str
 * @returns {string}
 */
CFP.escHtml = function (str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
};

/**
 * Truncate a string to maxLen chars, appending '…'.
 * @param {string} str
 * @param {number} maxLen
 * @returns {string}
 */
CFP.truncate = function (str, maxLen = 24) {
  str = String(str);
  return str.length > maxLen ? str.slice(0, maxLen) + '…' : str;
};

/* ============================================================
   COPY TO CLIPBOARD
   ============================================================ */

/**
 * Copy text to clipboard and briefly update a button label.
 * @param {string}      text
 * @param {HTMLElement} [btn]
 */
CFP.copyToClipboard = async function (text, btn) {
  try {
    await navigator.clipboard.writeText(text);
    if (btn) {
      const orig = btn.textContent;
      btn.textContent = '✓ Copied!';
      setTimeout(() => { btn.textContent = orig; }, 2000);
    }
  } catch {
    // Fallback for older browsers
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    if (btn) {
      const orig = btn.textContent;
      btn.textContent = '✓ Copied!';
      setTimeout(() => { btn.textContent = orig; }, 2000);
    }
  }
};

/* ============================================================
   WIN / LOSS OVERLAY
   ============================================================ */

/**
 * Briefly flash a win or lose overlay badge on screen.
 * @param {'win'|'lose'} type
 * @param {string}       [label]  Custom label (e.g. "+2,500 sat")
 */
CFP.flashResult = function (type, label) {
  let overlay = document.getElementById('cfp-result-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'cfp-result-overlay';
    overlay.className = 'cfp-game-result-overlay';
    overlay.innerHTML = '<div class="cfp-result-badge"></div>';
    document.body.appendChild(overlay);
  }

  const badge = overlay.querySelector('.cfp-result-badge');
  badge.className = `cfp-result-badge ${type}`;
  badge.textContent = label || (type === 'win' ? '🏆 WIN!' : '💀 BUST');

  overlay.classList.add('show');
  setTimeout(() => { overlay.classList.remove('show'); }, 1800);
};

/* ============================================================
   DEBOUNCE / THROTTLE
   ============================================================ */

CFP.debounce = function (fn, ms = 300) {
  let t;
  return function (...args) {
    clearTimeout(t);
    t = setTimeout(() => fn.apply(this, args), ms);
  };
};

CFP.throttle = function (fn, ms = 200) {
  let last = 0;
  return function (...args) {
    const now = Date.now();
    if (now - last >= ms) {
      last = now;
      fn.apply(this, args);
    }
  };
};

/* ============================================================
   INIT: SESSION-READY LISTENER
   ============================================================ */

document.addEventListener('cfpSessionReady', function (e) {
  const detail = e.detail || {};
  // Broadcast user data to any widget that cares
  document.dispatchEvent(new CustomEvent('cfpUserLoaded', { detail }));
});
