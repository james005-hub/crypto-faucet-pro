/**
 * Crypto Faucet Pro — Faucet & Auth JS
 * Handles: faucet claim, login, register, withdraw, deposit, Hi-Lo
 *
 * Depends on: cfp-core.js (CFP namespace)
 *
 * @package CryptoFaucetPro
 * @since   4.3.0
 */

/* global CFP, cfpSetSessionToken */
'use strict';

/* ============================================================
   FAUCET CLAIM
   ============================================================ */
CFP.Faucet = (function () {
  async function claim() {
    const email  = document.getElementById('cfp-claim-email')?.value?.trim();
    const btn    = document.getElementById('cfp-claim-btn');
    const msgEl  = document.getElementById('cfp-claim-msg');

    if (!email) { CFP.showMsg(msgEl, 'Please enter your email.', 'error'); return; }

    if (btn) btn.disabled = true;
    CFP.clearMsg(msgEl);

    let data;
    try {
      data = await CFP.ajax('cfp_claim', { email });
    } catch {
      CFP.showMsg(msgEl, 'Network error. Please try again.', 'error');
      if (btn) btn.disabled = false;
      return;
    }

    CFP.showMsg(msgEl, data.data?.msg || '', data.success ? 'success' : 'error');

    if (data.success) {
      CFP.startTimer('faucet', data.data.next_in, '#cfp-timer', () => {
        if (btn) btn.disabled = false;
        document.getElementById('cfp-timer-box').style.display = 'none';
      });
      document.getElementById('cfp-timer-box').style.display = '';
      refreshBalance(email);
    } else {
      if (data.data?.remaining) {
        CFP.startTimer('faucet', data.data.remaining, '#cfp-timer', () => {
          if (btn) btn.disabled = false;
          document.getElementById('cfp-timer-box').style.display = 'none';
        });
        document.getElementById('cfp-timer-box').style.display = '';
      } else {
        if (btn) btn.disabled = false;
      }
    }
  }

  async function refreshBalance(email) {
    const data = await CFP.ajax('cfp_get_user', { email });
    if (!data.success) return;

    const balBox = document.getElementById('cfp-main-balance');
    const balAmt = document.getElementById('cfp-bal-amount');
    if (balBox) balBox.style.display = '';
    if (balAmt) balAmt.textContent = CFP.formatSat(data.data.balance);

    if (data.data.remaining > 0) {
      CFP.startTimer('faucet', data.data.remaining, '#cfp-timer', () => {
        const btn = document.getElementById('cfp-claim-btn');
        if (btn) btn.disabled = false;
        document.getElementById('cfp-timer-box').style.display = 'none';
      });
      document.getElementById('cfp-timer-box').style.display = '';
    }
  }

  function init() {
    const btn = document.getElementById('cfp-claim-btn');
    if (btn) btn.addEventListener('click', claim);
  }

  return { init, claim };
})();

/* ============================================================
   AUTH (login / register)
   ============================================================ */
CFP.Auth = (function () {
  async function login(email, password) {
    const data = await CFP.ajax('cfp_login', { email, password });
    if (data.success && data.data?.session_token) {
      if (typeof cfpSetSessionToken === 'function') cfpSetSessionToken(data.data.session_token);
      document.dispatchEvent(new CustomEvent('cfpUserLoaded', { detail: data.data }));
    }
    return data;
  }

  async function register(email, password, ref) {
    const data = await CFP.ajax('cfp_register', { email, password, ref });
    if (data.success && data.data?.session_token) {
      if (typeof cfpSetSessionToken === 'function') cfpSetSessionToken(data.data.session_token);
    }
    return data;
  }

  async function logout(email) {
    return CFP.ajax('cfp_logout', { email });
  }

  function initLoginForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email    = form.querySelector('[name="email"]')?.value;
      const password = form.querySelector('[name="password"]')?.value;
      const msgEl    = form.querySelector('.cfp-auth-msg');
      const btn      = form.querySelector('[type="submit"]');

      if (btn) btn.disabled = true;
      const data = await login(email, password);
      if (btn) btn.disabled = false;

      if (msgEl) CFP.showMsg(msgEl, data.data?.msg || '', data.success ? 'success' : 'error');
      if (data.success) setTimeout(() => location.reload(), 800);
    });
  }

  function initRegisterForm(formId) {
    const form = document.getElementById(formId);
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email    = form.querySelector('[name="email"]')?.value;
      const password = form.querySelector('[name="password"]')?.value;
      const ref      = new URLSearchParams(location.search).get('ref') || '';
      const msgEl    = form.querySelector('.cfp-auth-msg');
      const btn      = form.querySelector('[type="submit"]');

      if (btn) btn.disabled = true;
      const data = await register(email, password, ref);
      if (btn) btn.disabled = false;

      if (msgEl) CFP.showMsg(msgEl, data.data?.msg || '', data.success ? 'success' : 'error');
    });
  }

  return { login, register, logout, initLoginForm, initRegisterForm };
})();

/* ============================================================
   HI-LO GAME
   ============================================================ */
CFP.HiLo = (function () {
  let betting = false;

  async function bet(direction) {
    if (betting) return;
    const email  = document.getElementById('cfp-hilo-email')?.value;
    const amount = document.getElementById('cfp-hilo-amount')?.value;
    if (!email || !amount) { CFP.showMsg('#cfp-hilo-msg', 'Enter email and bet amount.', 'error'); return; }

    betting = true;
    CFP.clearMsg('#cfp-hilo-msg');

    const diceEl = document.getElementById('cfp-dice');
    if (diceEl) diceEl.textContent = '🎲';

    const data = await CFP.ajax('cfp_multiply', { email, amount, bet: direction });

    if (diceEl) {
      const faces = ['⚀','⚁','⚂','⚃','⚄','⚅'];
      const roll  = data.data?.roll ?? Math.ceil(Math.random() * 6);
      diceEl.textContent = faces[Math.min(5, roll - 1)];
    }

    const resultEl = document.getElementById('cfp-roll-result');
    if (resultEl) {
      const roll = data.data?.roll;
      resultEl.textContent = roll ? `Rolled: ${roll}` : '';
      resultEl.style.color = data.success && data.data?.win ? 'var(--cfp-gr)' : 'var(--cfp-rd)';
    }

    betting = false;

    if (data.success && data.data?.win) {
      CFP.flashResult('win', `+${CFP.formatSat(data.data.won)} sat`);
      CFP.showMsg('#cfp-hilo-msg', data.data.msg || 'You win!', 'success', 4000);
    } else {
      CFP.showMsg('#cfp-hilo-msg', data.data?.msg || 'You lose!', 'error', 4000);
    }
  }

  function init() {
    const hiBtn = document.getElementById('cfp-hi-btn') || document.querySelector('.cfp-hi-btn');
    const loBtn = document.getElementById('cfp-lo-btn') || document.querySelector('.cfp-lo-btn');
    if (hiBtn) hiBtn.addEventListener('click', () => bet('hi'));
    if (loBtn) loBtn.addEventListener('click', () => bet('lo'));
  }

  return { init, bet };
})();

/* ============================================================
   WITHDRAW
   ============================================================ */
CFP.Withdraw = (function () {
  async function submit(email, address, amount, currency) {
    const data = await CFP.ajax('cfp_withdraw', { email, address, amount, currency });
    return data;
  }

  function init() {
    const form = document.getElementById('cfp-withdraw-form');
    if (!form) return;

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const email    = form.querySelector('[name="email"]')?.value;
      const address  = form.querySelector('[name="address"]')?.value;
      const amount   = form.querySelector('[name="amount"]')?.value;
      const currency = form.querySelector('[name="currency"]')?.value || 'BTC';
      const msgEl    = form.querySelector('.cfp-withdraw-msg');
      const btn      = form.querySelector('[type="submit"]');

      if (btn) btn.disabled = true;
      const data = await submit(email, address, amount, currency);
      if (btn) btn.disabled = false;
      if (msgEl) CFP.showMsg(msgEl, data.data?.msg || '', data.success ? 'success' : 'error', 5000);
    });
  }

  return { init, submit };
})();

/* ============================================================
   LOTTERY
   ============================================================ */
CFP.Lottery = (function () {
  async function buyTickets(email, qty) {
    return CFP.ajax('cfp_buy_tickets', { email, qty });
  }

  function init() {
    const btn    = document.getElementById('cfp-lottery-buy-btn');
    const qtyEl  = document.getElementById('cfp-ticket-qty');
    const emailEl = document.getElementById('cfp-lottery-email');
    const msgEl  = document.getElementById('cfp-lottery-msg');

    if (btn) {
      btn.addEventListener('click', async () => {
        btn.disabled = true;
        const data = await buyTickets(emailEl?.value, qtyEl?.value || 1);
        btn.disabled = false;

        if (msgEl) CFP.showMsg(msgEl, data.data?.msg || '', data.success ? 'success' : 'error', 5000);
        if (data.success) {
          const countEl = document.getElementById('cfp-ticket-count-num');
          if (countEl && data.data?.tickets) countEl.textContent = data.data.tickets;
        }
      });
    }
  }

  return { init, buyTickets };
})();

/* ============================================================
   SAVINGS
   ============================================================ */
CFP.Savings = (function () {
  async function deposit(email, amount) {
    return CFP.ajax('cfp_savings_deposit', { email, amount });
  }

  async function withdraw(email, amount) {
    return CFP.ajax('cfp_savings_withdraw', { email, amount });
  }

  function init() {
    const depBtn  = document.getElementById('cfp-savings-dep-btn');
    const witBtn  = document.getElementById('cfp-savings-wit-btn');
    const amtEl   = document.getElementById('cfp-savings-amount');
    const emailEl = document.getElementById('cfp-savings-email');
    const msgEl   = document.getElementById('cfp-savings-msg');

    if (depBtn) {
      depBtn.addEventListener('click', async () => {
        const data = await deposit(emailEl?.value, amtEl?.value);
        if (msgEl) CFP.showMsg(msgEl, data.data?.msg || '', data.success ? 'success' : 'error', 5000);
      });
    }

    if (witBtn) {
      witBtn.addEventListener('click', async () => {
        const data = await withdraw(emailEl?.value, amtEl?.value);
        if (msgEl) CFP.showMsg(msgEl, data.data?.msg || '', data.success ? 'success' : 'error', 5000);
      });
    }
  }

  return { init, deposit, withdraw };
})();

/* ============================================================
   LIVE CRYPTO PRICE TICKER
   ============================================================ */
CFP.PriceTicker = (function () {
  async function refresh() {
    const data = await CFP.ajax('cfp_live_price');
    if (!data.success) return;
    document.querySelectorAll('[data-cfp-price]').forEach((el) => {
      const coin = el.dataset.cfpPrice;
      if (data.data?.[coin]) {
        el.textContent = '$' + Number(data.data[coin]).toLocaleString('en-US', { maximumFractionDigits: 2 });
      }
    });
  }

  function init(intervalMs = 60000) {
    refresh();
    setInterval(refresh, intervalMs);
  }

  return { init, refresh };
})();

/* ============================================================
   DOM-READY INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
  CFP.Faucet.init();
  CFP.HiLo.init();
  CFP.Withdraw.init();
  CFP.Lottery.init();
  CFP.Savings.init();
  CFP.PriceTicker.init();
  CFP.Auth.initLoginForm('cfp-login-form');
  CFP.Auth.initRegisterForm('cfp-register-form');
});
