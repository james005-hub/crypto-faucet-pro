/**
 * Crypto Faucet Pro — Casino Games JS
 * Handles: Slots, Dice, Crash, Coin Flip, Wheel of Fortune
 *
 * Depends on: cfp-core.js (CFP namespace)
 *
 * @package CryptoFaucetPro
 * @since   4.3.0
 */

/* global CFP */
'use strict';

/* ============================================================
   SLOTS
   ============================================================ */
CFP.Slots = (function () {
  const SYMBOLS = ['🍒', '🍋', '🔔', '⭐', '💎', '7️⃣', '🎰'];
  let spinning = false;

  function getReelEls() {
    return document.querySelectorAll('#cfp-slots-widget .cfp-reel');
  }

  function randomSymbol() {
    return SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
  }

  function animateReels(results, callback) {
    const reels = getReelEls();
    reels.forEach((reel) => reel.classList.add('spinning'));

    // Stagger stop: each reel stops 300ms after the previous
    reels.forEach((reel, i) => {
      setTimeout(() => {
        reel.classList.remove('spinning');
        reel.textContent = results[i];
        if (i === reels.length - 1 && typeof callback === 'function') {
          callback();
        }
      }, 600 + i * 300);
    });
  }

  async function spin() {
    if (spinning) return;
    const email = document.getElementById('cfp-slots-email')?.value;
    const amount = document.getElementById('cfp-slots-amount')?.value;
    if (!email || !amount) { CFP.showMsg('#cfp-slots-msg', 'Enter email and bet amount.', 'error'); return; }

    spinning = true;
    CFP.clearMsg('#cfp-slots-msg');

    // Animate with placeholder symbols while waiting for server
    const reels = getReelEls();
    reels.forEach((r) => r.classList.add('spinning'));

    let data;
    try {
      data = await CFP.ajax('cfp_slots', { email, amount });
    } catch (err) {
      CFP.showMsg('#cfp-slots-msg', 'Network error. Try again.', 'error');
      reels.forEach((r) => r.classList.remove('spinning'));
      spinning = false;
      return;
    }

    const results = data.data?.reels || [randomSymbol(), randomSymbol(), randomSymbol()];

    animateReels(results, () => {
      spinning = false;
      if (data.success && data.data?.win) {
        reels.forEach((r) => r.classList.add('win'));
        setTimeout(() => reels.forEach((r) => r.classList.remove('win')), 1200);
        CFP.flashResult('win', `+${CFP.formatSat(data.data.won)} sat`);
        CFP.showMsg('#cfp-slots-msg', data.data.msg || 'You win!', 'success', 4000);
      } else {
        CFP.showMsg('#cfp-slots-msg', data.data?.msg || 'No win this time.', 'error', 4000);
      }
    });
  }

  function init() {
    const btn = document.getElementById('cfp-slots-spin-btn');
    if (btn) btn.addEventListener('click', spin);
  }

  return { init, spin };
})();

/* ============================================================
   DICE
   ============================================================ */
CFP.Dice = (function () {
  const DICE_FACES = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
  let rolling = false;

  function getDisplay() { return document.getElementById('cfp-dice-display'); }

  function updateSliderColor() {
    const slider = document.getElementById('cfp-dice-slider');
    if (!slider) return;
    const pct = ((slider.value - slider.min) / (slider.max - slider.min)) * 100;
    slider.style.setProperty('--val', pct + '%');
    const payoutEl = document.getElementById('cfp-dice-payout');
    if (payoutEl) {
      const edge = parseFloat(payoutEl.dataset.edge || 1);
      const mult = ((100 - edge) / parseFloat(slider.value)).toFixed(4);
      payoutEl.innerHTML = `Win if roll < <strong>${slider.value}</strong> &nbsp;·&nbsp; Payout <strong>${mult}x</strong>`;
    }
  }

  async function roll(direction) {
    if (rolling) return;
    const email  = document.getElementById('cfp-dice-email')?.value;
    const amount = document.getElementById('cfp-dice-amount')?.value;
    const target = document.getElementById('cfp-dice-slider')?.value || 50;
    if (!email || !amount) { CFP.showMsg('#cfp-dice-msg', 'Enter email and bet amount.', 'error'); return; }

    rolling = true;
    CFP.clearMsg('#cfp-dice-msg');

    const display = getDisplay();
    if (display) display.classList.add('rolling');

    let data;
    try {
      data = await CFP.ajax('cfp_dice', { email, amount, target, direction });
    } catch {
      CFP.showMsg('#cfp-dice-msg', 'Network error.', 'error');
      if (display) display.classList.remove('rolling');
      rolling = false;
      return;
    }

    if (display) {
      display.classList.remove('rolling');
      const roll = data.data?.roll ?? Math.ceil(Math.random() * 100);
      display.textContent = DICE_FACES[Math.min(5, Math.floor(roll / 17))];
    }

    const resultEl = document.getElementById('cfp-dice-result');
    if (resultEl) resultEl.textContent = data.data?.roll ? `Rolled: ${data.data.roll}` : '';

    rolling = false;

    if (data.success && data.data?.win) {
      CFP.flashResult('win', `+${CFP.formatSat(data.data.won)} sat`);
      CFP.showMsg('#cfp-dice-msg', data.data.msg || 'Win!', 'success', 4000);
    } else {
      CFP.showMsg('#cfp-dice-msg', data.data?.msg || 'Loss.', 'error', 4000);
    }
  }

  function init() {
    const slider = document.getElementById('cfp-dice-slider');
    if (slider) { slider.addEventListener('input', updateSliderColor); updateSliderColor(); }

    const rollOver  = document.getElementById('cfp-dice-over');
    const rollUnder = document.getElementById('cfp-dice-under');
    if (rollOver)  rollOver.addEventListener('click',  () => roll('over'));
    if (rollUnder) rollUnder.addEventListener('click', () => roll('under'));
  }

  return { init, roll };
})();

/* ============================================================
   CRASH
   ============================================================ */
CFP.Crash = (function () {
  let interval  = null;
  let mult      = 1.00;
  let betPlaced = false;
  let cashedOut = false;
  let running   = false;

  function getMultEl() { return document.getElementById('cfp-crash-mult'); }

  function updateDisplay(val, crashed) {
    const el = getMultEl();
    if (!el) return;
    el.textContent = CFP.formatMult(val);
    if (crashed) {
      el.classList.add('crashed');
    } else {
      el.classList.remove('crashed');
    }
  }

  function addHistory(val) {
    const wrap = document.getElementById('cfp-crash-history');
    if (!wrap) return;
    const cls = val < 2 ? 'low' : val < 5 ? 'mid' : 'high';
    const pill = document.createElement('span');
    pill.className = `cfp-crash-pill ${cls}`;
    pill.textContent = CFP.formatMult(val);
    wrap.prepend(pill);
    // Keep only last 15
    while (wrap.children.length > 15) wrap.lastChild.remove();
  }

  async function placeBet() {
    const email  = document.getElementById('cfp-crash-email')?.value;
    const amount = document.getElementById('cfp-crash-amount')?.value;
    if (!email || !amount) { CFP.showMsg('#cfp-crash-msg', 'Enter email and bet.', 'error'); return; }

    const data = await CFP.ajax('cfp_crash_bet', { email, amount });
    if (!data.success) { CFP.showMsg('#cfp-crash-msg', data.data?.msg || 'Error.', 'error'); return; }

    betPlaced = true;
    cashedOut = false;
    mult = 1.00;
    updateDisplay(mult, false);
    CFP.clearMsg('#cfp-crash-msg');
    startLocal(data.data.crash_at);
  }

  function startLocal(crashAt) {
    running = true;
    interval = setInterval(() => {
      mult = parseFloat((mult * 1.02).toFixed(2));

      if (mult >= crashAt) {
        clearInterval(interval);
        running = false;
        updateDisplay(mult, true);
        addHistory(mult);
        if (betPlaced && !cashedOut) {
          CFP.showMsg('#cfp-crash-msg', `Crashed at ${CFP.formatMult(mult)}! You lost.`, 'error');
          CFP.flashResult('lose', `Crashed ${CFP.formatMult(mult)}`);
          betPlaced = false;
        }
        return;
      }

      updateDisplay(mult, false);
    }, 100);
  }

  async function cashOut() {
    if (!betPlaced || cashedOut || !running) return;
    cashedOut = true;
    const email = document.getElementById('cfp-crash-email')?.value;
    const data = await CFP.ajax('cfp_crash_cashout', { email, mult });
    if (data.success) {
      CFP.flashResult('win', `+${CFP.formatSat(data.data.won)} sat @ ${CFP.formatMult(mult)}`);
      CFP.showMsg('#cfp-crash-msg', data.data.msg || `Cashed out at ${CFP.formatMult(mult)}!`, 'success');
    }
    betPlaced = false;
  }

  function init() {
    const betBtn  = document.getElementById('cfp-crash-bet-btn');
    const cashBtn = document.getElementById('cfp-crash-cashout-btn');
    if (betBtn)  betBtn.addEventListener('click', placeBet);
    if (cashBtn) cashBtn.addEventListener('click', cashOut);
  }

  return { init };
})();

/* ============================================================
   COIN FLIP
   ============================================================ */
CFP.CoinFlip = (function () {
  let flipping = false;

  async function flip(choice) {
    if (flipping) return;
    const email  = document.getElementById('cfp-coinflip-email')?.value;
    const amount = document.getElementById('cfp-coinflip-amount')?.value;
    if (!email || !amount) { CFP.showMsg('#cfp-coinflip-msg', 'Enter email and bet.', 'error'); return; }

    flipping = true;
    CFP.clearMsg('#cfp-coinflip-msg');

    const coin = document.getElementById('cfp-coin');
    if (coin) coin.classList.add('flipping');

    let data;
    try {
      data = await CFP.ajax('cfp_coinflip', { email, amount, choice });
    } catch {
      CFP.showMsg('#cfp-coinflip-msg', 'Network error.', 'error');
      if (coin) coin.classList.remove('flipping');
      flipping = false;
      return;
    }

    setTimeout(() => {
      if (coin) coin.classList.remove('flipping');
      flipping = false;

      const result = data.data?.result || (Math.random() > 0.5 ? 'heads' : 'tails');
      const faceEl = document.getElementById('cfp-coin-face-emoji');
      const backEl = document.getElementById('cfp-coin-back-emoji');
      if (faceEl) faceEl.textContent = '🟡'; // heads
      if (backEl) backEl.textContent = '⚪'; // tails

      if (data.success && data.data?.win) {
        CFP.flashResult('win', `+${CFP.formatSat(data.data.won)} sat`);
        CFP.showMsg('#cfp-coinflip-msg', data.data.msg || 'You win!', 'success', 4000);
      } else {
        CFP.showMsg('#cfp-coinflip-msg', data.data?.msg || `${result === 'heads' ? '🟡 Heads' : '⚪ Tails'} — You lose.`, 'error', 4000);
      }
    }, 900);
  }

  function init() {
    const headsBtn = document.getElementById('cfp-coinflip-heads');
    const tailsBtn = document.getElementById('cfp-coinflip-tails');
    if (headsBtn) headsBtn.addEventListener('click', () => flip('heads'));
    if (tailsBtn) tailsBtn.addEventListener('click', () => flip('tails'));
  }

  return { init };
})();

/* ============================================================
   WHEEL OF FORTUNE
   ============================================================ */
CFP.Wheel = (function () {
  let spinning = false;
  let currentRotation = 0;

  const SEGMENTS = [
    { label: '100 sat',  color: '#1c1c1c', value: 100  },
    { label: '2x',       color: '#2a1a00', value: 'x2' },
    { label: '500 sat',  color: '#1c1c1c', value: 500  },
    { label: '50 sat',   color: '#111',    value: 50   },
    { label: 'JACKPOT',  color: '#1a0a00', value: 5000 },
    { label: '200 sat',  color: '#1c1c1c', value: 200  },
    { label: 'TRY AGAIN',color: '#111',    value: 0    },
    { label: '1000 sat', color: '#2a1a00', value: 1000 },
  ];

  function drawWheel(canvas) {
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const size = canvas.width;
    const cx = size / 2;
    const cy = size / 2;
    const radius = cx - 4;
    const arc = (2 * Math.PI) / SEGMENTS.length;

    SEGMENTS.forEach((seg, i) => {
      const startAngle = arc * i - Math.PI / 2;
      const endAngle   = startAngle + arc;

      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.arc(cx, cy, radius, startAngle, endAngle);
      ctx.closePath();
      ctx.fillStyle = seg.color;
      ctx.fill();
      ctx.strokeStyle = '#2a2a2a';
      ctx.lineWidth = 2;
      ctx.stroke();

      // Label
      ctx.save();
      ctx.translate(cx, cy);
      ctx.rotate(startAngle + arc / 2);
      ctx.textAlign = 'right';
      ctx.fillStyle = seg.value === 5000 ? '#f7931a' : '#e0e0e0';
      ctx.font = `bold ${size < 260 ? 10 : 13}px 'Oswald', sans-serif`;
      ctx.fillText(seg.label, radius - 10, 4);
      ctx.restore();
    });

    // Centre hub
    ctx.beginPath();
    ctx.arc(cx, cy, 20, 0, Math.PI * 2);
    ctx.fillStyle = '#f7931a';
    ctx.fill();
  }

  async function spinWheel() {
    if (spinning) return;
    const email  = document.getElementById('cfp-wheel-email')?.value;
    const amount = document.getElementById('cfp-wheel-amount')?.value;
    if (!email || !amount) { CFP.showMsg('#cfp-wheel-msg', 'Enter email and bet.', 'error'); return; }

    spinning = true;
    CFP.clearMsg('#cfp-wheel-msg');
    const resultEl = document.getElementById('cfp-wheel-result');
    if (resultEl) resultEl.textContent = '';

    let data;
    try {
      data = await CFP.ajax('cfp_wheel', { email, amount });
    } catch {
      CFP.showMsg('#cfp-wheel-msg', 'Network error.', 'error');
      spinning = false;
      return;
    }

    const segIndex = data.data?.segment ?? Math.floor(Math.random() * SEGMENTS.length);
    const arc = 360 / SEGMENTS.length;
    const targetDeg = 360 - (segIndex * arc + arc / 2); // align segment to pointer
    const spins = 5 * 360;
    const finalRotation = currentRotation + spins + ((targetDeg - currentRotation) % 360);
    currentRotation = finalRotation;

    const canvas = document.getElementById('cfp-wheel-canvas');
    if (canvas) {
      canvas.style.transition = 'transform 4s cubic-bezier(0.17, 0.67, 0.12, 0.99)';
      canvas.style.transform  = `rotate(${finalRotation}deg)`;
    }

    setTimeout(() => {
      spinning = false;
      const seg = SEGMENTS[segIndex];
      if (data.success && data.data?.win) {
        CFP.flashResult('win', `+${CFP.formatSat(data.data.won)} sat`);
        CFP.showMsg('#cfp-wheel-msg', data.data.msg || `Won ${seg.label}!`, 'success', 5000);
        if (resultEl) { resultEl.textContent = `🏆 ${seg.label}`; resultEl.style.color = 'var(--cfp-gr)'; }
      } else {
        CFP.showMsg('#cfp-wheel-msg', data.data?.msg || seg.label, 'error', 4000);
        if (resultEl) { resultEl.textContent = seg.label; resultEl.style.color = 'var(--cfp-rd)'; }
      }
    }, 4200);
  }

  function init() {
    const canvas = document.getElementById('cfp-wheel-canvas');
    drawWheel(canvas);

    const spinBtn = document.getElementById('cfp-wheel-spin-btn');
    if (spinBtn) spinBtn.addEventListener('click', spinWheel);
  }

  return { init, drawWheel };
})();

/* ============================================================
   AUTOPLAY CONTROLLER
   ============================================================ */
CFP.Autoplay = (function () {
  let active    = false;
  let remaining = 0;
  let interval  = null;
  let gameFunc  = null;

  function start(game, rounds) {
    if (active) return;
    active    = true;
    remaining = parseInt(rounds, 10) || 10;
    gameFunc  = game;

    const badge = document.querySelector('.cfp-autoplay-badge');
    if (badge) badge.style.display = 'inline-flex';

    interval = setInterval(async () => {
      if (remaining <= 0 || !active) { stop(); return; }
      remaining--;
      updateBadge();
      await gameFunc();
    }, 1800);
  }

  function stop() {
    active = false;
    remaining = 0;
    clearInterval(interval);
    const badge = document.querySelector('.cfp-autoplay-badge');
    if (badge) badge.style.display = 'none';
  }

  function updateBadge() {
    const badge = document.querySelector('.cfp-autoplay-badge');
    if (badge) badge.textContent = `⏵ Autoplay (${remaining} left)`;
  }

  function init() {
    const startBtn = document.getElementById('cfp-autoplay-start');
    const stopBtn  = document.getElementById('cfp-autoplay-stop');
    const countEl  = document.getElementById('cfp-autoplay-count');

    if (startBtn) {
      startBtn.addEventListener('click', () => {
        const game  = window[startBtn.dataset.game];
        const count = countEl?.value || 10;
        if (typeof game === 'function') start(game, count);
      });
    }

    if (stopBtn) stopBtn.addEventListener('click', stop);
  }

  return { init, start, stop };
})();

/* ============================================================
   DOM-READY INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
  CFP.Slots.init();
  CFP.Dice.init();
  CFP.Crash.init();
  CFP.CoinFlip.init();
  CFP.Wheel.init();
  CFP.Autoplay.init();
});
