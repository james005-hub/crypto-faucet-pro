/**
 * Crypto Faucet Pro — Dashboard JS
 * Handles: profile tabs, live balance refresh, XP progress, chat,
 *          referral copy, achievement popups, KYC upload, 2FA toggle.
 *
 * Depends on: cfp-core.js (CFP namespace)
 *
 * @package CryptoFaucetPro
 * @since   4.3.0
 */

/* global CFP */
'use strict';

/* ============================================================
   TAB NAVIGATION
   ============================================================ */
CFP.Tabs = (function () {
  function init(containerSel) {
    const container = document.querySelector(containerSel);
    if (!container) return;

    const buttons = container.querySelectorAll('.cfp-tab-btn');
    const panels  = container.querySelectorAll('.cfp-tab-panel');

    buttons.forEach((btn) => {
      btn.addEventListener('click', () => {
        buttons.forEach((b) => b.classList.remove('active'));
        panels.forEach((p)  => p.classList.remove('active'));
        btn.classList.add('active');
        const target = container.querySelector(`#${btn.dataset.tab}`);
        if (target) target.classList.add('active');
      });
    });

    // Activate first tab by default
    if (buttons[0]) buttons[0].click();
  }

  return { init };
})();

/* ============================================================
   DASHBOARD NAV (sidebar items → panel toggle)
   ============================================================ */
CFP.DashNav = (function () {
  function init() {
    const items  = document.querySelectorAll('.cfp-dash-nav-item[data-panel]');
    const panels = document.querySelectorAll('.cfp-dash-panel[data-panel]');

    items.forEach((item) => {
      item.addEventListener('click', () => {
        items.forEach((i)  => i.classList.remove('active'));
        panels.forEach((p) => p.style.display = 'none');
        item.classList.add('active');
        const panel = document.querySelector(`.cfp-dash-panel[data-panel="${item.dataset.panel}"]`);
        if (panel) panel.style.display = 'block';
      });
    });

    if (items[0]) items[0].click();
  }

  return { init };
})();

/* ============================================================
   LIVE BALANCE REFRESH
   ============================================================ */
CFP.Balance = (function () {
  let refreshInterval = null;

  async function refresh(email) {
    if (!email) return;
    try {
      const data = await CFP.ajax('cfp_get_user', { email });
      if (data.success) updateDisplay(data.data);
    } catch { /* silent */ }
  }

  function updateDisplay(userData) {
    const balEls = document.querySelectorAll('[data-cfp-balance]');
    balEls.forEach((el) => {
      el.textContent = CFP.formatSat(userData.balance || 0);
    });

    const xpFill = document.querySelector('.cfp-xp-fill');
    if (xpFill && userData.xp !== undefined && userData.xp_next !== undefined) {
      const pct = Math.min(100, Math.round((userData.xp / userData.xp_next) * 100));
      xpFill.style.width = pct + '%';
    }

    const xpPoints = document.querySelector('.cfp-xp-points');
    if (xpPoints && userData.xp !== undefined) {
      xpPoints.textContent = `${CFP.formatSat(userData.xp)} / ${CFP.formatSat(userData.xp_next)} XP`;
    }

    const levelEl = document.querySelector('.cfp-xp-level');
    if (levelEl && userData.level) {
      levelEl.textContent = `Level ${userData.level}`;
    }
  }

  function startPolling(email, intervalMs = 30000) {
    stopPolling();
    refresh(email);
    refreshInterval = setInterval(() => refresh(email), intervalMs);
  }

  function stopPolling() {
    if (refreshInterval) { clearInterval(refreshInterval); refreshInterval = null; }
  }

  return { refresh, startPolling, stopPolling, updateDisplay };
})();

/* ============================================================
   REFERRAL COPY
   ============================================================ */
CFP.Referral = (function () {
  function init() {
    const copyBtns = document.querySelectorAll('[data-cfp-copy-ref]');
    copyBtns.forEach((btn) => {
      btn.addEventListener('click', async () => {
        const link = document.querySelector(btn.dataset.cfpCopyRef)?.textContent
                  || btn.dataset.cfpCopyRef;
        await CFP.copyToClipboard(link, btn);
      });
    });
  }

  return { init };
})();

/* ============================================================
   ACHIEVEMENT POPUP
   ============================================================ */
CFP.Achievements = (function () {
  function showPopup(achievement) {
    const existing = document.getElementById('cfp-ach-popup');
    if (existing) existing.remove();

    const popup = document.createElement('div');
    popup.id = 'cfp-ach-popup';
    popup.style.cssText = `
      position: fixed; bottom: 24px; right: 24px; z-index: 10000;
      background: #111; border: 1px solid #f7931a; border-radius: 12px;
      padding: 16px 20px; display: flex; align-items: center; gap: 14px;
      box-shadow: 0 8px 40px rgba(247,147,26,.3); max-width: 300px;
      animation: cfp-slide-in 0.4s cubic-bezier(0.34,1.56,0.64,1);
    `;

    const style = document.createElement('style');
    style.textContent = `
      @keyframes cfp-slide-in {
        from { transform: translateX(120%); opacity: 0; }
        to   { transform: translateX(0);    opacity: 1; }
      }
    `;
    document.head.appendChild(style);

    popup.innerHTML = `
      <div style="font-size:2.4rem">${achievement.icon || '🏆'}</div>
      <div>
        <div style="font-size:0.65rem;text-transform:uppercase;letter-spacing:2px;color:#f7931a;margin-bottom:4px">Achievement Unlocked</div>
        <div style="font-family:'Oswald',sans-serif;font-size:1rem;color:#fff;margin-bottom:2px">${CFP.escHtml(achievement.name)}</div>
        <div style="font-size:0.78rem;color:#777">${CFP.escHtml(achievement.desc || '')}</div>
      </div>
    `;

    document.body.appendChild(popup);
    setTimeout(() => popup.remove(), 5000);
  }

  function init() {
    // Listen for server-pushed achievement events
    document.addEventListener('cfpAchievementUnlocked', (e) => {
      showPopup(e.detail);
    });
  }

  return { init, showPopup };
})();

/* ============================================================
   LIVE CHAT
   ============================================================ */
CFP.Chat = (function () {
  let pollInterval = null;
  let lastMsgId    = 0;

  async function fetchMessages() {
    try {
      const data = await CFP.ajax('cfp_chat_get', { since: lastMsgId });
      if (data.success && Array.isArray(data.data?.messages)) {
        data.data.messages.forEach(appendMessage);
        if (data.data.messages.length) {
          lastMsgId = data.data.messages[data.data.messages.length - 1].id;
        }
      }
    } catch { /* silent */ }
  }

  function appendMessage(msg) {
    const list = document.getElementById('cfp-chat-messages');
    if (!list) return;

    const row = document.createElement('div');
    row.className = 'cfp-chat-msg';
    row.innerHTML = `
      <div class="cfp-chat-msg-avatar">${CFP.escHtml(msg.avatar || '🙂')}</div>
      <div class="cfp-chat-msg-body">
        <div class="cfp-chat-msg-meta">
          <span class="cfp-chat-msg-user">${CFP.escHtml(msg.username || 'Anon')}</span>
          <span class="cfp-chat-msg-time">${CFP.escHtml(msg.time || '')}</span>
        </div>
        <div class="cfp-chat-msg-text">${CFP.escHtml(msg.text)}</div>
      </div>
    `;

    list.appendChild(row);
    list.scrollTop = list.scrollHeight;
  }

  async function sendMessage(email, text) {
    if (!text.trim()) return;
    const data = await CFP.ajax('cfp_chat_send', { email, text });
    if (data.success && data.data?.message) appendMessage(data.data.message);
  }

  function init() {
    const sendBtn  = document.getElementById('cfp-chat-send');
    const inputEl  = document.getElementById('cfp-chat-input');
    const emailEl  = document.getElementById('cfp-chat-email');

    if (sendBtn && inputEl) {
      sendBtn.addEventListener('click', async () => {
        const text  = inputEl.value.trim();
        const email = emailEl?.value || '';
        await sendMessage(email, text);
        inputEl.value = '';
      });

      inputEl.addEventListener('keydown', async (e) => {
        if (e.key === 'Enter' && !e.shiftKey) {
          e.preventDefault();
          sendBtn.click();
        }
      });
    }

    // Poll every 5 seconds
    fetchMessages();
    pollInterval = setInterval(fetchMessages, 5000);
  }

  function destroy() {
    clearInterval(pollInterval);
  }

  return { init, destroy };
})();

/* ============================================================
   KYC DOCUMENT UPLOAD
   ============================================================ */
CFP.KYC = (function () {
  async function upload(email, fileInput) {
    if (!fileInput.files.length) { CFP.showMsg('#cfp-kyc-msg', 'Select a file to upload.', 'error'); return; }
    const file = fileInput.files[0];
    const fd   = new FormData();
    fd.append('action', 'cfp_kyc_upload');
    fd.append('nonce', typeof cfpNonce !== 'undefined' ? cfpNonce : '');
    fd.append('email', email);
    fd.append('document', file);

    CFP.showMsg('#cfp-kyc-msg', 'Uploading…', 'info');

    try {
      const r    = await fetch(typeof cfpAjax !== 'undefined' ? cfpAjax : '/wp-admin/admin-ajax.php', { method: 'POST', body: fd, credentials: 'same-origin' });
      const data = await r.json();
      CFP.showMsg('#cfp-kyc-msg', data.data?.msg || (data.success ? 'Uploaded!' : 'Error.'), data.success ? 'success' : 'error', 5000);
    } catch {
      CFP.showMsg('#cfp-kyc-msg', 'Upload failed. Try again.', 'error');
    }
  }

  function init() {
    const btn      = document.getElementById('cfp-kyc-upload-btn');
    const fileEl   = document.getElementById('cfp-kyc-file');
    const emailEl  = document.getElementById('cfp-kyc-email');
    if (btn && fileEl) {
      btn.addEventListener('click', () => upload(emailEl?.value || '', fileEl));
    }
  }

  return { init };
})();

/* ============================================================
   2FA TOGGLE
   ============================================================ */
CFP.TwoFA = (function () {
  async function toggle(email, enable) {
    const data = await CFP.ajax('cfp_2fa_toggle', { email, enable: enable ? '1' : '0' });
    if (data.success) {
      CFP.showMsg('#cfp-2fa-msg', data.data?.msg || (enable ? '2FA enabled.' : '2FA disabled.'), 'success', 4000);
      const qr = document.getElementById('cfp-2fa-qr');
      if (qr) qr.style.display = enable ? 'block' : 'none';
    } else {
      CFP.showMsg('#cfp-2fa-msg', data.data?.msg || 'Error.', 'error', 4000);
    }
  }

  function init() {
    const enableBtn  = document.getElementById('cfp-2fa-enable');
    const disableBtn = document.getElementById('cfp-2fa-disable');
    const emailEl    = document.getElementById('cfp-2fa-email');

    if (enableBtn)  enableBtn.addEventListener('click',  () => toggle(emailEl?.value, true));
    if (disableBtn) disableBtn.addEventListener('click', () => toggle(emailEl?.value, false));
  }

  return { init };
})();

/* ============================================================
   NOTIFICATIONS (toast queue)
   ============================================================ */
CFP.Notifications = (function () {
  const queue = [];
  let showing  = false;

  function push(msg, type = 'info', ttl = 4000) {
    queue.push({ msg, type, ttl });
    if (!showing) next();
  }

  function next() {
    if (!queue.length) { showing = false; return; }
    showing = true;
    const { msg, type, ttl } = queue.shift();

    let container = document.getElementById('cfp-toast-container');
    if (!container) {
      container = document.createElement('div');
      container.id = 'cfp-toast-container';
      container.style.cssText = 'position:fixed;top:20px;right:20px;z-index:10001;display:flex;flex-direction:column;gap:10px;';
      document.body.appendChild(container);
    }

    const toast = document.createElement('div');
    toast.className = `cfp-msg ${type}`;
    toast.style.cssText = 'max-width:320px;padding:14px 18px;border-radius:10px;box-shadow:0 4px 20px rgba(0,0,0,.5);animation:cfp-slide-in .3s ease;';
    toast.textContent = msg;
    container.appendChild(toast);

    setTimeout(() => {
      toast.remove();
      setTimeout(next, 200);
    }, ttl);
  }

  return { push };
})();

/* ============================================================
   DOM-READY INIT
   ============================================================ */
document.addEventListener('DOMContentLoaded', function () {
  CFP.Tabs.init('#cfp-dashboard');
  CFP.DashNav.init();
  CFP.Referral.init();
  CFP.Achievements.init();
  CFP.Chat.init();
  CFP.KYC.init();
  CFP.TwoFA.init();

  // Auto-start balance polling if email is known
  const emailEl = document.getElementById('cfp-dash-email');
  if (emailEl?.value) CFP.Balance.startPolling(emailEl.value);

  // Session ready → start polling
  document.addEventListener('cfpUserLoaded', (e) => {
    if (e.detail?.email) CFP.Balance.startPolling(e.detail.email);
  });
});
