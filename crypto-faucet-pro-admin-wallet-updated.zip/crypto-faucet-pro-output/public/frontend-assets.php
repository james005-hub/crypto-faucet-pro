<?php
/**
 * Frontend asset enqueue and inline CSS generator
 * FULLY UPDATED VERSION
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action('wp_enqueue_scripts','cfp_frontend_assets');

function cfp_frontend_assets() {

    // ✅ Fonts
    wp_enqueue_style(
        'cfp-fonts',
        'https://fonts.googleapis.com/css2?family=Oswald:wght@400;700;900&family=Source+Sans+3:wght@400;600;700&display=swap',
        [],
        null
    );

    // ✅ CSS FILES
    wp_enqueue_style('cfp-base', CFP_PLUGIN_URL . 'public/css/cfp-base.css', [], '1.0');
    wp_enqueue_style('cfp-widgets', CFP_PLUGIN_URL . 'public/css/cfp-widgets.css', ['cfp-base'], '1.0');
    wp_enqueue_style('cfp-games', CFP_PLUGIN_URL . 'public/css/cfp-games.css', ['cfp-base'], '1.0');
    wp_enqueue_style('cfp-dashboard', CFP_PLUGIN_URL . 'public/css/cfp-dashboard.css', ['cfp-base'], '1.0');
    wp_enqueue_style('cfp-responsive', CFP_PLUGIN_URL . 'public/css/cfp-responsive.css', ['cfp-base'], '1.0');

    // ✅ JS FILES (ORDER MATTERS)
    wp_enqueue_script('cfp-core', CFP_PLUGIN_URL . 'public/js/cfp-core.js', [], '1.0', true);
    wp_enqueue_script('cfp-faucet', CFP_PLUGIN_URL . 'public/js/cfp-faucet.js', ['cfp-core'], '1.0', true);
    wp_enqueue_script('cfp-games', CFP_PLUGIN_URL . 'public/js/cfp-games.js', ['cfp-core'], '1.0', true);
    wp_enqueue_script('cfp-dashboard', CFP_PLUGIN_URL . 'public/js/cfp-dashboard.js', ['cfp-core'], '1.0', true);

    // ✅ AJAX CONFIG (REQUIRED FOR JS)
    wp_localize_script('cfp-core', 'cfpAjax', admin_url('admin-ajax.php'));
    wp_localize_script('cfp-core', 'cfpNonce', wp_create_nonce('cfp_nonce'));

    // ✅ Optional: reCAPTCHA
    if (cfp_get_setting('captcha_enabled','0') && cfp_get_setting('recaptcha_site_key')) {
        wp_enqueue_script('recaptcha','https://www.google.com/recaptcha/api.js',[],'',true);
    }

    // ✅ INLINE CSS (your existing system)
    wp_add_inline_style('cfp-base', cfp_frontend_css());

    // ✅ SESSION HELPER (required for login persistence)
    wp_add_inline_script('cfp-core', cfp_session_js_helper(), 'after');
}

/* ============================================================
   SESSION TOKEN HELPER (unchanged)
   ============================================================ */

function cfp_session_js_helper() {
    $ajax = esc_js( admin_url('admin-ajax.php') );
    return <<<JS
(function(){
    let _cfpToken = '';

    window.cfpSetSessionToken = function(token) {
        _cfpToken = token || '';
    };

    window.cfpGetSessionToken = function() {
        return _cfpToken;
    };

    document.addEventListener('DOMContentLoaded', function() {
        var fd = new FormData();
        fd.append('action', 'cfp_ping_session');
        fd.append('nonce', (typeof cfpNonce !== 'undefined') ? cfpNonce : '');

        fetch('{$ajax}', { method: 'POST', body: fd })
            .then(function(r){ return r.json(); })
            .then(function(d){
                if (d && d.success && d.data && d.data.session_token) {
                    _cfpToken = d.data.session_token;
                    document.dispatchEvent(new CustomEvent('cfpSessionReady', { detail: d.data }));
                }
            })
            .catch(function(){});
    });
})();
JS;
}

/* ============================================================
   INLINE CSS GENERATOR (unchanged)
   ============================================================ */

function cfp_frontend_css() {
    $p = cfp_get_setting('primary_color','#f7931a');
    $a = cfp_get_setting('accent_color','#ffcc02');

    return "
:root{--cfp-p:{$p};--cfp-a:{$a};--cfp-dk:#0a0a0a;--cfp-pn:#111;--cfp-br:#2a2a2a;--cfp-tx:#e0e0e0;--cfp-mt:#777;--cfp-gr:#22c55e;--cfp-rd:#ef4444;}
.cfp-page{background:var(--cfp-dk);color:var(--cfp-tx);font-family:'Source Sans 3',sans-serif;margin:0;padding:0;}
.cfp-hero{background:linear-gradient(135deg,#0a0a0a 60%,#1a1000 100%);padding:60px 20px;}
";
}