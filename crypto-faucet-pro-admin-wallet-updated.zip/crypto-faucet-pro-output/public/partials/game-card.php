<?php
/**
 * Crypto Faucet Pro — Game Card Partial
 * Renders a single game preview card for the Games listing page.
 *
 * Required variables (set before including):
 *   $game_icon   string  Emoji or <img> tag
 *   $game_name   string  Display name
 *   $game_desc   string  Short description
 *   $game_url    string  URL to the game page
 *   $game_edge   float   House edge percentage
 *   $game_max    string  Max multiplier or payout label (e.g. "2x", "10,000 sat")
 *   $game_badge  string  Optional badge text (e.g. "HOT", "NEW")
 *
 * @package CryptoFaucetPro
 * @since   4.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$game_icon  = $game_icon  ?? '🎲';
$game_name  = $game_name  ?? 'Game';
$game_desc  = $game_desc  ?? '';
$game_url   = $game_url   ?? '#';
$game_edge  = $game_edge  ?? 1.0;
$game_max   = $game_max   ?? '—';
$game_badge = $game_badge ?? '';
?>
<div class="cfp-game-card">
    <?php if ( $game_badge ) : ?>
        <div class="cfp-game-card-badge"><?= esc_html( $game_badge ) ?></div>
    <?php endif; ?>

    <div class="cfp-game-card-icon"><?= $game_icon /* allow emoji */ ?></div>

    <div class="cfp-game-card-body">
        <h3 class="cfp-game-card-title"><?= esc_html( $game_name ) ?></h3>
        <p class="cfp-game-card-desc"><?= esc_html( $game_desc ) ?></p>

        <div class="cfp-game-card-meta">
            <span class="cfp-game-meta-item">
                <span class="meta-label"><?= esc_html__( 'House Edge', 'crypto-faucet-pro' ) ?></span>
                <span class="meta-value"><?= esc_html( number_format( $game_edge, 1 ) ) ?>%</span>
            </span>
            <span class="cfp-game-meta-item">
                <span class="meta-label"><?= esc_html__( 'Max Win', 'crypto-faucet-pro' ) ?></span>
                <span class="meta-value"><?= esc_html( $game_max ) ?></span>
            </span>
        </div>
    </div>

    <a href="<?= esc_url( $game_url ) ?>" class="cfp-game-card-btn">
        <?= esc_html__( 'Play Now', 'crypto-faucet-pro' ) ?> →
    </a>
</div>

<?php
/* ── Styles (output once per page via wp_add_inline_style or directly here) ─ */
static $cfp_game_card_css_printed = false;
if ( ! $cfp_game_card_css_printed ) :
    $cfp_game_card_css_printed = true;
?>
<style>
.cfp-game-card {
    background: #111;
    border: 1px solid #222;
    border-radius: 14px;
    padding: 22px;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
    position: relative;
    transition: border-color 0.2s, transform 0.2s;
    overflow: hidden;
}

.cfp-game-card:hover {
    border-color: var(--cfp-p);
    transform: translateY(-3px);
}

.cfp-game-card-badge {
    position: absolute;
    top: 12px;
    right: 12px;
    background: var(--cfp-p);
    color: #000;
    font-size: 0.62rem;
    font-weight: 900;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    padding: 3px 8px;
    border-radius: 20px;
}

.cfp-game-card-icon {
    font-size: 3.5rem;
    margin-bottom: 14px;
    width: 80px;
    height: 80px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #0d0d0d;
    border-radius: 50%;
    border: 1px solid #2a2a2a;
}

.cfp-game-card-title {
    font-family: 'Oswald', sans-serif;
    font-size: 1.1rem;
    color: #fff;
    text-transform: uppercase;
    letter-spacing: 1px;
    margin: 0 0 8px;
}

.cfp-game-card-desc {
    font-size: 0.83rem;
    color: var(--cfp-mt);
    line-height: 1.5;
    margin: 0 0 14px;
    flex: 1;
}

.cfp-game-card-meta {
    display: flex;
    gap: 20px;
    margin-bottom: 18px;
}

.cfp-game-meta-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 2px;
}

.meta-label {
    font-size: 0.62rem;
    text-transform: uppercase;
    letter-spacing: 1.5px;
    color: #444;
}

.meta-value {
    font-family: 'Oswald', sans-serif;
    font-size: 1rem;
    color: var(--cfp-p);
    font-weight: 700;
}

.cfp-game-card-btn {
    display: block;
    width: 100%;
    background: linear-gradient(135deg, var(--cfp-p), var(--cfp-a));
    color: #000;
    font-family: 'Oswald', sans-serif;
    font-weight: 700;
    font-size: 0.88rem;
    letter-spacing: 1.5px;
    text-transform: uppercase;
    text-decoration: none;
    padding: 11px;
    border-radius: 8px;
    transition: opacity 0.18s;
}

.cfp-game-card-btn:hover { opacity: 0.85; }
</style>
<?php endif; ?>
