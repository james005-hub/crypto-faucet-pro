<?php
/**
 * Crypto Faucet Pro — Site Footer Partial
 *
 * Usage: include CFP_PLUGIN_DIR . 'public/partials/footer.php';
 *
 * @package CryptoFaucetPro
 * @since   4.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$site_name  = get_bloginfo( 'name' );
$year       = gmdate( 'Y' );
$currency   = cfp_get_setting( 'faucet_currency', 'BTC' );
$primary    = cfp_get_setting( 'primary_color', '#f7931a' );
$tos_url    = cfp_get_setting( 'tos_url',    home_url( '/terms' ) );
$priv_url   = cfp_get_setting( 'privacy_url', home_url( '/privacy' ) );
$support_url = cfp_get_setting( 'support_url', home_url( '/contact' ) );
?>
<footer class="cfp-footer" role="contentinfo">
    <div class="cfp-footer-inner cfp-container">

        <div class="cfp-footer-col">
            <h4>Earn <?= esc_html( $currency ) ?></h4>
            <a href="<?= esc_url( cfp_get_setting( 'page_faucet_url', home_url('/faucet') ) ) ?>">Free Faucet</a>
            <a href="<?= esc_url( cfp_get_setting( 'page_lottery_url', home_url('/lottery') ) ) ?>">Weekly Lottery</a>
            <a href="<?= esc_url( cfp_get_setting( 'page_savings_url', home_url('/savings') ) ) ?>">Savings Account</a>
            <a href="<?= esc_url( cfp_get_setting( 'page_ref_url', home_url('/referral') ) ) ?>">Referral Programme</a>
        </div>

        <div class="cfp-footer-col">
            <h4>Games</h4>
            <a href="<?= esc_url( cfp_get_setting( 'page_hilo_url',     home_url('/games/hilo') ) ) ?>">Hi-Lo Multiply</a>
            <a href="<?= esc_url( cfp_get_setting( 'page_slots_url',    home_url('/games/slots') ) ) ?>">Slots</a>
            <a href="<?= esc_url( cfp_get_setting( 'page_dice_url',     home_url('/games/dice') ) ) ?>">Dice</a>
            <a href="<?= esc_url( cfp_get_setting( 'page_crash_url',    home_url('/games/crash') ) ) ?>">Crash</a>
            <a href="<?= esc_url( cfp_get_setting( 'page_coinflip_url', home_url('/games/coinflip') ) ) ?>">Coin Flip</a>
            <a href="<?= esc_url( cfp_get_setting( 'page_wheel_url',    home_url('/games/wheel') ) ) ?>">Wheel of Fortune</a>
        </div>

        <div class="cfp-footer-col">
            <h4>Support</h4>
            <a href="<?= esc_url( $tos_url ) ?>">Terms of Service</a>
            <a href="<?= esc_url( $priv_url ) ?>">Privacy Policy</a>
            <a href="<?= esc_url( $support_url ) ?>">Contact Us</a>
            <?php if ( cfp_get_setting( 'provably_fair_enabled', '1' ) ) : ?>
            <a href="<?= esc_url( home_url('/provably-fair') ) ?>">Provably Fair</a>
            <?php endif; ?>
        </div>

    </div><!-- /.cfp-footer-inner -->

    <!-- Responsible gambling notice -->
    <div class="cfp-footer-disclaimer cfp-container">
        <p>
            <?= esc_html__( '18+', 'crypto-faucet-pro' ) ?> &bull;
            <?= esc_html__( 'This site is for entertainment purposes only. Please play responsibly.', 'crypto-faucet-pro' ) ?>
        </p>
        <p class="cfp-footer-copy">
            &copy; <?= esc_html( $year ) ?> <?= esc_html( $site_name ) ?>.
            <?= esc_html__( 'All rights reserved.', 'crypto-faucet-pro' ) ?>
        </p>
    </div>
</footer>

<style>
.cfp-footer {
    background: #060606;
    border-top: 1px solid #1c1c1c;
    padding: 48px 20px 24px;
    color: #777;
    font-size: 0.85rem;
}

.cfp-footer-inner {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 30px;
    margin-bottom: 30px;
}

.cfp-footer-col h4 {
    font-size: 0.72rem;
    text-transform: uppercase;
    letter-spacing: 2px;
    color: <?= esc_html( $primary ) ?>;
    margin: 0 0 14px;
    font-family: 'Oswald', sans-serif;
}

.cfp-footer-col a {
    display: block;
    color: #555;
    text-decoration: none;
    margin-bottom: 8px;
    transition: color 0.18s;
}

.cfp-footer-col a:hover { color: #ccc; }

.cfp-footer-disclaimer {
    border-top: 1px solid #111;
    padding-top: 20px;
    text-align: center;
    color: #2a2a2a;
    font-size: 0.75rem;
    line-height: 1.6;
}

@media (max-width: 640px) {
    .cfp-footer-inner {
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
}

@media (max-width: 400px) {
    .cfp-footer-inner {
        grid-template-columns: 1fr;
    }
}
</style>
