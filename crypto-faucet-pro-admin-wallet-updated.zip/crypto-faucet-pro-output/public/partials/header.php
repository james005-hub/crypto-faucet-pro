<?php
/**
 * Crypto Faucet Pro — Site Header Partial
 *
 * Usage: include CFP_PLUGIN_DIR . 'public/partials/header.php';
 *
 * @package CryptoFaucetPro
 * @since   4.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$site_name    = get_bloginfo( 'name' );
$currency     = cfp_get_setting( 'faucet_currency', 'BTC' );
$primary      = cfp_get_setting( 'primary_color', '#f7931a' );
$logo_url     = cfp_get_setting( 'logo_url', '' );
$nav_links    = apply_filters( 'cfp_nav_links', [
    'Faucet'      => cfp_get_setting( 'page_faucet_url',   home_url( '/faucet' ) ),
    'Games'       => cfp_get_setting( 'page_games_url',    home_url( '/games' ) ),
    'Lottery'     => cfp_get_setting( 'page_lottery_url',  home_url( '/lottery' ) ),
    'Leaderboard' => cfp_get_setting( 'page_lb_url',       home_url( '/leaderboard' ) ),
    'Dashboard'   => cfp_get_setting( 'page_dash_url',     home_url( '/dashboard' ) ),
] );
?>
<header class="cfp-header" role="banner">
    <div class="cfp-header-inner">

        <!-- Logo / Wordmark -->
        <a class="cfp-logo" href="<?= esc_url( home_url( '/' ) ) ?>" aria-label="<?= esc_attr( $site_name ) ?> home">
            <?php if ( $logo_url ) : ?>
                <img src="<?= esc_url( $logo_url ) ?>" alt="<?= esc_attr( $site_name ) ?>" height="36" width="auto">
            <?php else : ?>
                <span class="cfp-logo-text">
                    <span class="cfp-logo-icon">₿</span>
                    <?= esc_html( $site_name ) ?>
                </span>
            <?php endif; ?>
        </a>

        <!-- Primary Navigation -->
        <nav class="cfp-nav" aria-label="Primary navigation">
            <ul class="cfp-nav-list" role="list">
                <?php foreach ( $nav_links as $label => $url ) : ?>
                    <li>
                        <a class="cfp-nav-link <?= ( esc_url( $url ) === esc_url( $_SERVER['REQUEST_URI'] ) ) ? 'active' : '' ?>"
                           href="<?= esc_url( $url ) ?>">
                            <?= esc_html( $label ) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </nav>

        <!-- Right-hand actions -->
        <div class="cfp-header-actions">
            <!-- Live BTC price chip -->
            <?php if ( cfp_get_setting( 'show_live_price', '1' ) ) : ?>
                <div class="cfp-price-chip">
                    <span class="cfp-price-sym">₿</span>
                    <span data-cfp-price="BTC" class="cfp-price-val">—</span>
                </div>
            <?php endif; ?>

            <!-- Login / Account -->
            <a href="<?= esc_url( cfp_get_setting( 'page_dash_url', home_url( '/dashboard' ) ) ) ?>"
               class="cfp-header-btn cfp-header-btn-primary">
                🎮 Play Now
            </a>
        </div>

        <!-- Mobile hamburger -->
        <button class="cfp-mobile-toggle" aria-label="Open menu" aria-expanded="false" aria-controls="cfp-mobile-menu">
            <span></span><span></span><span></span>
        </button>

    </div><!-- /.cfp-header-inner -->

    <!-- Mobile menu (hidden by default, toggled via JS) -->
    <div class="cfp-mobile-menu" id="cfp-mobile-menu" hidden>
        <ul role="list">
            <?php foreach ( $nav_links as $label => $url ) : ?>
                <li>
                    <a href="<?= esc_url( $url ) ?>"><?= esc_html( $label ) ?></a>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
</header>

<style>
/* Header styles — extracted here so they live next to the partial */
.cfp-header {
    background: #0a0a0a;
    border-bottom: 1px solid #1c1c1c;
    position: sticky;
    top: 0;
    z-index: 1000;
}

.cfp-header-inner {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
    height: 64px;
    display: flex;
    align-items: center;
    gap: 24px;
}

.cfp-logo {
    text-decoration: none;
    flex-shrink: 0;
}

.cfp-logo-text {
    display: flex;
    align-items: center;
    gap: 8px;
    font-family: 'Oswald', sans-serif;
    font-size: 1.3rem;
    font-weight: 700;
    color: #fff;
    text-transform: uppercase;
    letter-spacing: 1px;
}

.cfp-logo-icon {
    color: <?= esc_html( $primary ) ?>;
    font-size: 1.6rem;
}

.cfp-nav { margin-left: auto; }

.cfp-nav-list {
    display: flex;
    gap: 4px;
    list-style: none;
    margin: 0;
    padding: 0;
}

.cfp-nav-link {
    display: block;
    padding: 8px 14px;
    color: #999;
    text-decoration: none;
    font-size: 0.85rem;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-radius: 6px;
    transition: color 0.18s, background 0.18s;
}

.cfp-nav-link:hover,
.cfp-nav-link.active {
    color: #fff;
    background: #1a1a1a;
}

.cfp-nav-link.active {
    color: <?= esc_html( $primary ) ?>;
}

.cfp-header-actions {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-shrink: 0;
}

.cfp-price-chip {
    display: flex;
    align-items: center;
    gap: 5px;
    background: #1a1a1a;
    border: 1px solid #2a2a2a;
    border-radius: 20px;
    padding: 5px 12px;
    font-size: 0.8rem;
    color: #e0e0e0;
}

.cfp-price-sym { color: <?= esc_html( $primary ) ?>; font-weight: 700; }

.cfp-header-btn {
    padding: 9px 20px;
    border-radius: 6px;
    font-family: 'Oswald', sans-serif;
    font-size: 0.85rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 1px;
    text-decoration: none;
    transition: opacity 0.18s, transform 0.1s;
}

.cfp-header-btn-primary {
    background: linear-gradient(135deg, <?= esc_html( $primary ) ?>, #ffcc02);
    color: #000;
}

.cfp-header-btn-primary:hover { opacity: 0.85; }

.cfp-mobile-toggle {
    display: none;
    flex-direction: column;
    gap: 5px;
    background: none;
    border: none;
    cursor: pointer;
    padding: 8px;
    margin-left: auto;
}

.cfp-mobile-toggle span {
    display: block;
    width: 24px;
    height: 2px;
    background: #e0e0e0;
    border-radius: 2px;
    transition: transform 0.2s, opacity 0.2s;
}

.cfp-mobile-menu {
    background: #0d0d0d;
    border-top: 1px solid #1c1c1c;
    padding: 16px 20px;
}

.cfp-mobile-menu ul { list-style: none; margin: 0; padding: 0; }
.cfp-mobile-menu a {
    display: block;
    padding: 12px 0;
    color: #ccc;
    text-decoration: none;
    font-weight: 600;
    font-size: 0.95rem;
    border-bottom: 1px solid #1c1c1c;
}
.cfp-mobile-menu a:hover { color: <?= esc_html( $primary ) ?>; }

@media (max-width: 768px) {
    .cfp-nav,
    .cfp-price-chip { display: none; }
    .cfp-mobile-toggle { display: flex; }
    .cfp-header-btn { display: none; }
}
</style>

<script>
(function () {
    const toggle = document.querySelector('.cfp-mobile-toggle');
    const menu   = document.getElementById('cfp-mobile-menu');
    if (!toggle || !menu) return;
    toggle.addEventListener('click', function () {
        const open = !menu.hidden;
        menu.hidden = open;
        toggle.setAttribute('aria-expanded', String(!open));
    });
})();
</script>
