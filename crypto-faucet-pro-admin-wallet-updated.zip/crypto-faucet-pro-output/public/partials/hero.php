<?php
/**
 * Crypto Faucet Pro — Hero Section Partial
 *
 * Usage: include CFP_PLUGIN_DIR . 'public/partials/hero.php';
 *
 * @package CryptoFaucetPro
 * @since   4.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

$site_name  = get_bloginfo( 'name' );
$currency   = cfp_get_setting( 'faucet_currency', 'BTC' );
$min        = (int) cfp_get_setting( 'min_claim_sat', 98 );
$max        = (int) cfp_get_setting( 'max_claim_sat', 200 );
$interval   = (int) cfp_get_setting( 'claim_interval_minutes', 60 );
$faucet_url = cfp_get_setting( 'page_faucet_url', home_url( '/faucet' ) );
?>
<section class="cfp-hero cfp-page" aria-label="Hero">
    <div class="cfp-hero-inner">

        <!-- LEFT: pitch copy -->
        <div class="cfp-hero-left">
            <h1>
                Win Free<br>
                <span><?= esc_html( $currency ) ?></span><br>
                Every Hour!
            </h1>

            <ul class="cfp-feature-list">
                <li>Claim <span class="hi"><?= esc_html( "{$min}–{$max}" ) ?> Satoshi</span> every <?= esc_html( $interval ) ?> minutes</li>
                <li>Play <a href="<?= esc_url( cfp_get_setting('page_games_url', home_url('/games')) ) ?>">6 casino games</a></li>
                <li>Enter weekly lottery &amp; golden ticket contest</li>
                <li>Earn <?= esc_html( cfp_get_setting('savings_apy','4.08') ) ?>% APY on savings</li>
                <li>Instant <?= esc_html( $currency ) ?> on-chain withdrawals</li>
            </ul>

            <a href="<?= esc_url( $faucet_url ) ?>" class="cfp-play-btn">
                ▶ PLAY NOW — IT'S FREE
            </a>
        </div>

        <!-- RIGHT: quick register card -->
        <div class="cfp-hero-right">
            <div class="cfp-reg-card">
                <h3><?= esc_html__( 'GET STARTED IN SECONDS', 'crypto-faucet-pro' ) ?></h3>

                <input class="cfp-reg-input" type="email" id="cfp-hero-email"
                       placeholder="<?= esc_attr__( 'Enter your email address', 'crypto-faucet-pro' ) ?>"
                       autocomplete="email">

                <input class="cfp-reg-input" type="password" id="cfp-hero-pw"
                       placeholder="<?= esc_attr__( 'Choose a password', 'crypto-faucet-pro' ) ?>"
                       autocomplete="new-password">

                <div id="cfp-hero-msg" class="cfp-auth-msg" style="margin-bottom:10px"></div>

                <button class="cfp-reg-btn" id="cfp-hero-reg-btn">
                    <?= esc_html__( 'CREATE FREE ACCOUNT', 'crypto-faucet-pro' ) ?>
                </button>

                <p style="font-size:.72rem;color:#999;text-align:center;margin:12px 0 0">
                    <?= esc_html__( 'By registering you agree to our', 'crypto-faucet-pro' ) ?>
                    <a href="<?= esc_url( cfp_get_setting('tos_url', home_url('/terms')) ) ?>"
                       style="color:#4285f4" target="_blank" rel="noopener">
                        <?= esc_html__( 'Terms of Service', 'crypto-faucet-pro' ) ?>
                    </a>.
                </p>
            </div>
        </div>

    </div><!-- /.cfp-hero-inner -->
</section>

<script>
(function () {
    const btn   = document.getElementById('cfp-hero-reg-btn');
    const email = document.getElementById('cfp-hero-email');
    const pw    = document.getElementById('cfp-hero-pw');
    const msg   = document.getElementById('cfp-hero-msg');

    if (!btn) return;

    btn.addEventListener('click', async function () {
        if (!email.value || !pw.value) {
            msg.innerHTML = '<div class="cfp-msg error">Please enter your email and a password.</div>';
            return;
        }
        btn.disabled = true;
        btn.textContent = 'Creating account…';

        const ref = new URLSearchParams(location.search).get('ref') || '';
        try {
            const data = await CFP.Auth.register(email.value, pw.value, ref);
            msg.innerHTML = `<div class="cfp-msg ${data.success ? 'success' : 'error'}">${data.data?.msg || ''}</div>`;
            if (data.success) {
                setTimeout(() => {
                    location.href = <?= wp_json_encode( esc_url( $faucet_url ) ) ?>;
                }, 1200);
            }
        } catch {
            msg.innerHTML = '<div class="cfp-msg error">Network error. Please try again.</div>';
        } finally {
            btn.disabled = false;
            btn.textContent = 'CREATE FREE ACCOUNT';
        }
    });
})();
</script>
