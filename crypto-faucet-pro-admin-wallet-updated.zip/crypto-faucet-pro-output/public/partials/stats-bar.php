<?php
/**
 * Crypto Faucet Pro — Stats Bar Partial
 * Renders the live statistics strip (users paid, total paid, next lottery).
 *
 * Usage: include CFP_PLUGIN_DIR . 'public/partials/stats-bar.php';
 *
 * @package CryptoFaucetPro
 * @since   4.3.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

global $wpdb;

// Cache stats for 5 min to avoid hammering DB on every page load
$stats = get_transient( 'cfp_hero_stats' );

if ( false === $stats ) {
    $users_paid  = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT user_id) FROM " . CFP_TABLE_WITHDRAWALS . " WHERE status='completed'" );
    $total_sat   = (int) $wpdb->get_var( "SELECT SUM(amount) FROM " . CFP_TABLE_WITHDRAWALS . " WHERE status='completed'" );
    $next_lottery = cfp_get_setting( 'lottery_next_draw', '' );

    $stats = [
        'users_paid'   => $users_paid,
        'total_sat'    => $total_sat,
        'next_lottery' => $next_lottery,
    ];
    set_transient( 'cfp_hero_stats', $stats, 5 * MINUTE_IN_SECONDS );
}

$currency = cfp_get_setting( 'faucet_currency', 'BTC' );
?>
<div class="cfp-stats-bar">
    <div class="cfp-stats-bar-inner">

        <div class="cfp-stat">
            <div class="cfp-stat-icon">👥</div>
            <div class="cfp-stat-label"><?= esc_html__( 'Users Paid', 'crypto-faucet-pro' ) ?></div>
            <div class="cfp-stat-number"><?= esc_html( number_format( $stats['users_paid'] ) ) ?></div>
        </div>

        <div class="cfp-stat">
            <div class="cfp-stat-icon">₿</div>
            <div class="cfp-stat-label"><?= esc_html__( 'Total Paid (sat)', 'crypto-faucet-pro' ) ?></div>
            <div class="cfp-stat-number"><?= esc_html( number_format( $stats['total_sat'] ) ) ?></div>
        </div>

        <div class="cfp-stat">
            <div class="cfp-stat-icon">🎟️</div>
            <div class="cfp-stat-label"><?= esc_html__( 'Next Lottery Draw', 'crypto-faucet-pro' ) ?></div>
            <div class="cfp-stat-number" id="cfp-lottery-countdown">
                <?php if ( $stats['next_lottery'] ) : ?>
                    <span data-cfp-countdown="<?= esc_attr( $stats['next_lottery'] ) ?>">—</span>
                <?php else : ?>
                    <?= esc_html__( 'Soon', 'crypto-faucet-pro' ) ?>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<script>
(function () {
    // Countdown for lottery draw date stored in data-cfp-countdown attribute
    document.querySelectorAll('[data-cfp-countdown]').forEach(function (el) {
        const target = new Date(el.dataset.cfpCountdown).getTime();

        function tick() {
            const diff = target - Date.now();
            if (diff <= 0) { el.textContent = 'Drawing now!'; return; }
            const d = Math.floor(diff / 86400000);
            const h = Math.floor((diff % 86400000) / 3600000);
            const m = Math.floor((diff % 3600000)  / 60000);
            const s = Math.floor((diff % 60000)    / 1000);
            el.textContent = (d > 0 ? d + 'd ' : '') +
                String(h).padStart(2,'0') + ':' +
                String(m).padStart(2,'0') + ':' +
                String(s).padStart(2,'0');
        }

        tick();
        setInterval(tick, 1000);
    });
})();
</script>
