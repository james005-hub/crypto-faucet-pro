<?php
/**
 * Plugin Name: Crypto Faucet Pro
 * Plugin URI:  https://yoursite.com/crypto-faucet-pro
 * Description: Full FreeBitco.in clone — hourly free BTC, Hi-Lo game, weekly lottery, savings interest, golden ticket contest, P2P events, referral commissions, 5 casino games, instant crypto deposits & withdrawals, full admin panel.
 * Version:     4.2.1
 * Author:      Crypto Faucet Pro
 * Requires PHP: 8.0
 * Requires at least: 5.8
 * License:     GPL2
 * Text Domain: crypto-faucet-pro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// SECURITY: Check PHP version requirement
if ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
    add_action( 'admin_notices', function() {
        ?>
        <div class="notice notice-error">
            <p><strong>Crypto Faucet Pro:</strong> This plugin requires PHP 8.0 or higher. You are running PHP <?= PHP_VERSION ?>. Please upgrade PHP for security and performance.</p>
        </div>
        <?php
    } );
    // Prevent plugin activation on old PHP versions
    if ( defined( 'WP_CLI' ) || ( isset( $_GET['action'] ) && $_GET['action'] === 'activate' ) ) {
        deactivate_plugins( plugin_basename( __FILE__ ) );
        wp_die( 'Crypto Faucet Pro requires PHP 8.0 or higher. You are running PHP ' . PHP_VERSION . '. Please upgrade PHP before activating this plugin.' );
    }
    return;
}

define( 'CFP_VERSION',    '4.2.1' );
define( 'CFP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CFP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'CFP_PLUGIN_FILE', __FILE__ );

// Register activation hook (must be before includes that use table constants)
register_activation_hook(__FILE__, 'cfp_activate');

global $wpdb;
define( 'CFP_TABLE_USERS',           $wpdb->prefix . 'cfp_users' );
define( 'CFP_TABLE_CLAIMS',          $wpdb->prefix . 'cfp_claims' );
define( 'CFP_TABLE_TRANSACTIONS',    $wpdb->prefix . 'cfp_transactions' );
define( 'CFP_TABLE_REFERRALS',       $wpdb->prefix . 'cfp_referrals' );
define( 'CFP_TABLE_SETTINGS',        $wpdb->prefix . 'cfp_settings' );
define( 'CFP_TABLE_WITHDRAWALS',     $wpdb->prefix . 'cfp_withdrawals' );
define( 'CFP_TABLE_LOTTERY',         $wpdb->prefix . 'cfp_lottery' );
define( 'CFP_TABLE_LOTTERY_TICKETS', $wpdb->prefix . 'cfp_lottery_tickets' );
define( 'CFP_TABLE_INTEREST',        $wpdb->prefix . 'cfp_interest' );
define( 'CFP_TABLE_GOLDEN',          $wpdb->prefix . 'cfp_golden_tickets' );
define( 'CFP_TABLE_P2P',             $wpdb->prefix . 'cfp_p2p_events' );
define( 'CFP_TABLE_P2P_BETS',        $wpdb->prefix . 'cfp_p2p_bets' );
define( 'CFP_TABLE_MULTIPLY',        $wpdb->prefix . 'cfp_multiply_games' );
define( 'CFP_TABLE_SLOTS',           $wpdb->prefix . 'cfp_slots_games' );
define( 'CFP_TABLE_COINFLIP',        $wpdb->prefix . 'cfp_coinflip_games' );
define( 'CFP_TABLE_DICE',            $wpdb->prefix . 'cfp_dice_games' );
define( 'CFP_TABLE_CRASH',           $wpdb->prefix . 'cfp_crash_games' );
define( 'CFP_TABLE_WHEEL',           $wpdb->prefix . 'cfp_wheel_games' );
define( 'CFP_TABLE_FP_DEPOSITS',     $wpdb->prefix . 'cfp_fp_deposits' );
define( 'CFP_TABLE_FP_WITHDRAWALS',  $wpdb->prefix . 'cfp_fp_withdrawals' );
define( 'CFP_TABLE_ADMIN_WALLET',    $wpdb->prefix . 'cfp_admin_wallet' );
define( 'CFP_TABLE_AD_REVENUE',      $wpdb->prefix . 'cfp_ad_revenue' );
define( 'CFP_TABLE_FUN_TOKENS',      $wpdb->prefix . 'cfp_fun_tokens' );
define( 'CFP_TABLE_PREMIUM',         $wpdb->prefix . 'cfp_premium' );
// v4 new tables
define( 'CFP_TABLE_CHAT',            $wpdb->prefix . 'cfp_chat' );
define( 'CFP_TABLE_XP_LOG',          $wpdb->prefix . 'cfp_xp_log' );
define( 'CFP_TABLE_VERIFY_TOKENS',   $wpdb->prefix . 'cfp_verify_tokens' );
define( 'CFP_TABLE_GAME_SEEDS',      $wpdb->prefix . 'cfp_game_seeds' );
define( 'CFP_TABLE_IP_LIMITS',       $wpdb->prefix . 'cfp_ip_limits' );
define( 'CFP_TABLE_KYC',             $wpdb->prefix . 'cfp_kyc' );

// NOWPayments table constants
define( 'CFP_TABLE_NP_DEPOSITS',    $wpdb->prefix . 'cfp_np_deposits' );
define( 'CFP_TABLE_NP_WITHDRAWALS', $wpdb->prefix . 'cfp_np_withdrawals' );

// Login history table (used in admin-users.php)
define( 'CFP_TABLE_LOGIN_HISTORY',  $wpdb->prefix . 'cfp_login_history' );

// Core includes
require_once CFP_PLUGIN_DIR . 'includes/activation.php';
require_once CFP_PLUGIN_DIR . 'includes/helpers.php';
require_once CFP_PLUGIN_DIR . 'includes/nowpayments-api.php';  // NOWPayments deposit/withdrawal/webhook

// Security layer MUST load before AJAX handlers
require_once CFP_PLUGIN_DIR . 'includes/security-enhanced.php';
require_once CFP_PLUGIN_DIR . 'includes/secure-settings.php';
require_once CFP_PLUGIN_DIR . 'includes/rate-limiting.php';
require_once CFP_PLUGIN_DIR . 'includes/security-headers.php';

// AJAX handlers (now can use cfp_require_auth)
require_once CFP_PLUGIN_DIR . 'includes/ajax-auth-claim.php';
require_once CFP_PLUGIN_DIR . 'includes/ajax-games.php';
require_once CFP_PLUGIN_DIR . 'includes/ajax-purchases.php';
require_once CFP_PLUGIN_DIR . 'includes/ajax-user.php';
require_once CFP_PLUGIN_DIR . 'includes/referral-system.php';
require_once CFP_PLUGIN_DIR . 'includes/ajax-new-games.php';
require_once CFP_PLUGIN_DIR . 'includes/ajax-nowpayments.php';
require_once CFP_PLUGIN_DIR . 'includes/etherscan-infura-api.php';  // Infura RPC + Etherscan API helpers
require_once CFP_PLUGIN_DIR . 'includes/ajax-web3-wallets.php';   // MetaMask & WalletConnect AJAX handlers
require_once CFP_PLUGIN_DIR . 'includes/shortcodes.php';
require_once CFP_PLUGIN_DIR . 'includes/shortcodes-web3-wallets.php'; // MetaMask & WalletConnect widgets

// v4 new feature modules
require_once CFP_PLUGIN_DIR . 'includes/provably-fair.php';
require_once CFP_PLUGIN_DIR . 'includes/autoplay.php';
require_once CFP_PLUGIN_DIR . 'includes/email-verify.php';
require_once CFP_PLUGIN_DIR . 'includes/ip-limiter.php';
require_once CFP_PLUGIN_DIR . 'includes/xp-system.php';
require_once CFP_PLUGIN_DIR . 'includes/live-price.php';
require_once CFP_PLUGIN_DIR . 'includes/chat.php';
require_once CFP_PLUGIN_DIR . 'includes/kyc.php';
require_once CFP_PLUGIN_DIR . 'includes/password-auth.php';
require_once CFP_PLUGIN_DIR . 'includes/monthly-contest.php';
require_once CFP_PLUGIN_DIR . 'includes/pwa.php';
require_once CFP_PLUGIN_DIR . 'includes/multi-crypto.php';
require_once CFP_PLUGIN_DIR . 'includes/achievement-system.php';   // Badge & achievement system
require_once CFP_PLUGIN_DIR . 'includes/leaderboard-system.php';   // Leaderboards
require_once CFP_PLUGIN_DIR . 'includes/anti-fraud-system.php';    // Fraud scoring & VPN detection
require_once CFP_PLUGIN_DIR . 'includes/notification-system.php';  // User notifications
require_once CFP_PLUGIN_DIR . 'includes/admin-notifications.php';  // Admin notification centre
require_once CFP_PLUGIN_DIR . 'includes/rest-api.php';             // Public REST API endpoints
require_once CFP_PLUGIN_DIR . 'includes/webhook-system.php';       // Outbound webhooks

// Admin panel
require_once CFP_PLUGIN_DIR . 'admin/admin-menu.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-settings.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-users.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-currency.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-claims-lottery-p2p.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-web3-wallets.php';       // MetaMask & WalletConnect admin settings
require_once CFP_PLUGIN_DIR . 'admin/admin-games.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-wallet-fees.php';
require_once CFP_PLUGIN_DIR . 'includes/onchain-balance.php';   // Live on-chain wallet balance (BTC/ETH)
require_once CFP_PLUGIN_DIR . 'includes/trezor-sweep.php';
require_once CFP_PLUGIN_DIR . 'includes/admin-trezor-hw.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-security.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-game-controls.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-email-alerts.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-referral-stats.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-geo-block.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-anti-fraud.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-branding.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-api-access.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-backup.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-demo-mode.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-promotions.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-system-status.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-traffic-analytics.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-cron-manager.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-ad-manager.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-reports-export.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-betting-analytics.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-jackpot-manager.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-fee-calculator.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-session-manager.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-activity-log.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-price-alerts.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-api-key-manager.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-bet-limits-manager.php';
require_once CFP_PLUGIN_DIR . 'admin/admin-referral-tiers.php';

// Relay key / auto-sweep system (EVM chains — Ethereum, BNB, Polygon, etc.)
require_once CFP_PLUGIN_DIR . 'includes/cfp-crypto-primitives.php';  // Keccak256, secp256k1, RLP, AES-256-GCM
require_once CFP_PLUGIN_DIR . 'includes/cfp-rpc.php';                 // Infura JSON-RPC, sign_and_broadcast
require_once CFP_PLUGIN_DIR . 'includes/cfp-relay.php';               // Relay keypair, EIP-712 auth, AJAX handlers
require_once CFP_PLUGIN_DIR . 'includes/cfp-relay-autosweep.php';     // cfp_after_wallet_credit hook + cron sweep
require_once CFP_PLUGIN_DIR . 'admin/admin-relay.php';                // Admin UI page

// Frontend
require_once CFP_PLUGIN_DIR . 'public/frontend-assets.php';
// Production hardening (v4.1)
require_once CFP_PLUGIN_DIR . 'includes/ssl-enforce.php';
require_once CFP_PLUGIN_DIR . 'includes/audit-log.php';
require_once CFP_PLUGIN_DIR . 'includes/withdrawal-controls.php';
require_once CFP_PLUGIN_DIR . 'includes/tos-age-verify.php';
require_once CFP_PLUGIN_DIR . 'includes/revenue-controller.php';
// Database migration (runs on activation)
require_once CFP_PLUGIN_DIR . 'includes/database-migration.php';

