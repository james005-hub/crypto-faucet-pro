# Crypto Faucet Pro — WordPress Plugin

A full-featured Bitcoin faucet plugin for WordPress, modelled after FreeBitco.in.

## Features

- ⏰ Hourly free BTC claims
- 🎰 Hi-Lo / Multiply game
- 🎟️ Weekly lottery
- 💰 Savings account with daily APY interest
- 🎫 Golden Ticket contest
- 🤝 P2P prediction events
- 👥 Referral commissions
- 🎮 5 casino games: Slots, Coin Flip, Dice, Crash, Wheel of Fortune
- 💳 FaucetPay instant deposits & withdrawals
- 🪙 FUN Token sale widget
- ⭐ Premium membership
- 📊 Full admin panel with revenue wallet, fee controls, and user management

## Installation

1. Upload the `crypto-faucet-pro` folder to `/wp-content/plugins/`
2. Activate through **Plugins → Installed Plugins** in WordPress
3. Go to **Crypto Faucet** in the WordPress admin sidebar
4. Configure your FaucetPay API key under **FaucetPay Settings**
5. Add shortcodes to your pages (see below)

## Shortcodes

| Shortcode              | Description                           |
|------------------------|---------------------------------------|
| `[cfp_faucet]`         | Main faucet claim + Hi-Lo game widget |
| `[cfp_buy_tickets]`    | Lottery ticket purchase widget        |
| `[cfp_fun_token]`      | FUN Token sale widget                 |

## File Structure

```
crypto-faucet-pro/
├── crypto-faucet-pro.php          ← Main plugin file (constants + loader)
│
├── includes/
│   ├── activation.php             ← DB table creation on activation
│   ├── helpers.php                ← Settings helpers, cron, admin wallet
│   ├── faucetpay-api.php          ← FaucetPay API wrapper + IPN handler
│   ├── ajax-auth-claim.php        ← Register, login, claim AJAX handlers
│   ├── ajax-games.php             ← Casino game AJAX handlers
│   ├── ajax-purchases.php         ← Ticket / token / premium AJAX handlers
│   ├── ajax-user.php              ← User data, withdraw, history AJAX handlers
│   └── shortcodes.php             ← Frontend shortcode output
│
├── admin/
│   ├── admin-menu.php             ← Admin menu registration + styles
│   ├── admin-users.php            ← Dashboard, Users list, Balance Adjustor
│   ├── admin-currency.php         ← Multi-coin / currency settings
│   ├── admin-claims-lottery-p2p.php ← Claims, Withdrawals, Lottery, P2P pages
│   ├── admin-faucetpay-settings.php ← FaucetPay config + General Settings
│   ├── admin-games.php            ← Casino game settings
│   └── admin-wallet-fees.php      ← Revenue Wallet + Fees & Rates
│
├── public/
│   ├── frontend-assets.php        ← wp_enqueue_scripts + inline CSS
│   ├── css/                       ← (reserved for extracted stylesheets)
│   └── js/                        ← (reserved for extracted scripts)
│
└── languages/                     ← Translation .pot / .mo files
```

## Requirements

- WordPress 5.8+
- PHP 7.4+
- A FaucetPay account and API key (for payouts)

## Configuration

All settings are managed via the WordPress admin under **Crypto Faucet**.

Key settings to configure after activation:

1. **FaucetPay API Key** — required for payouts
2. **Claim Amount** — satoshi amount per hourly claim
3. **Primary / Accent Color** — brand colours for the widgets
4. **Savings APY** — annual yield paid to savings users
5. **House Edge** — per-game edge percentage for casino games
6. **Admin Wallet** — enable/disable revenue tracking streams

## License

GPL2 — see [https://www.gnu.org/licenses/gpl-2.0.html](https://www.gnu.org/licenses/gpl-2.0.html)
