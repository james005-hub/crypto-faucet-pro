<?php
/**
 * Crypto Faucet Pro — EVM RPC Layer
 *
 * Provides:
 *   - EVM network registry (Ethereum, BNB, Polygon, Arbitrum, Base, Optimism, Avalanche)
 *   - Infura / fallback RPC URL resolution
 *   - JSON-RPC call wrapper
 *   - High-level sign-and-broadcast using cfp-crypto-primitives.php
 *
 * Settings keys used (stored in cfp_settings table):
 *   cfp_relay_infura_project_id  — Infura Project ID (v3)
 *
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// EVM NETWORK REGISTRY
// ============================================================

function cfp_evm_networks(): array {
    return [
        1     => [ 'name'=>'Ethereum',       'symbol'=>'ETH',  'infura_path'=>'mainnet',           'infura'=>true,  'fallback_rpc'=>null ],
        56    => [ 'name'=>'BNB Smart Chain', 'symbol'=>'BNB',  'infura_path'=>null,                'infura'=>false, 'fallback_rpc'=>'https://bsc-dataseed1.binance.org' ],
        137   => [ 'name'=>'Polygon',         'symbol'=>'MATIC','infura_path'=>'polygon-mainnet',   'infura'=>true,  'fallback_rpc'=>'https://polygon-rpc.com' ],
        42161 => [ 'name'=>'Arbitrum One',    'symbol'=>'ETH',  'infura_path'=>'arbitrum-mainnet',  'infura'=>true,  'fallback_rpc'=>'https://arb1.arbitrum.io/rpc' ],
        8453  => [ 'name'=>'Base',            'symbol'=>'ETH',  'infura_path'=>'base-mainnet',      'infura'=>true,  'fallback_rpc'=>'https://mainnet.base.org' ],
        10    => [ 'name'=>'Optimism',        'symbol'=>'ETH',  'infura_path'=>'optimism-mainnet',  'infura'=>true,  'fallback_rpc'=>'https://mainnet.optimism.io' ],
        43114 => [ 'name'=>'Avalanche',       'symbol'=>'AVAX', 'infura_path'=>'avalanche-mainnet', 'infura'=>true,  'fallback_rpc'=>'https://api.avax.network/ext/bc/C/rpc' ],
    ];
}

// ============================================================
// RPC URL RESOLUTION
// ============================================================

function cfp_rpc_infura_url( int $chain_id ): ?string {
    $nets = cfp_evm_networks();
    $net  = $nets[$chain_id] ?? null;
    if ( ! $net || ! $net['infura'] ) return null;
    $pid = trim( cfp_get_setting('cfp_relay_infura_project_id','') );
    if ( ! $pid ) return null;
    return 'https://' . $net['infura_path'] . '.infura.io/v3/' . $pid;
}

function cfp_rpc_url( int $chain_id ): ?string {
    $url = cfp_rpc_infura_url($chain_id);
    if ($url) return $url;
    return cfp_evm_networks()[$chain_id]['fallback_rpc'] ?? null;
}

// ============================================================
// JSON-RPC CALL
// ============================================================

/**
 * Make a JSON-RPC call to an EVM node.
 * Returns decoded response array or WP_Error.
 */
function cfp_rpc( int $chain_id, string $method, array $params = [] ): array|\WP_Error {
    $url = cfp_rpc_url($chain_id);
    if ( ! $url )
        return new \WP_Error('no_rpc',
            'No RPC endpoint for chain '.$chain_id.'. Configure your Infura Project ID in Admin → Relay Settings.');

    $resp = wp_remote_post( $url, [
        'timeout' => 15,
        'headers' => ['Content-Type'=>'application/json'],
        'body'    => wp_json_encode(['jsonrpc'=>'2.0','method'=>$method,'params'=>$params,'id'=>1]),
    ]);

    if ( is_wp_error($resp) ) return $resp;

    $data = json_decode(wp_remote_retrieve_body($resp),true);
    if ( isset($data['error']) )
        return new \WP_Error('rpc_error', $data['error']['message'] ?? 'RPC error from node.');

    return $data;
}

// ============================================================
// BROADCAST
// ============================================================

/** Broadcast a signed raw tx. Returns tx hash or WP_Error. */
function cfp_rpc_broadcast( int $chain_id, string $signed_hex ): string|\WP_Error {
    $result = cfp_rpc($chain_id,'eth_sendRawTransaction',[$signed_hex]);
    if ( is_wp_error($result) ) return $result;
    $hash = $result['result'] ?? '';
    if ( strlen($hash)===66 ) return $hash;
    return new \WP_Error('broadcast_failed','Unexpected RPC response: '.wp_json_encode($result));
}

// ============================================================
// GAS HELPERS
// ============================================================

/** Get native coin balance of an address in decimal string (e.g. '0.05000000'). */
function cfp_rpc_get_balance( int $chain_id, string $address ): string|\WP_Error {
    $result = cfp_rpc($chain_id,'eth_getBalance',[$address,'latest']);
    if ( is_wp_error($result) ) return $result;
    $hex = $result['result'] ?? '0x0';
    $wei = base_convert(ltrim($hex,'0x') ?: '0',16,10);
    return cfp_from_wei($wei,18);
}

/** Get current gas price in wei (as integer string). */
function cfp_rpc_gas_price( int $chain_id ): string|\WP_Error {
    $result = cfp_rpc($chain_id,'eth_gasPrice',[]);
    if ( is_wp_error($result) ) return $result;
    $hex = $result['result'] ?? '0x3B9ACA00';
    return base_convert(ltrim($hex,'0x') ?: '3b9aca00',16,10);
}

/** Get pending nonce for an address. */
function cfp_rpc_get_nonce( int $chain_id, string $address ): int|\WP_Error {
    $result = cfp_rpc($chain_id,'eth_getTransactionCount',[$address,'pending']);
    if ( is_wp_error($result) ) return $result;
    return (int) base_convert(ltrim($result['result']??'0x0','0x'),16,10);
}

// ============================================================
// HIGH-LEVEL: SIGN AND BROADCAST
// ============================================================

/**
 * Build, sign, and broadcast an EVM transaction from a given private key.
 *
 * @param int         $chain_id
 * @param string      $private_key_hex  32-byte hex private key (no 0x)
 * @param string      $from             Sender address (0x...)  — must match private key
 * @param string      $to               Destination address (0x...)
 * @param string      $amount           Decimal amount string (e.g. '0.05')
 * @param string|null $contract         ERC-20 contract address, or null for native transfer
 * @param int         $decimals         Token decimals (ignored for native)
 * @return string|\WP_Error             TX hash or error
 */
function cfp_rpc_sign_and_broadcast(
    int $chain_id,
    string $private_key_hex,
    string $from,
    string $to,
    string $amount,
    ?string $contract,
    int $decimals = 18
): string|\WP_Error {

    // Nonce
    $nonce = cfp_rpc_get_nonce($chain_id,$from);
    if ( is_wp_error($nonce) ) return $nonce;

    // Gas price (+10% buffer)
    $gp = cfp_rpc_gas_price($chain_id);
    if ( is_wp_error($gp) ) return $gp;
    $gp = (string) intval( (int)$gp * 1.1 );

    // Build tx fields
    if ( $contract ) {
        $amount_wei = cfp_to_wei($amount,$decimals);
        $data       = cfp_erc20_transfer_data($to,$amount_wei);
        $value      = '0';
        $to_addr    = $contract;
        $gas_limit  = 100000;
    } else {
        $amount_wei = cfp_to_wei($amount,18);
        $data       = '0x';
        $value      = $amount_wei;
        $to_addr    = $to;
        $gas_limit  = 21000;
    }

    $tx = [
        'nonce'     => $nonce,
        'gas_price' => $gp,
        'gas_limit' => $gas_limit,
        'to'        => $to_addr,
        'value'     => $value,
        'data'      => $data,
        'chain_id'  => $chain_id,
    ];

    $signed = cfp_sign_evm_tx($tx,$private_key_hex);
    if ( is_wp_error($signed) ) return $signed;

    return cfp_rpc_broadcast($chain_id,$signed);
}
