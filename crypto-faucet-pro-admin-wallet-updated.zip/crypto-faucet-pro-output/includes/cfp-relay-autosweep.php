<?php
/**
 * Crypto Faucet Pro — Relay Auto-Sweep
 *
 * Hooks into cfp_after_wallet_credit (fired by cfp_wallet_credit() in helpers.php)
 * and triggers an automatic on-chain sweep to the Trezor address whenever the
 * accumulated Admin Wallet balance exceeds the configured threshold.
 *
 * Settings keys (cfp_settings table):
 *   cfp_relay_auto_sweep_enabled    — '1' / '0'
 *   cfp_relay_trezor_address        — Destination Trezor/hardware wallet address
 *   cfp_relay_sweep_chain_id        — EVM chain ID to sweep on (default 1 = Ethereum)
 *   cfp_relay_sweep_threshold_sat   — Min sat balance before sweep fires (default 500000)
 *   cfp_relay_sweep_amount_sat      — Amount to sweep per trigger (0 = sweep full balance)
 *   cfp_relay_sweep_contract        — ERC-20 contract address (blank = native ETH/BNB/etc.)
 *   cfp_relay_sweep_decimals        — Token decimals (default 18)
 *   cfp_relay_sat_per_coin          — How many sat = 1 coin unit (for amount conversion)
 *
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// HOOK INTO WALLET CREDIT
// ============================================================

add_action( 'cfp_after_wallet_credit', 'cfp_relay_maybe_auto_sweep', 10, 2 );

function cfp_relay_maybe_auto_sweep( string $stream, int $amount_sat ): void {
    if ( ! cfp_get_setting('cfp_relay_auto_sweep_enabled','0') ) return;

    // Don't run if the NowPayments sweep is already active — avoid double sweep.
    // The relay only takes over when NowPayments is not configured or its sweep is off.
    if ( cfp_get_setting('trezor_auto_sweep_enabled','1') === '1'
         && function_exists('cfp_np_enabled') && cfp_np_enabled()
         && function_exists('cfp_np_api_key') && cfp_np_api_key() ) return;

    $trezor_addr = cfp_get_setting('cfp_relay_trezor_address','');
    if ( empty($trezor_addr) ) return;

    $chain_id  = (int) cfp_get_setting('cfp_relay_sweep_chain_id','1');
    $threshold = (int) cfp_get_setting('cfp_relay_sweep_threshold_sat','500000');

    // Check current net balance
    $net_balance = cfp_relay_get_net_balance_sat();
    if ( $net_balance < $threshold ) return;

    // Check relay is authorized and has gas
    $auth_check = cfp_relay_check_authorized($chain_id,'0');
    if ( is_wp_error($auth_check) ) {
        error_log('[CFP Relay] Auto-sweep skipped: ' . $auth_check->get_error_message());
        return;
    }
    if ( ! cfp_relay_has_gas($chain_id) ) {
        error_log('[CFP Relay] Auto-sweep skipped: relay address low on gas for chain ' . $chain_id);
        return;
    }

    // Prevent concurrent sweeps within same minute
    $lock_key = 'cfp_relay_sweep_lock';
    if ( get_transient($lock_key) ) return;
    set_transient($lock_key,1,60);

    // Determine amount to sweep
    $sweep_sat  = (int) cfp_get_setting('cfp_relay_sweep_amount_sat','0');
    if ( $sweep_sat <= 0 ) $sweep_sat = $net_balance; // sweep full balance

    // Convert sat to coin units for the on-chain tx
    $sat_per_coin = (int) cfp_get_setting('cfp_relay_sat_per_coin','100000000'); // default 1 BTC = 100M sat
    if ( $sat_per_coin <= 0 ) $sat_per_coin = 100000000;
    $amount_coin = number_format($sweep_sat / $sat_per_coin, 8, '.', '');

    $contract = cfp_get_setting('cfp_relay_sweep_contract','') ?: null;
    $decimals = (int) cfp_get_setting('cfp_relay_sweep_decimals','18');

    $result = cfp_relay_sign_and_send(
        $chain_id,
        $trezor_addr,
        $amount_coin,
        $contract,
        $decimals,
        'auto_sweep',
        'Auto-sweep: ' . number_format($sweep_sat) . ' sat → Trezor. Triggered by stream: ' . $stream
    );

    if ( is_wp_error($result) ) {
        error_log('[CFP Relay] Auto-sweep failed: ' . $result->get_error_message());
        delete_transient($lock_key);
        return;
    }

    // Record the sweep deduction in the admin wallet ledger
    global $wpdb;
    $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
        'stream'      => 'trezor_payout',
        'amount_sat'  => -$sweep_sat,
        'description' => 'Auto-sweep via relay key to Trezor. Chain:'.$chain_id.' TX:'.$result,
        'ref_id'      => null,
    ]);

    // Email alert if enabled
    if ( cfp_get_setting('cfp_relay_email_on_sweep','0') ) {
        $admin_email = get_option('admin_email');
        wp_mail(
            $admin_email,
            '[CFP] Auto-Sweep Completed',
            "A relay auto-sweep has been broadcast.\n\n"
            . "Amount : " . number_format($sweep_sat) . " sat (" . $amount_coin . " coin)\n"
            . "To     : " . $trezor_addr . "\n"
            . "Chain  : " . $chain_id . "\n"
            . "TX Hash: " . $result . "\n\n"
            . "Log in to your admin panel → Relay Settings to view the full transaction log."
        );
    }

    delete_transient($lock_key);
}

// ============================================================
// HELPER: NET BALANCE (total in minus total out from admin wallet)
// ============================================================

function cfp_relay_get_net_balance_sat(): int {
    global $wpdb;
    return (int) $wpdb->get_var(
        "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET
    );
}

// ============================================================
// CRON: PERIODIC SWEEP CHECK (backup if cfp_after_wallet_credit missed)
// ============================================================

add_action('cfp_relay_cron_sweep','cfp_relay_cron_sweep_handler');

add_action('init', function(){
    if ( ! wp_next_scheduled('cfp_relay_cron_sweep') )
        wp_schedule_event(time(),'hourly','cfp_relay_cron_sweep');
});

function cfp_relay_cron_sweep_handler(): void {
    // Re-use the same logic as the credit hook — just trigger with 'cron' stream
    cfp_relay_maybe_auto_sweep('cron_check',0);
}
