<?php
/**
 * Crypto Faucet Pro — Trezor Relay Key System
 *
 * Implements the same meta-tx relay pattern as MFCREX:
 *
 *   • The Trezor hardware wallet is the authoritative owner of all platform funds.
 *   • A server-side relay keypair (AES-256-GCM encrypted) signs every routine
 *     on-chain transaction automatically — no device touch per transaction.
 *   • The Trezor authorises the relay address ONCE via an EIP-712 signed message.
 *   • Relay scope is enforced server-side: per-tx cap, expiry date.
 *   • The relay address holds a small gas float funded by the Trezor.
 *   • When the admin Admin Wallet balance exceeds the configured threshold,
 *     an auto-sweep is triggered to the Trezor address via the relay key.
 *
 * Flow:
 *   1. Admin generates relay keypair (server-side) — only the address is shown.
 *   2. Admin connects Trezor → signs EIP-712 authorization for that relay address.
 *   3. Server stores the authorization + scoped limits.
 *   4. Auto-sweep fires on cfp_after_wallet_credit when threshold is met.
 *   5. Admin tops up relay gas float periodically (shown in UI when low).
 *   6. Trezor can revoke relay at any time via the admin panel.
 *
 * Requires: cfp-crypto-primitives.php, cfp-rpc.php
 *
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// DB — RELAY LOG TABLE
// ============================================================

function cfp_relay_create_log_table(): void {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cfp_relay_log (
        id         bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        chain_id   int(11)    NOT NULL,
        type       varchar(30)NOT NULL DEFAULT 'sweep',
        from_addr  varchar(255)NOT NULL,
        to_addr    varchar(255)NOT NULL,
        amount     varchar(100)NOT NULL,
        contract   varchar(255)DEFAULT NULL,
        tx_hash    varchar(255)DEFAULT NULL,
        note       text        DEFAULT NULL,
        created_at datetime    NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY chain_id (chain_id),
        KEY type (type),
        KEY created_at (created_at)
    ) " . $wpdb->get_charset_collate() . ";" );
    update_option('cfp_relay_log_db_version','1.0.0');
}

add_action('admin_init', function(){
    if ( get_option('cfp_relay_log_db_version') !== '1.0.0' )
        cfp_relay_create_log_table();
});

// ============================================================
// KEYPAIR GENERATION & STORAGE
// ============================================================

/**
 * Generate a fresh secp256k1 relay keypair.
 * Returns ['private_key'=>hex64, 'address'=>'0x...'] or WP_Error.
 * The private key is returned ONCE — caller must encrypt and store immediately.
 */
function cfp_relay_generate_keypair(): array|\WP_Error {
    if ( ! extension_loaded('gmp') )
        return new \WP_Error('no_gmp','PHP GMP extension is required to generate a relay keypair. Enable it in php.ini.');

    $n = gmp_init('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141',16);
    do {
        $pk_bin = random_bytes(32);
        $pk_hex = bin2hex($pk_bin);
        $pk_int = gmp_init($pk_hex,16);
    } while ( gmp_cmp($pk_int,1)<0 || gmp_cmp($pk_int,$n)>=0 );

    $address = cfp_pk_to_eth_address($pk_hex);
    if ( is_wp_error($address) ) return $address;

    return ['private_key'=>$pk_hex,'address'=>$address];
}

/**
 * Save relay keypair for a chain (private key AES-256-GCM encrypted).
 */
function cfp_relay_save_keypair( int $chain_id, string $pk_hex, string $address ): void {
    update_option('cfp_relay_key_'.$chain_id,   cfp_encrypt($pk_hex),   false);
    update_option('cfp_relay_addr_'.$chain_id,  strtolower(sanitize_text_field($address)), false);
}

/**
 * Get decrypted relay private key for a chain. Returns hex64 or null.
 */
function cfp_relay_get_key( int $chain_id ): ?string {
    $enc = get_option('cfp_relay_key_'.$chain_id,'');
    if ( empty($enc) ) return null;
    $key = cfp_decrypt($enc);
    return preg_match('/^[0-9a-fA-F]{64}$/',$key) ? strtolower($key) : null;
}

/**
 * Get the relay Ethereum address for a chain.
 */
function cfp_relay_get_address( int $chain_id ): string {
    return get_option('cfp_relay_addr_'.$chain_id,'');
}

// ============================================================
// TREZOR AUTHORIZATION (EIP-712)
// ============================================================

/**
 * Build the EIP-712 typed-data structure the Trezor must sign to authorize the relay.
 * This is a gasless off-chain signature — no blockchain transaction, no fee.
 */
function cfp_relay_build_auth_typeddata( int $chain_id, string $relay_address, string $max_per_tx, int $expiry ): array {
    $trezor_addr = cfp_get_setting('cfp_relay_trezor_address','');
    $site_name   = get_bloginfo('name');
    return [
        'types' => [
            'EIP712Domain' => [
                ['name'=>'name',              'type'=>'string'],
                ['name'=>'version',           'type'=>'string'],
                ['name'=>'chainId',           'type'=>'uint256'],
                ['name'=>'verifyingContract', 'type'=>'address'],
            ],
            'RelayAuthorization' => [
                ['name'=>'owner',       'type'=>'address'],
                ['name'=>'relay',       'type'=>'address'],
                ['name'=>'maxPerTx',    'type'=>'uint256'],
                ['name'=>'expiry',      'type'=>'uint256'],
                ['name'=>'description', 'type'=>'string'],
            ],
        ],
        'primaryType' => 'RelayAuthorization',
        'domain' => [
            'name'              => $site_name . ' CFP Relay',
            'version'           => '1',
            'chainId'           => $chain_id,
            'verifyingContract' => '0x0000000000000000000000000000000000000000',
        ],
        'message' => [
            'owner'       => $trezor_addr,
            'relay'       => $relay_address,
            'maxPerTx'    => $max_per_tx,
            'expiry'      => $expiry,
            'description' => 'Authorize relay address to execute fee sweeps on behalf of the Trezor owner within the stated limits. Revoke by signing a new authorization with expiry in the past.',
        ],
    ];
}

/**
 * Save a Trezor-signed relay authorization.
 */
function cfp_relay_save_authorization( int $chain_id, string $signature, string $relay_address, string $max_per_tx, int $expiry ): void {
    $auths = get_option('cfp_relay_authorizations',[]);
    if ( ! is_array($auths) ) $auths = [];
    $auths[$chain_id] = [
        'signature'     => sanitize_text_field($signature),
        'relay_address' => strtolower(sanitize_text_field($relay_address)),
        'max_per_tx'    => sanitize_text_field($max_per_tx),
        'expiry'        => absint($expiry),
        'granted_at'    => time(),
        'chain_id'      => absint($chain_id),
    ];
    update_option('cfp_relay_authorizations',$auths);
}

/**
 * Get relay authorization for a chain. Returns array or null if missing/expired.
 */
function cfp_relay_get_authorization( int $chain_id ): ?array {
    $auths = get_option('cfp_relay_authorizations',[]);
    if ( empty($auths[$chain_id]) ) return null;
    $auth = $auths[$chain_id];
    if ( ! empty($auth['expiry']) && $auth['expiry'] < time() ) return null;
    return $auth;
}

/**
 * Check relay is authorized for a chain and the given amount.
 * Returns true or WP_Error.
 */
function cfp_relay_check_authorized( int $chain_id, string $amount ): bool|\WP_Error {
    $key  = cfp_relay_get_key($chain_id);
    $auth = cfp_relay_get_authorization($chain_id);

    if ( ! $key )
        return new \WP_Error('no_relay_key',
            'No relay key configured for chain '.$chain_id.'. Go to Admin → Relay Settings and generate one.');

    if ( ! $auth )
        return new \WP_Error('not_authorized',
            'Relay not authorized by Trezor for chain '.$chain_id.'. Connect your Trezor and sign the authorization.');

    if ( ! empty($auth['expiry']) && $auth['expiry'] < time() )
        return new \WP_Error('authorization_expired',
            'Relay authorization expired for chain '.$chain_id.'. Re-authorize in Admin → Relay Settings.');

    $max = $auth['max_per_tx'] ?? '0';
    if ( bccomp($max,'0',8)>0 && bccomp((string)$amount,$max,8)>0 )
        return new \WP_Error('exceeds_max',
            sprintf('Amount %s exceeds relay max-per-tx cap of %s. Increase the cap or split the transaction.',$amount,$max));

    return true;
}

// ============================================================
// RELAY BROADCAST — PRIMARY AUTO-SIGNING PATH
// ============================================================

/**
 * Sign and broadcast an on-chain transaction using the relay key.
 *
 * @param int         $chain_id
 * @param string      $to          Destination address (0x...)
 * @param string      $amount      Decimal amount (e.g. '0.05000000')
 * @param string|null $contract    ERC-20 contract address or null for native
 * @param int         $decimals    Token decimals
 * @param string      $type        Log type: 'sweep'|'withdrawal'|'gas_topup'
 * @param string      $note        Human-readable log note
 * @return string|\WP_Error        TX hash or error
 */
function cfp_relay_sign_and_send(
    int $chain_id,
    string $to,
    string $amount,
    ?string $contract,
    int $decimals,
    string $type = 'sweep',
    string $note = ''
): string|\WP_Error {

    $check = cfp_relay_check_authorized($chain_id,$amount);
    if ( is_wp_error($check) ) return $check;

    $relay_key  = cfp_relay_get_key($chain_id);
    $relay_addr = cfp_relay_get_address($chain_id);

    if ( ! $relay_key )  return new \WP_Error('no_relay_key','Relay key not found for chain '.$chain_id);
    if ( ! $relay_addr ) return new \WP_Error('no_relay_addr','Relay address not found for chain '.$chain_id);

    $result = cfp_rpc_sign_and_broadcast($chain_id,$relay_key,$relay_addr,$to,$amount,$contract,$decimals);
    if ( is_wp_error($result) ) return $result;

    cfp_relay_log_tx($chain_id,$type,$relay_addr,$to,$amount,$contract,$result,$note);
    return $result;
}

// ============================================================
// GAS BALANCE
// ============================================================

/** Get relay gas balance (decimal string) or WP_Error. */
function cfp_relay_get_gas_balance( int $chain_id ): string|\WP_Error {
    $addr = cfp_relay_get_address($chain_id);
    if ( empty($addr) )
        return new \WP_Error('no_addr','Relay address not configured for chain '.$chain_id);
    return cfp_rpc_get_balance($chain_id,$addr);
}

/** Returns true if relay gas balance ≥ 0.005 native coin. */
function cfp_relay_has_gas( int $chain_id ): bool {
    $bal = cfp_relay_get_gas_balance($chain_id);
    if ( is_wp_error($bal) ) return false;
    return bccomp($bal,'0.005',8) >= 0;
}

// ============================================================
// TRANSACTION LOG
// ============================================================

function cfp_relay_log_tx(
    int $chain_id,
    string $type,
    string $from,
    string $to,
    string $amount,
    ?string $contract,
    string $tx_hash,
    string $note = ''
): void {
    global $wpdb;
    if ( get_option('cfp_relay_log_db_version') !== '1.0.0' )
        cfp_relay_create_log_table();
    $wpdb->insert(
        $wpdb->prefix.'cfp_relay_log',
        [
            'chain_id'  => absint($chain_id),
            'type'      => sanitize_text_field($type),
            'from_addr' => strtolower(sanitize_text_field($from)),
            'to_addr'   => strtolower(sanitize_text_field($to)),
            'amount'    => sanitize_text_field($amount),
            'contract'  => $contract ? strtolower(sanitize_text_field($contract)) : null,
            'tx_hash'   => sanitize_text_field($tx_hash),
            'note'      => sanitize_text_field($note),
        ],
        ['%d','%s','%s','%s','%s','%s','%s','%s']
    );
}

// ============================================================
// AJAX: GENERATE RELAY KEYPAIR
// ============================================================

add_action('wp_ajax_cfp_relay_generate','cfp_ajax_relay_generate');
function cfp_ajax_relay_generate(): void {
    if ( ! current_user_can('manage_options') ) wp_send_json_error('Permission denied.');
    if ( ! check_ajax_referer('cfp_relay_nonce','nonce',false) ) wp_send_json_error('Nonce failed.');

    $chain_id = absint($_POST['chain_id'] ?? 1);
    $pair     = cfp_relay_generate_keypair();
    if ( is_wp_error($pair) ) wp_send_json_error($pair->get_error_message());

    cfp_relay_save_keypair($chain_id,$pair['private_key'],$pair['address']);

    wp_send_json_success([
        'address'  => $pair['address'],
        'chain_id' => $chain_id,
        'message'  => 'Relay keypair generated and saved. Fund this address with gas, then authorize it with your Trezor below.',
    ]);
}

// ============================================================
// AJAX: GET EIP-712 TYPED DATA (for Trezor to sign)
// ============================================================

add_action('wp_ajax_cfp_relay_get_auth_data','cfp_ajax_relay_get_auth_data');
function cfp_ajax_relay_get_auth_data(): void {
    if ( ! current_user_can('manage_options') ) wp_send_json_error('Permission denied.');
    if ( ! check_ajax_referer('cfp_relay_nonce','nonce',false) ) wp_send_json_error('Nonce failed.');

    $chain_id   = absint($_POST['chain_id'] ?? 1);
    $max_per_tx = sanitize_text_field($_POST['max_per_tx'] ?? '1');
    $days       = absint($_POST['expiry_days'] ?? 30);
    $expiry     = time() + ($days * 86400);

    $relay_addr = cfp_relay_get_address($chain_id);
    if ( empty($relay_addr) )
        wp_send_json_error('No relay address for chain '.$chain_id.'. Generate a relay keypair first.');

    $typed_data = cfp_relay_build_auth_typeddata($chain_id,$relay_addr,$max_per_tx,$expiry);
    wp_send_json_success([
        'typed_data'    => $typed_data,
        'relay_address' => $relay_addr,
        'expiry'        => $expiry,
        'expiry_human'  => gmdate('Y-m-d H:i',$expiry),
        'max_per_tx'    => $max_per_tx,
        'chain_id'      => $chain_id,
    ]);
}

// ============================================================
// AJAX: SAVE TREZOR AUTHORIZATION SIGNATURE
// ============================================================

add_action('wp_ajax_cfp_relay_save_auth','cfp_ajax_relay_save_auth');
function cfp_ajax_relay_save_auth(): void {
    if ( ! current_user_can('manage_options') ) wp_send_json_error('Permission denied.');
    if ( ! check_ajax_referer('cfp_relay_nonce','nonce',false) ) wp_send_json_error('Nonce failed.');

    $chain_id      = absint($_POST['chain_id'] ?? 1);
    $signature     = sanitize_text_field(wp_unslash($_POST['signature'] ?? ''));
    $relay_address = sanitize_text_field(wp_unslash($_POST['relay_address'] ?? ''));
    $max_per_tx    = sanitize_text_field(wp_unslash($_POST['max_per_tx'] ?? '1'));
    $expiry        = absint($_POST['expiry'] ?? 0);
    $trezor_addr   = strtolower(sanitize_text_field(wp_unslash($_POST['trezor_address'] ?? '')));

    if ( ! $signature || ! $relay_address || ! $expiry )
        wp_send_json_error('Missing required fields: signature, relay_address, expiry.');

    $expected = strtolower(cfp_get_setting('cfp_relay_trezor_address',''));
    if ( $trezor_addr && $expected && $trezor_addr !== $expected )
        wp_send_json_error('Signature is from '.$trezor_addr.' but expected Trezor address is '.$expected.'. Connect the correct Trezor account.');

    cfp_relay_save_authorization($chain_id,$signature,$relay_address,$max_per_tx,$expiry);

    wp_send_json_success([
        'message'  => 'Relay authorization saved. Auto-sweep is now active for chain '.$chain_id.'.',
        'chain_id' => $chain_id,
        'relay'    => $relay_address,
        'expires'  => gmdate('Y-m-d H:i',$expiry),
    ]);
}

// ============================================================
// AJAX: REVOKE RELAY AUTHORIZATION
// ============================================================

add_action('wp_ajax_cfp_relay_revoke','cfp_ajax_relay_revoke');
function cfp_ajax_relay_revoke(): void {
    if ( ! current_user_can('manage_options') ) wp_send_json_error('Permission denied.');
    if ( ! check_ajax_referer('cfp_relay_nonce','nonce',false) ) wp_send_json_error('Nonce failed.');

    $chain_id = absint($_POST['chain_id'] ?? 0);
    $auths    = get_option('cfp_relay_authorizations',[]);
    if ( ! is_array($auths) ) $auths = [];

    if ($chain_id) { unset($auths[$chain_id]); }
    else           { $auths = []; }

    update_option('cfp_relay_authorizations',$auths);
    wp_send_json_success('Relay authorization revoked. No further auto-sweeps until re-authorized.');
}

// ============================================================
// AJAX: RELAY STATUS (all chains)
// ============================================================

add_action('wp_ajax_cfp_relay_status','cfp_ajax_relay_status');
function cfp_ajax_relay_status(): void {
    if ( ! current_user_can('manage_options') ) wp_send_json_error('Permission denied.');
    if ( ! check_ajax_referer('cfp_relay_nonce','nonce',false) ) wp_send_json_error('Nonce failed.');

    $status = [];
    foreach ( cfp_evm_networks() as $cid => $net ) {
        $relay_addr = cfp_relay_get_address($cid);
        $auth       = cfp_relay_get_authorization($cid);
        $gas_bal    = $relay_addr ? cfp_relay_get_gas_balance($cid) : null;

        $status[$cid] = [
            'chain_id'      => $cid,
            'chain_name'    => $net['name'],
            'symbol'        => $net['symbol'],
            'relay_address' => $relay_addr,
            'has_key'       => ! empty(cfp_relay_get_key($cid)),
            'authorized'    => ! empty($auth),
            'expiry'        => $auth ? $auth['expiry'] : null,
            'expiry_human'  => $auth ? gmdate('Y-m-d',$auth['expiry']) : null,
            'max_per_tx'    => $auth ? $auth['max_per_tx'] : null,
            'gas_balance'   => is_wp_error($gas_bal) ? null : $gas_bal,
            'gas_ok'        => $relay_addr ? cfp_relay_has_gas($cid) : false,
        ];
    }
    wp_send_json_success($status);
}

// ============================================================
// AJAX: MANUAL ON-DEMAND SWEEP
// ============================================================

add_action('wp_ajax_cfp_relay_manual_sweep','cfp_ajax_relay_manual_sweep');
function cfp_ajax_relay_manual_sweep(): void {
    if ( ! current_user_can('manage_options') ) wp_send_json_error('Permission denied.');
    if ( ! check_ajax_referer('cfp_relay_nonce','nonce',false) ) wp_send_json_error('Nonce failed.');

    $chain_id   = absint($_POST['chain_id'] ?? 1);
    $amount     = sanitize_text_field($_POST['amount'] ?? '0');
    $to         = sanitize_text_field(wp_unslash($_POST['to_address'] ?? ''));
    $contract   = sanitize_text_field(wp_unslash($_POST['contract'] ?? '')) ?: null;
    $decimals   = absint($_POST['decimals'] ?? 18);
    $note       = sanitize_text_field(wp_unslash($_POST['note'] ?? 'Manual admin sweep'));

    if ( bccomp($amount,'0',8) <= 0 ) wp_send_json_error('Amount must be greater than 0.');
    if ( empty($to) ) wp_send_json_error('Destination address is required.');

    $result = cfp_relay_sign_and_send($chain_id,$to,$amount,$contract,$decimals,'manual_sweep',$note);
    if ( is_wp_error($result) ) wp_send_json_error($result->get_error_message());

    wp_send_json_success([
        'message'  => '✅ Swept '.$amount.' to '.$to.'. TX: '.$result,
        'tx_hash'  => $result,
        'chain_id' => $chain_id,
    ]);
}
