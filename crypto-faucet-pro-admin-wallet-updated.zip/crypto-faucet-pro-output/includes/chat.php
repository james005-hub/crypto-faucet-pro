<?php
/**
 * Live Chat — real-time chat widget using long-polling.
 * Includes: tip other users, rain (split sat to active chatters).
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// Send message
add_action('wp_ajax_cfp_chat_send',        'cfp_ajax_chat_send');
add_action('wp_ajax_nopriv_cfp_chat_send', 'cfp_ajax_chat_send');
function cfp_ajax_chat_send() {
    check_ajax_referer('cfp_nonce','nonce');
    if ( ! cfp_get_setting('chat_enabled','1') ) wp_send_json_error(['msg'=>'Chat is disabled.']);
    $email   = sanitize_email($_POST['email'] ?? '');
    $message = sanitize_text_field(substr($_POST['message'] ?? '', 0, 300));
    if ( empty($message) ) wp_send_json_error(['msg'=>'Empty message.']);
    $user = cfp_get_user_by_email($email);
    if (!$user) wp_send_json_error(['msg'=>'Account not found.']);
    if ($user->is_banned) wp_send_json_error(['msg'=>'Account suspended.']);
    cfp_ip_gate('chat', intval(cfp_get_setting('ip_limit_chat',30)), 60);
    global $wpdb;
    $level_data = cfp_xp_levels();
    $level      = $user->xp_level ?: 1;
    $icon       = $level_data[$level]['icon'] ?? '🌱';
    $wpdb->insert(CFP_TABLE_CHAT, ['user_id'=>$user->id,'username'=>$user->username,'message'=>$message]);
    wp_send_json_success(['msg'=>'sent','id'=>$wpdb->insert_id]);
}

// Poll messages
add_action('wp_ajax_cfp_chat_poll',        'cfp_ajax_chat_poll');
add_action('wp_ajax_nopriv_cfp_chat_poll', 'cfp_ajax_chat_poll');
function cfp_ajax_chat_poll() {
    check_ajax_referer('cfp_nonce','nonce');
    $after = intval($_POST['after'] ?? 0);
    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT c.id, c.username, c.message, c.tip_amount, c.is_rain, c.created_at,
                u.xp_level
         FROM ".CFP_TABLE_CHAT." c
         LEFT JOIN ".CFP_TABLE_USERS." u ON c.user_id=u.id
         WHERE c.id > %d
         ORDER BY c.id ASC LIMIT 30",
        $after
    ));
    $levels = cfp_xp_levels();
    $msgs   = array_map(function($r) use ($levels) {
        $lvl  = $r->xp_level ?: 1;
        $icon = $levels[$lvl]['icon'] ?? '🌱';
        return [
            'id'       => $r->id,
            'username' => esc_html($r->username),
            'message'  => esc_html($r->message),
            'tip'      => intval($r->tip_amount),
            'is_rain'  => (bool)$r->is_rain,
            'icon'     => $icon,
            'time'     => date('H:i', strtotime($r->created_at)),
        ];
    }, $rows);
    wp_send_json_success(['messages'=>$msgs]);
}

// Tip user
add_action('wp_ajax_cfp_chat_tip',        'cfp_ajax_chat_tip');
add_action('wp_ajax_nopriv_cfp_chat_tip', 'cfp_ajax_chat_tip');
function cfp_ajax_chat_tip() {
    check_ajax_referer('cfp_nonce','nonce');
    $from_email = sanitize_email($_POST['email'] ?? '');
    $to_user    = sanitize_text_field($_POST['to_username'] ?? '');
    $amount     = intval($_POST['amount'] ?? 0);
    if ($amount < intval(cfp_get_setting('chat_min_tip',100))) wp_send_json_error(['msg'=>'Minimum tip is '.cfp_get_setting('chat_min_tip',100).' sat.']);
    global $wpdb;
    $from = cfp_get_user_by_email($from_email);
    if (!$from) wp_send_json_error(['msg'=>'Account not found.']);
    if ($from->balance_sat < $amount) wp_send_json_error(['msg'=>'Insufficient balance.']);
    $to = $wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_USERS." WHERE username=%s",$to_user));
    if (!$to) wp_send_json_error(['msg'=>'User not found.']);
    if ($to->id === $from->id) wp_send_json_error(['msg'=>"You can't tip yourself."]);
    $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d",$amount,$from->id));
    $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$amount,$to->id));
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$from->id,'type'=>'tip_sent','amount_sat'=>-$amount,'description'=>"Tip to {$to->username}"]);
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$to->id,'type'=>'tip_received','amount_sat'=>$amount,'description'=>"Tip from {$from->username}"]);
    $wpdb->insert(CFP_TABLE_CHAT,['user_id'=>$from->id,'username'=>$from->username,'message'=>"🎁 Tipped {$amount} sat to @{$to->username}!",'tip_amount'=>$amount]);
    cfp_xp_award($from->id, 5, 'tip_sent');
    wp_send_json_success(['msg'=>"✅ Tipped {$amount} sat to {$to->username}!"]);
}

// Rain — split sat among recent chatters
add_action('wp_ajax_cfp_chat_rain',        'cfp_ajax_chat_rain');
add_action('wp_ajax_nopriv_cfp_chat_rain', 'cfp_ajax_chat_rain');
function cfp_ajax_chat_rain() {
    check_ajax_referer('cfp_nonce','nonce');
    $email  = sanitize_email($_POST['email'] ?? '');
    $amount = intval($_POST['amount'] ?? 0);
    $min_rain = intval(cfp_get_setting('chat_min_rain', 1000));
    if ($amount < $min_rain) wp_send_json_error(['msg'=>"Minimum rain is {$min_rain} sat."]);
    global $wpdb;
    $from = cfp_get_user_by_email($email);
    if (!$from) wp_send_json_error(['msg'=>'Account not found.']);
    if ($from->balance_sat < $amount) wp_send_json_error(['msg'=>'Insufficient balance.']);
    // Get unique chatters in last 10 minutes (excluding sender)
    $chatters = $wpdb->get_col($wpdb->prepare(
        "SELECT DISTINCT user_id FROM ".CFP_TABLE_CHAT." WHERE created_at > DATE_SUB(NOW(), INTERVAL 10 MINUTE) AND user_id != %d LIMIT 20",
        $from->id
    ));
    if (empty($chatters)) wp_send_json_error(['msg'=>'No active chatters right now. Try later!']);
    $per   = (int)floor($amount / count($chatters));
    if ($per < 1) wp_send_json_error(['msg'=>'Amount too small to split.']);
    $actual = $per * count($chatters);
    $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d",$actual,$from->id));
    $usernames = [];
    foreach ($chatters as $uid) {
        $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$per,$uid));
        $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$uid,'type'=>'rain_received','amount_sat'=>$per,'description'=>"Rain from {$from->username}"]);
        $uname = $wpdb->get_var($wpdb->prepare("SELECT username FROM ".CFP_TABLE_USERS." WHERE id=%d",$uid));
        if ($uname) $usernames[] = $uname;
    }
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$from->id,'type'=>'rain_sent','amount_sat'=>-$actual,'description'=>"Rain: {$actual} sat to ".count($chatters)." users"]);
    $wpdb->insert(CFP_TABLE_CHAT,['user_id'=>$from->id,'username'=>$from->username,
        'message'=>"🌧️ It's raining! {$from->username} rained {$actual} sat on ".count($chatters)." chatters ({$per} sat each)!",'is_rain'=>1,'tip_amount'=>$actual]);
    cfp_xp_award($from->id, 20, 'rain');
    wp_send_json_success(['msg'=>"🌧️ Rained {$actual} sat on ".count($chatters)." people!",'count'=>count($chatters),'per'=>$per]);
}

/* ============================================================
   SHORTCODE: [cfp_chat]
   ============================================================ */
add_shortcode('cfp_chat', function() {
    if (!cfp_get_setting('chat_enabled','1')) return '<p style="color:#555">Chat is currently disabled.</p>';
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-chat-widget" style="max-width:600px">
        <h2>💬 Live Chat</h2>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px">
            <input class="cfp-input" type="email" id="cfp-chat-email" placeholder="Account email" style="margin-bottom:0">
            <input class="cfp-input" type="text" id="cfp-chat-user" placeholder="Your username (auto-loaded)" readonly style="margin-bottom:0;opacity:.5">
        </div>
        <div id="cfp-chat-log" style="background:#060606;border:1px solid #1a1a1a;border-radius:10px;padding:12px;height:320px;overflow-y:auto;margin-bottom:10px;font-size:.82rem"></div>
        <div style="display:flex;gap:8px;margin-bottom:8px">
            <input class="cfp-input" type="text" id="cfp-chat-msg" placeholder="Say something…" style="margin-bottom:0;flex:1" onkeydown="if(event.key==='Enter')cfpChatSend()">
            <button class="cfp-btn-full" onclick="cfpChatSend()" style="width:auto;padding:10px 18px">Send</button>
        </div>
        <div style="display:flex;gap:6px">
            <div style="flex:1">
                <input class="cfp-input" type="text" id="cfp-tip-user" placeholder="Tip username" style="margin-bottom:4px">
                <div style="display:flex;gap:4px">
                    <input class="cfp-input" type="number" id="cfp-tip-amt" placeholder="Sat" style="margin-bottom:0">
                    <button onclick="cfpChatTip()" style="background:#f7931a;color:#000;border:none;padding:8px 12px;border-radius:8px;cursor:pointer;font-weight:700;white-space:nowrap;font-size:.8rem">💰 Tip</button>
                </div>
            </div>
            <div style="flex:1">
                <div style="font-size:.7rem;color:#555;margin-bottom:4px;text-transform:uppercase;letter-spacing:1px">🌧️ Rain (split to chatters)</div>
                <div style="display:flex;gap:4px">
                    <input class="cfp-input" type="number" id="cfp-rain-amt" placeholder="Sat" style="margin-bottom:0">
                    <button onclick="cfpChatRain()" style="background:#3b82f6;color:#fff;border:none;padding:8px 12px;border-radius:8px;cursor:pointer;font-weight:700;white-space:nowrap;font-size:.8rem">🌧️ Rain</button>
                </div>
            </div>
        </div>
        <div id="cfp-chat-msg-out" style="margin-top:8px"></div>
    </div>
    <script>
    let cfpChatLastId=0; const cfpChatAjax='<?=esc_js($ajax)?>'; const cfpChatNonce='<?=esc_js($nonce)?>';
    function cfpChatMsg(m,t='success'){const d=document.getElementById('cfp-chat-msg-out');d.textContent='';d.appendChild(Object.assign(document.createElement('div'),{className:'cfp-msg '+t,textContent:m}));}
    async function cfpChatSend(){
        const email=document.getElementById('cfp-chat-email').value;
        const msg=document.getElementById('cfp-chat-msg').value;
        if(!msg.trim()) return;
        const fd=new FormData(); fd.append('action','cfp_chat_send'); fd.append('nonce',cfpChatNonce); fd.append('email',email); fd.append('message',msg);
        const r=await fetch(cfpChatAjax,{method:'POST',body:fd}); const d=await r.json();
        if(d.success) {document.getElementById('cfp-chat-msg').value='';}
        else cfpChatMsg(d.data.msg||'Error','error');
    }
    async function cfpChatPoll(){
        const fd=new FormData(); fd.append('action','cfp_chat_poll'); fd.append('nonce',cfpChatNonce); fd.append('after',cfpChatLastId);
        try{
            const r=await fetch(cfpChatAjax,{method:'POST',body:fd}); const d=await r.json();
            if(d.success && d.data.messages.length){
                const log=document.getElementById('cfp-chat-log');
                d.data.messages.forEach(m=>{
                    const isRain=m.is_rain;
                    const bg=isRain?'rgba(59,130,246,.08)':'transparent';
                    const div=document.createElement('div');
                    div.style.cssText='padding:3px 0;border-bottom:1px solid #0d0d0d;background:'+bg;
                    const ts=document.createElement('span');ts.style.cssText='color:#555;font-size:.72rem';ts.textContent='['+m.time+'] ';
                    const ic=document.createElement('span');ic.style.cssText='font-size:.8rem';ic.textContent=m.icon;
                    const nm=document.createElement('strong');nm.style.cssText='font-size:.82rem;color:'+(isRain?'#3b82f6':'#f7931a');nm.textContent=m.username;
                    const msg=document.createElement('span');msg.style.cssText='color:#aaa';msg.textContent=': '+m.message;
                    div.appendChild(ts);div.appendChild(ic);div.appendChild(nm);div.appendChild(msg);
                    log.appendChild(div);
                    cfpChatLastId=Math.max(cfpChatLastId,m.id);
                });
                log.scrollTop=log.scrollHeight;
            }
        }catch(e){}
        setTimeout(cfpChatPoll, 4000);
    }
    async function cfpChatTip(){
        const email=document.getElementById('cfp-chat-email').value;
        const toU=document.getElementById('cfp-tip-user').value;
        const amt=document.getElementById('cfp-tip-amt').value;
        const fd=new FormData(); fd.append('action','cfp_chat_tip'); fd.append('nonce',cfpChatNonce); fd.append('email',email); fd.append('to_username',toU); fd.append('amount',amt);
        const r=await fetch(cfpChatAjax,{method:'POST',body:fd}); const d=await r.json();
        cfpChatMsg(d.data.msg,d.success?'success':'error');
    }
    async function cfpChatRain(){
        const email=document.getElementById('cfp-chat-email').value;
        const amt=document.getElementById('cfp-rain-amt').value;
        const fd=new FormData(); fd.append('action','cfp_chat_rain'); fd.append('nonce',cfpChatNonce); fd.append('email',email); fd.append('amount',amt);
        const r=await fetch(cfpChatAjax,{method:'POST',body:fd}); const d=await r.json();
        cfpChatMsg(d.data.msg,d.success?'success':'error');
    }
    cfpChatPoll();
    </script>
    <?php return ob_get_clean();
});
