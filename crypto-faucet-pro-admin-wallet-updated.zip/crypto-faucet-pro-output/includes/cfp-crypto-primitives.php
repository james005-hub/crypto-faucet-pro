<?php
/**
 * Crypto Faucet Pro — Crypto Primitives
 *
 * Pure-PHP implementations of:
 *   - AES-256-GCM encryption / decryption (PBKDF2 key derivation)
 *   - Keccak-256 hashing
 *   - secp256k1 scalar multiplication, ECDSA signing (RFC6979 deterministic k)
 *   - RLP encoding helpers
 *   - EVM transaction builder (legacy type-0, EIP-155)
 *   - ERC-20 calldata builder
 *   - Wei conversion helpers
 *
 * All functions prefixed cfp_ to avoid collisions.
 * Requires PHP 8.0+, openssl, gmp extensions.
 *
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// AES-256-GCM ENCRYPTION (key stored via WordPress options)
// ============================================================

/**
 * Derive a 256-bit AES key from WordPress salts + server entropy + stored PBKDF2 salt.
 */
function cfp_get_encryption_key(): string {
    $base  = AUTH_KEY . SECURE_AUTH_KEY . LOGGED_IN_KEY . NONCE_KEY;
    if ( defined( 'DB_NAME' ) )  $base .= DB_NAME;
    if ( defined( 'DB_USER' ) )  $base .= DB_USER;
    if ( isset( $_SERVER['SERVER_ADDR'] ) ) $base .= sanitize_text_field( wp_unslash( $_SERVER['SERVER_ADDR'] ) );
    if ( isset( $_SERVER['SERVER_NAME'] ) ) $base .= sanitize_text_field( wp_unslash( $_SERVER['SERVER_NAME'] ) );

    $salt = get_option( 'cfp_relay_encryption_salt' );
    if ( ! $salt ) {
        $salt = bin2hex( random_bytes( 32 ) );
        update_option( 'cfp_relay_encryption_salt', $salt, false );
    }

    return hash_pbkdf2( 'sha256', $base, $salt, 100000, 32, true );
}

/**
 * Encrypt a string with AES-256-GCM. Returns base64(iv[12] + tag[16] + ciphertext).
 */
function cfp_encrypt( string $data ): string {
    if ( $data === '' ) return '';
    $key = cfp_get_encryption_key();
    $iv  = random_bytes( 12 );
    $tag = '';
    $enc = openssl_encrypt( $data, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
    if ( $enc === false ) return '';
    return base64_encode( $iv . $tag . $enc );
}

/**
 * Decrypt a string produced by cfp_encrypt(). Returns plaintext or ''.
 */
function cfp_decrypt( string $data ): string {
    if ( $data === '' ) return '';
    $raw = base64_decode( $data );
    if ( $raw === false || strlen( $raw ) < 29 ) return '';
    $key        = cfp_get_encryption_key();
    $iv         = substr( $raw, 0, 12 );
    $tag        = substr( $raw, 12, 16 );
    $ciphertext = substr( $raw, 28 );
    $dec        = openssl_decrypt( $ciphertext, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
    return ( $dec !== false ) ? $dec : '';
}

// ============================================================
// PURE-PHP KECCAK-256
// ============================================================

/**
 * Compute Keccak-256 of binary string. Returns 32-byte binary.
 * (MIT-licensed implementation derived from kornrunner/php-keccak)
 */
function cfp_keccak256( string $data ): string {
    $RC = [
        [0x00000001,0x00000000],[0x00008082,0x00000000],[0x0000808A,0x80000000],[0x80008000,0x80000000],
        [0x0000808B,0x00000000],[0x80000001,0x00000000],[0x80008081,0x80000000],[0x00008009,0x80000000],
        [0x0000008A,0x00000000],[0x00000088,0x00000000],[0x80008009,0x00000000],[0x8000000A,0x00000000],
        [0x8000808B,0x00000000],[0x0000008B,0x80000000],[0x00008089,0x80000000],[0x00008003,0x80000000],
        [0x00008002,0x80000000],[0x00000080,0x80000000],[0x0000800A,0x00000000],[0x8000000A,0x80000000],
        [0x80008081,0x80000000],[0x00008080,0x80000000],[0x80000001,0x00000000],[0x80008008,0x80000000],
    ];
    $rate  = 136;
    $msg   = $data . "\x01";
    $pad   = $rate - ( strlen( $msg ) % $rate );
    $msg  .= str_repeat( "\x00", $pad - 1 ) . "\x80";
    $state = array_fill( 0, 25, [0, 0] );

    for ( $i = 0; $i < strlen( $msg ); $i += $rate ) {
        $block = substr( $msg, $i, $rate );
        for ( $j = 0; $j < $rate / 8; $j++ ) {
            $l = unpack( 'V2', substr( $block, $j * 8, 8 ) );
            $state[$j][0] ^= $l[1];
            $state[$j][1] ^= $l[2];
        }
        for ( $r = 0; $r < 24; $r++ ) {
            $C = [];
            for ( $x = 0; $x < 5; $x++ )
                $C[$x] = [
                    $state[$x][0]^$state[$x+5][0]^$state[$x+10][0]^$state[$x+15][0]^$state[$x+20][0],
                    $state[$x][1]^$state[$x+5][1]^$state[$x+10][1]^$state[$x+15][1]^$state[$x+20][1],
                ];
            $D = [];
            for ( $x = 0; $x < 5; $x++ ) {
                $rx   = ($x+1)%5; $lx = ($x+4)%5;
                $rot1 = cfp_keccak_rot64( $C[$rx][0], $C[$rx][1], 1 );
                $D[$x] = [ $C[$lx][0]^$rot1[0], $C[$lx][1]^$rot1[1] ];
            }
            for ( $x = 0; $x < 5; $x++ )
                for ( $y = 0; $y < 5; $y++ ) {
                    $idx = $x + 5*$y;
                    $state[$idx][0] ^= $D[$x][0];
                    $state[$idx][1] ^= $D[$x][1];
                }
            $B = array_fill( 0, 25, [0,0] );
            $rotations = [[0,1,62,28,27],[36,44,6,55,20],[3,10,43,25,39],[41,45,15,21,8],[18,2,61,56,14]];
            for ( $x = 0; $x < 5; $x++ )
                for ( $y = 0; $y < 5; $y++ ) {
                    $r2  = $rotations[$y][$x];
                    $rot = cfp_keccak_rot64( $state[$x+5*$y][0], $state[$x+5*$y][1], $r2 );
                    $B[$y+5*(($x+3*$y+1)%5)] = $rot;
                }
            $A = [];
            for ( $x = 0; $x < 5; $x++ )
                for ( $y = 0; $y < 5; $y++ ) {
                    $idx = $x+5*$y;
                    $A[$idx] = [
                        $B[$idx][0] ^ ( (~$B[($x+1)%5+5*$y][0]) & $B[($x+2)%5+5*$y][0] ),
                        $B[$idx][1] ^ ( (~$B[($x+1)%5+5*$y][1]) & $B[($x+2)%5+5*$y][1] ),
                    ];
                }
            $A[0][0] ^= $RC[$r][0];
            $A[0][1] ^= $RC[$r][1];
            $state = $A;
        }
    }
    $hash = '';
    for ( $i = 0; $i < 4; $i++ ) $hash .= pack( 'V2', $state[$i][0], $state[$i][1] );
    return $hash;
}

function cfp_keccak_rot64( int $lo, int $hi, int $n ): array {
    if ( $n < 32 ) {
        $newlo = ($lo<<$n) | (($hi>>(32-$n)) & ((1<<$n)-1));
        $newhi = ($hi<<$n) | (($lo>>(32-$n)) & ((1<<$n)-1));
    } else {
        $n -= 32;
        $newlo = ($hi<<$n) | (($lo>>(32-$n)) & ((1<<$n)-1));
        $newhi = ($lo<<$n) | (($hi>>(32-$n)) & ((1<<$n)-1));
    }
    return [ $newlo & 0xFFFFFFFF, $newhi & 0xFFFFFFFF ];
}

// ============================================================
// secp256k1 ECDSA SIGNING (GMP)
// ============================================================

/** Derive Ethereum address from 32-byte hex private key. */
function cfp_pk_to_eth_address( string $pk_hex ): string|\WP_Error {
    if ( ! extension_loaded('gmp') ) return new \WP_Error('no_gmp','PHP GMP extension required.');
    $p  = gmp_init('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F',16);
    $n  = gmp_init('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141',16);
    $Gx = gmp_init('79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798',16);
    $Gy = gmp_init('483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8',16);
    $pk = gmp_init( $pk_hex, 16 );
    $pub = cfp_secp256k1_mul( [$Gx,$Gy], $pk, $p, $n );
    $x_hex  = str_pad( gmp_strval($pub[0],16), 64, '0', STR_PAD_LEFT );
    $y_hex  = str_pad( gmp_strval($pub[1],16), 64, '0', STR_PAD_LEFT );
    $hash   = cfp_keccak256( hex2bin($x_hex.$y_hex) );
    return '0x' . substr( bin2hex($hash), 24 );
}

/** secp256k1 ECDSA sign — returns ['r'=>hex,'s'=>hex,'v'=>int] or WP_Error. */
function cfp_secp256k1_sign( string $msg_bin, string $pk_hex, int $chain_id ): array|\WP_Error {
    if ( ! extension_loaded('gmp') ) return new \WP_Error('no_gmp','GMP required.');
    $p   = gmp_init('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F',16);
    $n   = gmp_init('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141',16);
    $Gx  = gmp_init('79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798',16);
    $Gy  = gmp_init('483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8',16);
    $G   = [$Gx,$Gy];
    $priv = gmp_init($pk_hex,16);
    $z    = gmp_init(bin2hex($msg_bin),16);
    $k    = cfp_secp256k1_rfc6979($msg_bin,$pk_hex);
    $R    = cfp_secp256k1_mul($G,$k,$p,$n);
    $r    = gmp_mod($R[0],$n);
    if ( gmp_cmp($r,0)===0 ) return new \WP_Error('sign_fail','r=0');
    $k_inv = gmp_invert($k,$n);
    $s     = gmp_mod(gmp_mul($k_inv,gmp_mod(gmp_add($z,gmp_mul($r,$priv)),$n)),$n);
    if ( gmp_cmp($s,0)===0 ) return new \WP_Error('sign_fail','s=0');
    $half_n = gmp_div($n,2);
    if ( gmp_cmp($s,$half_n)>0 ) $s = gmp_sub($n,$s);
    $v_base = gmp_cmp($R[1],gmp_div($p,2))>0 ? 1 : 0;
    $v      = $chain_id*2 + 35 + $v_base;
    return ['r'=>gmp_strval($r,16),'s'=>gmp_strval($s,16),'v'=>$v];
}

/** RFC6979 deterministic k. */
function cfp_secp256k1_rfc6979( string $msg_bin, string $pk_hex ): \GMP {
    $pk_bin = hex2bin(str_pad($pk_hex,64,'0',STR_PAD_LEFT));
    $V = str_repeat("\x01",32);
    $K = str_repeat("\x00",32);
    $K = hash_hmac('sha256',$V."\x00".$pk_bin.$msg_bin,$K,true);
    $V = hash_hmac('sha256',$V,$K,true);
    $K = hash_hmac('sha256',$V."\x01".$pk_bin.$msg_bin,$K,true);
    $V = hash_hmac('sha256',$V,$K,true);
    $V = hash_hmac('sha256',$V,$K,true);
    $k = gmp_init(bin2hex($V),16);
    $n = gmp_init('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141',16);
    while ( gmp_cmp($k,1)<0 || gmp_cmp($k,$n)>=0 ) {
        $K = hash_hmac('sha256',$V."\x00",$K,true);
        $V = hash_hmac('sha256',$V,$K,true);
        $V = hash_hmac('sha256',$V,$K,true);
        $k = gmp_init(bin2hex($V),16);
    }
    return $k;
}

/** Double-and-add scalar multiplication on secp256k1. */
function cfp_secp256k1_mul( array $P, \GMP $k, \GMP $p, \GMP $n ): array {
    $R = null; $Q = $P;
    $bits = gmp_strval($k,2);
    for ( $i=0; $i<strlen($bits); $i++ ) {
        if ($R!==null) $R = cfp_ec_double($R,$p);
        if ($bits[$i]==='1') $R = ($R===null) ? $Q : cfp_ec_add($R,$Q,$p);
    }
    return $R;
}

function cfp_ec_double( array $P, \GMP $p ): array {
    [$x,$y] = $P;
    $lam = gmp_mod(gmp_mul(gmp_mul(3,gmp_pow($x,2)),gmp_invert(gmp_mul(2,$y),$p)),$p);
    $xr  = gmp_mod(gmp_sub(gmp_pow($lam,2),gmp_mul(2,$x)),$p);
    $yr  = gmp_mod(gmp_sub(gmp_mul($lam,gmp_sub($x,$xr)),$y),$p);
    return [gmp_mod(gmp_add($xr,$p),$p),gmp_mod(gmp_add($yr,$p),$p)];
}

function cfp_ec_add( array $P, array $Q, \GMP $p ): array {
    [$x1,$y1]=$P; [$x2,$y2]=$Q;
    $lam = gmp_mod(gmp_mul(gmp_sub($y2,$y1),gmp_invert(gmp_sub($x2,$x1),$p)),$p);
    $xr  = gmp_mod(gmp_sub(gmp_sub(gmp_pow($lam,2),$x1),$x2),$p);
    $yr  = gmp_mod(gmp_sub(gmp_mul($lam,gmp_sub($x1,$xr)),$y1),$p);
    return [gmp_mod(gmp_add($xr,$p),$p),gmp_mod(gmp_add($yr,$p),$p)];
}

// ============================================================
// RLP ENCODING
// ============================================================

function cfp_rlp_encode_int( string $val ): string {
    if ($val==='0') return "\x80";
    $hex = base_convert($val,10,16);
    if (strlen($hex)%2) $hex='0'.$hex;
    $bin = hex2bin($hex); $len = strlen($bin);
    if ($len===1 && ord($bin[0])<0x80) return $bin;
    return ($len<=55 ? chr(0x80+$len) : cfp_rlp_length_prefix(0xB7,$len)) . $bin;
}

function cfp_rlp_encode_hex( string $hex ): string {
    if ($hex===''||$hex==='00') return "\x80";
    $bin = hex2bin($hex); $len = strlen($bin);
    if ($len===1 && ord($bin[0])<0x80) return $bin;
    return ($len<=55 ? chr(0x80+$len) : cfp_rlp_length_prefix(0xB7,$len)) . $bin;
}

function cfp_rlp_encode_data( string $hex ): string {
    $hex = ltrim($hex,'0x');
    if ($hex==='') return "\x80";
    $bin = hex2bin($hex); $len = strlen($bin);
    if ($len===1 && ord($bin[0])<0x80) return $bin;
    return ($len<=55 ? chr(0x80+$len) : cfp_rlp_length_prefix(0xB7,$len)) . $bin;
}

function cfp_rlp_list( array $items ): string {
    $payload = implode('',$items); $len = strlen($payload);
    return ($len<=55 ? chr(0xC0+$len) : cfp_rlp_length_prefix(0xF7,$len)) . $payload;
}

function cfp_rlp_length_prefix( int $base, int $len ): string {
    $hex = base_convert((string)$len,10,16);
    if (strlen($hex)%2) $hex='0'.$hex;
    $bin = hex2bin($hex);
    return chr($base+strlen($bin)) . $bin;
}

// ============================================================
// EVM TRANSACTION SIGNING (Legacy type-0, EIP-155)
// ============================================================

/**
 * Build, sign, and return a signed raw EVM transaction (0x-prefixed hex).
 *
 * @param array  $tx  Keys: nonce, gas_price, gas_limit, to, value (wei string), data (0x hex), chain_id
 * @param string $pk_hex  32-byte private key hex (no 0x)
 */
function cfp_sign_evm_tx( array $tx, string $pk_hex ): string|\WP_Error {
    if ( ! extension_loaded('gmp') )
        return new \WP_Error('no_gmp','PHP GMP extension required for EVM tx signing.');

    $unsigned = cfp_rlp_list([
        cfp_rlp_encode_int( (string)$tx['nonce'] ),
        cfp_rlp_encode_int( (string)$tx['gas_price'] ),
        cfp_rlp_encode_int( (string)$tx['gas_limit'] ),
        cfp_rlp_encode_hex( ltrim($tx['to'],'0x') ),
        cfp_rlp_encode_int( (string)$tx['value'] ),
        cfp_rlp_encode_data( $tx['data'] ),
        cfp_rlp_encode_int( (string)$tx['chain_id'] ),
        cfp_rlp_encode_int('0'),
        cfp_rlp_encode_int('0'),
    ]);

    $hash = cfp_keccak256($unsigned);
    $sig  = cfp_secp256k1_sign($hash,$pk_hex,$tx['chain_id']);
    if ( is_wp_error($sig) ) return $sig;

    $signed = cfp_rlp_list([
        cfp_rlp_encode_int( (string)$tx['nonce'] ),
        cfp_rlp_encode_int( (string)$tx['gas_price'] ),
        cfp_rlp_encode_int( (string)$tx['gas_limit'] ),
        cfp_rlp_encode_hex( ltrim($tx['to'],'0x') ),
        cfp_rlp_encode_int( (string)$tx['value'] ),
        cfp_rlp_encode_data( $tx['data'] ),
        cfp_rlp_encode_int( (string)$sig['v'] ),
        cfp_rlp_encode_hex( str_pad($sig['r'],64,'0',STR_PAD_LEFT) ),
        cfp_rlp_encode_hex( str_pad($sig['s'],64,'0',STR_PAD_LEFT) ),
    ]);

    return '0x' . bin2hex($signed);
}

// ============================================================
// ERC-20 CALLDATA
// ============================================================

/** Build transfer(address,uint256) calldata hex. */
function cfp_erc20_transfer_data( string $to, string $amount_wei ): string {
    return '0xa9059cbb'
        . str_pad(ltrim($to,'0x'),64,'0',STR_PAD_LEFT)
        . str_pad(base_convert($amount_wei,10,16),64,'0',STR_PAD_LEFT);
}

// ============================================================
// WEI CONVERSION
// ============================================================

/** Convert decimal amount string (e.g. '0.05') to wei integer string given decimals. */
function cfp_to_wei( string $amount, int $decimals ): string {
    $parts = explode('.',(string)$amount);
    $whole = $parts[0];
    $frac  = isset($parts[1]) ? str_pad(substr($parts[1],0,$decimals),$decimals,'0') : str_repeat('0',$decimals);
    return ltrim($whole,'0') . $frac ?: '0';
}

/** Convert wei integer string to decimal string with $decimals places. */
function cfp_from_wei( string $wei, int $decimals ): string {
    $wei = ltrim($wei,'0') ?: '0';
    if ($decimals===0) return $wei;
    $padded = str_pad($wei,$decimals+1,'0',STR_PAD_LEFT);
    $pos    = strlen($padded) - $decimals;
    return rtrim(substr($padded,0,$pos).'.'.substr($padded,$pos),'0') ?: '0';
}
