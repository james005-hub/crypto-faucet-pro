<?php
/**
 * AJAX handlers: NOWPayments deposit invoice creation & withdrawal requests.
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: CREATE NOWPAYMENTS DEPOSIT INVOICE
   FIX #3: Replaced email-only lookup with cfp_require_auth() session check.
           Removed wp_ajax_nopriv hook — deposits require authentication.
   FIX #14: Generic error for missing/invalid session (no email enumeration).
   ============================================================ */
add_action( 'wp_ajax_cfp_np_create_deposit', 'cfp_ajax_np_create_deposit' );
function cfp_ajax_np_create_deposit() {
    check_ajax_referer( 'cfp_nonce', 'nonce' );

    if ( ! cfp_np_enabled() ) {
        wp_send_json_error( ['msg' => 'Coinbase deposits are not enabled.'] );
    }

    // FIX #3: Authenticate via session — no email param accepted.
    $user     = cfp_require_auth();
    $currency = strtolower( sanitize_text_field( $_POST['currency'] ?? cfp_np_currency() ) );
    $amount   = floatval( $_POST['amount'] ?? 0 );

    global $wpdb;

    // Validate minimum deposit amount
    $min_usd = floatval( cfp_get_setting( 'np_min_deposit_usd', 1 ) );
    if ( $amount > 0 && $amount < $min_usd ) {
        wp_send_json_error( ['msg' => "Minimum deposit is \${$min_usd} USD equivalent."] );
    }

    // Use $1 USD minimum if no amount specified (NOWPayments requires a price_amount)
    if ( $amount <= 0 ) $amount = $min_usd > 0 ? $min_usd : 1;

    $order_id = 'cfp_user_' . $user->id . '_' . time();

    // Call NOWPayments to create the invoice
    $result = cfp_np_create_payment( $amount, $currency, $order_id, "CFP Deposit for user #{$user->id}" );

    if ( ! empty( $result['error'] ) ) {
        wp_send_json_error( ['msg' => 'Coinbase error: ' . $result['error']] );
    }

    if ( empty( $result['payment_id'] ) || empty( $result['pay_address'] ) ) {
        wp_send_json_error( ['msg' => 'Failed to create deposit address. Please try again.'] );
    }

    // Store pending deposit record
    $wpdb->insert( CFP_TABLE_NP_DEPOSITS, [
        'user_id'       => $user->id,
        'np_payment_id' => (string) $result['payment_id'],
        'order_id'      => $order_id,
        'currency'      => $currency,
        'pay_amount'    => floatval( $result['pay_amount'] ?? 0 ),
        'amount_sat'    => 0,
        'price_amount'  => $amount,
        'status'        => 'waiting',
        'raw_ipn'       => json_encode( $result ),
    ] );

    wp_send_json_success( [
        'payment_id'   => $result['payment_id'],
        'pay_address'  => $result['pay_address'],
        'pay_amount'   => $result['pay_amount']   ?? '',
        'pay_currency' => $result['pay_currency'] ?? $currency,
        'expiry'       => $result['expiration_estimate_date'] ?? '',
        'qr'           => 'https://api.qrserver.com/v1/create-qr-code/?data=' . urlencode( $result['pay_address'] ) . '&size=200x200',
        'msg'          => "✅ Send exactly {$result['pay_amount']} " . strtoupper( $currency ) . " to the address below.",
    ] );
}

/* ============================================================
   AJAX: CHECK NOWPAYMENTS DEPOSIT STATUS
   FIX #4: Now requires authentication and verifies the payment_id
           belongs to the requesting user before returning any data.
           Removed nopriv hook — status polling requires a session.
   ============================================================ */
add_action( 'wp_ajax_cfp_np_check_deposit', 'cfp_ajax_np_check_deposit' );
function cfp_ajax_np_check_deposit() {
    check_ajax_referer( 'cfp_nonce', 'nonce' );

    // FIX #4: Require a valid session.
    $user = cfp_require_auth();

    $payment_id = sanitize_text_field( $_POST['payment_id'] ?? '' );
    if ( empty( $payment_id ) ) wp_send_json_error( ['msg' => 'No payment ID.'] );

    global $wpdb;

    // FIX #4: Check our local record AND verify ownership in one query.
    $rec = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_NP_DEPOSITS . " WHERE np_payment_id=%s AND user_id=%d",
        $payment_id, $user->id
    ) );

    // Return a generic error if the payment_id doesn't belong to this user,
    // so attackers cannot enumerate other users' payment IDs.
    if ( ! $rec ) {
        wp_send_json_error( ['msg' => 'Payment not found.'] );
    }

    if ( $rec->status === 'credited' ) {
        wp_send_json_success( ['status' => 'credited', 'amount_sat' => $rec->amount_sat, 'msg' => '✅ Deposit confirmed and credited to your balance!'] );
    }

    // Query NOWPayments for live status
    $result = cfp_np_get_payment( $payment_id );
    if ( ! empty( $result['error'] ) ) {
        wp_send_json_error( ['msg' => $result['error']] );
    }

    $status = $result['payment_status'] ?? 'unknown';

    wp_send_json_success( [
        'status'        => $status,
        'actually_paid' => $result['actually_paid'] ?? 0,
        'pay_amount'    => $result['pay_amount'] ?? 0,
        'pay_currency'  => $result['pay_currency'] ?? '',
        'msg'           => cfp_np_status_label( $status ),
    ] );
}

/* ============================================================
   AJAX: NOWPAYMENTS WITHDRAWAL
   FIX #3: Replaced email-only lookup with cfp_require_auth() session check.
           Removed nopriv hook — withdrawals require authentication.
   ============================================================ */
add_action( 'wp_ajax_cfp_np_withdraw', 'cfp_ajax_np_withdraw' );
function cfp_ajax_np_withdraw() {
    check_ajax_referer( 'cfp_nonce', 'nonce' );

    if ( ! cfp_np_enabled() ) {
        wp_send_json_error( ['msg' => 'Coinbase withdrawals are not enabled.'] );
    }

    // FIX #3: Authenticate via session — no email param accepted.
    $user     = cfp_require_auth();
    $address  = sanitize_text_field( $_POST['np_address'] ?? '' );
    $amount   = intval( $_POST['amount'] ?? 0 );
    $currency = strtolower( sanitize_text_field( $_POST['currency'] ?? cfp_np_currency() ) );

    global $wpdb;

    // Withdrawal controls gate
    do_action( 'cfp_before_withdraw', $user, $amount );

    $min = intval( cfp_get_setting( 'np_min_withdraw_sat', 10000 ) );
    $fee = intval( cfp_get_setting( 'np_fee_sat', 0 ) );

    if ( $amount < $min ) {
        wp_send_json_error( ['msg' => "Minimum withdrawal is " . number_format( $min ) . " sat."] );
    }
    if ( empty( $address ) ) {
        wp_send_json_error( ['msg' => 'Enter your wallet address.'] );
    }
    if ( strlen( $address ) < 10 ) {
        wp_send_json_error( ['msg' => 'Invalid wallet address.'] );
    }

    $total_deduct = $amount + $fee;

    // Convert sat to the payout currency amount
    $pay_amount = cfp_np_sat_to_currency( $amount, $currency );
    if ( $pay_amount <= 0 ) {
        wp_send_json_error( ['msg' => 'Cannot calculate payout amount. Please contact support.'] );
    }

    // Block duplicate pending requests
    $pending = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM " . CFP_TABLE_NP_WITHDRAWALS . " WHERE user_id=%d AND status='pending' LIMIT 1",
        $user->id
    ) );
    if ( $pending ) {
        wp_send_json_error( ['msg' => 'You already have a pending withdrawal. Please wait for it to complete.'] );
    }

    // Deduct balance atomically (already had this pattern — kept as-is)
    $rows = $wpdb->query( $wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $total_deduct, $user->id, $total_deduct
    ) );
    if ( $rows === 0 ) {
        wp_send_json_error( ['msg' => 'Insufficient balance. Please refresh and try again.'] );
    }

    // Call NOWPayments Mass Payout API
    $result = cfp_np_send_payout( $address, $pay_amount, $currency, "cfp_user_{$user->id}" );

    $np_payout_id = '';
    $status       = 'pending';

    if ( ! empty( $result['error'] ) ) {
        // Refund the user if payout API call fails outright
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
            $total_deduct, $user->id
        ) );
        wp_send_json_error( ['msg' => 'Coinbase payout error: ' . $result['error']] );
    }

    // Extract payout ID from response
    $withdrawals = $result['withdrawals'] ?? [];
    if ( ! empty( $withdrawals[0]['id'] ) ) {
        $np_payout_id = (string) $withdrawals[0]['id'];
        $status       = strtolower( $withdrawals[0]['status'] ?? 'pending' );
    }

    // Record the withdrawal
    $wpdb->insert( CFP_TABLE_NP_WITHDRAWALS, [
        'user_id'       => $user->id,
        'np_payout_id'  => $np_payout_id,
        'to_address'    => $address,
        'currency'      => $currency,
        'amount_sat'    => $amount,
        'pay_amount'    => $pay_amount,
        'fee_sat'       => $fee,
        'status'        => $status,
        'np_response'   => json_encode( $result ),
    ] );

    $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
        'user_id'     => $user->id,
        'type'        => 'coinbase_withdrawal',
        'amount_sat'  => -$total_deduct,
        'description' => "Coinbase withdrawal {$amount} sat ({$pay_amount} {$currency}) to {$address}",
    ] );

    if ( $fee > 0 ) {
        cfp_wallet_credit_game( 'admin_wallet_stream_np_withdraw_fee', 'np_withdraw_fee', $fee, "Coinbase withdrawal fee from user #{$user->id}" );
    }

    wp_send_json_success( [
        'msg'       => "✅ Withdrawal submitted! {$pay_amount} " . strtoupper( $currency ) . " is being sent to your wallet. Payout ID: {$np_payout_id}",
        'payout_id' => $np_payout_id,
    ] );
}

/* ============================================================
   AJAX: GET AVAILABLE NOWPAYMENTS CURRENCIES
   ============================================================ */
add_action( 'wp_ajax_cfp_np_get_currencies',        'cfp_ajax_np_get_currencies' );
add_action( 'wp_ajax_nopriv_cfp_np_get_currencies', 'cfp_ajax_np_get_currencies' );
function cfp_ajax_np_get_currencies() {
    check_ajax_referer( 'cfp_nonce', 'nonce' );
    $currencies = cfp_np_get_currencies();
    wp_send_json_success( ['currencies' => $currencies] );
}

/* ============================================================
   HELPER: CONVERT SATOSHIS TO PAYOUT CURRENCY AMOUNT
   ============================================================ */
function cfp_np_sat_to_currency( $amount_sat, $currency ) {
    $currency = strtolower( $currency );

    if ( $currency === 'btc' ) {
        return round( $amount_sat / 100000000, 8 );
    }
    if ( $currency === 'sat' || $currency === 'sats' ) {
        return $amount_sat;
    }

    // Use sat_per_usd rate configured in admin
    $sat_per_usd = floatval( cfp_get_setting( 'np_sat_per_usd', 0 ) );
    if ( $sat_per_usd > 0 ) {
        $usd_amount = $amount_sat / $sat_per_usd;
        return round( $usd_amount, 6 );
    }

    // Use live BTC price
    $btc_price_usd = floatval( get_transient( 'cfp_btc_price_usd' ) );
    if ( $btc_price_usd > 0 ) {
        $btc_amount = $amount_sat / 100000000;
        $usd_amount = $btc_amount * $btc_price_usd;
        return round( $usd_amount, 6 );
    }

    return 0;
}

/* ============================================================
   HELPER: HUMAN-READABLE STATUS LABELS
   ============================================================ */
function cfp_np_status_label( $status ) {
    return match( strtolower( $status ) ) {
        'waiting'        => '⏳ Waiting for payment…',
        'confirming'     => '🔄 Confirming transaction…',
        'confirmed'      => '✅ Confirmed! Crediting balance…',
        'finished'       => '✅ Payment complete!',
        'partially_paid' => '⚠️ Partially paid — awaiting remainder.',
        'failed'         => '❌ Payment failed.',
        'refunded'       => '↩️ Payment refunded.',
        'expired'        => '⌛ Payment expired. Please create a new deposit.',
        default          => ucfirst( $status ),
    };
}
