<?php
/**
 * Leaderboard System
 *
 * @package CryptoFaucetPro
 */

if (!defined('ABSPATH')) exit;

/* ============================================================
   LEADERBOARD TABLES
   ============================================================ */
function cfp_create_leaderboard_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $table = $wpdb->prefix . 'cfp_leaderboard_cache';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
        $wpdb->query("
            CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                leaderboard_type varchar(30) NOT NULL,
                period enum('daily','weekly','monthly','alltime') DEFAULT 'alltime',
                user_id bigint(20) NOT NULL,
                rank int(11) NOT NULL,
                score bigint(20) DEFAULT 0,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                UNIQUE KEY type_period_user (leaderboard_type, period, user_id),
                KEY rank (rank),
                KEY period (period)
            ) $charset
        ");
    }
}

/* ============================================================
   UPDATE LEADERBOARDS
   ============================================================ */
function cfp_update_leaderboards() {
    global $wpdb;
    
    $types = [
        'earners' => "SELECT id, total_earned as score FROM " . CFP_TABLE_USERS . " WHERE is_banned = 0 ORDER BY total_earned DESC",
        'winners' => "SELECT id, total_wins as score FROM " . CFP_TABLE_USERS . " WHERE is_banned = 0 ORDER BY total_wins DESC",
        'claimers' => "SELECT id, total_claims as score FROM " . CFP_TABLE_USERS . " WHERE is_banned = 0 ORDER BY total_claims DESC",
        'referrers' => "SELECT id, COUNT(*) as score FROM " . CFP_TABLE_REFERRALS . " r
                        LEFT JOIN " . CFP_TABLE_USERS . " u ON r.referrer_id = u.id
                        WHERE u.is_banned = 0 GROUP BY referrer_id ORDER BY score DESC"
    ];
    
    $periods = ['daily', 'weekly', 'monthly', 'alltime'];
    
    foreach ($types as $type => $query) {
        foreach ($periods as $period) {
            $score_query = $query;
            
            if ($period !== 'alltime') {
                $date_condition = '';
                switch ($period) {
                    case 'daily':
                        $date_condition = " AND created_at >= '" . date('Y-m-d 00:00:00') . "'";
                        break;
                    case 'weekly':
                        $date_condition = " AND created_at >= '" . date('Y-m-d 00:00:00', strtotime('-7 days')) . "'";
                        break;
                    case 'monthly':
                        $date_condition = " AND created_at >= '" . date('Y-m-01 00:00:00') . "'";
                        break;
                }
                
                if ($type === 'earners') {
                    $score_query = str_replace(' WHERE ', ' WHERE created_at >= "' . date('Y-m-01 00:00:00') . '" AND ', $query);
                    if ($period === 'daily') {
                        $score_query = "SELECT id, COALESCE(SUM(total_earned), 0) as score FROM " . CFP_TABLE_USERS . " 
                                      WHERE is_banned = 0 AND last_claim >= '" . date('Y-m-d 00:00:00') . "' GROUP BY id ORDER BY score DESC";
                    } elseif ($period === 'weekly') {
                        $score_query = "SELECT id, COALESCE(SUM(total_earned), 0) as score FROM " . CFP_TABLE_USERS . " 
                                      WHERE is_banned = 0 AND last_claim >= '" . date('Y-m-d 00:00:00', strtotime('-7 days')) . "' GROUP BY id ORDER BY score DESC";
                    }
                }
                
                if ($type === 'winners' || $type === 'claimers') {
                    $score_query = str_replace('WHERE ', 'WHERE created_at >= "' . date('Y-m-01 00:00:00') . '" AND ', $query);
                    if ($period === 'daily') {
                        $score_query = str_replace('ORDER BY', "WHERE created_at >= '" . date('Y-m-d 00:00:00') . "' AND is_banned = 0 ORDER BY", $query);
                    } elseif ($period === 'weekly') {
                        $score_query = str_replace('WHERE ', "WHERE created_at >= '" . date('Y-m-d 00:00:00', strtotime('-7 days')) . "' AND ", $query);
                    }
                }
            }
            
            $results = $wpdb->get_results($score_query . " LIMIT 100");
            
            $rank = 1;
            foreach ($results as $user) {
                $existing = $wpdb->get_var($wpdb->prepare(
                    "SELECT id FROM " . $wpdb->prefix . "cfp_leaderboard_cache 
                    WHERE leaderboard_type = %s AND period = %s AND user_id = %d",
                    $type, $period, $user->id
                ));
                
                if ($existing) {
                    $wpdb->update($wpdb->prefix . 'cfp_leaderboard_cache', [
                        'rank' => $rank,
                        'score' => $user->score,
                        'updated_at' => current_time('mysql')
                    ], ['id' => $existing]);
                } else {
                    $wpdb->insert($wpdb->prefix . 'cfp_leaderboard_cache', [
                        'leaderboard_type' => $type,
                        'period' => $period,
                        'user_id' => $user->id,
                        'rank' => $rank,
                        'score' => $user->score
                    ]);
                }
                $rank++;
            }
        }
    }
}

add_action('cfp_hourly_leaderboard_hook', 'cfp_update_leaderboards');
add_action( 'init', function() {
    if ( ! wp_next_scheduled( 'cfp_hourly_leaderboard_hook' ) ) {
        wp_schedule_event( time(), 'hourly', 'cfp_hourly_leaderboard_hook' );
    }
} );

/* ============================================================
   GET LEADERBOARD DATA
   ============================================================ */
function cfp_get_leaderboard($type, $period = 'alltime', $limit = 10) {
    global $wpdb;
    
    $cache_key = "cfp_leaderboard_{$type}_{$period}_{$limit}";
    $cached = get_transient($cache_key);
    
    if (false !== $cached) {
        return $cached;
    }
    
    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT l.rank, l.score, u.username, u.avatar 
        FROM " . $wpdb->prefix . "cfp_leaderboard_cache l
        LEFT JOIN " . CFP_TABLE_USERS . " u ON l.user_id = u.id
        WHERE l.leaderboard_type = %s AND l.period = %s
        ORDER BY l.rank LIMIT %d",
        $type, $period, $limit
    ));
    
    set_transient($cache_key, $results, 300);
    
    return $results;
}

/* ============================================================
   AJAX: Get Leaderboards
   ============================================================ */
add_action('wp_ajax_cfp_get_leaderboards', 'cfp_ajax_get_leaderboards');
add_action('wp_ajax_nopriv_cfp_get_leaderboards', 'cfp_ajax_get_leaderboards');
function cfp_ajax_get_leaderboards() {
    $type = sanitize_text_field($_POST['type'] ?? 'earners');
    $period = sanitize_text_field($_POST['period'] ?? 'alltime');
    $limit = intval($_POST['limit'] ?? 10);
    
    $valid_types = ['earners', 'winners', 'claimers', 'referrers'];
    $valid_periods = ['daily', 'weekly', 'monthly', 'alltime'];
    
    if (!in_array($type, $valid_types)) $type = 'earners';
    if (!in_array($period, $valid_periods)) $period = 'alltime';
    
    $data = cfp_get_leaderboard($type, $period, $limit);
    
    wp_send_json_success(['leaderboard' => $data]);
}

/* ============================================================
   SHORTCODE: [cfp_leaderboard]
   ============================================================ */
add_shortcode('cfp_leaderboard', function($atts) {
    $atts = shortcode_atts([
        'type' => 'earners',
        'period' => 'alltime',
        'limit' => 10,
        'title' => ''
    ], $atts);
    
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax = admin_url('admin-ajax.php');
    
    $type_labels = [
        'earners' => 'Top Earners',
        'winners' => 'Biggest Winners',
        'claimers' => 'Most Claims',
        'referrers' => 'Top Referrers'
    ];
    
    ob_start();
    ?>
    <div class="cfp-widget cfp-leaderboard" data-type="<?=$atts['type']?>" data-period="<?=$atts['period']?>">
        <h2>🏆 <?=$atts['title'] ?: $type_labels[$atts['type']]?></h2>
        
        <div style="display:flex;gap:8px;margin-bottom:16px">
            <button onclick="cfpSwitchPeriod('daily')" class="cfp-period-btn" data-period="daily">Today</button>
            <button onclick="cfpSwitchPeriod('weekly')" class="cfp-period-btn" data-period="weekly">Week</button>
            <button onclick="cfpSwitchPeriod('monthly')" class="cfp-period-btn" data-period="monthly">Month</button>
            <button onclick="cfpSwitchPeriod('alltime')" class="cfp-period-btn active" data-period="alltime">All Time</button>
        </div>
        
        <div id="cfp-leaderboard-list">
            <div style="text-align:center;padding:20px;color:#555">Loading...</div>
        </div>
    </div>
    
    <script>
    let cfpCurrentType = '<?=$atts['type']?>';
    let cfpCurrentPeriod = '<?=$atts['period']?>';
    
    function cfpSwitchPeriod(period) {
        cfpCurrentPeriod = period;
        document.querySelectorAll('.cfp-period-btn').forEach(b => b.classList.remove('active'));
        document.querySelector('[data-period="' + period + '"]').classList.add('active');
        cfpLoadLeaderboard();
    }
    
    function cfpLoadLeaderboard() {
        const fd = new FormData();
        fd.append('action', 'cfp_get_leaderboards');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('type', cfpCurrentType);
        fd.append('period', cfpCurrentPeriod);
        fd.append('limit', <?=$atts['limit']?>);
        
        fetch('<?=$ajax?>', {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    const list = document.getElementById('cfp-leaderboard-list');
                    if(d.data.leaderboard.length === 0) {
                        list.innerHTML = '<div style="text-align:center;padding:20px;color:#555">No data yet</div>';
                        return;
                    }
                    
                    list.innerHTML = d.data.leaderboard.map((u, i) => {
                        const medals = ['','🥇','🥈','🥉'];
                        const bg = i < 3 ? '#1a1a1a' : '#111';
                        const border = i < 3 ? '1px solid #333' : 'none';
                        
                        return '<div style="display:flex;align-items:center;gap:12px;background:' + bg + ';padding:12px;border-radius:8px;margin-bottom:6px;border:' + border + '">' +
                            '<div style="width:30px;text-align:center;font-weight:700;color:' + (i < 3 ? '#ffd700' : '#555') + '">' + (medals[i] || '#' + (i+1)) + '</div>' +
                            '<div style="flex:1;font-weight:600">' + u.username + '</div>' +
                            '<div style="color:var(--g);font-weight:700">' + cfpFormatNumber(u.score) + '</div>' +
                        '</div>';
                    }).join('');
                }
            });
    }
    
    function cfpFormatNumber(n) {
        if(n >= 1000000000) return (n/1000000000).toFixed(2) + 'B';
        if(n >= 1000000) return (n/1000000).toFixed(2) + 'M';
        if(n >= 1000) return (n/1000).toFixed(1) + 'K';
        return n;
    }
    
    cfpLoadLeaderboard();
    </script>
    <?php
    return ob_get_clean();
});

/* ============================================================
   ADMIN: Force Update
   ============================================================ */
add_action('cfp_security_extra_cards', function() {
    if (isset($_POST['cfp_update_leaderboards'])) {
        check_admin_referer('cfp_update_leaderboards');
        cfp_update_leaderboards();
        echo '<div class="notice notice-success"><p>Leaderboards updated!</p></div>';
    }
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🏆 Leaderboard System</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Leaderboards are auto-updated hourly. Manual update available.</p>
        
        <form method="post">
            <?php wp_nonce_field('cfp_update_leaderboards'); ?>
            <button type="submit" name="cfp_update_leaderboards" class="cfp-btn">Update Now</button>
        </form>
        
        <h3 style="margin-top:20px;color:var(--g)">Preview</h3>
        <?php echo do_shortcode('[cfp_leaderboard type="earners" period="alltime" limit="5" title=""]'); ?>
    </div>
    <?php
});
