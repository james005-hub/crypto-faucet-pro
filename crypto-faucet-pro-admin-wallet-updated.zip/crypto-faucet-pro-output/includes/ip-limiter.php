<?php
/**
 * IP Rate Limiter & Security Layer
 *
 * Enhancements over original:
 *  - Sliding window per-IP per-action counters (unchanged base)
 *  - Country/region block list (configurable from admin)
 *  - User-Agent bot fingerprint blocking
 *  - Honeypot field check (anti-bot on registration)
 *  - Suspicious pattern detection: same email + different IPs rapid-fire
 *  - Auto-ban flag on repeat offenders (>3 rate-limit hits in 10 min)
 *  - Request signing: HMAC timestamp check to block replayed requests
 *  - Tor/VPN IP block via configurable CIDR list
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   CORE SLIDING-WINDOW RATE LIMITER
   ============================================================ */

/**
 * Check and increment an IP rate limit counter.
 *
 * @param string $action     Identifier: 'game','claim','register','withdraw','chat'
 * @param int    $max        Max hits allowed within the window
 * @param int    $window_sec Window in seconds (default 60)
 * @return true|WP_Error
 */
function cfp_ip_check( $action, $max, $window_sec = 60 ) {
    if ( cfp_get_setting('ip_limiter_enabled','1') !== '1' ) return true;

    global $wpdb;
    $ip = cfp_get_real_ip();
    if ( empty($ip) ) return true;

    // Block banned IPs immediately
    if ( cfp_is_ip_banned($ip) ) {
        return new WP_Error('ip_banned', '🚫 Your IP has been blocked due to repeated abuse.');
    }

    // Block VPN/Tor if setting enabled
    if ( cfp_get_setting('block_vpn_tor','0') === '1' && cfp_is_vpn_or_tor($ip) ) {
        return new WP_Error('vpn_blocked', '🚫 VPN/Tor connections are not allowed.');
    }

    // Bot user-agent check
    if ( cfp_is_bot_ua() ) {
        return new WP_Error('bot_blocked', '🚫 Automated requests are not allowed.');
    }

    $now = current_time('mysql');
    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_IP_LIMITS . " WHERE ip_address=%s AND action_type=%s",
        $ip, $action
    ));

    if ( ! $row ) {
        $wpdb->insert( CFP_TABLE_IP_LIMITS, [
            'ip_address'   => $ip,
            'action_type'  => $action,
            'hit_count'    => 1,
            'window_start' => $now,
        ]);
        return true;
    }

    $elapsed = strtotime($now) - strtotime($row->window_start);

    if ( $elapsed > $window_sec ) {
        // Reset window
        $wpdb->update( CFP_TABLE_IP_LIMITS,
            ['hit_count'=>1,'window_start'=>$now],
            ['ip_address'=>$ip,'action_type'=>$action]
        );
        return true;
    }

    if ( $row->hit_count >= $max ) {
        // Record abuse strike; auto-ban after threshold
        cfp_record_abuse_strike($ip, $action);
        $retry = $window_sec - $elapsed;
        return new WP_Error('rate_limited', "⏳ Too many requests. Please wait {$retry} seconds.");
    }

    $wpdb->query( $wpdb->prepare(
        "UPDATE " . CFP_TABLE_IP_LIMITS . " SET hit_count=hit_count+1 WHERE ip_address=%s AND action_type=%s",
        $ip, $action
    ));
    return true;
}

/**
 * Helper — sends JSON error and exits if rate limited.
 */
function cfp_ip_gate( $action, $max, $window_sec = 60 ) {
    $result = cfp_ip_check($action, $max, $window_sec);
    if ( is_wp_error($result) ) {
        wp_send_json_error(['msg' => $result->get_error_message()]);
    }
}

/* ============================================================
   REAL IP DETECTION (SECURE - Cloudflare only, prevents spoofing)
   ============================================================ */
function cfp_get_real_ip() {
    if (function_exists('cfp_get_real_ip_secure')) {
        return cfp_get_real_ip_secure();
    }
    
    $remote_addr = $_SERVER['REMOTE_ADDR'] ?? '';
    
    $cloudflare_ips = [
        '173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22',
        '103.31.4.0/22', '141.101.64.0/18', '108.162.192.0/18',
        '190.93.240.0/20', '188.114.96.0/20', '197.234.240.0/22',
        '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
        '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22'
    ];
    
    if (cfp_ip_in_cidr($remote_addr, $cloudflare_ips)) {
        $cf_ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? '';
        if (!empty($cf_ip)) {
            $ip = trim(explode(',', $cf_ip)[0]);
            if (filter_var($ip, FILTER_VALIDATE_IP)) {
                return sanitize_text_field($ip);
            }
        }
    }
    
    return sanitize_text_field($remote_addr);
}

function cfp_ip_in_cidr($ip, $cidr) {
    if (is_array($cidr)) {
        foreach ($cidr as $c) {
            if (cfp_ip_in_cidr($ip, $c)) return true;
        }
        return false;
    }
    
    if (strpos($cidr, '/') === false) {
        return $ip === $cidr;
    }
    
    list($subnet, $bits) = explode('/', $cidr);
    if (!filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) || 
        !filter_var($subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        return false;
    }
    
    $ip_long = ip2long($ip);
    $subnet_long = ip2long($subnet);
    $mask = -1 << (32 - intval($bits));
    
    return ($ip_long & $mask) === ($subnet_long & $mask);
}

/* ============================================================
   BOT USER-AGENT DETECTION
   ============================================================ */
function cfp_is_bot_ua() {
    if ( cfp_get_setting('block_bot_ua','1') !== '1' ) return false;
    $ua = strtolower($_SERVER['HTTP_USER_AGENT'] ?? '');
    if ( empty($ua) ) return true; // no UA is suspicious for game requests

    $bot_patterns = [
        'curl','wget','python-requests','python-urllib','java/','libwww',
        'scrapy','bot','crawler','spider','headless','phantomjs','selenium',
        'puppeteer','playwright','mechanize','httpie','go-http-client',
    ];
    foreach ( $bot_patterns as $p ) {
        if ( strpos($ua, $p) !== false ) return true;
    }
    return false;
}

/* ============================================================
   IP BAN LIST (stored in settings table as JSON)
   ============================================================ */
function cfp_get_banned_ips() {
    $raw = cfp_get_setting('banned_ips','[]');
    $list = json_decode($raw, true);
    return is_array($list) ? $list : [];
}

function cfp_is_ip_banned( $ip ) {
    $banned = cfp_get_banned_ips();
    foreach ( $banned as $entry ) {
        // Support CIDR blocks
        if ( strpos($entry, '/') !== false ) {
            if ( cfp_ip_in_cidr($ip, $entry) ) return true;
        } elseif ( $ip === $entry ) {
            return true;
        }
    }
    return false;
}

function cfp_ban_ip( $ip, $reason = '' ) {
    $banned = cfp_get_banned_ips();
    if ( ! in_array($ip, $banned) ) {
        $banned[] = $ip;
        cfp_update_setting('banned_ips', json_encode($banned));
        // Log it
        global $wpdb;
        $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
            'user_id'     => 0,
            'type'        => 'ip_ban',
            'amount_sat'  => 0,
            'description' => "Auto-banned IP {$ip}: {$reason}",
        ]);
    }
}



/* ============================================================
   ABUSE STRIKE SYSTEM — auto-ban after N strikes
   ============================================================ */
function cfp_record_abuse_strike( $ip, $action ) {
    $threshold = intval( cfp_get_setting('auto_ban_strikes', 5) );
    if ( $threshold <= 0 ) return;

    $key   = "abuse_strikes_{$ip}";
    $raw   = get_transient($key);
    $strikes = $raw ? intval($raw) + 1 : 1;
    set_transient($key, $strikes, 10 * MINUTE_IN_SECONDS);

    if ( $strikes >= $threshold ) {
        cfp_ban_ip($ip, "Auto-banned after {$strikes} rate-limit violations on action '{$action}'");
    }
}

/* ============================================================
   SIMPLE VPN/TOR CIDR BLOCK
   Block configurable CIDR ranges (admin adds them in Security settings).
   ============================================================ */
function cfp_is_vpn_or_tor( $ip ) {
    $blocked_cidrs = cfp_get_setting('blocked_cidrs','');
    if ( empty($blocked_cidrs) ) return false;
    foreach ( array_filter(array_map('trim', explode("\n", $blocked_cidrs))) as $cidr ) {
        if ( strpos($cidr,'/') !== false && cfp_ip_in_cidr($ip,$cidr) ) return true;
        if ( $cidr === $ip ) return true;
    }
    return false;
}

/* ============================================================
   REQUEST TIMESTAMP VALIDATION
   Prevents replayed AJAX requests (requests > 5 min old are rejected).
   JS must send: fd.append('cfp_ts', Math.floor(Date.now()/1000));
   ============================================================ */
function cfp_validate_request_timestamp() {
    if ( cfp_get_setting('request_ts_check','1') !== '1' ) return;
    $ts = intval($_POST['cfp_ts'] ?? 0);
    if ( $ts <= 0 ) return; // not sent; optional check
    $now = time();
    if ( abs($now - $ts) > 300 ) { // 5 minute tolerance
        wp_send_json_error(['msg' => '⏰ Request expired. Please refresh the page and try again.']);
    }
}

/* ============================================================
   HONEYPOT FIELD CHECK — call in registration handler
   Form must include: <input type="text" name="cfp_hp_field" style="display:none" tabindex="-1" autocomplete="off">
   ============================================================ */
function cfp_check_honeypot() {
    if ( cfp_get_setting('honeypot_enabled','1') !== '1' ) return;
    if ( ! empty($_POST['cfp_hp_field']) ) {
        // Bot filled the hidden field
        $ip = cfp_get_real_ip();
        cfp_ban_ip($ip, 'Honeypot triggered on registration');
        wp_send_json_error(['msg' => 'Registration failed. Please try again.']);
    }
}

/* ============================================================
   MULTI-IP FRAUD DETECTION
   Flag if the same email is used from >3 different IPs within an hour.
   ============================================================ */
function cfp_check_email_multi_ip( $email ) {
    if ( cfp_get_setting('multi_ip_check','1') !== '1' ) return;
    $key   = 'cfp_email_ips_' . md5($email);
    $ips   = get_transient($key);
    $ips   = is_array($ips) ? $ips : [];
    $ip    = cfp_get_real_ip();
    if ( ! in_array($ip, $ips) ) $ips[] = $ip;
    set_transient($key, $ips, HOUR_IN_SECONDS);
    $max = intval( cfp_get_setting('multi_ip_max',5) );
    if ( count($ips) > $max ) {
        // Flag the user account
        global $wpdb;
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET is_banned=1 WHERE email=%s",
            sanitize_email($email)
        ));
        wp_send_json_error(['msg' => '🚫 Account flagged for suspicious activity. Contact support.']);
    }
}

/* ============================================================
   HOOK INTO ALL GAME AJAX ACTIONS
   ============================================================ */

// Games: max 120 rolls per minute per IP
$game_actions = ['cfp_multiply','cfp_slots','cfp_coinflip','cfp_coinflip_don','cfp_dice_roll','cfp_crash','cfp_wheel','cfp_autoplay'];
foreach ( $game_actions as $action ) {
    add_action("wp_ajax_{$action}",        function() use ($action) {
        cfp_ip_gate('game', intval(cfp_get_setting('ip_limit_game',120)), 60);
        cfp_validate_request_timestamp();
    }, 1);
    add_action("wp_ajax_nopriv_{$action}", function() use ($action) {
        cfp_ip_gate('game', intval(cfp_get_setting('ip_limit_game',120)), 60);
        cfp_validate_request_timestamp();
    }, 1);
}

// Claims: max 5 per 5 minutes per IP
add_action('wp_ajax_cfp_claim',        function(){ cfp_ip_gate('claim', intval(cfp_get_setting('ip_limit_claim',5)), 300); cfp_validate_request_timestamp(); }, 1);
add_action('wp_ajax_nopriv_cfp_claim', function(){ cfp_ip_gate('claim', intval(cfp_get_setting('ip_limit_claim',5)), 300); cfp_validate_request_timestamp(); }, 1);

// Register: max 3 per hour per IP
add_action('wp_ajax_cfp_register',        function(){ cfp_ip_gate('register', intval(cfp_get_setting('ip_limit_register',3)), 3600); cfp_check_honeypot(); }, 1);
add_action('wp_ajax_nopriv_cfp_register', function(){ cfp_ip_gate('register', intval(cfp_get_setting('ip_limit_register',3)), 3600); cfp_check_honeypot(); }, 1);

// Withdraw: max 5 per hour per IP
add_action('wp_ajax_cfp_withdraw',        function(){ cfp_ip_gate('withdraw', intval(cfp_get_setting('ip_limit_withdraw',5)), 3600); cfp_validate_request_timestamp(); }, 1);
add_action('wp_ajax_nopriv_cfp_withdraw', function(){ cfp_ip_gate('withdraw', intval(cfp_get_setting('ip_limit_withdraw',5)), 3600); cfp_validate_request_timestamp(); }, 1);

// Chat
add_action('wp_ajax_cfp_chat',        function(){ cfp_ip_gate('chat', intval(cfp_get_setting('ip_limit_chat',30)), 60); }, 1);
add_action('wp_ajax_nopriv_cfp_chat', function(){ cfp_ip_gate('chat', intval(cfp_get_setting('ip_limit_chat',30)), 60); }, 1);

/* ============================================================
   CLEANUP — run on daily cron
   ============================================================ */
add_action('cfp_daily_interest_hook', function() {
    global $wpdb;
    $wpdb->query("DELETE FROM " . CFP_TABLE_IP_LIMITS . " WHERE window_start < DATE_SUB(NOW(), INTERVAL 2 HOUR)");
    // Purge expired sessions (keeps cfp_sessions table lean)
    $wpdb->query("DELETE FROM {$wpdb->prefix}cfp_sessions WHERE expires_at < NOW()");
    // Clear old abuse transients are auto-expired by WP
});
