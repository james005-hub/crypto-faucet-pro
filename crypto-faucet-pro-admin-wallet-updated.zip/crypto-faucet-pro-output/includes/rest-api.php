<?php
/**
 * REST API for CryptoFaucetPro
 *
 * @package CryptoFaucetPro
 */

if (!defined('ABSPATH')) exit;

/* ============================================================
   REST API INIT
   ============================================================ */
function cfp_register_rest_routes() {
    register_rest_route('cfp/v1', '/stats', [
        'methods' => 'GET',
        'callback' => 'cfp_api_get_stats',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('cfp/v1', '/price', [
        'methods' => 'GET',
        'callback' => 'cfp_api_get_price',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('cfp/v1', '/leaderboard', [
        'methods' => 'GET',
        'callback' => 'cfp_api_get_leaderboard',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('cfp/v1', '/user/(?P<email>.+)', [
        'methods' => 'GET',
        'callback' => 'cfp_api_get_user',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('cfp/v1', '/claim/status', [
        'methods' => 'GET',
        'callback' => 'cfp_api_claim_status',
        'permission_callback' => '__return_true'
    ]);

    register_rest_route('cfp/v1', '/games', [
        'methods' => 'GET',
        'callback' => 'cfp_api_get_games',
        'permission_callback' => '__return_true'
    ]);
    
    register_rest_route('cfp/v1', '/auth/verify', [
        'methods'             => 'POST',
        'callback'            => 'cfp_api_auth_verify',
        'permission_callback' => function() {
            // Rate-limit: 10 attempts per minute per IP before returning 403.
            // Prevents brute-forcing API keys via this endpoint.
            $result = cfp_ip_check( 'api_auth', 10, 60 );
            if ( is_wp_error( $result ) ) {
                return new WP_Error( 'rate_limited', $result->get_error_message(), [ 'status' => 429 ] );
            }
            return true;
        },
    ]);
}

add_action('rest_api_init', 'cfp_register_rest_routes');

/* ============================================================
   API: Global Stats
   ============================================================ */
function cfp_api_get_stats() {
    global $wpdb;
    
    $total_users = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_USERS);
    $total_claims = (int)$wpdb->get_var("SELECT COALESCE(SUM(claim_count), 0) FROM " . CFP_TABLE_USERS);
    $total_earned = (int)$wpdb->get_var("SELECT COALESCE(SUM(total_earned), 0) FROM " . CFP_TABLE_USERS);
    $total_withdrawn = (int)$wpdb->get_var("SELECT COALESCE(SUM(amount_sat), 0) FROM " . CFP_TABLE_WITHDRAWALS);
    $today_claims = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . CFP_TABLE_CLAIMS . " WHERE created_at >= %s",
        date('Y-m-d 00:00:00')
    ));
    
    return rest_ensure_response([
        'total_users' => $total_users,
        'total_claims' => $total_claims,
        'total_earned_sat' => $total_earned,
        'total_earned_btc' => $total_earned / 100000000,
        'total_withdrawn_sat' => $total_withdrawn,
        'today_claims' => $today_claims,
        'timestamp' => current_time('timestamp')
    ]);
}

/* ============================================================
   API: Current Price
   ============================================================ */
function cfp_api_get_price() {
    $btc_price = cfp_get_btc_price();
    $ltc_price = cfp_get_setting('ltc_price_usd', 0);
    $doge_price = cfp_get_setting('doge_price_usd', 0);
    
    return rest_ensure_response([
        'btc_usd' => $btc_price,
        'ltc_usd' => floatval($ltc_price),
        'doge_usd' => floatval($doge_price),
        'timestamp' => current_time('timestamp')
    ]);
}

/* ============================================================
   API: Leaderboard
   ============================================================ */
function cfp_api_get_leaderboard() {
    global $wpdb;
    
    $top_earners = $wpdb->get_results($wpdb->prepare(
        "SELECT username, total_earned, total_wins FROM " . CFP_TABLE_USERS . " 
        WHERE is_banned = 0 ORDER BY total_earned DESC LIMIT 10"
    ));
    
    $top_winners = $wpdb->get_results($wpdb->prepare(
        "SELECT username, total_earned, total_wins FROM " . CFP_TABLE_USERS . " 
        WHERE is_banned = 0 ORDER BY total_wins DESC LIMIT 10"
    ));
    
    return rest_ensure_response([
        'top_earners' => array_map(function($u) {
            return [
                'username' => $u->username,
                'total_earned_sat' => $u->total_earned,
                'total_earned_btc' => $u->total_earned / 100000000
            ];
        }, $top_earners),
        'top_winners' => array_map(function($u) {
            return [
                'username' => $u->username,
                'total_wins' => $u->total_wins
            ];
        }, $top_winners)
    ]);
}

/* ============================================================
   API: User Info
   SECURITY FIX: Endpoint now requires a valid cfp session.
   Users can only fetch their own record; the email URL param is
   ignored — the session token determines which account is returned.
   This eliminates the PII leak / GDPR violation where any anonymous
   caller could enumerate balances, KYC status, and ref codes for
   any account just by knowing (or guessing) an email address.
   ============================================================ */
function cfp_api_get_user( WP_REST_Request $request ) {
    // cfp_get_authenticated_user() reads cfp_session_token from POST body or cookie.
    // REST requests send the token in the JSON body as "cfp_session_token".
    // We temporarily populate $_POST so the existing helper can read it.
    if ( ! isset( $_POST['cfp_session_token'] ) ) {
        $body = $request->get_json_params();
        if ( ! empty( $body['cfp_session_token'] ) ) {
            $_POST['cfp_session_token'] = sanitize_text_field( $body['cfp_session_token'] );
        }
    }

    $user = cfp_get_authenticated_user();
    if ( is_wp_error( $user ) ) {
        return new WP_Error( 'unauthorized', 'Authentication required.', [ 'status' => 401 ] );
    }

    return rest_ensure_response( [
        'username'         => $user->username,
        'balance_sat'      => (int) $user->balance_sat,
        'balance_btc'      => $user->balance_sat / 100000000,
        'total_earned_sat' => (int) $user->total_earned,
        'total_earned_btc' => $user->total_earned / 100000000,
        'total_claims'     => (int) $user->total_claims,
        'total_wins'       => (int) $user->total_wins,
        'xp'               => (int) $user->xp,
        'ref_code'         => $user->ref_code,
    ] );
}

/* ============================================================
   API: Claim Status
   ============================================================ */
function cfp_api_claim_status() {
    $next_claim = cfp_get_next_claim_time();
    $can_claim = cfp_can_claim();
    
    return rest_ensure_response([
        'can_claim' => $can_claim,
        'next_claim_at' => $next_claim ? $next_claim->format('c') : null,
        'seconds_until_claim' => $next_claim ? $next_claim->getTimestamp() - time() : 0
    ]);
}

/* ============================================================
   API: Games List
   ============================================================ */
function cfp_api_get_games() {
    $games = [
        [
            'id' => 'dice',
            'name' => 'Dice',
            'house_edge' => floatval(cfp_get_setting('dice_house_edge', 1)),
            'min_bet' => intval(cfp_get_setting('dice_min_bet', 1)),
            'max_bet' => intval(cfp_get_setting('dice_max_bet', 100000))
        ],
        [
            'id' => 'slots',
            'name' => 'Slots',
            'house_edge' => floatval(cfp_get_setting('slots_house_edge', 5)),
            'min_bet' => intval(cfp_get_setting('slots_min_bet', 1)),
            'max_bet' => intval(cfp_get_setting('slots_max_bet', 10000))
        ],
        [
            'id' => 'wheel',
            'name' => 'Wheel',
            'house_edge' => floatval(cfp_get_setting('wheel_house_edge', 3)),
            'min_bet' => intval(cfp_get_setting('wheel_min_bet', 1)),
            'max_bet' => intval(cfp_get_setting('wheel_max_bet', 50000))
        ],
        [
            'id' => 'coinflip',
            'name' => 'Coin Flip',
            'house_edge' => floatval(cfp_get_setting('coinflip_house_edge', 2)),
            'min_bet' => intval(cfp_get_setting('coinflip_min_bet', 1)),
            'max_bet' => intval(cfp_get_setting('coinflip_max_bet', 100000))
        ],
        [
            'id' => 'crash',
            'name' => 'Crash',
            'house_edge' => floatval(cfp_get_setting('crash_house_edge', 2)),
            'min_bet' => intval(cfp_get_setting('crash_min_bet', 1)),
            'max_bet' => intval(cfp_get_setting('crash_max_bet', 50000))
        ]
    ];
    
    return rest_ensure_response(['games' => $games]);
}

/* ============================================================
   API: Auth Verify (for external integrations)
   ============================================================ */
function cfp_api_auth_verify($data) {
    $email = sanitize_email($data['email'] ?? '');
    $api_key = sanitize_text_field($data['api_key'] ?? '');
    
    if (!is_email($email) || empty($api_key)) {
        return new WP_Error('invalid_params', 'Email and API key required', ['status' => 400]);
    }
    
    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_USERS . " WHERE email = %s", $email
    ));
    
    if (!$user) {
        return new WP_Error('user_not_found', 'User not found', ['status' => 404]);
    }
    
    $stored_key = get_user_meta($user->wp_user_id, 'cfp_api_key', true);
    
    if (empty($stored_key) || !hash_equals($stored_key, $api_key)) {
        return new WP_Error('invalid_key', 'Invalid API key', ['status' => 401]);
    }
    
    return rest_ensure_response([
        'valid' => true,
        'user_id' => $user->id,
        'username' => $user->username,
        'balance_sat' => $user->balance_sat
    ]);
}

/* ============================================================
   ADMIN: API SETTINGS
   ============================================================ */
add_action('cfp_security_extra_cards', function() {
    $api_enabled = cfp_get_setting('rest_api_enabled', '1');
    $api_rate_limit = cfp_get_setting('rest_api_rate_limit', 60);
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🔌 REST API</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Configure REST API access for external integrations.</p>
        
        <form method="post" action="<?=admin_url('admin-post.php')?>">
            <?php wp_nonce_field('cfp_save_api_settings'); ?>
            <input type="hidden" name="action" value="cfp_save_api_settings">
            
            <div style="margin-bottom:16px">
                <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                    <input type="checkbox" name="rest_api_enabled" value="1" <?=checked($api_enabled, '1', false)?>>
                    <span>Enable REST API</span>
                </label>
            </div>
            
            <div style="margin-bottom:16px">
                <label style="font-size:.85rem;color:#777;display:block;margin-bottom:6px">Rate Limit (requests per minute)</label>
                <input type="number" name="rest_api_rate_limit" value="<?=esc_attr($api_rate_limit)?>" min="10" max="600" style="width:200px;padding:8px;background:#111;border:1px solid #333;color:#fff;border-radius:4px">
            </div>
            
            <button type="submit" class="cfp-btn">Save Settings</button>
        </form>
        
        <h3 style="margin-top:24px;color:var(--g)">API Endpoints</h3>
        <table class="cfp-table">
            <thead>
                <tr>
                    <th>Endpoint</th>
                    <th>Method</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                <tr><td>/wp-json/cfp/v1/stats</td><td>GET</td><td>Global statistics</td></tr>
                <tr><td>/wp-json/cfp/v1/price</td><td>GET</td><td>Current crypto prices</td></tr>
                <tr><td>/wp-json/cfp/v1/leaderboard</td><td>GET</td><td>Top earners and winners</td></tr>
                <tr><td>/wp-json/cfp/v1/user/{email}</td><td>GET</td><td>User information</td></tr>
                <tr><td>/wp-json/cfp/v1/claim/status</td><td>GET</td><td>Claim availability</td></tr>
                <tr><td>/wp-json/cfp/v1/games</td><td>GET</td><td>Available games</td></tr>
            </tbody>
        </table>
    </div>
    <?php
});

add_action('admin_post_cfp_save_api_settings', function() {
    check_admin_referer('cfp_save_api_settings');
    
    cfp_update_setting('rest_api_enabled', isset($_POST['rest_api_enabled']) ? '1' : '0');
    cfp_update_setting('rest_api_rate_limit', intval($_POST['rest_api_rate_limit']));
    
    $redirect = wp_validate_redirect( wp_sanitize_redirect( $_POST['_wp_http_referer'] ?? '' ), admin_url() );
    wp_safe_redirect( add_query_arg( 'saved', '1', $redirect ) );
    exit;
});
