<?php
/**
 * Rate Limiting for AJAX Endpoints
 *
 * Prevents abuse by limiting requests per IP/user per time window.
 * Uses database-backed sliding window algorithm for accuracy.
 *
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   RATE LIMIT CONFIGURATION
   ============================================================ */

/**
 * Get rate limit rules for different endpoint types
 * Returns array of [max_requests, window_seconds]
 */
function cfp_get_rate_limits() {
    return [
        'login'      => [5, 300],    // 5 attempts per 5 minutes
        'register'   => [3, 3600],   // 3 registrations per hour
        'claim'      => [2, 120],    // 2 claims per 2 minutes (plus faucet interval)
        'game'       => [30, 60],    // 30 games per minute
        'withdrawal' => [5, 3600],   // 5 withdrawals per hour
        'api'        => [60, 60],    // 60 API calls per minute
        'default'    => [20, 60],    // 20 requests per minute (default)
    ];
}

/* ============================================================
   RATE LIMITING FUNCTIONS
   ============================================================ */

/**
 * Check if request should be rate limited
 *
 * @param string $action Action type (login, claim, game, etc.)
 * @param string $identifier Unique identifier (IP address or user ID)
 * @return bool|WP_Error True if allowed, WP_Error if rate limited
 */
function cfp_check_rate_limit($action, $identifier = null) {
    global $wpdb;

    // Get identifier (IP by default)
    if ($identifier === null) {
        $identifier = cfp_get_real_ip_secure();
    }

    // Get rate limit for this action
    $limits = cfp_get_rate_limits();
    $limit_config = $limits[$action] ?? $limits['default'];
    list($max_requests, $window_seconds) = $limit_config;

    // Check if rate limiting is enabled
    if (cfp_get_setting('rate_limiting_enabled', '1') !== '1') {
        return true; // Rate limiting disabled
    }

    // Create unique key for this action + identifier
    $rate_key = hash('sha256', $action . '|' . $identifier);

    // Clean up old entries first (older than window)
    $cutoff_time = date('Y-m-d H:i:s', time() - $window_seconds);
    $wpdb->query($wpdb->prepare(
        "DELETE FROM " . CFP_TABLE_IP_LIMITS . " WHERE action_type = %s AND window_start < %s",
        $action,
        $cutoff_time
    ));

    // Count requests in current window
    $request_count = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . CFP_TABLE_IP_LIMITS . "
         WHERE ip_address = %s AND action_type = %s AND window_start >= %s",
        $rate_key,
        $action,
        $cutoff_time
    ));

    // Check if limit exceeded
    if ($request_count >= $max_requests) {
        // Calculate retry time
        $oldest_request = $wpdb->get_var($wpdb->prepare(
            "SELECT window_start FROM " . CFP_TABLE_IP_LIMITS . "
             WHERE ip_address = %s AND action_type = %s
             ORDER BY window_start ASC LIMIT 1",
            $rate_key,
            $action
        ));

        if ($oldest_request) {
            $retry_after = $window_seconds - (time() - strtotime($oldest_request));
            $retry_after = max(1, $retry_after);
        } else {
            $retry_after = $window_seconds;
        }

        // Log rate limit violation
        cfp_security_log('rate_limit_exceeded', 0, [
            'action' => $action,
            'ip' => $identifier,
            'limit' => $max_requests,
            'window' => $window_seconds,
            'retry_after' => $retry_after
        ], 'warning');

        return new WP_Error(
            'rate_limit_exceeded',
            sprintf(
                'Too many requests. Please wait %d seconds before trying again.',
                $retry_after
            ),
            ['retry_after' => $retry_after]
        );
    }

    // Record this request
    $wpdb->insert(CFP_TABLE_IP_LIMITS, [
        'ip_address' => $rate_key,
        'action_type' => $action,
        'hit_count' => 1,
        'window_start' => current_time('mysql')
    ], ['%s', '%s', '%d', '%s']);

    return true;
}

/**
 * Check rate limit and send error if exceeded
 * Use this in AJAX handlers for automatic error response
 *
 * @param string $action Action type
 * @param string $identifier Optional identifier
 */
function cfp_require_rate_limit($action, $identifier = null) {
    $result = cfp_check_rate_limit($action, $identifier);

    if (is_wp_error($result)) {
        $data = $result->get_error_data();
        wp_send_json_error([
            'msg' => $result->get_error_message(),
            'retry_after' => $data['retry_after'] ?? 60
        ], 429); // HTTP 429 Too Many Requests
    }

    return true;
}

/**
 * Get remaining requests for identifier
 *
 * @param string $action Action type
 * @param string $identifier Identifier (IP or user ID)
 * @return array ['remaining' => int, 'reset_in' => int]
 */
function cfp_get_rate_limit_status($action, $identifier = null) {
    global $wpdb;

    if ($identifier === null) {
        $identifier = cfp_get_real_ip_secure();
    }

    $limits = cfp_get_rate_limits();
    $limit_config = $limits[$action] ?? $limits['default'];
    list($max_requests, $window_seconds) = $limit_config;

    $rate_key = hash('sha256', $action . '|' . $identifier);
    $cutoff_time = date('Y-m-d H:i:s', time() - $window_seconds);

    $request_count = (int) $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . CFP_TABLE_IP_LIMITS . "
         WHERE ip_address = %s AND action_type = %s AND window_start >= %s",
        $rate_key,
        $action,
        $cutoff_time
    ));

    $oldest_request = $wpdb->get_var($wpdb->prepare(
        "SELECT window_start FROM " . CFP_TABLE_IP_LIMITS . "
         WHERE ip_address = %s AND action_type = %s
         ORDER BY window_start ASC LIMIT 1",
        $rate_key,
        $action
    ));

    $reset_in = 0;
    if ($oldest_request) {
        $reset_in = $window_seconds - (time() - strtotime($oldest_request));
        $reset_in = max(0, $reset_in);
    }

    return [
        'limit' => $max_requests,
        'used' => $request_count,
        'remaining' => max(0, $max_requests - $request_count),
        'reset_in' => $reset_in,
        'window' => $window_seconds
    ];
}

/* ============================================================
   CLEANUP CRON JOB
   ============================================================ */

// Schedule cleanup cron
add_action('cfp_rate_limit_cleanup', 'cfp_cleanup_rate_limits');
add_action( 'init', function() {
    if ( ! wp_next_scheduled( 'cfp_rate_limit_cleanup' ) ) {
        wp_schedule_event( time(), 'hourly', 'cfp_rate_limit_cleanup' );
    }
} );

/**
 * Clean up old rate limit entries
 * Runs hourly to keep table size manageable
 */
function cfp_cleanup_rate_limits() {
    global $wpdb;

    // Delete entries older than 24 hours
    $cutoff = date('Y-m-d H:i:s', time() - DAY_IN_SECONDS);

    $deleted = $wpdb->query($wpdb->prepare(
        "DELETE FROM " . CFP_TABLE_IP_LIMITS . " WHERE window_start < %s",
        $cutoff
    ));

    if ($deleted > 0) {
        error_log("[CFP Rate Limit] Cleaned up {$deleted} old rate limit entries");
    }

    // Optimize table
    $wpdb->query("OPTIMIZE TABLE " . CFP_TABLE_IP_LIMITS);
}

/* ============================================================
   HTTP HEADERS FOR RATE LIMITING
   ============================================================ */

/**
 * Add rate limit headers to response
 *
 * @param string $action Action type
 */
function cfp_send_rate_limit_headers($action) {
    $status = cfp_get_rate_limit_status($action);

    header('X-RateLimit-Limit: ' . $status['limit']);
    header('X-RateLimit-Remaining: ' . $status['remaining']);
    header('X-RateLimit-Reset: ' . (time() + $status['reset_in']));

    if ($status['remaining'] == 0) {
        header('Retry-After: ' . $status['reset_in']);
    }
}

/* ============================================================
   ADMIN: RATE LIMIT CONFIGURATION
   ============================================================ */

add_action('cfp_security_extra_cards', function() {
    $limits = cfp_get_rate_limits();
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>⏱️ Rate Limiting</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">
            Prevent abuse by limiting requests per IP address. All limits are enforced automatically.
        </p>

        <table class="cfp-table">
            <thead>
                <tr>
                    <th>Action</th>
                    <th>Max Requests</th>
                    <th>Time Window</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($limits as $action => $config): ?>
                <tr>
                    <td style="font-weight:700"><?=ucfirst($action)?></td>
                    <td><?=$config[0]?> requests</td>
                    <td><?=cfp_format_duration($config[1])?></td>
                    <td><span style="color:#0f0">✓ Active</span></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <div style="margin-top:16px;padding:12px;background:#1a1a1a;border-radius:8px">
            <label style="display:flex;align-items:center;cursor:pointer">
                <input type="checkbox" id="cfp-rate-limiting-enabled"
                       <?=cfp_get_setting('rate_limiting_enabled','1')==='1'?'checked':''?>
                       onchange="cfpSaveRateLimitSetting(this.checked)">
                <span style="margin-left:8px;font-weight:700">Enable Rate Limiting (Recommended)</span>
            </label>
            <p style="margin:8px 0 0 28px;font-size:.8rem;color:#777">
                Disabling rate limiting may expose your site to abuse and DDoS attacks.
            </p>
        </div>
    </div>

    <script>
    async function cfpSaveRateLimitSetting(enabled) {
        const fd = new FormData();
        fd.append('action', 'cfp_admin_save_setting');
        fd.append('nonce', '<?=wp_create_nonce('cfp_admin_action')?>');
        fd.append('key', 'rate_limiting_enabled');
        fd.append('value', enabled ? '1' : '0');

        try {
            await fetch('<?=admin_url('admin-ajax.php')?>', {method: 'POST', body: fd});
            alert(enabled ? 'Rate limiting enabled' : 'Rate limiting disabled');
        } catch(e) {
            alert('Error saving setting');
        }
    }
    </script>
    <?php
});

/**
 * Helper function to format duration in human-readable format
 */
function cfp_format_duration($seconds) {
    if ($seconds < 60) {
        return $seconds . ' seconds';
    } elseif ($seconds < 3600) {
        $minutes = floor($seconds / 60);
        return $minutes . ' minute' . ($minutes > 1 ? 's' : '');
    } else {
        $hours = floor($seconds / 3600);
        return $hours . ' hour' . ($hours > 1 ? 's' : '');
    }
}

/* ============================================================
   ADMIN AJAX: View Current Rate Limits
   ============================================================ */

add_action('wp_ajax_cfp_view_rate_limits', function() {
    check_ajax_referer('cfp_admin_action', 'nonce');

    if (!current_user_can('manage_options')) {
        wp_send_json_error(['msg' => 'Unauthorized']);
    }

    global $wpdb;

    // Get top rate-limited IPs in last hour
    $cutoff = date('Y-m-d H:i:s', time() - 3600);
    $top_ips = $wpdb->get_results($wpdb->prepare(
        "SELECT ip_address, action_type, COUNT(*) as count, MAX(window_start) as last_hit
         FROM " . CFP_TABLE_IP_LIMITS . "
         WHERE window_start >= %s
         GROUP BY ip_address, action_type
         ORDER BY count DESC
         LIMIT 50",
        $cutoff
    ), ARRAY_A);

    wp_send_json_success(['limits' => $top_ips]);
});
