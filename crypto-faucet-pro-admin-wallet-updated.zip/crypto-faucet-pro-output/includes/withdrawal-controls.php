<?php
/**
 * Withdrawal Controls — cooling period, large-win delay, daily caps
 *
 * Enforced at the cfp_ajax_withdraw level via hooks:
 *
 *  1. Cooling period after large wins:
 *     If a user won more than X sat in the last Y hours, they cannot
 *     withdraw until the cooling window passes. Configurable in admin.
 *
 *  2. Daily withdrawal cap per user:
 *     Users cannot withdraw more than N sat in a rolling 24-hour window.
 *
 *  3. New account hold:
 *     Accounts younger than N days cannot withdraw (prevents hit-and-run).
 *
 *  4. Suspicious win-rate flag:
 *     If a user's game win rate in the last 24h is above the threshold
 *     (default 80%), their withdrawal is held for manual review.
 *
 * All limits are configurable in Security settings and default to safe values.
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   MAIN GATE — called inside cfp_ajax_withdraw() before payout
   Add this call at the top of cfp_ajax_withdraw after user lookup.
   Hooked via 'cfp_before_withdraw' action.
   ============================================================ */
add_action('cfp_before_withdraw', 'cfp_withdrawal_controls_gate', 10, 2);
function cfp_withdrawal_controls_gate( $user, $amount ) {
    global $wpdb;

    /* --- 1. New account hold --------------------------------- */
    $hold_days = intval( cfp_get_setting('withdraw_new_account_hold_days', 1) );
    if ( $hold_days > 0 ) {
        $age_days = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT DATEDIFF(NOW(), created_at) FROM " . CFP_TABLE_USERS . " WHERE id=%d",
            $user->id
        ));
        if ( $age_days < $hold_days ) {
            $remaining = $hold_days - $age_days;
            wp_send_json_error(['msg' => "🕐 New accounts must be at least {$hold_days} day(s) old to withdraw. {$remaining} day(s) remaining."]);
        }
    }

    /* --- 2. Cooling period after large wins ------------------ */
    $cooling_hours      = intval( cfp_get_setting('withdraw_cooling_hours', 24) );
    $cooling_win_thresh = intval( cfp_get_setting('withdraw_cooling_win_sat', 500000) );
    if ( $cooling_hours > 0 && $cooling_win_thresh > 0 ) {
        $recent_wins = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_TRANSACTIONS .
            " WHERE user_id=%d AND amount_sat > 0
              AND type IN ('slots_win','coinflip_win','dice_win','crash_win','wheel_win','multiply_win','jackpot_win','don_win')
              AND created_at >= DATE_SUB(NOW(), INTERVAL %d HOUR)",
            $user->id, $cooling_hours
        ));
        if ( $recent_wins >= $cooling_win_thresh ) {
            // Check if the cooling period has fully elapsed since the last big win
            $last_big_win = $wpdb->get_var( $wpdb->prepare(
                "SELECT MAX(created_at) FROM " . CFP_TABLE_TRANSACTIONS .
                " WHERE user_id=%d AND amount_sat >= %d
                  AND type IN ('slots_win','coinflip_win','dice_win','crash_win','wheel_win','multiply_win','jackpot_win','don_win')",
                $user->id, $cooling_win_thresh
            ));
            if ( $last_big_win ) {
                $elapsed_h = ( time() - strtotime($last_big_win) ) / 3600;
                if ( $elapsed_h < $cooling_hours ) {
                    $left = ceil($cooling_hours - $elapsed_h);
                    wp_send_json_error(['msg' => "⏳ Large win detected! A {$cooling_hours}-hour cooling period is required before withdrawal. {$left} hour(s) remaining."]);
                }
            }
        }
    }

    /* --- 3. Daily withdrawal cap ----------------------------- */
    $daily_cap = intval( cfp_get_setting('withdraw_daily_cap_sat', 0) );
    if ( $daily_cap > 0 ) {
        $today_withdrawn = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(ABS(amount_sat)),0) FROM " . CFP_TABLE_TRANSACTIONS .
            " WHERE user_id=%d
              AND type IN ('faucetpay_withdrawal','withdrawal_pending')
              AND DATE(created_at) = CURDATE()",
            $user->id
        ));
        if ( $today_withdrawn + $amount > $daily_cap ) {
            $remaining = max(0, $daily_cap - $today_withdrawn);
            wp_send_json_error(['msg' => "📊 Daily withdrawal cap of " . number_format($daily_cap) . " sat reached. You have " . number_format($remaining) . " sat remaining today."]);
        }
    }

    /* --- 4. Suspicious win-rate flag ------------------------- */
    $flag_winrate = intval( cfp_get_setting('withdraw_flag_winrate', 0) ); // 0 = disabled, e.g. 85 = flag above 85%
    if ( $flag_winrate > 0 ) {
        $game_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT type FROM " . CFP_TABLE_TRANSACTIONS .
            " WHERE user_id=%d
              AND type REGEXP 'win|loss'
              AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)
              AND type NOT IN ('slots_win','slots_loss','coinflip_win','coinflip_loss','dice_win','dice_loss','crash_win','crash_loss','wheel_win','wheel_loss','multiply_win','multiply_loss','don_win','don_loss')",
            $user->id
        ));
        // Recount correctly
        $all_games = $wpdb->get_results( $wpdb->prepare(
            "SELECT type FROM " . CFP_TABLE_TRANSACTIONS .
            " WHERE user_id=%d
              AND (type LIKE '%_win' OR type LIKE '%_loss')
              AND type NOT IN ('jackpot_win','don_win','don_loss')
              AND created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)",
            $user->id
        ));
        $total_g = count($all_games);
        $wins_g  = count(array_filter($all_games, fn($r) => str_contains($r->type,'_win')));
        if ( $total_g >= 20 && $wins_g / $total_g * 100 >= $flag_winrate ) {
            // Flag account for review — don't hard-block, just notify admin and hold
            cfp_audit_log('suspicious_winrate_flagged', [
                'user_id'  => $user->id,
                'email'    => $user->email,
                'wins'     => $wins_g,
                'total'    => $total_g,
                'winrate'  => round($wins_g/$total_g*100,1),
                'amount'   => $amount,
            ]);
            // Send admin email notification
            $admin_email = get_option('admin_email');
            wp_mail(
                $admin_email,
                '⚠️ CFP: Suspicious win rate on withdrawal',
                "User {$user->email} (ID {$user->id}) has a " . round($wins_g/$total_g*100,1) . "% win rate in the last 24h and is attempting to withdraw " . number_format($amount) . " sat.\n\nReview: " . admin_url('admin.php?page=cfp-users')
            );
            // Hold for manual review
            wp_send_json_error(['msg' => '🔍 Your withdrawal has been flagged for manual review due to unusual activity. Our team will process it within 24 hours.']);
        }
    }
}

/* ============================================================
   ADMIN SETTINGS UI (injected into Security page)
   These fields are saved by the existing cfp_save_security handler.
   ============================================================ */
// Fields already added to the $fields array via the earlier patch.
// This function renders the UI card — called from cfp_admin_security() hook.
add_action('cfp_security_extra_cards', 'cfp_withdrawal_controls_admin_ui');
function cfp_withdrawal_controls_admin_ui() {
    $gs = fn($k,$d='') => cfp_get_setting($k,$d);
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>💸 Withdrawal Controls</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Cooling periods, daily caps, and fraud detection for withdrawals.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>New account hold (days before first withdrawal)</label>
                <input type="number" name="withdraw_new_account_hold_days" value="<?=esc_attr($gs('withdraw_new_account_hold_days',1))?>" min="0">
                <span class="hint">0 = disabled. 1 = must be 1+ day old. Prevents hit-and-run abuse.</span>
            </div>
            <div class="cfp-field">
                <label>Cooling period after large win (hours)</label>
                <input type="number" name="withdraw_cooling_hours" value="<?=esc_attr($gs('withdraw_cooling_hours',24))?>" min="0">
                <span class="hint">0 = disabled. How long to block withdrawal after a big win.</span>
            </div>
            <div class="cfp-field">
                <label>Large win threshold for cooling (sat)</label>
                <input type="number" name="withdraw_cooling_win_sat" value="<?=esc_attr($gs('withdraw_cooling_win_sat',500000))?>" min="0">
                <span class="hint">Win this much in the cooling window to trigger the hold. e.g. 500000 = 0.005 BTC.</span>
            </div>
            <div class="cfp-field">
                <label>Daily withdrawal cap per user (sat, 0 = unlimited)</label>
                <input type="number" name="withdraw_daily_cap_sat" value="<?=esc_attr($gs('withdraw_daily_cap_sat',0))?>" min="0">
            </div>
            <div class="cfp-field">
                <label>Flag withdrawal if 24h win rate above (%, 0 = disabled)</label>
                <input type="number" name="withdraw_flag_winrate" value="<?=esc_attr($gs('withdraw_flag_winrate',0))?>" min="0" max="100">
                <span class="hint">e.g. 85 = flag accounts winning 85%+ of games before withdrawal (min 20 games). Sends admin email.</span>
            </div>
        </div>
    </div>
    <?php
}
