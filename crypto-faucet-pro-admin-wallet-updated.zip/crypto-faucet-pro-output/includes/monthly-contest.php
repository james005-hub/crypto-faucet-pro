<?php
/**
 * Monthly Hi-Lo Contest — tracks wagered sat per calendar month,
 * pays out prize pool to top 10 players, auto-resets each month.
 *
 * Tables used: CFP_TABLE_MULTIPLY (existing) — queries by month.
 * Prize funded from admin settings (cfp_monthly_prize_sat).
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   CRON: End-of-month contest payout
   ============================================================ */
add_action('cfp_monthly_contest_hook', 'cfp_run_monthly_contest');

// Schedule on first day of each month at 00:05
add_action('init', function() {
    if ( ! wp_next_scheduled('cfp_monthly_contest_hook') ) {
        // Find next 1st of month midnight
        $next = mktime(0, 5, 0, intval(date('n'))+1, 1, intval(date('Y')));
        wp_schedule_single_event($next, 'cfp_monthly_contest_hook');
    }
});

function cfp_run_monthly_contest( $month = null, $year = null ) {
    if ( ! cfp_get_setting('monthly_contest_enabled','1') ) return;

    $month = $month ?? intval(date('n', strtotime('-1 month')));
    $year  = $year  ?? intval(date('Y', strtotime('-1 month')));

    global $wpdb;

    // Get top 10 by total wagered sat that month across Hi-Lo games
    $winners = $wpdb->get_results($wpdb->prepare(
        "SELECT m.user_id, u.username, u.email,
                SUM(m.bet_sat) AS total_wagered,
                SUM(m.payout_sat) AS total_payout,
                COUNT(*) AS games_played
         FROM " . CFP_TABLE_MULTIPLY . " m
         LEFT JOIN " . CFP_TABLE_USERS . " u ON m.user_id = u.id
         WHERE MONTH(m.played_at) = %d AND YEAR(m.played_at) = %d
           AND u.is_banned = 0
         GROUP BY m.user_id
         ORDER BY total_wagered DESC
         LIMIT 10",
        $month, $year
    ));

    if ( empty($winners) ) {
        // Reschedule for next month and bail
        cfp_reschedule_monthly_contest();
        return;
    }

    $prize_pool  = intval(cfp_get_setting('monthly_contest_prize_sat', 5000000));
    $prize_splits = cfp_monthly_prize_splits($prize_pool, count($winners));
    $month_label  = date('F Y', mktime(0,0,0,$month,1,$year));

    $results = [];
    foreach ( $winners as $rank => $w ) {
        $prize = $prize_splits[$rank] ?? 0;
        if ( $prize <= 0 ) continue;

        $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
            $prize, $w->user_id
        ));
        $wpdb->insert(CFP_TABLE_TRANSACTIONS, [
            'user_id'     => $w->user_id,
            'type'        => 'monthly_contest_prize',
            'amount_sat'  => $prize,
            'description' => "Monthly Hi-Lo Contest #".($rank+1)." place — {$month_label}",
        ]);

        // Send email notification
        wp_mail(
            $w->email,
            "🏆 Monthly Contest — You placed #".($rank+1)." — ".get_bloginfo('name'),
            "Congratulations {$w->username}!\n\nYou placed #".($rank+1)." in the {$month_label} Hi-Lo Contest.\n\nYour prize of ".number_format($prize)." sat has been added to your balance.\n\nWagered: ".number_format($w->total_wagered)." sat | Games: ".$w->games_played."\n\nKeep playing to win next month!\n\n".home_url('/')
        );

        $results[] = ['rank'=>$rank+1,'username'=>$w->username,'prize'=>$prize,'wagered'=>$w->total_wagered];
    }

    // Store results for admin display
    $history = get_option('cfp_contest_history', []);
    array_unshift($history, [
        'month'   => $month_label,
        'results' => $results,
        'prize_pool' => $prize_pool,
        'run_at'  => current_time('mysql'),
    ]);
    update_option('cfp_contest_history', array_slice($history, 0, 24)); // keep 2 years

    // Notify admin
    wp_mail(
        get_option('admin_email'),
        "Monthly Contest Completed — {$month_label}",
        "Monthly Hi-Lo Contest for {$month_label} has been paid out.\n\nPrize pool: ".number_format($prize_pool)." sat\nWinners: ".count($results)."\n\nTop winner: ".(isset($results[0])?$results[0]['username'].' — '.number_format($results[0]['prize']).' sat':'n/a')
    );

    cfp_reschedule_monthly_contest();
}

function cfp_reschedule_monthly_contest() {
    wp_clear_scheduled_hook('cfp_monthly_contest_hook');
    $next = mktime(0, 5, 0, intval(date('n'))+1, 1, intval(date('Y')));
    wp_schedule_single_event($next, 'cfp_monthly_contest_hook');
}

/**
 * Split prize pool across top N finishers.
 * Distribution: 1st=40%, 2nd=20%, 3rd=12%, 4th=8%, 5th=5%, 6-10=3% each
 */
function cfp_monthly_prize_splits( $pool, $n ) {
    $pcts = [40, 20, 12, 8, 5, 3, 3, 3, 3, 3];
    $splits = [];
    for ($i = 0; $i < $n; $i++) {
        $splits[$i] = (int)floor($pool * ($pcts[$i] ?? 0) / 100);
    }
    return $splits;
}

/* ============================================================
   AJAX: Manual trigger (admin only)
   ============================================================ */
add_action('wp_ajax_cfp_run_contest_now', function() {
    if ( ! current_user_can('manage_options') ) wp_send_json_error(['msg'=>'Unauthorized.']);
    check_ajax_referer('cfp_contest_nonce','nonce');
    $month = intval($_POST['month'] ?? date('n', strtotime('-1 month')));
    $year  = intval($_POST['year']  ?? date('Y', strtotime('-1 month')));
    cfp_run_monthly_contest($month, $year);
    wp_send_json_success(['msg'=>"✅ Contest run for ".date('F Y', mktime(0,0,0,$month,1,$year))."."]);
});

/* ============================================================
   SHORTCODE: [cfp_monthly_contest]
   Live leaderboard + countdown to next payout
   ============================================================ */
add_shortcode('cfp_monthly_contest', function() {
    global $wpdb;
    if ( ! cfp_get_setting('monthly_contest_enabled','1') )
        return '<p style="color:#555;text-align:center">Monthly contest is currently disabled.</p>';

    $prize_pool  = intval(cfp_get_setting('monthly_contest_prize_sat', 5000000));
    $splits      = cfp_monthly_prize_splits($prize_pool, 10);
    $month_label = date('F Y');

    // Current month standings
    $standings = $wpdb->get_results(
        "SELECT m.user_id, u.username, u.xp_level,
                SUM(m.bet_sat) AS total_wagered,
                COUNT(*) AS games_played
         FROM " . CFP_TABLE_MULTIPLY . " m
         LEFT JOIN " . CFP_TABLE_USERS . " u ON m.user_id = u.id
         WHERE MONTH(m.played_at) = MONTH(NOW()) AND YEAR(m.played_at) = YEAR(NOW())
           AND u.is_banned = 0
         GROUP BY m.user_id
         ORDER BY total_wagered DESC
         LIMIT 10"
    );

    // Days left in month
    $days_left = intval(date('t')) - intval(date('j'));
    $levels = function_exists('cfp_xp_levels') ? cfp_xp_levels() : [];

    ob_start(); ?>
    <div class="cfp-widget" id="cfp-contest-widget">
        <div style="text-align:center;margin-bottom:18px">
            <div style="font-size:2.5rem">🏆</div>
            <h2 style="margin:4px 0">Monthly Hi-Lo Contest</h2>
            <p class="sub" style="margin:0"><?=esc_html($month_label)?> · <?=$days_left?> day<?=$days_left!==1?'s':''?> remaining</p>
            <div style="display:inline-block;background:linear-gradient(135deg,#f7931a,#ffcc02);color:#000;font-family:'Oswald',sans-serif;font-size:1.3rem;font-weight:900;padding:8px 24px;border-radius:8px;margin-top:10px">
                Prize Pool: <?=number_format($prize_pool)?> sat
            </div>
        </div>

        <!-- Prize breakdown -->
        <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin-bottom:18px">
            <?php foreach(array_slice($splits,0,5) as $rank=>$prize): ?>
            <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:8px;padding:8px;text-align:center">
                <div style="font-size:.75rem;color:#555"><?=["🥇","🥈","🥉","4th","5th"][$rank]?></div>
                <div style="font-family:'Oswald',sans-serif;font-weight:700;color:<?=["#ffd700","#c0c0c0","#cd7f32","#f7931a","#555"][$rank]?>;font-size:.95rem"><?=number_format($prize)?></div>
                <div style="font-size:.65rem;color:#333">sat</div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Live standings -->
        <table style="width:100%;border-collapse:collapse">
            <thead><tr>
                <th style="padding:8px;text-align:left;color:#444;font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid #1c1c1c">#</th>
                <th style="padding:8px;text-align:left;color:#444;font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid #1c1c1c">Player</th>
                <th style="padding:8px;text-align:right;color:#444;font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid #1c1c1c">Wagered (sat)</th>
                <th style="padding:8px;text-align:right;color:#444;font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid #1c1c1c">Prize</th>
            </tr></thead>
            <tbody>
            <?php if (empty($standings)): ?>
            <tr><td colspan="4" style="text-align:center;color:#555;padding:30px;font-size:.88rem">
                No games played yet this month. Play Hi-Lo to get on the leaderboard! 🎲
            </td></tr>
            <?php else: foreach($standings as $i=>$s):
                $medal = ['🥇','🥈','🥉'][$i] ?? '#'.($i+1);
                $color = ['#ffd700','#c0c0c0','#cd7f32'][$i] ?? '#888';
                $prize = $splits[$i] ?? 0;
                $icon  = $levels[$s->xp_level]['icon'] ?? '🌱';
            ?>
            <tr style="border-bottom:1px solid #141414">
                <td style="padding:10px 8px;font-size:1.1rem"><?=$medal?></td>
                <td style="padding:10px 8px">
                    <span style="font-weight:700;color:<?=$color?>"><?=esc_html($s->username)?></span>
                    <span style="font-size:.8rem;margin-left:4px"><?=$icon?></span>
                    <div style="font-size:.72rem;color:#555"><?=number_format($s->games_played)?> games</div>
                </td>
                <td style="padding:10px 8px;text-align:right;font-family:'Oswald',sans-serif;font-weight:700;color:var(--cfp-p)"><?=number_format($s->total_wagered)?></td>
                <td style="padding:10px 8px;text-align:right;color:#22c55e;font-weight:700;font-size:.9rem"><?=$prize>0?'+'.number_format($prize):'—'?></td>
            </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>

        <p style="font-size:.76rem;color:#333;text-align:center;margin-top:14px">
            Ranking by total sat wagered on Hi-Lo this month. Top 10 win prizes. Resets <?=date('M 1', strtotime('first day of next month'))?>.
        </p>
    </div>
    <?php return ob_get_clean();
});

/* ============================================================
   ADMIN: Monthly Contest Settings & History Page
   ============================================================ */
function cfp_admin_monthly_contest() {
    global $wpdb;
    $saved = false;
    if ( isset($_POST['cfp_save_contest']) && check_admin_referer('cfp_contest') ) {
        cfp_update_setting('monthly_contest_enabled', sanitize_text_field($_POST['monthly_contest_enabled'] ?? '1'));
        cfp_update_setting('monthly_contest_prize_sat', intval($_POST['monthly_contest_prize_sat'] ?? 5000000));
        $saved = true;
    }

    $next_run   = wp_next_scheduled('cfp_monthly_contest_hook');
    $history    = get_option('cfp_contest_history', []);
    $prize_pool = intval(cfp_get_setting('monthly_contest_prize_sat', 5000000));
    $contest_nonce = wp_create_nonce('cfp_contest_nonce');

    // Current month preview
    $cur_standings = $wpdb->get_results(
        "SELECT u.username, SUM(m.bet_sat) as wager, COUNT(*) as plays
         FROM ".CFP_TABLE_MULTIPLY." m LEFT JOIN ".CFP_TABLE_USERS." u ON m.user_id=u.id
         WHERE MONTH(m.played_at)=MONTH(NOW()) AND YEAR(m.played_at)=YEAR(NOW()) AND u.is_banned=0
         GROUP BY m.user_id ORDER BY wager DESC LIMIT 10"
    );
    ?>
    <div class="cfp-wrap">
    <div class="cfp-header"><span class="cfp-logo-badge">⚡ CFP</span><h1>🏆 Monthly Hi-Lo Contest</h1></div>
    <?php if($saved): ?><div class="cfp-notice success">✅ Contest settings saved!</div><?php endif; ?>

    <div class="cfp-2col">
    <div>
    <!-- Settings -->
    <form method="post">
    <?php wp_nonce_field('cfp_contest'); ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>Contest Settings</h2>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Monthly Contest</label>
                <select name="monthly_contest_enabled" style="background:#111">
                    <option value="1" <?=selected(cfp_get_setting('monthly_contest_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected(cfp_get_setting('monthly_contest_enabled','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Monthly Prize Pool (sat)</label>
                <input type="number" name="monthly_contest_prize_sat" value="<?=esc_attr($prize_pool)?>" min="0">
                <span class="hint">Paid out from your admin wallet / faucet balance. Set to 0 to disable prize.</span>
            </div>
        </div>
        <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:8px;padding:12px;margin-top:14px;font-size:.82rem;color:#777">
            Next auto-payout: <?=$next_run ? date('M j, Y H:i', $next_run) : 'Not scheduled'?><br>
            Prize splits: 1st=40% · 2nd=20% · 3rd=12% · 4th=8% · 5th=5% · 6th–10th=3% each
        </div>
        <button type="submit" name="cfp_save_contest" class="cfp-btn cfp-btn-gold" style="margin-top:14px">💾 Save</button>
    </div>
    </form>

    <!-- Manual run -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>▶️ Manual Run</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:12px">Run the payout for a specific month manually. Use for testing or if the cron missed a run.</p>
        <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
            <select id="cm-month" style="background:#111;border:1px solid #2a2a2a;color:#aaa;padding:8px;border-radius:8px">
                <?php for($m=1;$m<=12;$m++): ?>
                <option value="<?=$m?>" <?=$m==intval(date('n',strtotime('-1 month')))?'selected':''?>><?=date('F',mktime(0,0,0,$m,1))?></option>
                <?php endfor; ?>
            </select>
            <input type="number" id="cm-year" value="<?=date('Y')?>" style="background:#111;border:1px solid #2a2a2a;color:#aaa;padding:8px;border-radius:8px;width:80px">
            <button onclick="cfpRunContest()" class="cfp-btn cfp-btn-gold">▶ Run Payout</button>
        </div>
        <div id="cm-result" style="margin-top:10px"></div>
    </div>
    </div>

    <div>
    <!-- Current month leaderboard -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>📊 This Month — <?=date('F Y')?></h2>
        <table class="cfp-table">
            <thead><tr><th>#</th><th>Player</th><th>Wagered</th><th>Games</th><th>Prize</th></tr></thead>
            <tbody>
            <?php $splits=cfp_monthly_prize_splits($prize_pool,10);
            foreach($cur_standings as $i=>$s): ?>
            <tr>
                <td><?=$i+1?></td>
                <td style="font-weight:700"><?=esc_html($s->username)?></td>
                <td style="color:var(--g)"><?=number_format($s->wager)?> sat</td>
                <td style="color:var(--mt)"><?=$s->plays?></td>
                <td style="color:#22c55e;font-weight:700"><?=isset($splits[$i])?'+'.number_format($splits[$i]):'—'?></td>
            </tr>
            <?php endforeach; if(empty($cur_standings)): ?>
            <tr><td colspan="5" style="text-align:center;color:var(--mt);padding:20px">No games this month yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    </div>
    </div>

    <!-- History -->
    <?php if (!empty($history)): ?>
    <div class="cfp-card">
        <h2>📜 Contest History</h2>
        <?php foreach(array_slice($history,0,6) as $h): ?>
        <div style="border-bottom:1px solid #1c1c1c;padding:12px 0">
            <div style="display:flex;justify-content:space-between;margin-bottom:6px">
                <strong style="color:#fff"><?=esc_html($h['month'])?></strong>
                <span style="font-size:.78rem;color:#555">Prize pool: <?=number_format($h['prize_pool'])?> sat</span>
            </div>
            <div style="display:flex;gap:12px;flex-wrap:wrap">
            <?php foreach(array_slice($h['results'],0,3) as $w): ?>
                <span style="font-size:.8rem;color:#aaa">
                    <?=["🥇","🥈","🥉"][$w['rank']-1]?> <?=esc_html($w['username'])?> — <strong style="color:#22c55e">+<?=number_format($w['prize'])?> sat</strong>
                </span>
            <?php endforeach; ?>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
    </div>

    <script>
    async function cfpRunContest(){
        const month=document.getElementById('cm-month').value;
        const year=document.getElementById('cm-year').value;
        const el=document.getElementById('cm-result');
        el.innerHTML='<span style="color:#f7931a">Running…</span>';
        const fd=new FormData(); fd.append('action','cfp_run_contest_now'); fd.append('nonce','<?=esc_js($contest_nonce)?>');
        fd.append('month',month); fd.append('year',year);
        const r=await fetch(ajaxurl,{method:'POST',body:fd}); const d=await r.json();
        el.innerHTML=`<div class="${d.success?'cfp-notice success':'cfp-notice error'}">${d.data.msg}</div>`;
        if(d.success) setTimeout(()=>location.reload(),1500);
    }
    </script>
    <?php
}
