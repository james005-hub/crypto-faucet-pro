<?php
/**
 * CFP NOWPayments → Trezor Sweep System
 *
 * Revenue from games, fees, ads, etc. accumulates in the admin wallet ledger
 * (cfp_admin_wallet table). Real BTC/crypto is swept on-chain to your Trezor
 * hardware wallet via the NOWPayments Mass Payout API.
 *
 * THREE SWEEP TIERS:
 *
 *   Tier 1 — NOWPayments API Auto-Sweep (preferred):
 *     When accumulated ledger balance exceeds the configured threshold,
 *     the system calls cfp_np_send_payout() to send crypto directly on-chain
 *     to your Trezor address. Fires on every wallet credit AND via cron.
 *
 *   Tier 2 — Cron Scheduled Sweep (every 12 hours):
 *     Catches any sweeps missed in Tier 1 (network down, API hiccup, etc.).
 *
 *   Tier 3 — Manual Signing Queue:
 *     If the NOWPayments API sweep fails, the pending sweep is queued.
 *     Admin sees it in Admin Wallet → Trezor Sweep and can retry or
 *     manually mark as sent.
 *
 * REQUIREMENTS:
 *   - NOWPayments API key configured (WP Admin → NOWPayments Settings)
 *   - NOWPayments account must have "Allow API withdrawals" enabled
 *   - Trezor destination address whitelisted in NOWPayments account settings
 *
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// DATABASE — SWEEP QUEUE TABLE
// ============================================================

function cfp_trezor_sweep_create_table() {
    global $wpdb;
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    $charset = $wpdb->get_charset_collate();

    dbDelta( "CREATE TABLE {$wpdb->prefix}cfp_trezor_sweep_queue (
        id           bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        type         varchar(30)  NOT NULL DEFAULT 'auto_sweep' COMMENT 'auto_sweep|manual_sweep|cron_sweep',
        coin         varchar(20)  NOT NULL DEFAULT 'BTC',
        amount_sat   bigint(20)   NOT NULL DEFAULT 0,
        to_address   varchar(255) NOT NULL,
        status       varchar(20)  NOT NULL DEFAULT 'pending' COMMENT 'pending|sent|failed|cancelled',
        np_payout_id varchar(100) DEFAULT NULL COMMENT 'NOWPayments payout ID on success',
        tx_hash      varchar(255) DEFAULT NULL,
        error_msg    text         DEFAULT NULL,
        note         text         DEFAULT NULL,
        attempts     tinyint(3)   NOT NULL DEFAULT 0,
        created_at   datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at   datetime     DEFAULT NULL,
        PRIMARY KEY (id),
        KEY status (status),
        KEY created_at (created_at)
    ) $charset;" );

    update_option( 'cfp_trezor_sweep_db_version', '1.1.0' );
}

add_action( 'admin_init', function () {
    if ( get_option( 'cfp_trezor_sweep_db_version' ) !== '1.1.0' ) {
        cfp_trezor_sweep_create_table();
    }
} );

// ============================================================
// CORE SWEEP HELPERS
// ============================================================

/** Get the configured Trezor destination address. */
function cfp_trezor_address() {
    return trim( cfp_get_setting( 'trezor_active_address', '' ) );
}

/** Default per-stream minimum thresholds (satoshis). Admin can override any. */
function cfp_trezor_stream_threshold_defaults() {
    return [
        'house_edge_dice'      => 50000,
        'house_edge_crash'     => 50000,
        'house_edge_slots'     => 50000,
        'house_edge_coinflip'  => 50000,
        'house_edge_hilo'      => 50000,
        'house_edge_wheel'     => 50000,
        'house_edge_plinko'    => 50000,
        'lottery_ticket_sales' => 75000,
        'fun_token_sales'      => 75000,
        'premium_membership'   => 100000,
        'advertising'          => 100000,
        'np_withdraw_fee'      => 50000,
        'interest_spread'      => 100000,
    ];
}

/**
 * Global auto-sweep threshold (satoshis).
 * Auto-sweep fires when TOTAL pending balance >= this value.
 * Floor: 10,000 sat. Ceiling: 100,000,000 sat (1 BTC safety cap).
 */
function cfp_trezor_sweep_threshold() {
    $raw = (int) cfp_get_setting( 'trezor_sweep_threshold', 100000 );
    return min( 100000000, max( 10000, $raw ) );
}

/** Per-stream minimum contribution threshold. Returns 0 if no override set. */
function cfp_trezor_stream_threshold( $stream ) {
    $key      = 'trezor_stream_threshold_' . sanitize_key( $stream );
    $override = cfp_get_setting( $key, '' );
    if ( $override !== '' && is_numeric( $override ) ) {
        return min( 100000000, max( 0, (int) $override ) );
    }
    $defaults = cfp_trezor_stream_threshold_defaults();
    return $defaults[ $stream ] ?? 0;
}

/**
 * Get total pending (un-swept) balance from the admin wallet ledger.
 * Sums all positive entries (earned) minus all negative entries (already swept).
 */
function cfp_trezor_pending_balance() {
    global $wpdb;
    $earned = (int) $wpdb->get_var( "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE amount_sat > 0" );
    $swept  = (int) abs( $wpdb->get_var( "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE amount_sat < 0" ) );
    return max( 0, $earned - $swept );
}

/**
 * Check whether auto-sweep conditions are met.
 * Returns true if: Trezor address set, NowPayments API key set, balance >= threshold, auto-sweep enabled.
 */
function cfp_trezor_should_auto_sweep() {
    if ( cfp_get_setting( 'trezor_auto_sweep_enabled', '1' ) !== '1' ) return false;
    if ( empty( cfp_trezor_address() ) )                                return false;
    if ( ! cfp_np_enabled() || empty( cfp_np_api_key() ) )             return false;
    if ( cfp_trezor_pending_balance() < cfp_trezor_sweep_threshold() )  return false;
    return true;
}

// ============================================================
// TIER 1 — NOWPAYMENTS API AUTO-SWEEP
// ============================================================

/**
* Attempt to sweep pending earnings to Trezor.
 * Mode options: nowpayments (uses NP API) or direct (you send manually)
 *
 * @param  int    $amount_sat  Amount to sweep in sat. 0 = sweep full pending balance.
 * @param  string $type        'auto_sweep' | 'cron_sweep' | 'manual_sweep' | 'direct_sweep'
 * @return array  ['success'=>bool, 'message'=>string, 'queue_id'=>int|null]
 */
function cfp_trezor_do_sweep( $amount_sat = 0, $type = 'auto_sweep' ) {
    global $wpdb;

    $addr      = cfp_trezor_address();
    $currency  = strtoupper( cfp_get_setting( 'faucet_currency', cfp_get_setting( 'blockchain_currency', 'BTC' ) ) );
    $pending   = cfp_trezor_pending_balance();
    $threshold = cfp_trezor_sweep_threshold();
    $sweep_mode = cfp_get_setting( 'trezor_sweep_method', 'nowpayments' );
    $network_fee = intval( cfp_get_setting( 'trezor_network_fee', 0 ) );

    // Validation
    if ( empty( $addr ) ) {
        return cfp_trezor_queue_pending( $amount_sat ?: $pending, $addr, $type,
            'No Trezor address configured. Set it in Admin Wallet → Trezor Sweep.' );
    }

    // Direct mode: record only, you send manually
    if ( $sweep_mode === 'direct' ) {
        $sweep_amount = $amount_sat > 0 ? min( $amount_sat, $pending ) : $pending;
        
        if ( $sweep_amount <= 0 ) {
            return [ 'success' => false, 'message' => 'Nothing to sweep — pending balance is 0.', 'queue_id' => null ];
        }
        
        if ( $sweep_amount < $threshold && $type !== 'manual_sweep' && $type !== 'direct_sweep' ) {
            return [ 'success' => false, 'message' => "Balance ({$sweep_amount} sat) below threshold ({$threshold} sat). Not sweeping yet.", 'queue_id' => null ];
        }
        
        // Calculate net after fee
        $net_amount = max( 0, $sweep_amount - $network_fee );
        
        // Record network fee in ledger
        if ( $network_fee > 0 ) {
            $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
                'stream'      => 'trezor_network_fee',
                'amount_sat'  => -$network_fee,
                'description'=> sprintf( 'Network fee for Trezor sweep: %s sat', $network_fee ),
            ]);
        }
        
        // Record direct sweep in ledger (net amount)
        $desc = sprintf( 'Direct sweep to Trezor: %s sat → %s (fee: %s sat, net: %s sat)',
            $sweep_amount, $addr, $network_fee, $net_amount );
        $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
            'stream'      => 'trezor_payout',
            'amount_sat'  => -$net_amount,
            'description'=> $desc,
        ]);
        
        $wpdb->insert( $wpdb->prefix . 'cfp_trezor_sweep_queue', [
            'type'        => 'direct_sweep',
            'coin'       => $currency,
            'amount_sat' => $net_amount,
            'to_address' => $addr,
            'status'    => 'pending',
            'note'      => "Net after {$network_fee} sat fee. Send {$net_amount} sat to {$addr}",
        ]);
        
        return [ 'success' => true, 'message' => "✅ Sweep: {$net_amount} sat net (after {$network_fee} sat fee). Send to {$addr}", 'queue_id' => $wpdb->insert_id, 'net_amount' => $net_amount, 'fee' => $network_fee ];
    }

    // NOWPayments mode (original)
    if ( ! cfp_np_enabled() || empty( cfp_np_api_key() ) ) {
        return cfp_trezor_queue_pending( $amount_sat ?: $pending, $addr, $type,
            'NOWPayments not configured or API key missing. Add it in WP Admin → NOWPayments Settings, or switch to Direct mode.' );
    }
    // Threshold check — instant sweeps and manual sweeps bypass it.
    $bypass_threshold = in_array( $type, [ 'manual_sweep', 'instant_sweep' ], true );
    if ( $pending < $threshold && ! $bypass_threshold ) {
        return [ 'success' => false, 'message' => "Balance ({$pending} sat) below threshold ({$threshold} sat). Not sweeping yet.", 'queue_id' => null ];
    }

    $sweep_amount = $amount_sat > 0 ? min( $amount_sat, $pending ) : $pending;

    if ( $sweep_amount <= 0 ) {
        return [ 'success' => false, 'message' => 'Nothing to sweep — pending balance is 0.', 'queue_id' => null ];
    }

    // Prevent duplicate in-flight sweeps (auto_sweep only — instant_sweep is per-credit and may legitimately stack)
    $in_flight = $wpdb->get_var(
        "SELECT id FROM {$wpdb->prefix}cfp_trezor_sweep_queue WHERE status = 'pending' LIMIT 1"
    );
    if ( $in_flight && $type === 'auto_sweep' ) {
        return [ 'success' => false, 'message' => "A sweep is already queued (ID #{$in_flight}). Resolve it first.", 'queue_id' => (int) $in_flight ];
    }

    // ── Tier 1: NOWPayments Mass Payout API ──────────────────────────────────
    $amount_coin = $sweep_amount / 1e8;
    $np_result   = cfp_np_send_payout( $addr, $amount_coin, strtolower( $currency ) );

    $payout_id  = $np_result['id'] ?? ( $np_result['withdrawals'][0]['id'] ?? '' );
    $np_success = ! empty( $payout_id ) || ( isset( $np_result['status'] ) && $np_result['status'] !== 'error' );

    if ( $np_success ) {
        // ✅ SUCCESS — Record negative ledger entry to zero the pending balance
        $note = sprintf( 'NOWPayments sweep to Trezor: %s sat → %s. Payout ID: %s',
            number_format( $sweep_amount ), $addr, $payout_id );

        $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
            'stream'      => 'trezor_payout',
            'amount_sat'  => -$sweep_amount,
            'description' => $note,
        ] );

        $wpdb->insert( "{$wpdb->prefix}cfp_trezor_sweep_queue", [
            'type'         => $type,
            'coin'         => $currency,
            'amount_sat'   => $sweep_amount,
            'to_address'   => $addr,
            'status'       => 'sent',
            'np_payout_id' => (string) $payout_id,
            'note'         => $note,
            'attempts'     => 1,
            'created_at'   => current_time( 'mysql' ),
            'updated_at'   => current_time( 'mysql' ),
        ] );

        do_action( 'cfp_trezor_sweep_success', $sweep_amount, $addr, $payout_id, $currency );

        return [
            'success'  => true,
            'message'  => "✅ Swept {$sweep_amount} sat to Trezor via NOWPayments. Payout ID: {$payout_id}",
            'queue_id' => (int) $wpdb->insert_id,
        ];
    }

    // ── Tier 2/3: NOWPayments API failed → queue for manual action ───────────
    $error = $np_result['message'] ?? ( $np_result['error'] ?? 'NOWPayments API returned an unexpected response.' );
    return cfp_trezor_queue_pending( $sweep_amount, $addr, $type, $error );
}

/**
 * Insert a pending sweep into the queue (Tier 3 fallback).
 * Called when NOWPayments API fails or is not configured.
 */
function cfp_trezor_queue_pending( $amount_sat, $to_address, $type, $error_msg ) {
    global $wpdb;

    $currency = strtoupper( cfp_get_setting( 'faucet_currency', cfp_get_setting( 'blockchain_currency', 'BTC' ) ) );

    $existing = $wpdb->get_var(
        "SELECT id FROM {$wpdb->prefix}cfp_trezor_sweep_queue WHERE status = 'pending' LIMIT 1"
    );

    $data = [
        'type'       => $type,
        'coin'       => $currency,
        'amount_sat' => max( 0, (int) $amount_sat ),
        'to_address' => $to_address ?: '(not configured)',
        'status'     => 'pending',
        'error_msg'  => sanitize_text_field( $error_msg ),
        'note'       => sprintf( 'Queued %s sat for manual Trezor sweep — auto-sweep failed: %s', number_format( (int) $amount_sat ), $error_msg ),
        'attempts'   => 1,
        'updated_at' => current_time( 'mysql' ),
    ];

    if ( $existing ) {
        $prev_attempts = (int) $wpdb->get_var( "SELECT attempts FROM {$wpdb->prefix}cfp_trezor_sweep_queue WHERE id={$existing}" );
        $wpdb->update(
            "{$wpdb->prefix}cfp_trezor_sweep_queue",
            array_merge( $data, [ 'attempts' => $prev_attempts + 1 ] ),
            [ 'id' => $existing ]
        );
        $queue_id = (int) $existing;
    } else {
        $data['created_at'] = current_time( 'mysql' );
        $wpdb->insert( "{$wpdb->prefix}cfp_trezor_sweep_queue", $data );
        $queue_id = (int) $wpdb->insert_id;
    }

    do_action( 'cfp_trezor_sweep_queued', $amount_sat, $to_address, $error_msg );

    return [
        'success'  => false,
        'message'  => "⚠️ Auto-sweep failed: {$error_msg}. Queued for manual action (Queue ID #{$queue_id}).",
        'queue_id' => $queue_id,
    ];
}

// ============================================================
// HOOK INTO EVERY WALLET CREDIT
//
// Two modes — pick ONE in Trezor Sweep Configuration:
//
//   • Threshold mode (default, conservative):
//       Wait until the off-chain ledger reaches `trezor_sweep_threshold`,
//       then sweep the full pending balance on-chain in one transaction.
//       Cheaper (1 NOWPayments fee per sweep) but balance lives off-chain
//       until the threshold is reached.
//
//   • Instant mode (`trezor_instant_sweep_enabled = 1`):
//       Every single earning is converted off-chain → on-chain immediately
//       when it lands. The on-chain Trezor balance grows in real time as
//       revenue is earned. Every credit ≥ `trezor_instant_min` triggers a
//       NOWPayments payout. Credits below the dust floor accumulate in the
//       ledger and are swept on the next earning that crosses the floor.
// ============================================================

/** Minimum amount (sat) that will trigger an instant on-chain sweep. */
function cfp_trezor_instant_min() {
    $raw = (int) cfp_get_setting( 'trezor_instant_min', 5000 );
    return min( 100000000, max( 1, $raw ) );
}

/** Is per-credit instant on-chain conversion enabled? */
function cfp_trezor_instant_enabled() {
    return cfp_get_setting( 'trezor_instant_sweep_enabled', '0' ) === '1';
}

add_action( 'cfp_after_wallet_credit', 'cfp_trezor_maybe_auto_sweep', 10, 2 );
function cfp_trezor_maybe_auto_sweep( $stream, $amount_sat ) {
    // Never recurse on bookkeeping / payout streams.
    if ( in_array( $stream, [ 'trezor_payout', 'trezor_network_fee', 'admin_payout', 'hw_sweep' ], true ) ) return;

    // ── Instant mode: convert every earning to on-chain immediately ──────
    if ( cfp_trezor_instant_enabled() ) {
        // Basic gating: address + NOWPayments must be configured.
        $addr        = cfp_trezor_address();
        $np_ready    = cfp_np_enabled() && ! empty( cfp_np_api_key() );
        $sweep_mode  = cfp_get_setting( 'trezor_sweep_method', 'nowpayments' );
        if ( empty( $addr ) ) return;
        if ( $sweep_mode === 'nowpayments' && ! $np_ready ) return;

        // Sweep the entire current pending balance (so accumulated dust below
        // the floor finally rides along when one credit crosses the floor).
        $pending = cfp_trezor_pending_balance();
        if ( $pending < cfp_trezor_instant_min() ) return;

        // Run after the credit's DB transaction commits, so cfp_trezor_pending_balance()
        // reflects the just-credited row.
        if ( function_exists( 'wp_schedule_single_event' ) ) {
            wp_schedule_single_event( time() + 1, 'cfp_trezor_run_instant_sweep' );
        } else {
            cfp_trezor_do_sweep( 0, 'instant_sweep' );
        }
        return;
    }

    // ── Threshold mode (legacy / default behaviour) ──────────────────────
    if ( cfp_trezor_should_auto_sweep() ) {
        cfp_trezor_do_sweep( 0, 'auto_sweep' );
    }
}

/** Cron handler for deferred instant sweep (so it runs after the credit row commits). */
add_action( 'cfp_trezor_run_instant_sweep', 'cfp_trezor_run_instant_sweep_handler' );
function cfp_trezor_run_instant_sweep_handler() {
    if ( ! cfp_trezor_instant_enabled() ) return;
    $pending = cfp_trezor_pending_balance();
    if ( $pending < cfp_trezor_instant_min() ) return;
    cfp_trezor_do_sweep( 0, 'instant_sweep' );
}

// ============================================================
// TIER 2 — CRON AUTO-SWEEP (every 12 hours)
// ============================================================

add_filter( 'cron_schedules', function ( $schedules ) {
    if ( ! isset( $schedules['cfp_twice_daily'] ) ) {
        $schedules['cfp_twice_daily'] = [ 'interval' => 43200, 'display' => 'Twice Daily (CFP)' ];
    }
    return $schedules;
} );

add_action( 'init', function () {
    if ( ! wp_next_scheduled( 'cfp_trezor_cron_sweep' ) ) {
        wp_schedule_event( time(), 'cfp_twice_daily', 'cfp_trezor_cron_sweep' );
    }
} );

add_action( 'cfp_trezor_cron_sweep', 'cfp_trezor_cron_sweep_handler' );
function cfp_trezor_cron_sweep_handler() {
    if ( ! cfp_trezor_should_auto_sweep() ) return;
    $result = cfp_trezor_do_sweep( 0, 'cron_sweep' );
    set_transient( 'cfp_trezor_last_cron_result', $result, DAY_IN_SECONDS );
}

// ============================================================
// ADMIN EMAIL NOTIFICATIONS
// ============================================================

add_action( 'cfp_trezor_sweep_success', function ( $amount_sat, $addr, $payout_id, $currency ) {
    if ( cfp_get_setting( 'trezor_email_on_sweep', '1' ) !== '1' ) return;
    $btc_price = (int) cfp_get_setting( 'btc_usd_price', 67694 );
    $usd       = round( $amount_sat / 100000000 * $btc_price, 2 );
    wp_mail(
        get_option( 'admin_email' ),
        sprintf( '✅ [%s] Trezor Sweep Completed — %s sat (%s)', get_bloginfo( 'name' ), $amount_sat, $currency ),
        "Your faucet automatically swept earnings to your Trezor via NOWPayments.\n\n" .
        "Amount:       {$amount_sat} sat ≈ \${$usd} USD\n" .
        "Currency:     {$currency}\n" .
        "To address:   {$addr}\n" .
        "NP Payout ID: {$payout_id}\n\n" .
        "View details in WP Admin → Admin Wallet → Trezor Sweep."
    );
}, 10, 4 );

add_action( 'cfp_trezor_sweep_queued', function ( $amount_sat, $addr, $error ) {
    if ( cfp_get_setting( 'trezor_email_on_sweep', '1' ) !== '1' ) return;
    wp_mail(
        get_option( 'admin_email' ),
        sprintf( '⚠️ [%s] Trezor Sweep Queued — Manual Action Required', get_bloginfo( 'name' ) ),
        "Your faucet tried to auto-sweep earnings via NOWPayments but the API call failed.\n\n" .
        "Amount queued:  {$amount_sat} sat\n" .
        "To address:     {$addr}\n" .
        "Failure reason: {$error}\n\n" .
        "Action required:\n" .
        "1. Check your NOWPayments account — ensure API withdrawals are enabled and the address is whitelisted.\n" .
        "2. Go to WP Admin → Admin Wallet → Trezor Sweep → Retry.\n\n" .
        "Once done, mark the queue entry as sent."
    );
}, 10, 3 );

// ============================================================
// AJAX: MANUAL TRIGGER SWEEP
// ============================================================

add_action( 'wp_ajax_cfp_trezor_manual_sweep', 'cfp_ajax_trezor_manual_sweep' );
function cfp_ajax_trezor_manual_sweep() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
    if ( ! check_ajax_referer( 'cfp_trezor_sweep_nonce', 'nonce', false ) ) wp_send_json_error( 'Nonce failed.' );

    $amount_sat = absint( $_POST['amount_sat'] ?? 0 );
    $result     = cfp_trezor_do_sweep( $amount_sat, 'manual_sweep' );

    $result['success'] ? wp_send_json_success( $result['message'] ) : wp_send_json_error( $result['message'] );
}

// ============================================================
// AJAX: RETRY QUEUED SWEEP
// ============================================================

add_action( 'wp_ajax_cfp_trezor_retry_sweep', 'cfp_ajax_trezor_retry_sweep' );
function cfp_ajax_trezor_retry_sweep() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
    if ( ! check_ajax_referer( 'cfp_trezor_sweep_nonce', 'nonce', false ) ) wp_send_json_error( 'Nonce failed.' );

    global $wpdb;
    $queue_id = absint( $_POST['queue_id'] ?? 0 );

    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}cfp_trezor_sweep_queue WHERE id = %d AND status = 'pending'", $queue_id
    ) );
    if ( ! $row ) wp_send_json_error( 'Queue entry not found or already processed.' );

    $wpdb->update( "{$wpdb->prefix}cfp_trezor_sweep_queue",
        [ 'status' => 'cancelled', 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $queue_id ] );

    $result = cfp_trezor_do_sweep( (int) $row->amount_sat, 'manual_sweep' );

    if ( $result['success'] ) {
        wp_send_json_success( $result['message'] );
    } else {
        $wpdb->update( "{$wpdb->prefix}cfp_trezor_sweep_queue",
            [ 'status' => 'pending', 'attempts' => $row->attempts + 1, 'updated_at' => current_time( 'mysql' ) ],
            [ 'id' => $queue_id ] );
        wp_send_json_error( $result['message'] );
    }
}

// ============================================================
// AJAX: MARK QUEUE ENTRY AS MANUALLY SENT
// ============================================================

add_action( 'wp_ajax_cfp_trezor_mark_sent', 'cfp_ajax_trezor_mark_sent' );
function cfp_ajax_trezor_mark_sent() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
    if ( ! check_ajax_referer( 'cfp_trezor_sweep_nonce', 'nonce', false ) ) wp_send_json_error( 'Nonce failed.' );

    global $wpdb;
    $queue_id = absint( $_POST['queue_id'] ?? 0 );
    $tx_hash  = sanitize_text_field( wp_unslash( $_POST['tx_hash'] ?? '' ) );

    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}cfp_trezor_sweep_queue WHERE id = %d AND status = 'pending'", $queue_id
    ) );
    if ( ! $row ) wp_send_json_error( 'Queue entry not found.' );

    $note = "Manual Trezor sweep: {$row->amount_sat} sat → {$row->to_address}" . ( $tx_hash ? ". TX: {$tx_hash}" : ' (no TX hash provided)' );
    $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
        'stream'      => 'trezor_payout',
        'amount_sat'  => -(int) $row->amount_sat,
        'description' => $note,
    ] );
    $wpdb->update( "{$wpdb->prefix}cfp_trezor_sweep_queue",
        [ 'status' => 'sent', 'tx_hash' => $tx_hash, 'note' => $note, 'updated_at' => current_time( 'mysql' ) ],
        [ 'id' => $queue_id ] );

    wp_send_json_success( 'Marked as sent. Ledger updated.' );
}

// ============================================================
// AJAX: DISMISS / CANCEL QUEUE ENTRY
// ============================================================

add_action( 'wp_ajax_cfp_trezor_dismiss_sweep', 'cfp_ajax_trezor_dismiss_sweep' );
function cfp_ajax_trezor_dismiss_sweep() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
    if ( ! check_ajax_referer( 'cfp_trezor_sweep_nonce', 'nonce', false ) ) wp_send_json_error( 'Nonce failed.' );

    global $wpdb;
    $queue_id = absint( $_POST['queue_id'] ?? 0 );
    $wpdb->update( "{$wpdb->prefix}cfp_trezor_sweep_queue",
        [ 'status' => 'cancelled', 'updated_at' => current_time( 'mysql' ) ], [ 'id' => $queue_id ] );
    wp_send_json_success( 'Queue entry dismissed.' );
}

// ============================================================
// AJAX: GET SWEEP STATUS (for UI polling)
// ============================================================

add_action( 'wp_ajax_cfp_trezor_sweep_status', 'cfp_ajax_trezor_sweep_status' );
function cfp_ajax_trezor_sweep_status() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
    if ( ! check_ajax_referer( 'cfp_trezor_sweep_nonce', 'nonce', false ) ) wp_send_json_error( 'Nonce failed.' );

    global $wpdb;

    $pending_balance = cfp_trezor_pending_balance();
    $threshold       = cfp_trezor_sweep_threshold();
    $trezor_addr     = cfp_trezor_address();
    $api_key_set     = cfp_np_enabled() && ! empty( cfp_np_api_key() );
    $auto_enabled    = cfp_get_setting( 'trezor_auto_sweep_enabled', '1' ) === '1';
    $currency        = strtoupper( cfp_get_setting( 'faucet_currency', 'BTC' ) );
    $btc_price       = (int) cfp_get_setting( 'btc_usd_price', 67694 );

    $pending_queue = $wpdb->get_results(
        "SELECT * FROM {$wpdb->prefix}cfp_trezor_sweep_queue WHERE status = 'pending' ORDER BY created_at DESC"
    );
    $recent_sweeps = $wpdb->get_results(
        "SELECT * FROM {$wpdb->prefix}cfp_trezor_sweep_queue WHERE status IN ('sent','failed','cancelled') ORDER BY updated_at DESC LIMIT 10"
    );
    $total_swept = (int) abs( $wpdb->get_var(
        "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE stream = 'trezor_payout'"
    ) );

    $onchain         = function_exists( 'cfp_onchain_trezor_balance' )  ? cfp_onchain_trezor_balance( false ) : null;
    $lifetime_earned = function_exists( 'cfp_onchain_lifetime_earned' ) ? cfp_onchain_lifetime_earned()       : 0;
    $lifetime_swept  = function_exists( 'cfp_onchain_lifetime_swept' )  ? cfp_onchain_lifetime_swept()        : $total_swept;

    wp_send_json_success( [
        'pending_balance'  => $pending_balance,
        'pending_usd'      => round( $pending_balance / 100000000 * $btc_price, 2 ),
        'threshold'        => $threshold,
        'threshold_met'    => $pending_balance >= $threshold,
        'trezor_addr'      => $trezor_addr,
        'addr_configured'  => ! empty( $trezor_addr ),
        'api_key_set'      => $api_key_set,
        'auto_enabled'     => $auto_enabled,
        'currency'         => $currency,
        'total_swept'      => $total_swept,
        'swept_usd'        => round( $total_swept / 100000000 * $btc_price, 2 ),
        'pending_queue'    => $pending_queue,
        'recent_sweeps'    => $recent_sweeps,
        'next_cron'        => wp_next_scheduled( 'cfp_trezor_cron_sweep' )
            ? date( 'Y-m-d H:i:s', wp_next_scheduled( 'cfp_trezor_cron_sweep' ) ) : null,
        'last_cron_result' => get_transient( 'cfp_trezor_last_cron_result' ),
        'onchain'          => $onchain,
        'lifetime_earned'  => $lifetime_earned,
        'lifetime_swept'   => $lifetime_swept,
    ] );
}

// ============================================================
// AJAX: SAVE TREZOR SWEEP SETTINGS
// ============================================================

add_action( 'wp_ajax_cfp_trezor_save_settings', 'cfp_ajax_trezor_save_settings' );
function cfp_ajax_trezor_save_settings() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
    if ( ! check_ajax_referer( 'cfp_trezor_sweep_nonce', 'nonce', false ) ) wp_send_json_error( 'Nonce failed.' );

    $threshold = min( 100000000, max( 10000, absint( $_POST['trezor_sweep_threshold'] ?? 100000 ) ) );

    $instant_min = min( 100000000, max( 1, absint( $_POST['trezor_instant_min'] ?? 5000 ) ) );

    $fields = [
        'trezor_active_address'        => sanitize_text_field( wp_unslash( $_POST['trezor_active_address'] ?? '' ) ),
        'trezor_sweep_threshold'       => $threshold,
        'trezor_auto_sweep_enabled'    => isset( $_POST['trezor_auto_sweep_enabled'] ) ? '1' : '0',
        'trezor_instant_sweep_enabled' => isset( $_POST['trezor_instant_sweep_enabled'] ) ? '1' : '0',
        'trezor_instant_min'           => $instant_min,
        'trezor_email_on_sweep'        => isset( $_POST['trezor_email_on_sweep'] ) ? '1' : '0',
        'trezor_label'                 => sanitize_text_field( wp_unslash( $_POST['trezor_label'] ?? 'My Trezor' ) ),
        'trezor_model'                 => sanitize_text_field( wp_unslash( $_POST['trezor_model'] ?? 'Model T' ) ),
    ];
    foreach ( $fields as $key => $val ) {
        cfp_update_setting( $key, $val );
    }

    foreach ( array_keys( cfp_trezor_stream_threshold_defaults() ) as $stream ) {
        $post_key = 'trezor_stream_threshold_' . $stream;
        if ( isset( $_POST[ $post_key ] ) && $_POST[ $post_key ] !== '' ) {
            cfp_update_setting( $post_key, min( 100000000, max( 0, absint( $_POST[ $post_key ] ) ) ) );
        } else {
            cfp_update_setting( $post_key, '' );
        }
    }

    wp_send_json_success( sprintf(
        'Trezor sweep settings saved. Global threshold: %s sat (%s BTC).',
        number_format( $threshold ),
        number_format( $threshold / 100000000, 8 )
    ) );
}

// ============================================================
// ADMIN UI — INJECT "TREZOR SWEEP" TAB INTO REVENUE WALLET PAGE
// ============================================================

add_action( 'cfp_admin_wallet_extra_tabs', 'cfp_trezor_sweep_render_tab_link' );
function cfp_trezor_sweep_render_tab_link( $current_tab ) {
    $active = $current_tab === 'trezor_sweep' ? 'nav-tab-active' : '';
    echo '<a href="' . esc_url( add_query_arg( 'wstab', 'trezor_sweep' ) ) . '" class="nav-tab ' . esc_attr( $active ) . '">🔐 Trezor Sweep</a>';
}

add_action( 'cfp_admin_wallet_extra_content', 'cfp_trezor_sweep_render_tab_content' );
function cfp_trezor_sweep_render_tab_content( $current_tab ) {
    if ( $current_tab !== 'trezor_sweep' ) return;
    cfp_trezor_render_sweep_page();
}

/**
 * Main render function for the Trezor Sweep admin page.
 */
function cfp_trezor_render_sweep_page() {
    global $wpdb;

    $nonce           = wp_create_nonce( 'cfp_trezor_sweep_nonce' );
    $pending_balance = cfp_trezor_pending_balance();
    $threshold       = cfp_trezor_sweep_threshold();
    $trezor_addr     = cfp_trezor_address();
    $auto_enabled    = cfp_get_setting( 'trezor_auto_sweep_enabled', '1' );
    $instant_enabled = cfp_get_setting( 'trezor_instant_sweep_enabled', '0' );
    $instant_min     = (int) cfp_get_setting( 'trezor_instant_min', 5000 );
    $email_notify    = cfp_get_setting( 'trezor_email_on_sweep', '1' );
    $trezor_label    = cfp_get_setting( 'trezor_label', 'My Trezor' );
    $trezor_model    = cfp_get_setting( 'trezor_model', 'Model T' );
    $api_key_set     = cfp_np_enabled() && ! empty( cfp_np_api_key() );
    $currency        = strtoupper( cfp_get_setting( 'faucet_currency', cfp_get_setting( 'blockchain_currency', 'BTC' ) ) );
    $btc_price       = (int) cfp_get_setting( 'btc_usd_price', 67694 );
    $pending_usd     = round( $pending_balance / 100000000 * $btc_price, 2 );
    $threshold_met   = $pending_balance >= $threshold;

    $total_swept = (int) abs( $wpdb->get_var(
        "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE stream = 'trezor_payout'"
    ) );
    $swept_usd = round( $total_swept / 100000000 * $btc_price, 2 );

    // ── LIVE ON-CHAIN BALANCE (real wallet, not the ledger) ──────────
    $onchain          = function_exists( 'cfp_onchain_trezor_balance' ) ? cfp_onchain_trezor_balance( false ) : [];
    $onchain_sat      = (int) ( $onchain['balance_sat']     ?? 0 );
    $onchain_unconf   = (int) ( $onchain['unconfirmed_sat'] ?? 0 );
    $onchain_total    = (int) ( $onchain['total_sat']       ?? $onchain_sat );
    $onchain_usd      = round( $onchain_sat / 100000000 * $btc_price, 2 );
    $onchain_source   = $onchain['source']    ?? null;
    $onchain_error    = $onchain['error']     ?? null;
    $onchain_age      = isset( $onchain['cached_at'] ) ? max( 0, time() - (int) $onchain['cached_at'] ) : null;

    $lifetime_earned  = function_exists( 'cfp_onchain_lifetime_earned' ) ? cfp_onchain_lifetime_earned() : 0;
    $lifetime_swept   = function_exists( 'cfp_onchain_lifetime_swept' )  ? cfp_onchain_lifetime_swept()  : $total_swept;

    $pending_queue = $wpdb->get_results(
        "SELECT * FROM {$wpdb->prefix}cfp_trezor_sweep_queue WHERE status = 'pending' ORDER BY created_at DESC"
    );
    $recent_sweeps = $wpdb->get_results(
        "SELECT * FROM {$wpdb->prefix}cfp_trezor_sweep_queue WHERE status IN ('sent','failed','cancelled') ORDER BY updated_at DESC LIMIT 15"
    );
    $next_cron = wp_next_scheduled( 'cfp_trezor_cron_sweep' );

    $tier1_ok = ! empty( $trezor_addr ) && $api_key_set && $auto_enabled === '1';
    $tier2_ok = (bool) $next_cron;
    ?>
    <div class="cfp-wrap" id="cfp-trezor-sweep-page">

        <div id="cfp-trezor-msg" style="margin-bottom:16px"></div>

        <!-- ── SWEEP SYSTEM STATUS ─────────────────────────────────── -->
        <div class="cfp-card" style="margin-bottom:22px">
            <h2 style="display:flex;align-items:center;gap:10px">
                <span style="background:linear-gradient(135deg,#1dc928,#009900);color:#fff;padding:4px 10px;border-radius:6px;font-size:.72rem;font-weight:800;letter-spacing:1px">TREZOR</span>
                NOWPayments → Trezor Sweep Status
            </h2>

            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-bottom:20px">

                <!-- Tier 1 — NowPayments Auto-Sweep -->
                <div style="background:#0d0d0d;border:1px solid <?=$tier1_ok?'#1dc92844':'#ef444444'?>;border-radius:10px;padding:16px">
                    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:1.5px;color:#444;margin-bottom:8px">Tier 1 — NOWPayments Auto-Sweep</div>
                    <div style="font-size:1rem;font-weight:700;color:<?=$tier1_ok?'#1dc928':'#ef4444'?>;margin-bottom:6px">
                        <?=$tier1_ok?'✅ Active':'❌ Not Ready'?>
                    </div>
                    <div style="font-size:.75rem;color:#555">
                        Trezor address: <?=$trezor_addr?'<span style="color:#1dc928">✓ Set</span>':'<span style="color:#ef4444">✗ Not set</span>'?><br>
                        NOWPayments API key: <?=$api_key_set?'<span style="color:#1dc928">✓ Set</span>':'<span style="color:#ef4444">✗ Not set</span>'?><br>
                        Auto-sweep: <?=$auto_enabled==='1'?'<span style="color:#1dc928">Enabled</span>':'<span style="color:#888">Disabled</span>'?>
                    </div>
                </div>

                <!-- Tier 2 — Cron -->
                <div style="background:#0d0d0d;border:1px solid <?=$tier2_ok?'#3b82f644':'#888'?>;border-radius:10px;padding:16px">
                    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:1.5px;color:#444;margin-bottom:8px">Tier 2 — Cron Auto-Sweep</div>
                    <div style="font-size:1rem;font-weight:700;color:<?=$tier2_ok?'#3b82f6':'#888'?>;margin-bottom:6px">
                        <?=$tier2_ok?'✅ Scheduled':'⚠️ Not Scheduled'?>
                    </div>
                    <div style="font-size:.75rem;color:#555">
                        Runs: every 12 hours<br>
                        Next run: <?=$next_cron?date('M j H:i',$next_cron):'Not scheduled'?>
                    </div>
                </div>

                <!-- Tier 3 — Manual Queue -->
                <div style="background:#0d0d0d;border:1px solid <?=count($pending_queue)?'#f97316':'#2a2a2a'?>;border-radius:10px;padding:16px">
                    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:1.5px;color:#444;margin-bottom:8px">Tier 3 — Manual Queue</div>
                    <div style="font-size:1rem;font-weight:700;color:<?=count($pending_queue)?'#f97316':'#888'?>;margin-bottom:6px">
                        <?=count($pending_queue)?count($pending_queue).' pending':'No pending items'?>
                    </div>
                    <div style="font-size:.75rem;color:#555">Fallback when auto-sweep fails.<br>Retry or mark as sent manually.</div>
                </div>

                <!-- Balance -->
                <div style="background:#0d0d0d;border:1px solid <?=$threshold_met?'#22c55e44':'#1a1a1a'?>;border-radius:10px;padding:16px">
                    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:1.5px;color:#444;margin-bottom:8px">Pending Balance</div>
                    <div style="font-size:1.4rem;font-weight:800;font-family:monospace;color:<?=$threshold_met?'#22c55e':'#fff'?>;margin-bottom:4px">
                        <?=number_format($pending_balance)?> sat
                    </div>
                    <div style="font-size:.75rem;color:#555">
                        ≈ $<?=number_format($pending_usd,2)?> USD<br>
                        Threshold: <?=number_format($threshold)?> sat
                        <?=$threshold_met?'<span style="color:#22c55e"> ✓ Ready to sweep</span>':'<span style="color:#888"> (accumulating…)</span>'?>
                    </div>
                </div>
            </div>

            <div style="display:flex;gap:24px;flex-wrap:wrap;border-top:1px solid #1a1a1a;padding-top:14px">
                <div style="text-align:center">
                    <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#444">Total Swept All Time</div>
                    <div style="font-size:1.1rem;font-weight:800;color:#1dc928;font-family:monospace"><?=number_format($total_swept)?> sat</div>
                    <div style="font-size:.7rem;color:#333">≈ $<?=number_format($swept_usd,2)?></div>
                </div>
                <div style="text-align:center">
                    <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#444">Currency</div>
                    <div style="font-size:1.1rem;font-weight:800;color:#f7931a"><?=esc_html($currency)?></div>
                </div>
                <div style="text-align:center">
                    <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#444">Trezor Address</div>
                    <div style="font-size:.8rem;font-weight:700;color:#1dc928;font-family:monospace;max-width:220px;word-break:break-all">
                        <?=$trezor_addr?esc_html(substr($trezor_addr,0,16)).'…':'<span style="color:#ef4444">Not configured</span>'?>
                    </div>
                </div>
            </div>
        </div>

        <!-- ── LIVE ON-CHAIN BALANCE ───────────────────────────────── -->
        <div class="cfp-card" style="margin-bottom:22px;background:linear-gradient(135deg,#0a1410 0%,#0d0d0d 60%);border:1px solid #1dc92844">
            <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:14px">
                <h2 style="margin:0;display:flex;align-items:center;gap:10px">
                    <span style="background:linear-gradient(135deg,#f7931a,#c97315);color:#000;padding:4px 10px;border-radius:6px;font-size:.72rem;font-weight:800;letter-spacing:1px">ON-CHAIN</span>
                    Real Wallet Balance
                </h2>
                <button type="button" id="cfp-onchain-refresh-btn"
                    onclick="cfpRefreshOnchain('<?=esc_js($nonce)?>')"
                    style="background:#0d2010;border:1px solid #1dc92844;color:#1dc928;padding:7px 14px;border-radius:7px;font-size:.78rem;font-weight:700;cursor:pointer;letter-spacing:.5px">
                    🔄 Refresh from blockchain
                </button>
            </div>

            <?php if ( ! $trezor_addr ): ?>
                <div style="background:#1a0a0a;border:1px solid #ef444433;border-radius:9px;padding:14px;color:#ef4444;font-size:.85rem">
                    No Trezor address configured. Set one in <strong>Configuration</strong> below to start tracking the on-chain balance.
                </div>
            <?php elseif ( $onchain_error ): ?>
                <div style="background:#1a1208;border:1px solid #f9731633;border-radius:9px;padding:14px;color:#f97316;font-size:.85rem">
                    <strong>⚠️ Could not read on-chain balance:</strong> <?=esc_html( $onchain_error )?>
                    <div style="font-size:.75rem;color:#666;margin-top:6px">Try the refresh button — explorers occasionally rate-limit.</div>
                </div>
            <?php else: ?>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px">

                    <!-- Confirmed on-chain balance -->
                    <div style="background:#060606;border:1px solid #1dc92833;border-radius:10px;padding:18px">
                        <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#1dc928;margin-bottom:10px">Confirmed On-Chain</div>
                        <div id="cfp-onchain-sat" style="font-size:1.65rem;font-weight:900;font-family:monospace;color:#1dc928;line-height:1.1">
                            <?=number_format($onchain_sat)?> <span style="font-size:.7rem;color:#3a6a3a">sat</span>
                        </div>
                        <div id="cfp-onchain-coin" style="font-size:.85rem;color:#888;font-family:monospace;margin-top:4px">
                            <?=number_format($onchain_sat/1e8,8)?> <?=esc_html($currency)?>
                        </div>
                        <div id="cfp-onchain-usd" style="font-size:.75rem;color:#444;margin-top:2px">≈ $<?=number_format($onchain_usd,2)?> USD</div>
                    </div>

                    <!-- Mempool / unconfirmed -->
                    <div style="background:#060606;border:1px solid #f9731633;border-radius:10px;padding:18px">
                        <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#f97316;margin-bottom:10px">Unconfirmed (mempool)</div>
                        <div id="cfp-onchain-unconf" style="font-size:1.4rem;font-weight:800;font-family:monospace;color:<?=$onchain_unconf!==0?'#f97316':'#444'?>;line-height:1.1">
                            <?=($onchain_unconf>=0?'+':'')?><?=number_format($onchain_unconf)?> <span style="font-size:.7rem;color:#7a4520">sat</span>
                        </div>
                        <div style="font-size:.75rem;color:#555;margin-top:6px">
                            <?=$onchain_unconf>0?'Incoming transaction in mempool — waiting for confirmation.':($onchain_unconf<0?'Outgoing TX in mempool.':'No pending transactions.')?>
                        </div>
                    </div>

                    <!-- Off-chain pending earnings — with Convert to On-Chain -->
                    <div style="background:#060606;border:1px solid #3b82f633;border-radius:10px;padding:18px;display:flex;flex-direction:column;gap:10px">
                        <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#3b82f6;margin-bottom:2px">Off-Chain Pending</div>
                        <div id="cfp-offchain-balance-sat" style="font-size:1.4rem;font-weight:800;font-family:monospace;color:#3b82f6;line-height:1.1">
                            <?=number_format($pending_balance)?> <span style="font-size:.7rem;color:#1e3a6a">sat</span>
                        </div>
                        <div style="font-size:.75rem;color:#555">
                            From games / fees / ads ledger.<br>
                            Auto-sweeps on-chain when ≥ <?=number_format($threshold)?> sat.
                        </div>

                        <!-- ── OFF-CHAIN → ON-CHAIN CONVERTER ─────────────────── -->
                        <?php if ( $pending_balance > 0 ) : ?>
                        <div style="border-top:1px solid #1a2a4a;padding-top:10px;margin-top:2px">
                            <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#3b82f6;margin-bottom:8px">⚡ Convert to On-Chain</div>

                            <!-- Amount selector -->
                            <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:8px">
                                <button type="button" onclick="cfpSetConvertAmount(<?=$pending_balance?>, 1)"
                                    style="flex:1;min-width:56px;padding:4px 6px;border-radius:5px;border:1px solid #3b82f644;background:#0a1a30;color:#3b82f6;font-size:.7rem;font-weight:700;cursor:pointer">
                                    100%
                                </button>
                                <button type="button" onclick="cfpSetConvertAmount(<?=$pending_balance?>, 0.5)"
                                    style="flex:1;min-width:56px;padding:4px 6px;border-radius:5px;border:1px solid #3b82f644;background:#0a1a30;color:#3b82f6;font-size:.7rem;font-weight:700;cursor:pointer">
                                    50%
                                </button>
                                <button type="button" onclick="cfpSetConvertAmount(<?=$pending_balance?>, 0.25)"
                                    style="flex:1;min-width:56px;padding:4px 6px;border-radius:5px;border:1px solid #3b82f644;background:#0a1a30;color:#3b82f6;font-size:.7rem;font-weight:700;cursor:pointer">
                                    25%
                                </button>
                            </div>

                            <!-- Custom sat input -->
                            <div style="display:flex;gap:6px;margin-bottom:8px">
                                <input type="number" id="cfp-convert-sat-input"
                                    min="1" max="<?=$pending_balance?>"
                                    value="<?=$pending_balance?>"
                                    placeholder="Amount in sat"
                                    style="flex:1;background:#080808;border:1px solid #3b82f644;border-radius:6px;color:#3b82f6;font-family:monospace;font-size:.8rem;padding:5px 8px;width:0"
                                    oninput="cfpUpdateConvertPreview(<?=$btc_price?>)"
                                />
                                <span style="align-self:center;font-size:.7rem;color:#444">sat</span>
                            </div>
                            <div id="cfp-convert-preview" style="font-size:.68rem;color:#555;margin-bottom:8px">
                                ≈ <?=number_format($pending_balance/1e8,8)?> <?=esc_html($currency)?> · $<?=number_format($pending_balance/1e8*$btc_price,2)?> USD
                            </div>

                            <!-- Convert button -->
                            <button type="button" id="cfp-convert-offchain-btn"
                                onclick="cfpConvertOffchainToOnchain('<?=esc_js($nonce)?>', <?=$pending_balance?>)"
                                style="width:100%;padding:8px 10px;border-radius:7px;border:none;background:linear-gradient(135deg,#1a3a80,#3b82f6);color:#fff;font-size:.78rem;font-weight:800;cursor:pointer;letter-spacing:.5px;transition:opacity .2s">
                                ⛓️ Convert Off-Chain → On-Chain
                            </button>
                            <div id="cfp-convert-msg" style="font-size:.72rem;margin-top:6px;min-height:1em;text-align:center"></div>
                        </div>
                        <?php else : ?>
                        <div style="font-size:.72rem;color:#333;border-top:1px solid #111;padding-top:8px;margin-top:2px">
                            No off-chain balance to convert.
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Combined "you have it" total -->
                    <div style="background:linear-gradient(135deg,#0d2010,#060606);border:1px solid #1dc92866;border-radius:10px;padding:18px">
                        <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#1dc928;margin-bottom:10px">Total Revenue Held</div>
                        <div style="font-size:1.65rem;font-weight:900;font-family:monospace;color:#fff;line-height:1.1">
                            <?=number_format($onchain_sat + $pending_balance)?> <span style="font-size:.7rem;color:#888">sat</span>
                        </div>
                        <div style="font-size:.75rem;color:#888;margin-top:6px">
                            On-chain wallet + off-chain ledger.<br>
                            ≈ $<?=number_format(($onchain_sat + $pending_balance)/1e8 * $btc_price, 2)?> USD
                        </div>
                    </div>
                </div>

                <div style="display:flex;gap:18px;flex-wrap:wrap;justify-content:space-between;margin-top:16px;padding-top:12px;border-top:1px solid #1a2a1a;font-size:.72rem;color:#555">
                    <div>
                        <span style="color:#444;text-transform:uppercase;letter-spacing:1px">Lifetime earned (off-chain):</span>
                        <span style="color:#3b82f6;font-family:monospace;font-weight:700"><?=number_format($lifetime_earned)?> sat</span>
                    </div>
                    <div>
                        <span style="color:#444;text-transform:uppercase;letter-spacing:1px">Lifetime moved on-chain:</span>
                        <span style="color:#1dc928;font-family:monospace;font-weight:700"><?=number_format($lifetime_swept)?> sat</span>
                    </div>
                    <div>
                        <span style="color:#444;text-transform:uppercase;letter-spacing:1px">Source:</span>
                        <span style="color:#888;font-family:monospace"><?=esc_html($onchain_source ?: '—')?></span>
                        <?php if ( $onchain_age !== null ): ?>
                            <span style="color:#333"> · updated <?=esc_html($onchain_age)?>s ago</span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <script>
        (function(){

            /* ── OFF-CHAIN → ON-CHAIN CONVERTER HELPERS ──────────────── */
            window.cfpSetConvertAmount = function(maxSat, pct){
                var inp = document.getElementById('cfp-convert-sat-input');
                if(!inp) return;
                inp.value = Math.floor(maxSat * pct);
                inp.dispatchEvent(new Event('input'));
            };

            window.cfpUpdateConvertPreview = function(btcPrice){
                var inp  = document.getElementById('cfp-convert-sat-input');
                var prev = document.getElementById('cfp-convert-preview');
                if(!inp || !prev) return;
                var sat  = parseInt(inp.value, 10) || 0;
                var btc  = (sat / 1e8).toFixed(8);
                var usd  = ((sat / 1e8) * btcPrice).toFixed(2);
                prev.textContent = '≈ ' + btc + ' BTC · $' + parseFloat(usd).toLocaleString() + ' USD';
            };

            window.cfpConvertOffchainToOnchain = function(nonce, maxSat){
                var inp = document.getElementById('cfp-convert-sat-input');
                var btn = document.getElementById('cfp-convert-offchain-btn');
                var msg = document.getElementById('cfp-convert-msg');
                if(!inp || !btn || !msg) return;

                var sat = parseInt(inp.value, 10) || 0;
                if(sat < 1){
                    msg.style.color = '#f97316';
                    msg.textContent = '⚠️ Enter a valid amount in sat.';
                    return;
                }
                if(sat > maxSat){
                    msg.style.color = '#ef4444';
                    msg.textContent = '❌ Amount exceeds available off-chain balance.';
                    return;
                }

                if(!confirm('Convert ' + sat.toLocaleString() + ' sat from off-chain ledger to on-chain wallet?\n\nThis triggers a real sweep to your Trezor address via NOWPayments.')) return;

                var orig = btn.innerHTML;
                btn.disabled = true;
                btn.style.opacity = '0.6';
                btn.innerHTML = '⏳ Converting…';
                msg.textContent = '';

                var fd = new FormData();
                fd.append('action',     'cfp_convert_offchain_to_onchain');
                fd.append('nonce',      nonce);
                fd.append('amount_sat', sat);

                fetch(ajaxurl, {method:'POST', body:fd, credentials:'same-origin'})
                    .then(function(r){ return r.json(); })
                    .then(function(j){
                        if(j.success){
                            msg.style.color   = '#1dc928';
                            msg.textContent   = '✅ ' + (j.data.message || 'Conversion initiated.');
                            btn.innerHTML     = '✅ Done';

                            /* Update the off-chain balance display */
                            var newBal = (maxSat - sat);
                            var balEl  = document.getElementById('cfp-offchain-balance-sat');
                            if(balEl) balEl.innerHTML = newBal.toLocaleString() + ' <span style="font-size:.7rem;color:#1e3a6a">sat</span>';
                            inp.max   = newBal;
                            inp.value = newBal;
                            window.cfpUpdateConvertPreview(<?=$btc_price?>);

                            /* Refresh the on-chain confirmed balance */
                            setTimeout(function(){ cfpRefreshOnchain(nonce); }, 2000);
                        } else {
                            msg.style.color = '#ef4444';
                            msg.textContent = '❌ ' + (j.data || 'Sweep failed. Check sweep log below.');
                            btn.innerHTML   = orig;
                            btn.disabled    = false;
                            btn.style.opacity = '1';
                        }
                    })
                    .catch(function(){
                        msg.style.color   = '#ef4444';
                        msg.textContent   = '❌ Network error. Please try again.';
                        btn.innerHTML     = orig;
                        btn.disabled      = false;
                        btn.style.opacity = '1';
                    });
            };
            /* ──────────────────────────────────────────────────────────── */

            window.cfpRefreshOnchain = function(nonce){
                var btn = document.getElementById('cfp-onchain-refresh-btn');
                if(!btn) return;
                var original = btn.innerHTML;
                btn.disabled = true;
                btn.innerHTML = '⏳ Querying blockchain…';
                var fd = new FormData();
                fd.append('action','cfp_onchain_refresh');
                fd.append('nonce',nonce);
                fetch(ajaxurl,{method:'POST',body:fd,credentials:'same-origin'})
                    .then(function(r){return r.json();})
                    .then(function(j){
                        if(!j.success){
                            btn.innerHTML = '❌ ' + (j.data || 'Failed');
                            setTimeout(function(){btn.innerHTML=original;btn.disabled=false;},2500);
                            return;
                        }
                        var d = j.data;
                        var fmt = function(n){return Number(n).toLocaleString();};
                        var sat = document.getElementById('cfp-onchain-sat');
                        var coin = document.getElementById('cfp-onchain-coin');
                        var usd = document.getElementById('cfp-onchain-usd');
                        var unc = document.getElementById('cfp-onchain-unconf');
                        if(sat)  sat.innerHTML  = fmt(d.balance_sat) + ' <span style="font-size:.7rem;color:#3a6a3a">sat</span>';
                        if(coin) coin.textContent = (d.balance_sat/1e8).toFixed(8) + ' ' + d.currency;
                        if(unc){
                            var u = d.unconfirmed_sat || 0;
                            unc.innerHTML = (u>=0?'+':'') + fmt(u) + ' <span style="font-size:.7rem;color:#7a4520">sat</span>';
                            unc.style.color = u !== 0 ? '#f97316' : '#444';
                        }
                        btn.innerHTML = '✅ Updated';
                        setTimeout(function(){btn.innerHTML=original;btn.disabled=false;},1500);
                    })
                    .catch(function(){
                        btn.innerHTML = '❌ Network error';
                        setTimeout(function(){btn.innerHTML=original;btn.disabled=false;},2500);
                    });
            };
        })();
        </script>

        <!-- ── MANUAL SWEEP TRIGGER ──────────────────────────────────── -->
        <div class="cfp-card" style="margin-bottom:22px">
            <h2>⛓️ Manual Sweep to Trezor</h2>
            <p style="color:#666;font-size:.85rem;margin-bottom:16px">
                Trigger an immediate on-chain sweep via NOWPayments. The pending balance will be sent
                directly to your Trezor address. Bypasses the threshold check.
            </p>

            <?php if ( ! $trezor_addr || ! $api_key_set ): ?>
            <div style="background:#1a0a0a;border:1px solid #ef444433;border-radius:9px;padding:14px;margin-bottom:16px">
                <div style="color:#ef4444;font-weight:700;margin-bottom:8px">⚠️ Setup Required Before Sweeping</div>
                <div style="font-size:.82rem;color:#888">
                    <?php if ( ! $api_key_set ): ?>• NOWPayments API key not set — go to <strong>WP Admin → NOWPayments Settings</strong>.<br><?php endif; ?>
                    <?php if ( ! $trezor_addr ): ?>• Trezor address not set — configure it in the <strong>Configuration</strong> section below.<br><?php endif; ?>
                </div>
            </div>
            <?php endif; ?>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;max-width:600px;margin-bottom:16px">
                <div class="cfp-field">
                    <label>Amount to Sweep (sat)</label>
                    <div style="position:relative">
                        <input type="number" id="cfp-sweep-amount"
                            value="<?=esc_attr($pending_balance)?>"
                            min="1" max="<?=esc_attr($pending_balance)?>"
                            style="background:#111;border:1px solid #1dc92833;color:#1dc928;padding:10px 12px;border-radius:8px;font-size:.9rem;width:100%;font-family:monospace">
                        <button type="button"
                            onclick="document.getElementById('cfp-sweep-amount').value=<?=$pending_balance?>"
                            style="position:absolute;right:8px;top:50%;transform:translateY(-50%);background:#0d2010;border:1px solid #1dc92833;color:#1dc928;padding:3px 8px;border-radius:5px;font-size:.68rem;cursor:pointer;font-weight:700">
                            MAX
                        </button>
                    </div>
                    <span class="hint">Available: <?=number_format($pending_balance)?> sat</span>
                </div>
                <div class="cfp-field">
                    <label>Destination (Trezor Address)</label>
                    <input type="text" id="cfp-sweep-addr" value="<?=esc_attr($trezor_addr)?>" readonly
                        style="background:#060606;border:1px solid #1dc92833;color:#1dc928;padding:10px 12px;border-radius:8px;font-size:.78rem;font-family:monospace;width:100%">
                    <span class="hint">Set in configuration below</span>
                </div>
            </div>

            <button id="cfp-sweep-btn"
                onclick="cfpTriggerManualSweep('<?=esc_js($nonce)?>')"
                <?=(!$trezor_addr||!$api_key_set)?'disabled':''?>
                style="padding:14px 28px;background:linear-gradient(135deg,#1dc928,#009900);color:#000;font-weight:900;font-size:1rem;border:none;border-radius:10px;cursor:pointer;letter-spacing:1.5px;text-transform:uppercase;opacity:<?=(!$trezor_addr||!$api_key_set)?'.4':'1'?>">
                🔐 SWEEP TO TREZOR VIA NOWPAYMENTS
            </button>

            <div style="margin-top:14px;background:#060606;border:1px solid #1a2a1a;border-radius:9px;padding:13px">
                <div style="font-size:.72rem;font-weight:700;color:#1dc928;margin-bottom:8px">ℹ️ How This Works</div>
                <?php foreach ([
                    'Calls NOWPayments Mass Payout API → sends crypto directly on-chain to your Trezor address',
                    'If NOWPayments API fails, the sweep is queued below for manual retry',
                    'On success: ledger is updated with a negative entry to zero the pending balance',
                    'Ensure your Trezor address is whitelisted in your NOWPayments account settings',
                    'NOWPayments must have "Allow API withdrawals" enabled in your account',
                ] as $note): ?>
                <div style="display:flex;gap:8px;margin-bottom:5px;align-items:flex-start">
                    <span style="color:#1dc928;font-size:.8rem;flex-shrink:0">✓</span>
                    <span style="font-size:.78rem;color:#3a6a3a;line-height:1.45"><?=$note?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- ── PENDING QUEUE ────────────────────────────────────────── -->
        <?php if ( ! empty( $pending_queue ) ): ?>
        <div class="cfp-card" style="margin-bottom:22px;border-color:#f9731644">
            <h2 style="color:#f97316">⚠️ Pending Sweep Queue (<?=count($pending_queue)?> item<?=(count($pending_queue)>1?'s':'')?>)</h2>
            <p style="color:#666;font-size:.82rem;margin-bottom:14px">
                These sweeps failed to auto-send via NOWPayments. Retry, mark as manually sent, or dismiss.
            </p>
            <table class="cfp-table" style="font-size:.82rem">
                <thead>
                    <tr><th>#</th><th>Amount</th><th>To Address</th><th>Error</th><th>Attempts</th><th>Queued</th><th>Actions</th></tr>
                </thead>
                <tbody>
                <?php foreach ( $pending_queue as $q ): ?>
                <tr id="cfp-queue-row-<?=esc_attr($q->id)?>">
                    <td style="color:#555">#<?=esc_html($q->id)?></td>
                    <td style="font-weight:700;color:#f97316;font-family:monospace"><?=number_format($q->amount_sat)?> sat</td>
                    <td style="font-family:monospace;font-size:.74rem;color:#888;max-width:160px;word-break:break-all"><?=esc_html(substr($q->to_address,0,20))?>…</td>
                    <td style="color:#ef4444;font-size:.76rem;max-width:200px"><?=esc_html(substr($q->error_msg??'',0,80))?></td>
                    <td style="color:#888"><?=esc_html($q->attempts)?></td>
                    <td style="color:#444;font-size:.74rem"><?=esc_html(date('M j H:i',strtotime($q->created_at)))?></td>
                    <td>
                        <div style="display:flex;gap:6px;flex-wrap:wrap">
                            <button onclick="cfpRetrySweep(<?=esc_attr($q->id)?>, '<?=esc_js($nonce)?>')"
                                style="background:#0a1a0a;border:1px solid #1dc92844;color:#1dc928;padding:5px 10px;border-radius:6px;font-size:.72rem;cursor:pointer;font-weight:700">
                                🔄 Retry via NP
                            </button>
                            <button onclick="cfpShowMarkSentForm(<?=esc_attr($q->id)?>)"
                                style="background:#0a0a1a;border:1px solid #3b82f644;color:#3b82f6;padding:5px 10px;border-radius:6px;font-size:.72rem;cursor:pointer">
                                ✓ Mark Sent
                            </button>
                            <button onclick="cfpDismissSweep(<?=esc_attr($q->id)?>, '<?=esc_js($nonce)?>')"
                                style="background:#1a0a0a;border:1px solid #ef444433;color:#ef4444;padding:5px 10px;border-radius:6px;font-size:.72rem;cursor:pointer">
                                ✗ Dismiss
                            </button>
                        </div>
                        <div id="cfp-mark-sent-<?=esc_attr($q->id)?>" style="display:none;margin-top:8px">
                            <input type="text" id="cfp-txhash-<?=esc_attr($q->id)?>"
                                placeholder="TX hash or NP Payout ID (optional)"
                                style="background:#111;border:1px solid #1a1a1a;color:#aaa;padding:6px 10px;border-radius:6px;font-size:.76rem;margin-bottom:5px;width:100%">
                            <button onclick="cfpMarkSent(<?=esc_attr($q->id)?>, '<?=esc_js($nonce)?>')"
                                style="background:#0a1a0a;border:1px solid #1dc92844;color:#1dc928;padding:5px 12px;border-radius:6px;font-size:.72rem;cursor:pointer;font-weight:700">
                                💾 Save
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

        <!-- ── SWEEP HISTORY ───────────────────────────────────────── -->
        <div class="cfp-card" style="margin-bottom:22px">
            <h2>📋 Sweep History</h2>
            <?php if ( empty( $recent_sweeps ) ): ?>
            <div style="text-align:center;color:#444;padding:20px;font-size:.85rem">No sweeps completed yet.</div>
            <?php else: ?>
            <table class="cfp-table" style="font-size:.8rem">
                <thead>
                    <tr><th>#</th><th>Type</th><th>Amount</th><th>Address</th><th>NP Payout ID / TX</th><th>Status</th><th>Date</th></tr>
                </thead>
                <tbody>
                <?php foreach ( $recent_sweeps as $s ):
                    $color = $s->status === 'sent' ? '#1dc928' : ( $s->status === 'failed' ? '#ef4444' : '#888' );
                ?>
                <tr>
                    <td style="color:#555">#<?=esc_html($s->id)?></td>
                    <td style="color:#888;font-size:.74rem"><?=esc_html($s->type)?></td>
                    <td style="font-weight:700;color:#1dc928;font-family:monospace"><?=number_format($s->amount_sat)?> sat</td>
                    <td style="font-family:monospace;font-size:.74rem;color:#555"><?=esc_html(substr($s->to_address,0,16))?>…</td>
                    <td style="font-family:monospace;font-size:.72rem;color:#3b82f6"><?=esc_html(substr($s->np_payout_id??$s->tx_hash??'—',0,30))?></td>
                    <td><span style="color:<?=esc_attr($color)?>;font-weight:700;font-size:.75rem"><?=esc_html(strtoupper($s->status))?></span></td>
                    <td style="color:#333;font-size:.74rem"><?=esc_html(date('M j H:i',strtotime($s->updated_at??$s->created_at)))?></td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- ── CONFIGURATION ──────────────────────────────────────── -->
        <div class="cfp-card" style="margin-bottom:22px">
            <h2>⚙️ Trezor Sweep Configuration</h2>

            <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;margin-bottom:20px">
                <div class="cfp-field" style="grid-column:1/-1">
                    <label>Trezor Receiving Address</label>
                    <input type="text" id="cfp-cfg-addr"
                        value="<?=esc_attr($trezor_addr)?>"
                        placeholder="bc1q… or 1… or 3…"
                        style="background:#111;border:1px solid #1dc92833;color:#1dc928;padding:10px 12px;border-radius:8px;font-family:monospace;font-size:.82rem;width:100%;box-sizing:border-box">
                    <span class="hint">Your Trezor receiving address. Must be whitelisted in your NOWPayments account settings.</span>
                </div>
                <div class="cfp-field">
                    <label>Device Label</label>
                    <input type="text" id="cfp-cfg-label" value="<?=esc_attr($trezor_label)?>"
                        style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                </div>
                <div class="cfp-field">
                    <label>Device Model</label>
                    <select id="cfp-cfg-model" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                        <?php foreach (['Trezor One','Model T','Model T2T1','Safe 3','Safe 5'] as $m): ?>
                        <option value="<?=esc_attr($m)?>" <?=selected($trezor_model,$m,false)?>><?=esc_html($m)?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="cfp-field">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                        <input type="checkbox" id="cfp-cfg-auto" <?=$auto_enabled==='1'?'checked':''?>>
                        Auto-Sweep Enabled (Threshold mode)
                    </label>
                    <span class="hint">Sweep fires automatically via NOWPayments on every revenue credit once threshold is met.</span>
                </div>

                <div class="cfp-field" style="background:#0a0a0a;border:1px solid #facc1555;border-radius:10px;padding:14px;margin-top:8px">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-weight:700;color:#facc15">
                        <input type="checkbox" id="cfp-cfg-instant" <?=$instant_enabled==='1'?'checked':''?>>
                        ⚡ Instant On-Chain Conversion (per earning)
                    </label>
                    <span class="hint" style="display:block;margin-top:6px;line-height:1.45">
                        When ON, <strong style="color:#facc15">every revenue credit is converted off-chain → on-chain immediately</strong>
                        via NOWPayments — your Trezor's confirmed balance grows in real time as earnings come in.
                        Threshold is bypassed; only the dust floor below applies.
                        ⚠️ Each sweep incurs a NOWPayments network fee — set the dust floor high enough so the fee doesn't eat your earnings.
                    </span>
                    <div style="display:flex;align-items:flex-end;gap:10px;margin-top:10px;flex-wrap:wrap">
                        <div style="flex:1;min-width:160px">
                            <label style="font-size:.75rem;color:#888;margin-bottom:4px;display:block">Dust floor (sat) — credits below this accumulate</label>
                            <input type="number" id="cfp-cfg-instant-min"
                                value="<?=esc_attr($instant_min)?>"
                                min="1" max="100000000" step="100"
                                style="background:#111;border:1px solid #facc1544;color:#facc15;padding:8px 10px;border-radius:6px;font-family:monospace;width:100%;box-sizing:border-box">
                        </div>
                        <div style="display:flex;gap:6px;flex-wrap:wrap">
                            <?php foreach ([1000,5000,10000,50000,100000] as $preset): ?>
                            <button type="button"
                                onclick="document.getElementById('cfp-cfg-instant-min').value=<?=$preset?>"
                                style="background:#111;border:1px solid #333;color:#888;padding:6px 10px;border-radius:6px;font-size:.72rem;cursor:pointer;font-family:monospace">
                                <?=number_format($preset)?>
                            </button>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <div class="cfp-field">
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                        <input type="checkbox" id="cfp-cfg-email" <?=$email_notify==='1'?'checked':''?>>
                        Email Notification on Sweep
                    </label>
                </div>
            </div>

            <!-- Global Threshold Editor -->
            <div style="background:#0a0a0a;border:1px solid #1dc92833;border-radius:10px;padding:20px;margin-bottom:20px">
                <h3 style="margin:0 0 6px;font-size:.95rem;color:#1dc928">🎯 Global Auto-Sweep Threshold</h3>
                <p style="color:#666;font-size:.8rem;margin:0 0 16px">
                    Auto-sweep via NOWPayments fires when <strong style="color:#aaa">total pending balance ≥ this value</strong>.
                    Floor: 10,000 sat. Ceiling: 100,000,000 sat (1 BTC safety cap).
                </p>

                <div style="display:flex;align-items:flex-end;gap:12px;flex-wrap:wrap;margin-bottom:14px">
                    <div style="flex:1;min-width:180px">
                        <label style="font-size:.78rem;color:#888;margin-bottom:4px;display:block">Satoshis (sat)</label>
                        <input type="number" id="cfp-cfg-threshold"
                            value="<?=esc_attr($threshold)?>"
                            min="10000" max="100000000" step="1000"
                            oninput="cfpThresholdSync('sat')"
                            style="background:#111;border:2px solid #1dc92855;color:#1dc928;padding:10px 12px;border-radius:8px;font-family:monospace;font-size:1rem;font-weight:700;width:100%;box-sizing:border-box">
                    </div>
                    <div style="flex:1;min-width:140px">
                        <label style="font-size:.78rem;color:#888;margin-bottom:4px;display:block">BTC</label>
                        <input type="number" id="cfp-cfg-threshold-btc"
                            value="<?=number_format($threshold/100000000,8,'.','')?>"
                            min="0.0001" max="1" step="0.00001"
                            oninput="cfpThresholdSync('btc')"
                            style="background:#111;border:1px solid #f7931a44;color:#f7931a;padding:10px 12px;border-radius:8px;font-family:monospace;font-size:.9rem;width:100%;box-sizing:border-box">
                    </div>
                    <div style="flex:1;min-width:140px">
                        <label style="font-size:.78rem;color:#888;margin-bottom:4px;display:block">USD (≈)</label>
                        <input type="number" id="cfp-cfg-threshold-usd"
                            value="<?=number_format($threshold/100000000*$btc_price,2,'.','')?>"
                            min="0" step="0.01"
                            oninput="cfpThresholdSync('usd')"
                            style="background:#111;border:1px solid #22c55e44;color:#22c55e;padding:10px 12px;border-radius:8px;font-family:monospace;font-size:.9rem;width:100%;box-sizing:border-box">
                        <span style="font-size:.72rem;color:#555">BTC/USD: $<?=number_format($btc_price)?></span>
                    </div>
                </div>

                <!-- Quick preset buttons -->
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:14px">
                    <?php
                    $presets = [
                        ['10K sat',  10000,    '0.0001 BTC — practical minimum'],
                        ['50K sat',  50000,    '0.0005 BTC'],
                        ['100K sat', 100000,   '0.001 BTC — default'],
                        ['250K sat', 250000,   '0.0025 BTC'],
                        ['500K sat', 500000,   '0.005 BTC'],
                        ['1M sat',   1000000,  '0.01 BTC'],
                        ['5M sat',   5000000,  '0.05 BTC'],
                        ['1 BTC',    100000000,'maximum allowed'],
                    ];
                    foreach ($presets as [$label, $sat, $hint]):
                    ?>
                    <button type="button"
                        onclick="cfpSetThreshold(<?=(int)$sat?>, <?=(float)$btc_price?>)"
                        title="<?=esc_attr($hint)?>"
                        style="background:<?=$threshold===$sat?'#1dc92822':'#111'?>;border:1px solid <?=$threshold===$sat?'#1dc928':'#333'?>;
                               color:<?=$threshold===$sat?'#1dc928':'#888'?>;padding:6px 12px;border-radius:6px;font-size:.75rem;
                               cursor:pointer;font-family:monospace;transition:all .15s"
                        class="cfp-preset-btn" data-sat="<?=(int)$sat?>">
                        <?=esc_html($label)?>
                    </button>
                    <?php endforeach; ?>
                </div>

                <!-- Relay status bar -->
                <?php
                $bal_pct     = $threshold > 0 ? min(100, round($pending_balance / $threshold * 100)) : 0;
                $relay_armed = !empty($trezor_addr) && cfp_np_enabled() && !empty(cfp_np_api_key()) && $auto_enabled==='1';
                ?>
                <div style="background:#111;border:1px solid #1a1a1a;border-radius:8px;padding:12px;display:flex;gap:16px;flex-wrap:wrap;align-items:center">
                    <div style="display:flex;align-items:center;gap:6px">
                        <span style="font-size:.75rem;color:#555">NOWPayments Relay:</span>
                        <span style="font-weight:700;font-size:.78rem;color:<?=$relay_armed?'#1dc928':'#ef4444'?>">
                            <?=$relay_armed?'🟢 ARMED':'🔴 NOT ARMED'?>
                        </span>
                    </div>
                    <div style="display:flex;align-items:center;gap:6px">
                        <span style="font-size:.75rem;color:#555">Pending:</span>
                        <span style="font-family:monospace;font-size:.8rem;color:<?=$threshold_met?'#1dc928':'#f97316'?>">
                            <?=number_format($pending_balance)?> / <?=number_format($threshold)?> sat
                        </span>
                    </div>
                    <div style="flex:1;min-width:120px">
                        <div style="background:#1a1a1a;border-radius:4px;height:7px;overflow:hidden">
                            <div style="width:<?=$bal_pct?>%;height:100%;background:linear-gradient(90deg,<?=$threshold_met?'#1dc928,#22ff44':'#f97316,#fbbf24'?>);border-radius:4px;transition:width .5s"></div>
                        </div>
                        <span style="font-size:.7rem;color:#555"><?=$bal_pct?>% of threshold</span>
                    </div>
                    <?php if ($threshold_met): ?>
                    <span style="background:#1dc92222;color:#1dc928;border:1px solid #1dc92844;padding:4px 10px;border-radius:5px;font-size:.75rem;font-weight:700">
                        ⚡ READY TO FIRE
                    </span>
                    <?php else: ?>
                    <span style="color:#555;font-size:.75rem"><?=number_format($threshold - $pending_balance)?> sat to go</span>
                    <?php endif; ?>
                </div>
            </div>

            <button onclick="cfpSaveSweepSettings('<?=esc_js($nonce)?>')"
                class="cfp-btn cfp-btn-gold" style="padding:12px 28px">
                💾 Save Configuration
            </button>
        </div>

        <!-- ── NOWPAYMENTS SETUP GUIDE ────────────────────────────── -->
        <div class="cfp-card">
            <h2>📖 NOWPayments Setup Guide</h2>
            <p style="color:#666;font-size:.85rem;margin-bottom:14px">
                Follow these steps to allow the plugin to sweep earnings to your Trezor on-chain via NOWPayments.
            </p>
            <div style="display:flex;flex-direction:column;gap:10px">
                <?php $steps = [
                    ['Log into <strong>nowpayments.io</strong> with your merchant account', '#f7931a'],
                    ['Go to <strong>Store Settings → Security</strong> and enable <strong>"Allow withdrawals via API"</strong>', '#22c55e'],
                    ['Go to <strong>Store Settings → Whitelisted Addresses</strong> and add your Trezor Bitcoin address', '#3b82f6'],
                    ['Copy your API key from <strong>Store Settings → API Keys</strong> and paste it into <strong>WP Admin → NOWPayments Settings</strong>', '#a855f7'],
                    ['Set your Trezor receiving address in the <strong>Configuration</strong> section above', '#1dc928'],
                    ['Set your threshold and enable Auto-Sweep — earnings above the threshold will be swept to your Trezor automatically!', '#f97316'],
                ]; foreach ($steps as $i => [$text, $color]): ?>
                <div style="display:flex;gap:12px;align-items:flex-start;background:#0d0d0d;border:1px solid #1a1a1a;border-radius:8px;padding:12px">
                    <span style="background:<?=esc_attr($color)?>;color:#000;font-weight:900;font-size:.75rem;padding:3px 8px;border-radius:5px;flex-shrink:0;min-width:20px;text-align:center"><?=$i+1?></span>
                    <span style="font-size:.82rem;color:#aaa;line-height:1.5"><?=$text?></span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script>
    const cfpAjaxUrl = '<?=esc_js(admin_url('admin-ajax.php'))?>';

    function cfpTrezorMsg(msg, ok) {
        const el = document.getElementById('cfp-trezor-msg');
        if (!el) return;
        el.innerHTML = `<div class="cfp-notice ${ok?'success':'error'}" style="margin-bottom:0">${msg}</div>`;
        setTimeout(() => { el.innerHTML = ''; }, 8000);
    }

    async function cfpTriggerManualSweep(nonce) {
        const amt  = parseInt(document.getElementById('cfp-sweep-amount')?.value || 0);
        const addr = document.getElementById('cfp-sweep-addr')?.value || '';
        if (!addr) { cfpTrezorMsg('⚠️ No Trezor address configured.', false); return; }
        if (!amt)  { cfpTrezorMsg('⚠️ Enter an amount to sweep.', false); return; }
        if (!confirm(`Sweep ${amt.toLocaleString()} sat via NOWPayments to:\n${addr}\n\nThis will send on-chain to your Trezor. Proceed?`)) return;

        const btn = document.getElementById('cfp-sweep-btn');
        if (btn) { btn.textContent = '⏳ Sweeping via NOWPayments…'; btn.disabled = true; }

        const fd = new FormData();
        fd.append('action', 'cfp_trezor_manual_sweep');
        fd.append('nonce', nonce);
        fd.append('amount_sat', amt);
        try {
            const r = await fetch(cfpAjaxUrl, { method: 'POST', body: fd });
            const d = await r.json();
            cfpTrezorMsg(d.data, d.success);
            if (d.success) setTimeout(() => location.reload(), 2000);
        } catch(e) { cfpTrezorMsg('Request failed: ' + e.message, false); }
        finally { if (btn) { btn.textContent = '🔐 SWEEP TO TREZOR VIA NOWPAYMENTS'; btn.disabled = false; } }
    }

    async function cfpRetrySweep(queueId, nonce) {
        if (!confirm('Retry this sweep via NOWPayments?')) return;
        const fd = new FormData();
        fd.append('action', 'cfp_trezor_retry_sweep');
        fd.append('nonce', nonce);
        fd.append('queue_id', queueId);
        try {
            const r = await fetch(cfpAjaxUrl, { method: 'POST', body: fd });
            const d = await r.json();
            cfpTrezorMsg(d.data, d.success);
            if (d.success) setTimeout(() => location.reload(), 2000);
        } catch(e) { cfpTrezorMsg('Retry failed: ' + e.message, false); }
    }

    function cfpShowMarkSentForm(queueId) {
        const el = document.getElementById('cfp-mark-sent-' + queueId);
        if (el) el.style.display = el.style.display === 'none' ? 'block' : 'none';
    }

    async function cfpMarkSent(queueId, nonce) {
        const txHash = document.getElementById('cfp-txhash-' + queueId)?.value || '';
        const fd = new FormData();
        fd.append('action', 'cfp_trezor_mark_sent');
        fd.append('nonce', nonce);
        fd.append('queue_id', queueId);
        fd.append('tx_hash', txHash);
        try {
            const r = await fetch(cfpAjaxUrl, { method: 'POST', body: fd });
            const d = await r.json();
            cfpTrezorMsg(d.data, d.success);
            if (d.success) { const row = document.getElementById('cfp-queue-row-' + queueId); if (row) row.style.opacity = '0.3'; setTimeout(() => location.reload(), 1500); }
        } catch(e) { cfpTrezorMsg('Failed: ' + e.message, false); }
    }

    async function cfpDismissSweep(queueId, nonce) {
        if (!confirm('Dismiss this queue entry? No ledger entry will be made.')) return;
        const fd = new FormData();
        fd.append('action', 'cfp_trezor_dismiss_sweep');
        fd.append('nonce', nonce);
        fd.append('queue_id', queueId);
        try {
            const r = await fetch(cfpAjaxUrl, { method: 'POST', body: fd });
            const d = await r.json();
            cfpTrezorMsg(d.data, d.success);
            if (d.success) { const row = document.getElementById('cfp-queue-row-' + queueId); if (row) row.remove(); }
        } catch(e) { cfpTrezorMsg('Failed: ' + e.message, false); }
    }

    const CFP_BTC_PRICE = parseFloat('<?=floatval($btc_price)?>') || 67694;

    function cfpThresholdSync(source) {
        const satEl = document.getElementById('cfp-cfg-threshold');
        const btcEl = document.getElementById('cfp-cfg-threshold-btc');
        const usdEl = document.getElementById('cfp-cfg-threshold-usd');
        if (!satEl || !btcEl || !usdEl) return;
        let sat;
        if (source === 'sat')      sat = Math.round(parseFloat(satEl.value) || 0);
        else if (source === 'btc') sat = Math.round((parseFloat(btcEl.value) || 0) * 1e8);
        else                       sat = Math.round(((parseFloat(usdEl.value) || 0) / CFP_BTC_PRICE) * 1e8);
        sat = Math.min(100000000, Math.max(0, sat));
        if (source !== 'sat') satEl.value = sat;
        if (source !== 'btc') btcEl.value = (sat / 1e8).toFixed(8);
        if (source !== 'usd') usdEl.value = ((sat / 1e8) * CFP_BTC_PRICE).toFixed(2);
        document.querySelectorAll('.cfp-preset-btn').forEach(btn => {
            const active = parseInt(btn.dataset.sat) === sat;
            btn.style.background   = active ? '#1dc92822' : '#111';
            btn.style.borderColor  = active ? '#1dc928'   : '#333';
            btn.style.color        = active ? '#1dc928'   : '#888';
        });
    }

    function cfpSetThreshold(sat) {
        const el = document.getElementById('cfp-cfg-threshold');
        if (el) { el.value = sat; cfpThresholdSync('sat'); }
    }

    async function cfpSaveSweepSettings(nonce) {
        const fd = new FormData();
        fd.append('action', 'cfp_trezor_save_settings');
        fd.append('nonce', nonce);
        fd.append('trezor_active_address',  document.getElementById('cfp-cfg-addr')?.value || '');
        fd.append('trezor_sweep_threshold', document.getElementById('cfp-cfg-threshold')?.value || 100000);
        fd.append('trezor_label',           document.getElementById('cfp-cfg-label')?.value || '');
        fd.append('trezor_model',           document.getElementById('cfp-cfg-model')?.value || '');
        if (document.getElementById('cfp-cfg-auto')?.checked)    fd.append('trezor_auto_sweep_enabled', '1');
        if (document.getElementById('cfp-cfg-instant')?.checked) fd.append('trezor_instant_sweep_enabled', '1');
        if (document.getElementById('cfp-cfg-email')?.checked)   fd.append('trezor_email_on_sweep', '1');
        fd.append('trezor_instant_min', document.getElementById('cfp-cfg-instant-min')?.value || '5000');
        document.querySelectorAll('[name^="trezor_stream_threshold_"]').forEach(el => fd.append(el.name, el.value));
        try {
            const r = await fetch(cfpAjaxUrl, { method: 'POST', body: fd });
            const d = await r.json();
            cfpTrezorMsg(d.success ? '✅ ' + d.data : '❌ ' + d.data, d.success);
            if (d.success) {
                const addrEl = document.getElementById('cfp-sweep-addr');
                if (addrEl) addrEl.value = document.getElementById('cfp-cfg-addr')?.value || '';
                setTimeout(() => location.reload(), 1800);
            }
        } catch(e) { cfpTrezorMsg('Save failed: ' + e.message, false); }
    }
    </script>
    <?php
}
