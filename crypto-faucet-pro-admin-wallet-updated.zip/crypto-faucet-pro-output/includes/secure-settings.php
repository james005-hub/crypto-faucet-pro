<?php
/**
 * Secure Settings Storage with Encryption
 *
 * Encrypts sensitive settings like API keys before storing in database.
 * Uses WordPress salts as encryption key for environment-specific security.
 *
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   ENCRYPTION FUNCTIONS
   ============================================================ */

/**
 * Get encryption key derived from WordPress salts (used for settings encryption only).
 * Renamed from cfp_get_encryption_key() to avoid collision with the stronger
 * PBKDF2 implementation in cfp-crypto-primitives.php.
 */
function cfp_get_settings_encryption_key() {
    // Use WordPress auth salts to derive encryption key
    // This is unique per installation and changes if salts are rotated
    $key_material = AUTH_KEY . SECURE_AUTH_KEY . LOGGED_IN_KEY . NONCE_KEY;

    // Derive a 256-bit key using SHA-256
    return hash('sha256', $key_material, true);
}

/**
 * Encrypt sensitive data before storing
 * Uses AES-256-GCM for authenticated encryption
 *
 * @param string $plaintext Data to encrypt
 * @return string Base64-encoded encrypted data with nonce and tag
 */
function cfp_encrypt_setting($plaintext) {
    if (empty($plaintext)) {
        return '';
    }

    // Check if OpenSSL is available
    if (!function_exists('openssl_encrypt')) {
        error_log('[CFP Security] OpenSSL not available - storing plaintext (INSECURE)');
        return 'PLAIN:' . $plaintext; // Fallback to plaintext with prefix
    }

    $key = cfp_get_settings_encryption_key();

    // Use AES-256-GCM for authenticated encryption (prevents tampering)
    $cipher = 'aes-256-gcm';

    // Generate random IV (nonce) - 12 bytes for GCM
    $iv = random_bytes(12);

    // Encrypt with authentication tag
    $tag = '';
    $ciphertext = openssl_encrypt(
        $plaintext,
        $cipher,
        $key,
        OPENSSL_RAW_DATA,
        $iv,
        $tag,
        '', // No additional authenticated data
        16  // Tag length: 16 bytes (128 bits)
    );

    if ($ciphertext === false) {
        error_log('[CFP Security] Encryption failed: ' . openssl_error_string());
        return '';
    }

    // Combine: version(1) + iv(12) + tag(16) + ciphertext
    // Version byte allows future algorithm changes
    $encrypted = "\x01" . $iv . $tag . $ciphertext;

    // Base64 encode for safe storage
    return 'ENC:' . base64_encode($encrypted);
}

/**
 * Decrypt sensitive data after retrieval
 *
 * @param string $encrypted Base64-encoded encrypted data
 * @return string Decrypted plaintext, or empty string on failure
 */
function cfp_decrypt_setting($encrypted) {
    if (empty($encrypted)) {
        return '';
    }

    // Handle plaintext fallback
    if (strpos($encrypted, 'PLAIN:') === 0) {
        $plaintext = substr($encrypted, 6);

        // Auto-migrate to encrypted storage
        if (!empty($plaintext)) {
            error_log('[CFP Security] Auto-migrating plaintext setting to encrypted storage');
            // Note: Caller should save the encrypted version
        }

        return $plaintext;
    }

    // Check for encrypted prefix
    if (strpos($encrypted, 'ENC:') !== 0) {
        return ''; // Invalid format
    }

    $encrypted = substr($encrypted, 4); // Remove 'ENC:' prefix

    // Check if OpenSSL is available
    if (!function_exists('openssl_decrypt')) {
        error_log('[CFP Security] OpenSSL not available - cannot decrypt');
        return '';
    }

    $key = cfp_get_settings_encryption_key();

    // Decode from base64
    $data = base64_decode($encrypted, true);
    if ($data === false || strlen($data) < 29) { // 1 + 12 + 16 minimum
        error_log('[CFP Security] Invalid encrypted data format');
        return '';
    }

    // Extract components
    $version = ord($data[0]);

    if ($version !== 1) {
        error_log('[CFP Security] Unknown encryption version: ' . $version);
        return '';
    }

    $iv = substr($data, 1, 12);
    $tag = substr($data, 13, 16);
    $ciphertext = substr($data, 29);

    // Decrypt with authentication
    $plaintext = openssl_decrypt(
        $ciphertext,
        'aes-256-gcm',
        $key,
        OPENSSL_RAW_DATA,
        $iv,
        $tag
    );

    if ($plaintext === false) {
        error_log('[CFP Security] Decryption failed - data may be corrupted or tampered');
        return '';
    }

    return $plaintext;
}

/* ============================================================
   SECURE SETTINGS HELPERS
   ============================================================ */

/**
 * List of sensitive settings that should be encrypted
 */
function cfp_get_sensitive_settings() {
    return [
        'blockchain_api_key',
        'blockchain_ipn_secret',
        'blockchain_ipn_enhanced_secret',
        'recaptcha_secret_key',
        'nowpayments_api_key',
        'nowpayments_ipn_secret',
        // Coinbase Commerce API credentials
        'coinbase_api_key',
        'coinbase_webhook_secret',
        'smtp_password',
        'twofa_master_secret',
    ];
}

/**
 * Save setting with automatic encryption for sensitive keys
 *
 * @param string $key Setting key
 * @param string $value Setting value
 */
function cfp_update_secure_setting($key, $value) {
    $sensitive_keys = cfp_get_sensitive_settings();

    // Encrypt if this is a sensitive setting
    if (in_array($key, $sensitive_keys, true)) {
        $value = cfp_encrypt_setting($value);
    }

    return cfp_update_setting($key, $value);
}

/**
 * Get setting with automatic decryption for sensitive keys
 *
 * @param string $key Setting key
 * @param string $default Default value if not found
 * @return string Decrypted value
 */
function cfp_get_secure_setting($key, $default = '') {
    $value = cfp_get_setting($key, $default);

    if (empty($value)) {
        return $default;
    }

    $sensitive_keys = cfp_get_sensitive_settings();

    // Decrypt if this is a sensitive setting
    if (in_array($key, $sensitive_keys, true)) {
        // Check if already encrypted
        if (strpos($value, 'ENC:') === 0 || strpos($value, 'PLAIN:') === 0) {
            return cfp_decrypt_setting($value);
        }

        // Legacy plaintext - auto-migrate to encrypted
        if (!empty($value)) {
            error_log("[CFP Security] Auto-encrypting legacy plaintext setting: {$key}");
            $encrypted = cfp_encrypt_setting($value);
            cfp_update_setting($key, $encrypted);
            return $value;
        }
    }

    return $value;
}

/* ============================================================
   ADMIN MIGRATION TOOL
   ============================================================ */

/**
 * Migrate all sensitive settings to encrypted storage
 * Call this after plugin update
 */
function cfp_migrate_settings_to_encrypted() {
    $sensitive_keys = cfp_get_sensitive_settings();
    $migrated = 0;

    foreach ($sensitive_keys as $key) {
        $value = cfp_get_setting($key, '');

        // Skip if empty or already encrypted
        if (empty($value) || strpos($value, 'ENC:') === 0) {
            continue;
        }

        // Encrypt and save
        $encrypted = cfp_encrypt_setting($value);
        if (!empty($encrypted)) {
            cfp_update_setting($key, $encrypted);
            $migrated++;
        }
    }

    if ($migrated > 0) {
        error_log("[CFP Security] Migrated {$migrated} sensitive settings to encrypted storage");
    }

    return $migrated;
}

// Auto-migrate on admin init
add_action('admin_init', function() {
    $migration_done = get_option('cfp_encryption_migrated', '0');
    if ($migration_done !== '1') {
        cfp_migrate_settings_to_encrypted();
        update_option('cfp_encryption_migrated', '1');
    }
}, 5);

/* ============================================================
   BACKWARD COMPATIBILITY WRAPPERS
   ============================================================ */

// Override existing setting functions for sensitive data
// This ensures all code automatically uses encryption
add_filter('cfp_get_setting_faucetpay_api_key', function($value, $default) {
    return cfp_get_secure_setting('blockchain_api_key', $default);
}, 10, 2);

add_filter('cfp_get_setting_faucetpay_ipn_secret', function($value, $default) {
    return cfp_get_secure_setting('blockchain_ipn_secret', $default);
}, 10, 2);

add_filter('cfp_get_setting_recaptcha_secret_key', function($value, $default) {
    return cfp_get_secure_setting('recaptcha_secret_key', $default);
}, 10, 2);

add_filter('cfp_get_setting_nowpayments_api_key', function($value, $default) {
    return cfp_get_secure_setting('nowpayments_api_key', $default);
}, 10, 2);

add_filter('cfp_get_setting_coinbase_api_key', function($value, $default) {
    return cfp_get_secure_setting('coinbase_api_key', $default);
}, 10, 2);

add_filter('cfp_get_setting_coinbase_webhook_secret', function($value, $default) {
    return cfp_get_secure_setting('coinbase_webhook_secret', $default);
}, 10, 2);

/* ============================================================
   ADMIN NOTICE: ENCRYPTION STATUS
   ============================================================ */

add_action('admin_notices', function() {
    $screen = get_current_screen();
    if (!$screen || strpos($screen->id, 'cfp') === false) {
        return; // Only show on plugin admin pages
    }

    // Check if OpenSSL is available
    if (!function_exists('openssl_encrypt')) {
        ?>
        <div class="notice notice-error">
            <p><strong>Crypto Faucet Pro Security Warning:</strong> OpenSSL is not available. API keys are being stored in PLAINTEXT. Please enable the PHP OpenSSL extension.</p>
        </div>
        <?php
        return;
    }

    // Check if sensitive settings are encrypted
    $sensitive_keys = cfp_get_sensitive_settings();
    $plaintext_found = false;

    foreach ($sensitive_keys as $key) {
        $raw_value = cfp_get_setting($key, '');
        if (!empty($raw_value) && strpos($raw_value, 'ENC:') !== 0 && strpos($raw_value, 'PLAIN:') !== 0) {
            $plaintext_found = true;
            break;
        }
    }

    if ($plaintext_found) {
        ?>
        <div class="notice notice-warning is-dismissible">
            <p><strong>Crypto Faucet Pro:</strong> Some API keys are stored in plaintext. They will be automatically encrypted when you save settings.</p>
        </div>
        <?php
    }
});

/* ============================================================
   ADMIN TEST FUNCTION
   ============================================================ */

/**
 * Test encryption/decryption
 * Use: cfp_test_encryption()
 */
function cfp_test_encryption() {
    $test_data = 'Test_API_Key_12345!@#$%';

    echo "Testing encryption...\n";
    echo "Original: {$test_data}\n";

    $encrypted = cfp_encrypt_setting($test_data);
    echo "Encrypted: {$encrypted}\n";

    $decrypted = cfp_decrypt_setting($encrypted);
    echo "Decrypted: {$decrypted}\n";

    if ($test_data === $decrypted) {
        echo "✅ Encryption test PASSED\n";
    } else {
        echo "❌ Encryption test FAILED\n";
    }
}
