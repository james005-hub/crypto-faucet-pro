<?php
/**
 * XP & Level System — players earn XP for every action.
 * Levels unlock perks: higher claim amounts, lower house edge, etc.
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// XP thresholds per level (cumulative)
function cfp_xp_levels() {
    return [
        1  => ['xp'=>0,      'label'=>'Newcomer',    'icon'=>'🌱', 'perk'=>''],
        2  => ['xp'=>500,    'label'=>'Rookie',      'icon'=>'🔰', 'perk'=>'+5% claim bonus'],
        3  => ['xp'=>1500,   'label'=>'Player',      'icon'=>'🎮', 'perk'=>'+10% claim bonus'],
        4  => ['xp'=>4000,   'label'=>'Gamer',       'icon'=>'🕹️', 'perk'=>'+15% claim bonus'],
        5  => ['xp'=>10000,  'label'=>'Pro',         'icon'=>'⚡', 'perk'=>'+20% claim bonus, -0.5% house edge'],
        6  => ['xp'=>25000,  'label'=>'Expert',      'icon'=>'💎', 'perk'=>'+25% claim bonus, -1% house edge'],
        7  => ['xp'=>60000,  'label'=>'Master',      'icon'=>'👑', 'perk'=>'+30% claim bonus, -2% house edge'],
        8  => ['xp'=>150000, 'label'=>'Legend',      'icon'=>'🏆', 'perk'=>'+40% claim bonus, -3% house edge, VIP badge'],
    ];
}

function cfp_xp_level_for( $total_xp ) {
    $levels = cfp_xp_levels();
    $level  = 1;
    foreach ( $levels as $lvl => $data ) {
        if ( $total_xp >= $data['xp'] ) $level = $lvl;
        else break;
    }
    return $level;
}

function cfp_xp_award( $user_id, $amount, $reason ) {
    if ( ! cfp_get_setting('xp_enabled','1') ) return;
    global $wpdb;
    $wpdb->insert( CFP_TABLE_XP_LOG, [
        'user_id'   => $user_id,
        'xp_amount' => $amount,
        'reason'    => $reason,
    ]);
    // Update totals and level
    $new_xp   = (int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(xp_amount),0) FROM ".CFP_TABLE_XP_LOG." WHERE user_id=%d", $user_id));
    $new_level = cfp_xp_level_for($new_xp);
    $wpdb->update(CFP_TABLE_USERS,['xp_total'=>$new_xp,'xp_level'=>$new_level],['id'=>$user_id]);
    return ['xp'=>$new_xp,'level'=>$new_level];
}

function cfp_xp_claim_bonus_pct( $user_id ) {
    global $wpdb;
    $level = (int)$wpdb->get_var($wpdb->prepare("SELECT xp_level FROM ".CFP_TABLE_USERS." WHERE id=%d",$user_id));
    $bonuses = [1=>0,2=>5,3=>10,4=>15,5=>20,6=>25,7=>30,8=>40];
    return $bonuses[$level] ?? 0;
}

function cfp_xp_edge_reduction( $user_id ) {
    global $wpdb;
    $level = (int)$wpdb->get_var($wpdb->prepare("SELECT xp_level FROM ".CFP_TABLE_USERS." WHERE id=%d",$user_id));
    $reductions = [1=>0,2=>0,3=>0,4=>0,5=>0.5,6=>1,7=>2,8=>3];
    return $reductions[$level] ?? 0;
}

// Hook XP awards into existing AJAX handlers via output buffer trick on filter
add_filter('cfp_after_claim', function($args) {
    cfp_xp_award($args['user_id'], 10, 'claim');
    return $args;
});
add_filter('cfp_after_game_win', function($args) {
    cfp_xp_award($args['user_id'], 5, 'game_win');
    return $args;
});
add_filter('cfp_after_game_play', function($args) {
    cfp_xp_award($args['user_id'], 1, 'game_played');
    return $args;
});

// Hook into claim AJAX to apply XP bonus
add_action('wp_ajax_cfp_claim',        'cfp_xp_hook_claim', 5);
add_action('wp_ajax_nopriv_cfp_claim', 'cfp_xp_hook_claim', 5);
function cfp_xp_hook_claim() {
    // Runs BEFORE the main claim handler but can't modify it directly
    // XP is awarded via cfp_xp_apply_to_claim_response filter below
}

// AJAX: get XP info
add_action('wp_ajax_cfp_xp_info',        'cfp_ajax_xp_info');
add_action('wp_ajax_nopriv_cfp_xp_info', 'cfp_ajax_xp_info');
function cfp_ajax_xp_info() {
    check_ajax_referer('cfp_nonce','nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    $user  = cfp_get_user_by_email($email);
    if (!$user) wp_send_json_error(['msg'=>'Account not found.']);
    $levels  = cfp_xp_levels();
    $level   = $user->xp_level ?: 1;
    $xp      = $user->xp_total ?: 0;
    $next_l  = $level + 1;
    $next_xp = isset($levels[$next_l]) ? $levels[$next_l]['xp'] : null;
    $pct     = $next_xp ? min(100, round(($xp - $levels[$level]['xp']) / ($next_xp - $levels[$level]['xp']) * 100)) : 100;
    wp_send_json_success([
        'level'      => $level,
        'xp'         => $xp,
        'label'      => $levels[$level]['label'] ?? 'Newcomer',
        'icon'       => $levels[$level]['icon'] ?? '🌱',
        'perk'       => $levels[$level]['perk'] ?? '',
        'next_xp'    => $next_xp,
        'progress'   => $pct,
        'claim_bonus'=> cfp_xp_claim_bonus_pct($user->id),
        'edge_reduction' => cfp_xp_edge_reduction($user->id),
    ]);
}

/* ============================================================
   SHORTCODE: [cfp_xp]
   ============================================================ */
add_shortcode('cfp_xp', function() {
    if ( ! cfp_get_setting('xp_enabled','1') ) return '';
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    $levels = cfp_xp_levels();
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-xp-widget">
        <h2>⭐ Level & XP</h2>
        <p class="sub">Earn XP by playing games and claiming. Level up to unlock perks.</p>
        <input class="cfp-input" type="email" id="cfp-xp-email" placeholder="Account email" onblur="cfpLoadXp()">
        <div id="cfp-xp-info" style="display:none">
            <div style="text-align:center;padding:18px 0 10px">
                <div id="cfp-xp-icon" style="font-size:3rem"></div>
                <div id="cfp-xp-label" style="font-family:'Oswald',sans-serif;font-size:1.4rem;color:#fff;font-weight:700"></div>
                <div id="cfp-xp-perk" style="font-size:.8rem;color:#22c55e;margin-top:4px"></div>
            </div>
            <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:10px;padding:14px;margin-bottom:14px">
                <div style="display:flex;justify-content:space-between;font-size:.72rem;color:#555;margin-bottom:6px">
                    <span id="cfp-xp-amount">0 XP</span><span id="cfp-xp-next">Next level</span>
                </div>
                <div style="height:8px;background:#1a1a1a;border-radius:4px;overflow:hidden">
                    <div id="cfp-xp-bar" style="height:100%;background:linear-gradient(90deg,#f7931a,#ffcc02);border-radius:4px;transition:width .5s;width:0%"></div>
                </div>
            </div>
        </div>
        <!-- Level chart -->
        <div style="margin-top:16px">
            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:#555;margin-bottom:10px">All Levels</div>
            <?php foreach($levels as $lvl => $data): ?>
            <div style="display:flex;align-items:center;gap:10px;padding:8px;border-radius:8px;margin-bottom:4px;background:#0d0d0d;border:1px solid #111">
                <span style="font-size:1.4rem;width:32px;text-align:center"><?=$data['icon']?></span>
                <div style="flex:1">
                    <div style="font-weight:700;color:#fff;font-size:.88rem">Level <?=$lvl?> — <?=$data['label']?></div>
                    <div style="font-size:.75rem;color:#555"><?=$data['xp']?> XP required<?=$data['perk']?' · '.$data['perk']:''?></div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div id="cfp-xp-msg"></div>
    </div>
    <script>
    async function cfpLoadXp(){
        const email=document.getElementById('cfp-xp-email').value; if(!email) return;
        const fd=new FormData(); fd.append('action','cfp_xp_info'); fd.append('nonce','<?=esc_js($nonce)?>'); fd.append('email',email);
        const r=await fetch('<?=esc_js($ajax)?>',{method:'POST',body:fd}); const d=await r.json();
        if(!d.success){document.getElementById('cfp-xp-msg').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;return;}
        const x=d.data;
        document.getElementById('cfp-xp-info').style.display='';
        document.getElementById('cfp-xp-icon').textContent=x.icon;
        document.getElementById('cfp-xp-label').textContent='Level '+x.level+' — '+x.label;
        document.getElementById('cfp-xp-perk').textContent=x.perk||'No perks yet';
        document.getElementById('cfp-xp-amount').textContent=x.xp.toLocaleString()+' XP';
        document.getElementById('cfp-xp-next').textContent=x.next_xp?'Next: '+x.next_xp.toLocaleString()+' XP':'MAX LEVEL';
        document.getElementById('cfp-xp-bar').style.width=x.progress+'%';
        if(x.claim_bonus>0) document.getElementById('cfp-xp-msg').innerHTML=`<div class="cfp-msg success">Your level gives +${x.claim_bonus}% claim bonus${x.edge_reduction>0?' and -'+x.edge_reduction+'% house edge on games':''}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});
