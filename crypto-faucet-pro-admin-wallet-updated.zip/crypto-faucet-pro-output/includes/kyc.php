<?php
/**
 * KYC — Know Your Customer identity verification.
 * Users submit basic info for large withdrawals.
 * Admin reviews and approves/rejects from admin panel.
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// Submit KYC — requires authentication
add_action('wp_ajax_cfp_kyc_submit', 'cfp_ajax_kyc_submit');
function cfp_ajax_kyc_submit() {
    check_ajax_referer('cfp_nonce','nonce');
    $user     = cfp_require_auth();
    $name     = sanitize_text_field($_POST['full_name'] ?? '');
    $country  = sanitize_text_field($_POST['country'] ?? '');
    $doc_type = sanitize_text_field($_POST['doc_type'] ?? '');
    $notes    = sanitize_textarea_field($_POST['notes'] ?? '');
    if (empty($name)||empty($country)||empty($doc_type))
        wp_send_json_error(['msg'=>'All fields are required.']);
    global $wpdb;
    $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_KYC." WHERE user_id=%d ORDER BY id DESC LIMIT 1",$user->id));
    if ($existing && in_array($existing->status,['pending','approved']))
        wp_send_json_error(['msg'=>$existing->status==='approved'?'Your KYC is already approved.':'KYC already submitted and under review.']);
    $wpdb->insert(CFP_TABLE_KYC,['user_id'=>$user->id,'full_name'=>$name,'country'=>$country,'doc_type'=>$doc_type,'doc_notes'=>$notes,'status'=>'pending']);
    $wpdb->update(CFP_TABLE_USERS,['kyc_status'=>'pending'],['id'=>$user->id]);
    wp_mail(get_option('admin_email'),"New KYC submission","User {$user->email} submitted KYC.\nName: {$name}\nCountry: {$country}\nDoc: {$doc_type}\nNotes: {$notes}\n\nReview: ".admin_url('admin.php?page=cfp-kyc'));
    wp_send_json_success(['msg'=>'✅ KYC submitted! We will review within 24–48 hours.']);
}

// Get KYC status — requires authentication
add_action('wp_ajax_cfp_kyc_status', 'cfp_ajax_kyc_status');
function cfp_ajax_kyc_status() {
    check_ajax_referer('cfp_nonce','nonce');
    $user = cfp_require_auth();
    global $wpdb;
    $kyc = $wpdb->get_row($wpdb->prepare("SELECT status, admin_note FROM ".CFP_TABLE_KYC." WHERE user_id=%d ORDER BY id DESC LIMIT 1",$user->id));
    wp_send_json_success([
        'status'     => $kyc ? $kyc->status : 'none',
        'kyc_status' => $user->kyc_status ?: 'none',
        // admin_note returned only to the authenticated owner, never publicly
        'admin_note' => $kyc ? $kyc->admin_note : '',
    ]);
}

/* ============================================================
   ADMIN: KYC MANAGEMENT PAGE
   ============================================================ */
function cfp_admin_kyc() {
    global $wpdb;
    $notice = '';
    if (isset($_GET['kyc_action'],$_GET['id']) && check_admin_referer('cfp_kyc')) {
        $kid = intval($_GET['id']);
        $act = sanitize_text_field($_GET['kyc_action']);
        $kyc = $wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_KYC." WHERE id=%d",$kid));
        if ($kyc) {
            $note = sanitize_text_field($_GET['note'] ?? '');
            $new_status = $act === 'approve' ? 'approved' : 'rejected';
            $wpdb->update(CFP_TABLE_KYC,['status'=>$new_status,'reviewed_at'=>current_time('mysql'),'admin_note'=>$note],['id'=>$kid]);
            $wpdb->update(CFP_TABLE_USERS,['kyc_status'=>$new_status],['id'=>$kyc->user_id]);
            // Notify user
            $user = $wpdb->get_row($wpdb->prepare("SELECT email,username FROM ".CFP_TABLE_USERS." WHERE id=%d",$kyc->user_id));
            if ($user) {
                $msg = $act === 'approve'
                    ? "Hello {$user->username},\n\nYour KYC has been approved! You can now make large withdrawals."
                    : "Hello {$user->username},\n\nYour KYC was not approved. Reason: {$note}\n\nPlease resubmit with correct documents.";
                wp_mail($user->email, "KYC Update — ".get_bloginfo('name'), $msg);
            }
            $notice = "<div class='cfp-notice success'>✅ KYC #{$kid} {$new_status}.</div>";
        }
    }
    $filter = $_GET['filter'] ?? 'pending';
    $where  = $filter !== 'all' ? $wpdb->prepare("WHERE k.status=%s",$filter) : '';
    $rows   = $wpdb->get_results("SELECT k.*,u.email,u.username FROM ".CFP_TABLE_KYC." k LEFT JOIN ".CFP_TABLE_USERS." u ON k.user_id=u.id {$where} ORDER BY k.submitted_at DESC LIMIT 50");
    $counts = $wpdb->get_results("SELECT status,COUNT(*) cnt FROM ".CFP_TABLE_KYC." GROUP BY status",OBJECT_K);
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header"><span class="cfp-logo-badge">⚡ CFP</span><h1>🪪 KYC Verification</h1></div>
        <?php echo wp_kses($notice, ['div' => ['class' => []], 'strong' => []]); ?>
        <div class="cfp-tabs">
        <?php foreach(['all'=>'All','pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected'] as $k=>$l):
            $cnt=$k==='all'?$wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_KYC):($counts[$k]->cnt??0); ?>
            <a href="<?=admin_url("admin.php?page=cfp-kyc&filter=$k")?>" class="cfp-tab <?=$filter===$k?'active':''?>"><?=$l?> <span style="opacity:.55;font-size:.72rem">(<?=$cnt?>)</span></a>
        <?php endforeach; ?>
        </div>
        <div class="cfp-card">
        <table class="cfp-table">
            <thead><tr><th>#</th><th>User</th><th>Name</th><th>Country</th><th>Doc Type</th><th>Notes</th><th>Status</th><th>Submitted</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach($rows as $k): $n=wp_create_nonce('cfp_kyc'); ?>
            <tr>
                <td style="color:var(--mt)"><?=$k->id?></td>
                <td><strong><?=esc_html($k->username)?></strong><br><span style="font-size:.73rem;color:var(--mt)"><?=esc_html($k->email)?></span></td>
                <td><?=esc_html($k->full_name)?></td>
                <td><?=esc_html($k->country)?></td>
                <td><?=esc_html($k->doc_type)?></td>
                <td style="font-size:.75rem;max-width:160px;color:var(--mt)"><?=esc_html(substr($k->doc_notes??'',0,80))?></td>
                <td><span class="cfp-badge <?=$k->status?>"><?=ucfirst($k->status)?></span>
                    <?php if($k->admin_note): ?><div style="font-size:.72rem;color:#555;margin-top:3px"><?=esc_html($k->admin_note)?></div><?php endif; ?>
                </td>
                <td style="font-size:.78rem;color:var(--mt)"><?=date('M j, Y',strtotime($k->submitted_at))?></td>
                <td><?php if($k->status==='pending'): ?>
                    <div style="display:flex;flex-direction:column;gap:4px">
                        <input type="text" id="kyc-note-<?=$k->id?>" placeholder="Admin note (optional)" style="background:#111;border:1px solid #2a2a2a;color:#aaa;padding:5px 8px;border-radius:5px;font-size:.73rem;width:130px">
                        <div style="display:flex;gap:4px">
                            <a href="#" onclick="cfpKycAction(<?=$k->id?>,'approve','<?=esc_js(admin_url("admin.php?page=cfp-kyc&kyc_action=approve&id={$k->id}&_wpnonce=$n"))?>')" class="cfp-btn cfp-btn-green cfp-btn-sm">✓ Approve</a>
                            <a href="#" onclick="cfpKycAction(<?=$k->id?>,'reject','<?=esc_js(admin_url("admin.php?page=cfp-kyc&kyc_action=reject&id={$k->id}&_wpnonce=$n"))?>')" class="cfp-btn cfp-btn-red cfp-btn-sm">✕ Reject</a>
                        </div>
                    </div>
                <?php else: echo '<span style="color:var(--mt);font-size:.8rem">'.ucfirst($k->status).'</span>'; endif; ?></td>
            </tr>
            <?php endforeach; if(empty($rows)): ?>
            <tr><td colspan="9" style="text-align:center;color:var(--mt);padding:30px">No <?=$filter?> KYC submissions.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
        </div>
    </div>
    <script>
    function cfpKycAction(id,act,url){
        const note=document.getElementById('kyc-note-'+id)?.value||'';
        if(act==='reject'&&!confirm('Reject KYC #'+id+'?')) return false;
        window.location=url+'&note='+encodeURIComponent(note);
        return false;
    }
    </script>
    <?php
}

/* ============================================================
   SHORTCODE: [cfp_kyc]
   ============================================================ */
add_shortcode('cfp_kyc', function() {
    $nonce   = wp_create_nonce('cfp_nonce');
    $ajax    = admin_url('admin-ajax.php');
    $kyc_min = intval(cfp_get_setting('kyc_required_above_sat',0));
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-kyc-widget">
        <h2>🪪 Identity Verification (KYC)</h2>
        <?php if($kyc_min > 0): ?>
        <div style="background:#1a1000;border:1px solid #f7931a33;border-radius:10px;padding:12px;margin-bottom:14px;font-size:.82rem;color:#f7931a">
            ⚠️ KYC is required for withdrawals over <?=number_format($kyc_min)?> sat.
        </div>
        <?php endif; ?>
        <input class="cfp-input" type="email" id="cfp-kyc-email" placeholder="Account email" onblur="cfpKycCheckStatus()">
        <div id="cfp-kyc-status-box" style="display:none;margin-bottom:14px"></div>
        <div id="cfp-kyc-form">
            <input class="cfp-input" type="text" id="cfp-kyc-name" placeholder="Full legal name">
            <input class="cfp-input" type="text" id="cfp-kyc-country" placeholder="Country">
            <select class="cfp-input" id="cfp-kyc-doctype" style="background:#0d0d0d">
                <option value="">Select document type…</option>
                <option>Passport</option>
                <option>National ID Card</option>
                <option>Driver's License</option>
                <option>Other government ID</option>
            </select>
            <textarea class="cfp-input" id="cfp-kyc-notes" placeholder="Additional notes (optional — e.g. ID number, expiry date)" rows="3" style="background:#0d0d0d;resize:vertical"></textarea>
            <button class="cfp-btn-full" onclick="cfpSubmitKyc()">Submit KYC</button>
        </div>
        <div id="cfp-kyc-msg" style="margin-top:10px"></div>
    </div>
    <script>
    async function cfpKycCheckStatus(){
        const email=document.getElementById('cfp-kyc-email').value; if(!email) return;
        const fd=new FormData(); fd.append('action','cfp_kyc_status'); fd.append('nonce','<?=esc_js($nonce)?>'); fd.append('email',email);
        const r=await fetch('<?=esc_js($ajax)?>',{method:'POST',body:fd}); const d=await r.json();
        if(!d.success) return;
        const s=d.data.status;
        const box=document.getElementById('cfp-kyc-status-box');
        const colors={'none':'#555','pending':'#f7931a','approved':'#22c55e','rejected':'#ef4444'};
        const labels={'none':'Not submitted','pending':'⏳ Under review','approved':'✅ Approved','rejected':'❌ Rejected'};
        box.innerHTML=`<div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:8px;padding:12px;font-size:.84rem">
            Status: <strong style="color:${colors[s]}">${labels[s]||s}</strong>
            ${d.data.admin_note?`<div style="color:#555;margin-top:4px;font-size:.78rem">Note: ${d.data.admin_note}</div>`:''}
        </div>`;
        box.style.display='';
        if(s==='approved'||s==='pending') document.getElementById('cfp-kyc-form').style.display='none';
    }
    async function cfpSubmitKyc(){
        const fd=new FormData(); fd.append('action','cfp_kyc_submit'); fd.append('nonce','<?=esc_js($nonce)?>');
        fd.append('email',document.getElementById('cfp-kyc-email').value);
        fd.append('full_name',document.getElementById('cfp-kyc-name').value);
        fd.append('country',document.getElementById('cfp-kyc-country').value);
        fd.append('doc_type',document.getElementById('cfp-kyc-doctype').value);
        fd.append('notes',document.getElementById('cfp-kyc-notes').value);
        const r=await fetch('<?=esc_js($ajax)?>',{method:'POST',body:fd}); const d=await r.json();
        const el=document.getElementById('cfp-kyc-msg');
        el.innerHTML=`<div class="cfp-msg ${d.success?'success':'error'}">${d.data.msg}</div>`;
        if(d.success) document.getElementById('cfp-kyc-form').style.display='none';
    }
    </script>
    <?php return ob_get_clean();
});
