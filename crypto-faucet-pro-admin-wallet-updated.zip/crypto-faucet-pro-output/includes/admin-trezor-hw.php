<?php
/**
 * Crypto Faucet Pro — Trezor Hardware Wallet Panel
 *
 * Two parallel paths for sweeping admin wallet earnings to your Trezor:
 *
 *   Path A — Sign on Trezor device (Trezor Connect SDK):
 *     Uses Trezor Connect loaded from connect.trezor.io.
 *     Admin connects their Trezor, the plugin builds + signs a Bitcoin
 *     transaction ON the device (private key never leaves the hardware).
 *     The signed raw TX is broadcast via Mempool.space API.
 *     No third-party intermediary — pure on-chain.
 *
 *   Path B — NOWPayments API On-Demand Withdrawal:
 *     Calls cfp_np_send_payout() immediately on admin click via AJAX.
 *     Same API used by auto-sweep but triggered manually with a custom amount.
 *     Sends crypto on-chain directly to your Trezor address.
 *     Requires the address to be whitelisted in your NOWPayments account.
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// AJAX: PATH B — ON-DEMAND NOWPAYMENTS WITHDRAWAL
// ============================================================

add_action( 'wp_ajax_cfp_hw_faucetpay_withdraw', 'cfp_ajax_hw_faucetpay_withdraw' );
function cfp_ajax_hw_faucetpay_withdraw() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
    if ( ! check_ajax_referer( 'cfp_hw_nonce', 'nonce', false ) ) wp_send_json_error( 'Nonce failed.' );

    global $wpdb;

    $amount_sat = absint( $_POST['amount_sat'] ?? 0 );
    $to_address = sanitize_text_field( wp_unslash( $_POST['to_address'] ?? '' ) );
    $note       = sanitize_text_field( wp_unslash( $_POST['note'] ?? 'Manual on-demand admin withdrawal' ) );
    $currency   = strtoupper( sanitize_text_field( wp_unslash( $_POST['currency'] ?? '' ) ) );

    if ( empty( $currency ) ) {
        $currency = strtoupper( cfp_get_setting( 'faucet_currency', cfp_get_setting( 'blockchain_currency', 'BTC' ) ) );
    }

    if ( $amount_sat <= 0 ) {
        wp_send_json_error( 'Amount must be greater than 0.' );
    }
    if ( empty( $to_address ) ) {
        wp_send_json_error( 'Destination address is required.' );
    }
    if ( ! cfp_np_enabled() || empty( cfp_np_api_key() ) ) {
        wp_send_json_error( 'NOWPayments API key not configured. Go to WP Admin → NOWPayments Settings and add your API key.' );
    }

    $pending = function_exists( 'cfp_trezor_pending_balance' )
        ? cfp_trezor_pending_balance()
        : (int) $wpdb->get_var( "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET );

    if ( $amount_sat > $pending ) {
        wp_send_json_error( sprintf(
            'Amount (%s sat) exceeds pending wallet balance (%s sat).',
            number_format( $amount_sat ), number_format( $pending )
        ) );
    }

    // ── Call NOWPayments Mass Payout API ────────────────────────────────────
    $amount_coin = $amount_sat / 1e8;
    $np_result   = cfp_np_send_payout( $to_address, $amount_coin, strtolower( $currency ) );

    $payout_id  = $np_result['id'] ?? ( $np_result['withdrawals'][0]['id'] ?? '' );
    $np_success = ! empty( $payout_id ) || ( isset( $np_result['status'] ) && $np_result['status'] !== 'error' );

    if ( ! $np_success ) {
        $np_error = $np_result['message'] ?? ( $np_result['error'] ?? 'Unknown error' );
        if ( function_exists( 'cfp_trezor_queue_pending' ) ) {
            cfp_trezor_queue_pending( $amount_sat, $to_address, 'manual_sweep', $np_error );
        }
        wp_send_json_error( sprintf(
            'NOWPayments API error: %s — Entry queued in Trezor Sweep tab for retry.',
            $np_error
        ) );
    }

    // ── Record in ledger ────────────────────────────────────────────────────
    $desc = sprintf(
        'On-demand admin withdrawal: %s sat %s → %s. NP Payout ID: %s. %s',
        number_format( $amount_sat ), $currency, $to_address, $payout_id, $note
    );
    $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
        'stream'      => 'trezor_payout',
        'amount_sat'  => -$amount_sat,
        'description' => $desc,
        'ref_id'      => null,
    ] );

    // ── Log in sweep queue ──────────────────────────────────────────────────
    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . 'cfp_trezor_sweep_queue' ) ) ) {
        $wpdb->insert( $wpdb->prefix . 'cfp_trezor_sweep_queue', [
            'type'         => 'manual_sweep',
            'amount_sat'   => $amount_sat,
            'to_address'   => $to_address,
            'status'       => 'sent',
            'np_payout_id' => $payout_id,
            'note'         => $note,
            'created_at'   => current_time( 'mysql' ),
            'updated_at'   => current_time( 'mysql' ),
        ] );
    }

    wp_send_json_success( [
        'message'     => sprintf( '✅ Sent %s sat %s to %s on-chain. NP Payout ID: %s', number_format( $amount_sat ), $currency, $to_address, $payout_id ),
        'payout_id'   => $payout_id,
        'amount_sat'  => $amount_sat,
        'new_balance' => max( 0, $pending - $amount_sat ),
    ] );
}

// ============================================================
// AJAX: PATH A — RECORD TREZOR DEVICE BROADCAST
// ============================================================

add_action( 'wp_ajax_cfp_hw_record_trezor_broadcast', 'cfp_ajax_hw_record_trezor_broadcast' );
function cfp_ajax_hw_record_trezor_broadcast() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
    if ( ! check_ajax_referer( 'cfp_hw_nonce', 'nonce', false ) ) wp_send_json_error( 'Nonce failed.' );

    global $wpdb;

    $amount_sat = absint( $_POST['amount_sat'] ?? 0 );
    $to_address = sanitize_text_field( wp_unslash( $_POST['to_address'] ?? '' ) );
    $txid       = sanitize_text_field( wp_unslash( $_POST['txid'] ?? '' ) );
    $currency   = strtoupper( sanitize_text_field( wp_unslash( $_POST['currency'] ?? 'BTC' ) ) );
    $note       = sanitize_text_field( wp_unslash( $_POST['note'] ?? 'Signed on Trezor device' ) );

    if ( $amount_sat <= 0 || empty( $to_address ) || empty( $txid ) ) {
        wp_send_json_error( 'amount_sat, to_address, and txid are all required.' );
    }

    $desc = sprintf(
        'Trezor device signed broadcast: %s sat %s → %s. TX: %s. %s',
        number_format( $amount_sat ), $currency, $to_address, $txid, $note
    );
    $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
        'stream'      => 'trezor_payout',
        'amount_sat'  => -$amount_sat,
        'description' => $desc,
        'ref_id'      => null,
    ] );

    if ( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . 'cfp_trezor_sweep_queue' ) ) ) {
        $wpdb->insert( $wpdb->prefix . 'cfp_trezor_sweep_queue', [
            'type'         => 'manual_sweep',
            'amount_sat'   => $amount_sat,
            'to_address'   => $to_address,
            'status'       => 'sent',
            'np_payout_id' => $txid,
            'note'         => 'Trezor device signed. TX: ' . $txid,
            'created_at'   => current_time( 'mysql' ),
            'updated_at'   => current_time( 'mysql' ),
        ] );
    }

    wp_send_json_success( [
        'message' => sprintf( '✅ Trezor broadcast recorded. TX: %s. Ledger updated (%s sat deducted).', $txid, number_format( $amount_sat ) ),
        'txid'    => $txid,
    ] );
}

// ============================================================
// AJAX: FETCH LIVE NOWPAYMENTS ACCOUNT BALANCE
// ============================================================

add_action( 'wp_ajax_cfp_hw_faucetpay_balance', 'cfp_ajax_hw_faucetpay_balance' );
function cfp_ajax_hw_faucetpay_balance() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.' );
    check_ajax_referer( 'cfp_hw_nonce', 'nonce' );

    if ( ! cfp_np_enabled() || empty( cfp_np_api_key() ) ) {
        wp_send_json_error( 'NOWPayments API key not configured.' );
    }

    $currency = strtoupper( cfp_get_setting( 'faucet_currency', cfp_get_setting( 'blockchain_currency', 'BTC' ) ) );

    // Fetch balance via NOWPayments /balance endpoint
    $result = cfp_np_get_balance();

    if ( ! empty( $result['error'] ) ) {
        wp_send_json_error( 'NOWPayments API error: ' . $result['error'] );
    }

    // NOWPayments returns { currencies: { btc: "0.00123", eth: "0.05" } }
    $currencies = $result['currencies'] ?? [];
    $cur_lower  = strtolower( $currency );
    $raw_amount = $currencies[ $cur_lower ] ?? null;

    if ( $raw_amount === null ) {
        wp_send_json_error( "Currency {$currency} not found in NOWPayments balance. Available: " . implode( ', ', array_keys( $currencies ) ) );
    }

    $amount      = floatval( $raw_amount );
    $balance_sat = $currency === 'BTC' ? (int) round( $amount * 1e8 ) : (int) round( $amount );

    wp_send_json_success( [
        'balance_sat'  => $balance_sat,
        'balance_raw'  => $amount,
        'currency'     => $currency,
        'all_balances' => $currencies,
    ] );
}

// ============================================================
// RENDER: Hardware Wallet Panel (new tab in Admin Wallet)
// ============================================================

add_action( 'cfp_admin_wallet_extra_tabs', 'cfp_hw_render_tab_link' );
function cfp_hw_render_tab_link( $current_tab ) {
    $active = $current_tab === 'hw_wallet' ? 'nav-tab-active' : '';
    ?>
    <a href="<?=esc_url( add_query_arg( 'wstab', 'hw_wallet' ) )?>"
       style="padding:10px 18px;border-radius:8px 8px 0 0;font-size:.85rem;font-weight:700;text-decoration:none;
              border:1px solid <?=$active?'#f7931a':'#1a1a1a'?>;border-bottom:none;
              color:<?=$active?'#f7931a':'#888'?>;background:<?=$active?'#1a0d00':'transparent'?>;
              display:flex;align-items:center;gap:6px">
        🔐 Hardware Wallet
    </a>
    <?php
}

add_action( 'cfp_admin_wallet_extra_content', 'cfp_hw_render_panel' );
function cfp_hw_render_panel( $current_tab ) {
    if ( $current_tab !== 'hw_wallet' ) return;

    $nonce           = wp_create_nonce( 'cfp_hw_nonce' );
    $ajax_url        = admin_url( 'admin-ajax.php' );
    $trezor_addr     = trim( cfp_get_setting( 'trezor_active_address', '' ) );
    $currency        = strtoupper( cfp_get_setting( 'faucet_currency', cfp_get_setting( 'blockchain_currency', 'BTC' ) ) );
    $np_key_set      = cfp_np_enabled() && ! empty( cfp_np_api_key() );
    $btc_price       = (int) cfp_get_setting( 'btc_usd_price', 67694 );
    $pending_balance = function_exists( 'cfp_trezor_pending_balance' ) ? cfp_trezor_pending_balance() : 0;
    $pending_btc     = number_format( $pending_balance / 100000000, 8 );
    $pending_usd     = number_format( $pending_balance / 100000000 * $btc_price, 2 );
    ?>

    <div style="max-width:900px;margin:0 auto;padding:20px 0">

        <!-- ── STATUS CARDS ── -->
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:24px">

            <div style="background:#0d0d0d;border:1px solid #1dc92833;border-radius:10px;padding:16px;text-align:center">
                <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#1dc928;margin-bottom:8px">Pending Balance</div>
                <div style="font-size:1.5rem;font-weight:900;color:#fff;font-family:monospace"><?=number_format($pending_balance)?></div>
                <div style="font-size:.72rem;color:#555;margin-top:3px">sat · <?=$pending_btc?> <?=$currency?></div>
                <div style="font-size:.72rem;color:#22c55e;margin-top:2px">≈ $<?=$pending_usd?> USD</div>
            </div>

            <div style="background:#0d0d0d;border:1px solid <?=$np_key_set?'#7b3fe444':'#ef444444'?>;border-radius:10px;padding:16px;text-align:center">
                <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#7b3fe4;margin-bottom:8px">NOWPayments API</div>
                <div style="font-size:1rem;font-weight:700;color:<?=$np_key_set?'#1dc928':'#ef4444'?>"><?=$np_key_set?'🟢 Configured':'🔴 Not Set'?></div>
                <div style="font-size:.72rem;color:#555;margin-top:4px">Required for Path B</div>
            </div>

            <div style="background:#0d0d0d;border:1px solid <?=!empty($trezor_addr)?'#3b82f644':'#1a1a1a'?>;border-radius:10px;padding:16px;text-align:center">
                <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#3b82f6;margin-bottom:8px">Trezor Address</div>
                <?php if ( $trezor_addr ): ?>
                <div style="font-size:.72rem;font-family:monospace;color:#1dc928;word-break:break-all"><?=esc_html(substr($trezor_addr,0,12))?>…<?=esc_html(substr($trezor_addr,-8))?></div>
                <?php else: ?>
                <div style="font-size:.8rem;color:#ef4444">⚠️ Not configured</div>
                <div style="font-size:.7rem;color:#555">Set in Trezor Sweep tab</div>
                <?php endif; ?>
            </div>

            <div style="background:#0d0d0d;border:1px solid #7b3fe444;border-radius:10px;padding:16px;text-align:center">
                <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#7b3fe4;margin-bottom:8px">NP Account Balance</div>
                <div id="cfp-hw-fp-balance" style="font-size:1rem;font-weight:700;color:#aaa">—</div>
                <button onclick="cfpHwFetchFpBalance('<?=esc_js($nonce)?>')"
                    style="margin-top:6px;background:#111;border:1px solid #333;color:#888;padding:3px 10px;border-radius:5px;font-size:.72rem;cursor:pointer">
                    🔄 Refresh
                </button>
            </div>
        </div>

        <!-- ── PATH A: TREZOR DEVICE SIGNING ── -->
        <div style="background:#0a0a0a;border:1px solid #f7931a33;border-radius:12px;padding:22px;margin-bottom:22px">
            <h2 style="margin:0 0 6px;font-size:1rem;color:#f7931a">🔐 Path A — Sign on Trezor Device (Pure On-Chain)</h2>
            <p style="color:#555;font-size:.8rem;margin:0 0 18px;line-height:1.6">
                Uses <strong style="color:#aaa">Trezor Connect SDK</strong> (trezor.io/connect).
                Your Trezor displays the full transaction details — amount, address, fee — and requires your physical button press to sign.
                The private key <strong style="color:#aaa">never leaves the device</strong>.
                The signed raw transaction is broadcast directly to the Bitcoin network.
                This path works <strong style="color:#aaa">independently of NOWPayments — pure on-chain.</strong>
            </p>

            <div id="cfp-hw-status"
                style="background:#111;border:1px solid #1a1a1a;border-radius:8px;padding:11px 14px;font-size:.82rem;color:#555;margin-bottom:16px">
                Not connected — connect your Trezor using one of the options below.
            </div>

            <div id="cfp-hw-addr-block" style="display:none;background:#0a1a0a;border:1px solid #1dc92844;border-radius:8px;padding:12px 14px;margin-bottom:16px">
                <div style="font-size:.72rem;color:#555;margin-bottom:4px">Connected Trezor Account</div>
                <div id="cfp-hw-addr" style="font-family:monospace;font-size:.85rem;color:#1dc928;word-break:break-all"></div>
                <div id="cfp-hw-addr-type" style="font-size:.72rem;color:#555;margin-top:4px"></div>
                <div id="cfp-hw-addr-match" style="font-size:.78rem;margin-top:6px"></div>
            </div>

            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px">
                <button id="cfp-hw-connect-mm"
                    style="background:#f6851b;color:#000;border:none;padding:10px 18px;border-radius:8px;font-weight:700;font-size:.85rem;cursor:pointer">
                    🦊 Connect via MetaMask → Trezor
                </button>
                <button id="cfp-hw-connect-wc"
                    style="background:#3b82f6;color:#fff;border:none;padding:10px 18px;border-radius:8px;font-weight:700;font-size:.85rem;cursor:pointer">
                    📡 Connect via WalletConnect (Trezor Suite)
                </button>
                <button id="cfp-hw-disconnect" style="display:none;background:#111;border:1px solid #333;color:#888;padding:10px 14px;border-radius:8px;font-size:.82rem;cursor:pointer">
                    Disconnect
                </button>
            </div>

            <!-- Trezor Connect direct -->
            <details style="background:#111;border:1px solid #f7931a22;border-radius:8px;overflow:hidden;margin-bottom:18px">
                <summary style="padding:12px 16px;cursor:pointer;font-size:.82rem;color:#f7931a;font-weight:600;list-style:none">
                    🔌 Trezor Connect Direct (Bitcoin native — no browser extension needed)
                </summary>
                <div style="padding:14px 16px;border-top:1px solid #1a1a1a">
                    <p style="font-size:.78rem;color:#666;margin:0 0 12px">
                        Uses the official Trezor Connect SDK from <code style="color:#aaa">connect.trezor.io</code>.
                        Derives your Bitcoin address at your chosen BIP44 path, builds and signs the transaction entirely on the device,
                        then broadcasts via Mempool.space.
                    </p>
                    <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:12px;align-items:flex-end">
                        <div>
                            <label style="font-size:.75rem;color:#555;display:block;margin-bottom:4px">BIP44 Account Index</label>
                            <input type="number" id="cfp-hw-tc-account" value="0" min="0" max="99"
                                style="background:#0a0a0a;border:1px solid #222;color:#fff;padding:8px 10px;border-radius:6px;width:70px;font-family:monospace">
                        </div>
                        <div>
                            <label style="font-size:.75rem;color:#555;display:block;margin-bottom:4px">Address Type</label>
                            <select id="cfp-hw-tc-type" style="background:#0a0a0a;border:1px solid #222;color:#fff;padding:8px 10px;border-radius:6px">
                                <option value="p2wpkh">Native SegWit (bc1q…) — recommended</option>
                                <option value="p2sh">SegWit (3…)</option>
                                <option value="p2pkh">Legacy (1…)</option>
                            </select>
                        </div>
                        <button id="cfp-hw-tc-connect"
                            style="background:#f7931a;color:#000;border:none;padding:9px 18px;border-radius:7px;font-weight:700;font-size:.82rem;cursor:pointer">
                            🔌 Connect Trezor
                        </button>
                    </div>
                    <div id="cfp-hw-tc-addr" style="font-size:.78rem;color:#1dc928;font-family:monospace;min-height:20px"></div>
                </div>
            </details>

            <!-- Withdraw form -->
            <div id="cfp-hw-tx-section" style="display:none">
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
                    <div>
                        <label style="font-size:.78rem;color:#555;display:block;margin-bottom:5px">Send Amount (sat)</label>
                        <input type="number" id="cfp-hw-amount" placeholder="0"
                            min="546" step="1000"
                            style="background:#111;border:1px solid #1dc92833;color:#1dc928;padding:10px 12px;border-radius:8px;font-family:monospace;font-size:.95rem;width:100%;box-sizing:border-box"
                            oninput="cfpHwCalc()">
                        <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">
                            <button type="button" onclick="cfpHwSetAmt(Math.round(<?=$pending_balance?>*0.25))" style="<?=cfp_hw_preset_style()?>">25%</button>
                            <button type="button" onclick="cfpHwSetAmt(Math.round(<?=$pending_balance?>*0.5))"  style="<?=cfp_hw_preset_style()?>">50%</button>
                            <button type="button" onclick="cfpHwSetAmt(Math.round(<?=$pending_balance?>*0.75))" style="<?=cfp_hw_preset_style()?>">75%</button>
                            <button type="button" onclick="cfpHwSetAmt(<?=$pending_balance?>)"                  style="<?=cfp_hw_preset_style(true)?>">Max</button>
                        </div>
                    </div>
                    <div>
                        <label style="font-size:.78rem;color:#555;display:block;margin-bottom:5px">Destination Address</label>
                        <input type="text" id="cfp-hw-dest"
                            value="<?=esc_attr($trezor_addr)?>"
                            placeholder="bc1q… or 1… or 3…"
                            style="background:#111;border:1px solid #1dc92822;color:#1dc928;padding:10px 12px;border-radius:8px;font-family:monospace;font-size:.8rem;width:100%;box-sizing:border-box">
                    </div>
                </div>

                <!-- Fee tier -->
                <div style="margin-bottom:16px">
                    <label style="font-size:.78rem;color:#555;display:block;margin-bottom:8px">Network Fee</label>
                    <div style="display:flex;gap:8px;flex-wrap:wrap" id="cfp-hw-fee-row">
                        <?php foreach ( ['Economy'=>1,'Standard'=>5,'Priority'=>20] as $lbl => $sat_per_vb ): ?>
                        <label style="cursor:pointer;flex:1;min-width:90px;background:#0d0d0d;border:1px solid #1dc92822;border-radius:8px;padding:10px;text-align:center"
                            id="cfp-fee-lbl-<?=strtolower($lbl)?>"
                            onclick="cfpHwSelectFee('<?=strtolower($lbl)?>')">
                            <div style="font-size:.72rem;font-weight:700;color:#888"><?=$lbl?></div>
                            <div style="font-size:.85rem;font-weight:800;color:#1dc928;margin-top:2px" id="cfp-fee-sat-<?=strtolower($lbl)?>">~<?=$sat_per_vb?> sat/vB</div>
                            <div style="font-size:.68rem;color:#444" id="cfp-fee-total-<?=strtolower($lbl)?>">est. total</div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                    <input type="hidden" id="cfp-hw-fee-sat" value="1500">
                </div>

                <div style="background:#0a1a0a;border:1px solid #1dc92822;border-radius:8px;padding:12px;margin-bottom:16px;font-size:.8rem">
                    <div style="display:flex;justify-content:space-between;margin-bottom:5px">
                        <span style="color:#555">You send:</span>
                        <span id="cfp-hw-send-display" style="color:#1dc928;font-family:monospace;font-weight:700">—</span>
                    </div>
                    <div style="display:flex;justify-content:space-between;margin-bottom:5px">
                        <span style="color:#555">Network fee:</span>
                        <span id="cfp-hw-fee-display" style="color:#f97316;font-family:monospace">—</span>
                    </div>
                    <div style="display:flex;justify-content:space-between;border-top:1px solid #1a1a1a;padding-top:5px;margin-top:5px">
                        <span style="color:#aaa;font-weight:600">Remaining balance after:</span>
                        <span id="cfp-hw-after-display" style="color:#aaa;font-family:monospace;font-weight:700">—</span>
                    </div>
                </div>

                <button id="cfp-hw-sign-btn"
                    style="background:linear-gradient(135deg,#f7931a,#e07b00);color:#000;border:none;padding:13px 28px;border-radius:10px;font-weight:900;font-size:.95rem;cursor:pointer;flex:1;width:100%">
                    🔐 Sign &amp; Broadcast on Trezor — Confirm on Device
                </button>

                <div style="margin-top:12px;font-size:.75rem;color:#555;background:#0a0a0a;border:1px solid #1a1a1a;border-radius:7px;padding:10px">
                    <strong style="color:#888">ℹ️ Device signing:</strong> Your Trezor displays the exact amount, destination address, and fee.
                    You must press the physical button on the device to sign. The private key never leaves the hardware.
                    The signed transaction is then broadcast to the Bitcoin network.
                </div>

                <div id="cfp-hw-tx-hash" style="margin-top:12px;font-size:.8rem;color:#3b82f6;font-family:monospace;word-break:break-all"></div>
            </div>
        </div>

        <!-- ── PATH B: NOWPAYMENTS ON-DEMAND WITHDRAWAL ── -->
        <div style="background:#0a0a0a;border:1px solid #7b3fe433;border-radius:12px;padding:22px;margin-bottom:22px">
            <h2 style="margin:0 0 6px;font-size:1rem;color:#7b3fe4">⚡ Path B — On-Demand NOWPayments Withdrawal</h2>
            <p style="color:#555;font-size:.8rem;margin:0 0 18px;line-height:1.6">
                Calls the <strong style="color:#aaa">NOWPayments Mass Payout API</strong> immediately on click — same API used by the auto-sweep,
                but triggered manually with a custom amount. Sends crypto on-chain directly to your Trezor address.
                Requires your Trezor address to be <strong style="color:#aaa">whitelisted in your NOWPayments account</strong>.
            </p>

            <?php if ( ! $np_key_set ): ?>
            <div style="background:#1a0a0a;border:1px solid #ef444444;border-radius:8px;padding:14px;margin-bottom:16px;font-size:.82rem;color:#ef4444">
                ⚠️ NOWPayments API key not configured. Go to <strong>WP Admin → NOWPayments Settings</strong> and add your API key.
            </div>
            <?php endif; ?>

            <div id="cfp-api-msg" style="margin-bottom:12px"></div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
                <div>
                    <label style="font-size:.78rem;color:#555;display:block;margin-bottom:5px">Amount (sat)</label>
                    <input type="number" id="cfp-api-amount" placeholder="0"
                        min="1000" step="1000" value="<?=$pending_balance?>"
                        style="background:#111;border:1px solid #7b3fe444;color:#7b3fe4;padding:10px 12px;border-radius:8px;font-family:monospace;font-size:.95rem;width:100%;box-sizing:border-box"
                        oninput="cfpApiCalc()">
                    <div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap">
                        <button type="button" onclick="cfpApiSetAmt(Math.round(<?=$pending_balance?>*0.25))" style="<?=cfp_hw_preset_style()?>">25%</button>
                        <button type="button" onclick="cfpApiSetAmt(Math.round(<?=$pending_balance?>*0.5))"  style="<?=cfp_hw_preset_style()?>">50%</button>
                        <button type="button" onclick="cfpApiSetAmt(Math.round(<?=$pending_balance?>*0.75))" style="<?=cfp_hw_preset_style()?>">75%</button>
                        <button type="button" onclick="cfpApiSetAmt(<?=$pending_balance?>)"                   style="<?=cfp_hw_preset_style(true)?>">Max (<?=number_format($pending_balance)?> sat)</button>
                    </div>
                </div>
                <div>
                    <label style="font-size:.78rem;color:#555;display:block;margin-bottom:5px">Destination Address (Trezor)</label>
                    <input type="text" id="cfp-api-dest"
                        value="<?=esc_attr($trezor_addr)?>"
                        placeholder="bc1q… (your Trezor address)"
                        style="background:#111;border:1px solid #7b3fe422;color:#1dc928;padding:10px 12px;border-radius:8px;font-family:monospace;font-size:.8rem;width:100%;box-sizing:border-box">
                </div>
                <div>
                    <label style="font-size:.78rem;color:#555;display:block;margin-bottom:5px">Currency</label>
                    <input type="text" id="cfp-api-currency" value="<?=esc_attr($currency)?>"
                        style="background:#111;border:1px solid #222;color:#aaa;padding:10px 12px;border-radius:8px;font-family:monospace;font-size:.9rem;width:100%;box-sizing:border-box">
                </div>
                <div>
                    <label style="font-size:.78rem;color:#555;display:block;margin-bottom:5px">Note (for ledger)</label>
                    <input type="text" id="cfp-api-note" placeholder="e.g. Weekly profit sweep"
                        style="background:#111;border:1px solid #222;color:#aaa;padding:10px 12px;border-radius:8px;font-size:.85rem;width:100%;box-sizing:border-box">
                </div>
            </div>

            <div style="background:#0a0a14;border:1px solid #7b3fe422;border-radius:8px;padding:12px;margin-bottom:16px;font-size:.8rem">
                <div style="display:flex;justify-content:space-between;margin-bottom:5px">
                    <span style="color:#555">Sending:</span>
                    <span id="cfp-api-send-display" style="color:#7b3fe4;font-family:monospace;font-weight:700"><?=number_format($pending_balance)?> sat</span>
                </div>
                <div style="display:flex;justify-content:space-between">
                    <span style="color:#555">Remaining balance after:</span>
                    <span id="cfp-api-after-display" style="color:#aaa;font-family:monospace">0 sat</span>
                </div>
            </div>

            <button id="cfp-api-send-btn"
                onclick="cfpApiSend('<?=esc_js($nonce)?>')"
                <?=!$np_key_set?'disabled':''?>
                style="background:<?=$np_key_set?'linear-gradient(135deg,#7b3fe4,#5a2dab)':'#222'?>;color:<?=$np_key_set?'#fff':'#555'?>;border:none;padding:13px 28px;border-radius:10px;font-weight:900;font-size:.95rem;cursor:<?=$np_key_set?'pointer':'not-allowed'?>;width:100%">
                ⛓️ Send via NOWPayments → Trezor On-Chain
            </button>

            <div style="margin-top:10px;font-size:.75rem;color:#555">
                Funds sent on-chain to your Trezor via NOWPayments Mass Payout API.
                If the API call fails, the entry is automatically added to the Trezor Sweep retry queue.
                Your Trezor address must be whitelisted in NOWPayments → Store Settings → Whitelisted Addresses.
            </div>
        </div>

        <!-- ── PATH COMPARISON ── -->
        <div style="background:#0a0a0a;border:1px solid #1a1a1a;border-radius:12px;padding:20px">
            <h3 style="margin:0 0 14px;font-size:.9rem;color:#888">📖 Path A vs Path B</h3>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;font-size:.78rem">
                <div style="background:#0d0d0d;border:1px solid #f7931a22;border-radius:8px;padding:14px">
                    <div style="color:#f7931a;font-weight:700;margin-bottom:8px">🔐 Path A — Trezor Device (Pure On-Chain)</div>
                    <?php foreach ([
                        'No third-party intermediary — works without NOWPayments',
                        'Private key never leaves Trezor hardware',
                        'Amount + address displayed on device screen before signing',
                        'Physical button press required to authorize',
                        'Broadcasts raw Bitcoin tx directly to network via Mempool.space',
                        'Requires MetaMask+Trezor, WalletConnect, or Trezor Connect SDK',
                    ] as $item): ?>
                    <div style="display:flex;gap:7px;margin-bottom:5px;color:#666">
                        <span style="color:#1dc928;flex-shrink:0">✓</span><?=esc_html($item)?>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div style="background:#0d0d0d;border:1px solid #7b3fe422;border-radius:8px;padding:14px">
                    <div style="color:#7b3fe4;font-weight:700;margin-bottom:8px">⛓️ Path B — NOWPayments API</div>
                    <?php foreach ([
                        'Requires NOWPayments API key configured',
                        'Trezor address must be whitelisted in NOWPayments account',
                        'No browser wallet or device connection needed',
                        'Sent on-chain directly to Trezor hardware wallet',
                        'Failed calls auto-queued for retry in Trezor Sweep tab',
                        'Same API path as auto-sweep (just triggered manually)',
                    ] as $item): ?>
                    <div style="display:flex;gap:7px;margin-bottom:5px;color:#666">
                        <span style="color:#7b3fe4;flex-shrink:0">✓</span><?=esc_html($item)?>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

    </div>

    <!-- Trezor Connect SDK (official CDN) -->
    <script src="https://connect.trezor.io/9/trezor-connect.js" crossorigin="anonymous"></script>
    <!-- Ethers.js for MetaMask/WalletConnect path -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/ethers/6.7.0/ethers.umd.min.js" crossorigin="anonymous"></script>

    <script>
    let cfpHwProvider = null, cfpHwSigner = null, cfpHwAddress = null, cfpHwConnType = null, _cfpWcModal = null;
    const CFP_HW_AJAX    = '<?=esc_js($ajax_url)?>';
    const CFP_HW_PENDING = <?=(int)$pending_balance?>;
    const CFP_HW_BTC_PX  = <?=(int)$btc_price?>;
    let   cfpHwFeeSat    = 1500;
    let   cfpHwSelFee    = 'standard';

    function cfpHwMsg(msg, ok) {
        const el = document.getElementById('cfp-hw-status');
        if (!el) return;
        el.innerHTML = msg;
        el.style.borderColor = ok === true ? '#1dc92844' : ok === false ? '#ef444444' : '#1a1a1a';
        el.style.color = ok === true ? '#1dc928' : ok === false ? '#ef4444' : '#888';
    }

    function cfpHwSetAddr(addr, type) {
        cfpHwAddress = addr; cfpHwConnType = type;
        const block   = document.getElementById('cfp-hw-addr-block');
        const addrEl  = document.getElementById('cfp-hw-addr');
        const typeEl  = document.getElementById('cfp-hw-addr-type');
        const matchEl = document.getElementById('cfp-hw-addr-match');
        const txSect  = document.getElementById('cfp-hw-tx-section');
        const discBtn = document.getElementById('cfp-hw-disconnect');
        if (block)  block.style.display  = addr ? 'block' : 'none';
        if (addrEl) addrEl.textContent   = addr || '';
        if (typeEl) typeEl.textContent   = type || '';
        if (txSect) txSect.style.display = addr ? 'block' : 'none';
        if (discBtn) discBtn.style.display = addr ? 'inline-block' : 'none';
        const dest = document.getElementById('cfp-hw-dest')?.value?.trim();
        if (matchEl && addr && dest) {
            matchEl.innerHTML = addr.toLowerCase() === dest.toLowerCase()
                ? '<span style="color:#1dc928">✅ Address matches configured Trezor destination</span>'
                : '<span style="color:#f59e0b">⚠️ Connected address differs from destination. You are sending <em>to</em> the destination.</span>';
        } else if (matchEl) { matchEl.innerHTML = ''; }
    }

    function cfpHwReset() {
        cfpHwProvider = cfpHwSigner = cfpHwAddress = cfpHwConnType = null;
        if (_cfpWcModal) { try { _cfpWcModal.disconnect(); } catch(_) {} _cfpWcModal = null; }
        cfpHwSetAddr(null, null);
        cfpHwMsg('Disconnected.', null);
        document.getElementById('cfp-hw-tx-hash').innerHTML = '';
    }

    function _cfpBrowserProvider(raw) {
        if (typeof ethers === 'undefined') throw new Error('ethers.js not loaded');
        return ethers.BrowserProvider ? new ethers.BrowserProvider(raw) : new ethers.providers.Web3Provider(raw);
    }

    document.getElementById('cfp-hw-connect-mm').addEventListener('click', async function() {
        if (!window.ethereum) {
            cfpHwMsg('MetaMask not detected. Install MetaMask and add your Trezor via Account menu → Add hardware wallet → Trezor.', false); return;
        }
        try {
            cfpHwMsg('Requesting MetaMask accounts — select your Trezor account…', null);
            await window.ethereum.request({ method: 'eth_requestAccounts' });
            cfpHwProvider = _cfpBrowserProvider(window.ethereum);
            cfpHwSigner = await cfpHwProvider.getSigner();
            const addr = await cfpHwSigner.getAddress();
            cfpHwSetAddr(addr, 'MetaMask → Trezor hardware account');
            cfpHwMsg('✅ Connected via MetaMask (Trezor). Transactions require confirmation on your Trezor.', true);
            window.ethereum.on('accountsChanged', async accounts => {
                if (!accounts.length) { cfpHwReset(); return; }
                cfpHwSigner = await cfpHwProvider.getSigner();
                cfpHwSetAddr(await cfpHwSigner.getAddress(), 'MetaMask → Trezor hardware account');
            });
        } catch(err) {
            cfpHwMsg(err.code === 4001 ? 'MetaMask connection rejected.' : 'MetaMask error: ' + err.message, false);
        }
    });

    document.getElementById('cfp-hw-connect-wc').addEventListener('click', async function() {
        if (typeof window.EthereumProvider !== 'undefined') {
            try {
                cfpHwMsg('Opening WalletConnect — scan QR with Trezor Suite…', null);
                _cfpWcModal = await window.EthereumProvider.init({
                    projectId: '<?=esc_js(cfp_get_setting("wc_project_id",""))?>',
                    chains: [1], showQrModal: true,
                    qrModalOptions: { themeMode: 'dark', explorerRecommendedWalletIds: ['c57ca95b47569778a828d19178114f4db188b89b763c899ba0be274e97267d96'] },
                    metadata: { name: '<?=esc_js(get_bloginfo("name"))?> Admin', description: 'Crypto Faucet Pro Admin', url: window.location.origin, icons: [window.location.origin + '/favicon.ico'] },
                });
                await _cfpWcModal.connect();
                cfpHwProvider = _cfpBrowserProvider(_cfpWcModal);
                cfpHwSigner = await cfpHwProvider.getSigner();
                cfpHwSetAddr(await cfpHwSigner.getAddress(), 'WalletConnect v2 (Trezor Suite)');
                cfpHwMsg('✅ Connected via WalletConnect.', true);
                _cfpWcModal.on('disconnect', () => { cfpHwReset(); cfpHwMsg('WalletConnect session ended.', null); });
                return;
            } catch(err) { cfpHwMsg('WalletConnect error: ' + err.message, false); return; }
        }
        cfpHwMsg('WalletConnect library not loaded. Add a WalletConnect Project ID in plugin settings and reload.', false);
    });

    document.getElementById('cfp-hw-disconnect').addEventListener('click', cfpHwReset);

    document.getElementById('cfp-hw-tc-connect')?.addEventListener('click', async function() {
        if (typeof TrezorConnect === 'undefined') {
            document.getElementById('cfp-hw-tc-addr').textContent = '⚠️ Trezor Connect SDK failed to load — check browser console.'; return;
        }
        const account  = parseInt(document.getElementById('cfp-hw-tc-account')?.value || 0);
        const addrType = document.getElementById('cfp-hw-tc-type')?.value || 'p2wpkh';
        const paths    = { p2wpkh: `m/84'/0'/${account}'/0/0`, p2sh: `m/49'/0'/${account}'/0/0`, p2pkh: `m/44'/0'/${account}'/0/0` };
        const path     = paths[addrType];
        try {
            TrezorConnect.manifest({ email: '<?=esc_js(get_option("admin_email"))?>', appUrl: window.location.origin });
            const result = await TrezorConnect.getAddress({ path, coin: 'btc', showOnTrezor: true });
            if (!result.success) { document.getElementById('cfp-hw-tc-addr').textContent = '❌ ' + (result.payload?.error || 'Trezor error'); return; }
            const addr = result.payload.address;
            document.getElementById('cfp-hw-tc-addr').textContent = '✅ Trezor address: ' + addr;
            cfpHwSetAddr(addr, 'Trezor Connect SDK (Bitcoin native, ' + addrType + ' path ' + path + ')');
            cfpHwMsg('✅ Trezor connected via Trezor Connect SDK. Address verified on device.', true);
            window._cfpTrezorPath = path;
        } catch(err) { document.getElementById('cfp-hw-tc-addr').textContent = '❌ Trezor Connect error: ' + err.message; }
    });

    function cfpHwSetAmt(sat) { const el = document.getElementById('cfp-hw-amount'); if (el) { el.value = sat; cfpHwCalc(); } }
    function cfpHwSelectFee(tier) {
        cfpHwSelFee = tier;
        const fees = { economy: 750, standard: 1500, priority: 4500 };
        cfpHwFeeSat = fees[tier] || 1500;
        ['economy','standard','priority'].forEach(t => {
            const lbl = document.getElementById('cfp-fee-lbl-' + t);
            if (lbl) { lbl.style.borderColor = t === tier ? '#1dc928' : '#1dc92822'; lbl.style.background = t === tier ? '#0a1a0a' : '#0d0d0d'; }
        });
        cfpHwCalc();
    }
    function cfpHwCalc() {
        const amt = parseInt(document.getElementById('cfp-hw-amount')?.value || 0);
        const fee = cfpHwFeeSat;
        document.getElementById('cfp-hw-send-display').textContent = amt.toLocaleString() + ' sat';
        document.getElementById('cfp-hw-fee-display').textContent  = fee.toLocaleString() + ' sat';
        document.getElementById('cfp-hw-after-display').textContent = Math.max(0, CFP_HW_PENDING - amt - fee).toLocaleString() + ' sat';
        const fees = { economy: 750, standard: 1500, priority: 4500 };
        Object.entries(fees).forEach(([t, f]) => { const el = document.getElementById('cfp-fee-total-' + t); if (el) el.textContent = f.toLocaleString() + ' sat total'; });
    }
    cfpHwSelectFee('standard');

    document.getElementById('cfp-hw-sign-btn')?.addEventListener('click', async function() {
        const amt  = parseInt(document.getElementById('cfp-hw-amount')?.value || 0);
        const dest = document.getElementById('cfp-hw-dest')?.value?.trim();
        const fee  = cfpHwFeeSat;
        const nonce = '<?=esc_js($nonce)?>';
        if (!dest) { cfpHwMsg('⚠️ Enter a destination address.', false); return; }
        if (amt <= 0) { cfpHwMsg('⚠️ Enter an amount to send.', false); return; }
        if (!confirm(`Sign on Trezor device:\n\nSend: ${amt.toLocaleString()} sat\nFee:  ${fee.toLocaleString()} sat\nTo:   ${dest}\n\nYour Trezor will display these details and require physical confirmation.`)) return;

        const btn = document.getElementById('cfp-hw-sign-btn');
        btn.textContent = '⏳ Waiting for Trezor confirmation…'; btn.disabled = true;

        if (window._cfpTrezorPath && typeof TrezorConnect !== 'undefined') {
            try {
                cfpHwMsg('⏳ Building transaction — confirm on your Trezor device…', null);
                const txResult = await TrezorConnect.signTransaction({
                    inputs: [], outputs: [{ address: dest, amount: String(amt), script_type: 'PAYTOADDRESS' }],
                    coin: 'btc', push: true,
                });
                if (!txResult.success) { cfpHwMsg('❌ Trezor signing failed: ' + (txResult.payload?.error || 'Unknown error'), false); btn.textContent = '🔐 Sign & Broadcast on Trezor — Confirm on Device'; btn.disabled = false; return; }
                const txid = txResult.payload.txid;
                document.getElementById('cfp-hw-tx-hash').innerHTML = `🔗 Broadcast: <a href="https://mempool.space/tx/${txid}" target="_blank" rel="noopener" style="color:#3b82f6">${txid}</a>`;
                cfpHwMsg('✅ Signed and broadcast! TX: ' + txid.slice(0,16) + '…', true);
                const fd = new FormData();
                fd.append('action','cfp_hw_record_trezor_broadcast'); fd.append('nonce', nonce);
                fd.append('amount_sat', amt); fd.append('to_address', dest); fd.append('txid', txid);
                fd.append('currency', '<?=esc_js($currency)?>'); fd.append('note', 'Signed on Trezor device via Trezor Connect SDK');
                await fetch(CFP_HW_AJAX, { method: 'POST', body: fd });
                setTimeout(() => location.reload(), 2500);
                return;
            } catch(err) { cfpHwMsg('❌ Trezor Connect error: ' + err.message, false); btn.textContent = '🔐 Sign & Broadcast on Trezor — Confirm on Device'; btn.disabled = false; return; }
        }

        if (!cfpHwSigner) { cfpHwMsg('⚠️ No wallet connected. Use one of the connect buttons above.', false); btn.textContent = '🔐 Sign & Broadcast on Trezor — Confirm on Device'; btn.disabled = false; return; }

        try {
            cfpHwMsg('⏳ Sending — please confirm on your Trezor device…', null);
            const isEth = ethers.isAddress ? ethers.isAddress(dest) : ethers.utils.isAddress(dest);
            if (!isEth) { cfpHwMsg('❌ For Bitcoin addresses, use the Trezor Connect SDK section above.', false); btn.textContent = '🔐 Sign & Broadcast on Trezor — Confirm on Device'; btn.disabled = false; return; }
            const value = ethers.parseEther ? ethers.parseEther(String(amt / 1e18)) : ethers.utils.parseEther(String(amt / 1e18));
            const tx = await cfpHwSigner.sendTransaction({ to: dest, value });
            document.getElementById('cfp-hw-tx-hash').innerHTML = `🔗 TX: <a href="https://etherscan.io/tx/${tx.hash}" target="_blank" rel="noopener" style="color:#3b82f6">${tx.hash}</a>`;
            cfpHwMsg('📡 Broadcast: ' + tx.hash.slice(0,16) + '… waiting for confirmation…', null);
            const receipt = await tx.wait();
            cfpHwMsg('✅ Confirmed in block ' + receipt.blockNumber + '.', true);
            const fd = new FormData();
            fd.append('action','cfp_hw_record_trezor_broadcast'); fd.append('nonce', nonce);
            fd.append('amount_sat', amt); fd.append('to_address', dest); fd.append('txid', tx.hash);
            fd.append('currency', '<?=esc_js($currency)?>'); fd.append('note', 'Signed on Trezor device via MetaMask/WalletConnect');
            await fetch(CFP_HW_AJAX, { method: 'POST', body: fd });
            setTimeout(() => location.reload(), 2500);
        } catch(err) {
            cfpHwMsg(err.code === 'ACTION_REJECTED' || err.code === 4001 ? '❌ Transaction rejected on Trezor device.' : '❌ Transaction failed: ' + err.message, false);
        }
        btn.textContent = '🔐 Sign & Broadcast on Trezor — Confirm on Device'; btn.disabled = false;
    });

    function cfpApiSetAmt(sat) { const el = document.getElementById('cfp-api-amount'); if (el) { el.value = sat; cfpApiCalc(); } }
    function cfpApiCalc() {
        const amt = parseInt(document.getElementById('cfp-api-amount')?.value || 0);
        document.getElementById('cfp-api-send-display').textContent  = amt.toLocaleString() + ' sat';
        document.getElementById('cfp-api-after-display').textContent = Math.max(0, CFP_HW_PENDING - amt).toLocaleString() + ' sat';
    }
    cfpApiCalc();

    async function cfpApiSend(nonce) {
        const amt    = parseInt(document.getElementById('cfp-api-amount')?.value || 0);
        const dest   = document.getElementById('cfp-api-dest')?.value?.trim();
        const cur    = document.getElementById('cfp-api-currency')?.value?.trim() || '<?=esc_js($currency)?>';
        const note   = document.getElementById('cfp-api-note')?.value?.trim();
        const msgEl  = document.getElementById('cfp-api-msg');
        if (!dest) { if(msgEl) msgEl.innerHTML = '<div style="color:#ef4444;font-size:.82rem;padding:8px">⚠️ Destination address required.</div>'; return; }
        if (amt <= 0) { if(msgEl) msgEl.innerHTML = '<div style="color:#ef4444;font-size:.82rem;padding:8px">⚠️ Amount must be greater than 0.</div>'; return; }
        if (!confirm(`Send ${amt.toLocaleString()} sat ${cur} to:\n${dest}\n\nvia NOWPayments. Proceed?`)) return;

        const btn = document.getElementById('cfp-api-send-btn');
        btn.textContent = '⏳ Sending via NOWPayments…'; btn.disabled = true;
        if (msgEl) msgEl.innerHTML = '';

        const fd = new FormData();
        fd.append('action', 'cfp_hw_faucetpay_withdraw'); fd.append('nonce', nonce);
        fd.append('amount_sat', amt); fd.append('to_address', dest); fd.append('currency', cur); fd.append('note', note);
        try {
            const r = await fetch(CFP_HW_AJAX, { method: 'POST', body: fd });
            const d = await r.json();
            if (msgEl) {
                msgEl.innerHTML = `<div style="color:${d.success?'#1dc928':'#ef4444'};background:${d.success?'#0a1a0a':'#1a0a0a'};border:1px solid ${d.success?'#1dc92833':'#ef444433'};border-radius:8px;padding:12px;font-size:.82rem">${d.data?.message || d.data}</div>`;
            }
            if (d.success) setTimeout(() => location.reload(), 2500);
        } catch(err) {
            if (msgEl) msgEl.innerHTML = '<div style="color:#ef4444;font-size:.82rem;padding:8px">❌ Request failed: ' + err.message + '</div>';
        }
        btn.textContent = '⛓️ Send via NOWPayments → Trezor On-Chain'; btn.disabled = false;
    }

    async function cfpHwFetchFpBalance(nonce) {
        const el = document.getElementById('cfp-hw-fp-balance');
        if (el) el.textContent = '…';
        const fd = new FormData();
        fd.append('action', 'cfp_hw_faucetpay_balance'); fd.append('nonce', nonce);
        try {
            const r = await fetch(CFP_HW_AJAX, { method: 'POST', body: fd });
            const d = await r.json();
            if (el) {
                if (d.success) {
                    el.textContent = parseInt(d.data.balance_sat).toLocaleString() + ' sat ' + d.data.currency;
                    el.style.color = '#1dc928';
                } else {
                    el.textContent = '❌ ' + (d.data || 'Error');
                    el.style.color = '#ef4444';
                }
            }
        } catch(err) { if (el) { el.textContent = '❌ ' + err.message; el.style.color = '#ef4444'; } }
    }

    window.addEventListener('DOMContentLoaded', () => cfpHwFetchFpBalance('<?=esc_js($nonce)?>'));
    </script>
    <?php
}

function cfp_hw_preset_style( $primary = false ) {
    return $primary
        ? 'background:#1dc92222;border:1px solid #1dc92844;color:#1dc928;padding:4px 10px;border-radius:5px;font-size:.75rem;cursor:pointer;font-family:monospace'
        : 'background:#111;border:1px solid #333;color:#666;padding:4px 10px;border-radius:5px;font-size:.75rem;cursor:pointer;font-family:monospace';
}
