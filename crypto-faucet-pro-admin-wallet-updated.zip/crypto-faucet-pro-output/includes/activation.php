<?php
/**
 * Activation & Deactivation hooks, database table creation
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_should_create_table($table_name) {
    global $wpdb;
    return $wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name;
}

function cfp_activate() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    // Create core tables
    $tables = [
    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_USERS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        email VARCHAR(200) NOT NULL,
        username VARCHAR(100) NOT NULL DEFAULT '',
        password_hash VARCHAR(255) DEFAULT '',
        btc_address VARCHAR(64) DEFAULT '',
        balance_sat BIGINT NOT NULL DEFAULT 0,
        savings_sat BIGINT NOT NULL DEFAULT 0,
        ref_code VARCHAR(20) UNIQUE NOT NULL,
        referred_by VARCHAR(20) DEFAULT '',
        total_claims INT NOT NULL DEFAULT 0,
        total_earned BIGINT NOT NULL DEFAULT 0,
        golden_tickets INT NOT NULL DEFAULT 0,
        lottery_tickets INT NOT NULL DEFAULT 0,
        is_banned TINYINT(1) NOT NULL DEFAULT 0,
        is_verified TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        last_claim DATETIME DEFAULT NULL,
        last_login DATETIME DEFAULT NULL,
        PRIMARY KEY (id), UNIQUE KEY email (email)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_CLAIMS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        amount_sat BIGINT NOT NULL,
        ip_address VARCHAR(45) NOT NULL,
        claimed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_TRANSACTIONS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        type VARCHAR(40) NOT NULL,
        amount_sat BIGINT NOT NULL,
        description VARCHAR(255) DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_REFERRALS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        referrer_id BIGINT UNSIGNED NOT NULL,
        referred_id BIGINT UNSIGNED NOT NULL,
        bonus_paid BIGINT NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_WITHDRAWALS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        btc_address VARCHAR(64) NOT NULL,
        amount_sat BIGINT NOT NULL,
        fee_sat BIGINT NOT NULL DEFAULT 0,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        txid VARCHAR(128) DEFAULT '',
        requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        processed_at DATETIME DEFAULT NULL,
        admin_note TEXT DEFAULT NULL,
        PRIMARY KEY (id), KEY user_id (user_id), KEY status (status)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_SETTINGS . " (
        setting_key VARCHAR(100) NOT NULL,
        setting_val TEXT NOT NULL,
        PRIMARY KEY (setting_key)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_LOTTERY . " (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        week_start DATE NOT NULL,
        week_end DATE NOT NULL,
        prize_pool_sat BIGINT NOT NULL DEFAULT 0,
        winner_user_id BIGINT UNSIGNED DEFAULT NULL,
        winning_ticket INT DEFAULT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'active',
        drawn_at DATETIME DEFAULT NULL,
        PRIMARY KEY (id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_LOTTERY_TICKETS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        lottery_id INT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        ticket_number INT NOT NULL,
        earned_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY lottery_user (lottery_id, user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_INTEREST . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        amount_sat BIGINT NOT NULL,
        balance_snapshot BIGINT NOT NULL,
        paid_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_GOLDEN . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        tickets INT NOT NULL DEFAULT 0,
        contest_id INT NOT NULL DEFAULT 1,
        PRIMARY KEY (id), KEY user_contest (user_id, contest_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_P2P . " (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        title VARCHAR(255) NOT NULL,
        description TEXT,
        option_a VARCHAR(100) NOT NULL,
        option_b VARCHAR(100) NOT NULL,
        result VARCHAR(10) DEFAULT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'open',
        close_time DATETIME DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_P2P_BETS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        event_id INT UNSIGNED NOT NULL,
        user_id BIGINT UNSIGNED NOT NULL,
        choice VARCHAR(10) NOT NULL,
        amount_sat BIGINT NOT NULL,
        payout_sat BIGINT DEFAULT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        placed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY event_user (event_id, user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_MULTIPLY . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        choice VARCHAR(10) NOT NULL,
        roll INT NOT NULL,
        won TINYINT(1) NOT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_SLOTS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        reel1 VARCHAR(20) NOT NULL,
        reel2 VARCHAR(20) NOT NULL,
        reel3 VARCHAR(20) NOT NULL,
        win_type VARCHAR(30) DEFAULT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_COINFLIP . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        choice VARCHAR(6) NOT NULL,
        result VARCHAR(6) NOT NULL,
        won TINYINT(1) NOT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_DICE . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        prediction INT NOT NULL,
        direction VARCHAR(5) NOT NULL,
        result INT NOT NULL,
        won TINYINT(1) NOT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_CRASH . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        cashout_at FLOAT DEFAULT NULL,
        crash_at FLOAT NOT NULL,
        won TINYINT(1) NOT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_WHEEL . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        segment VARCHAR(30) NOT NULL,
        multiplier FLOAT NOT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_FP_DEPOSITS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        fp_payment_id VARCHAR(128) NOT NULL,
        currency VARCHAR(10) NOT NULL,
        amount_sat BIGINT NOT NULL,
        from_address VARCHAR(128) DEFAULT '',
        ip_address VARCHAR(45) DEFAULT '',
        status VARCHAR(20) NOT NULL DEFAULT 'confirmed',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY fp_payment_id (fp_payment_id),
        KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_FP_WITHDRAWALS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        fp_payout_id VARCHAR(128) DEFAULT '',
        to_address VARCHAR(128) NOT NULL,
        currency VARCHAR(10) NOT NULL,
        amount_sat BIGINT NOT NULL,
        fee_sat BIGINT NOT NULL DEFAULT 0,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        fp_response TEXT DEFAULT NULL,
        requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        processed_at DATETIME DEFAULT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY status (status)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_ADMIN_WALLET . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        stream VARCHAR(40) NOT NULL,
        amount_sat BIGINT NOT NULL,
        description VARCHAR(255) DEFAULT '',
        ref_id BIGINT UNSIGNED DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY stream (stream),
        KEY created_at (created_at)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_AD_REVENUE . " (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT,
        network VARCHAR(60) NOT NULL,
        amount_sat BIGINT NOT NULL,
        period_label VARCHAR(30) DEFAULT '',
        notes TEXT DEFAULT NULL,
        recorded_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_FUN_TOKENS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        type VARCHAR(30) NOT NULL,
        amount DECIMAL(18,6) NOT NULL,
        price_sat BIGINT NOT NULL DEFAULT 0,
        description VARCHAR(255) DEFAULT '',
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset",

    "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_PREMIUM . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        tier VARCHAR(20) NOT NULL DEFAULT 'silver',
        price_sat BIGINT NOT NULL,
        expires_at DATETIME NOT NULL,
        purchased_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY user_id (user_id)
    ) $charset",

    ];

    foreach($tables as $sql) dbDelta($sql);

    // Traffic Analytics tables
    if (cfp_should_create_table($wpdb->prefix . 'cfp_traffic_sessions')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_traffic_sessions (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(64) NOT NULL UNIQUE,
            user_id bigint(20) DEFAULT NULL,
            ip_address varchar(45) NOT NULL,
            country varchar(2) DEFAULT NULL,
            city varchar(100) DEFAULT NULL,
            referrer varchar(500) DEFAULT NULL,
            user_agent text,
            device_type varchar(20) DEFAULT 'desktop',
            browser varchar(50) DEFAULT NULL,
            os varchar(50) DEFAULT NULL,
            is_bot tinyint(1) DEFAULT 0,
            page_views int(11) DEFAULT 0,
            time_on_site int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            last_activity datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY session_id (session_id),
            KEY user_id (user_id),
            KEY ip_address (ip_address),
            KEY created_at (created_at)
        ) $charset");
    }

    if (cfp_should_create_table($wpdb->prefix . 'cfp_traffic_pageviews')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_traffic_pageviews (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            session_id varchar(64) NOT NULL,
            path varchar(500) NOT NULL,
            title varchar(200) DEFAULT NULL,
            query_string varchar(500) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY session_id (session_id),
            KEY created_at (created_at)
        ) $charset");
    }

    if (cfp_should_create_table($wpdb->prefix . 'cfp_traffic_summary')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_traffic_summary (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            date date NOT NULL,
            unique_visitors int(11) DEFAULT 0,
            page_views int(11) DEFAULT 0,
            bounces int(11) DEFAULT 0,
            new_visitors int(11) DEFAULT 0,
            returning_visitors int(11) DEFAULT 0,
            avg_time_on_site int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY date (date)
        ) $charset");
    }

    // Ad Manager tables
    if (cfp_should_create_table($wpdb->prefix . 'cfp_ads')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_ads (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            type varchar(20) NOT NULL,
            content text,
            url varchar(500) DEFAULT NULL,
            image_url varchar(500) DEFAULT NULL,
            code text,
            position varchar(50) DEFAULT 'header',
            placements text,
            impressions int(11) DEFAULT 0,
            clicks int(11) DEFAULT 0,
            enabled tinyint(1) DEFAULT 1,
            start_date datetime DEFAULT NULL,
            end_date datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY type (type),
            KEY enabled (enabled)
        ) $charset");
    }

    if (cfp_should_create_table($wpdb->prefix . 'cfp_ad_stats')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_ad_stats (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            ad_id bigint(20) NOT NULL,
            date date NOT NULL,
            impressions int(11) DEFAULT 0,
            clicks int(11) DEFAULT 0,
            PRIMARY KEY  (id),
            UNIQUE KEY ad_date (ad_id, date)
        ) $charset");
    }

    // Jackpot Manager table
    if (cfp_should_create_table($wpdb->prefix . 'cfp_jackpots')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_jackpots (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            game_type varchar(30) NOT NULL,
            current_amount bigint(20) DEFAULT 1000000,
            min_contribution int(11) DEFAULT 0,
            contribution_percent float DEFAULT 1,
            min_bet_for_jackpot int(11) DEFAULT 100,
            win_chance float DEFAULT 0.1,
            max_win bigint(20) DEFAULT 10000000,
            is_active tinyint(1) DEFAULT 1,
            last_winner_id bigint(20) DEFAULT 0,
            last_win_amount bigint(20) DEFAULT 0,
            last_win_date datetime DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY game_type (game_type),
            KEY is_active (is_active)
        ) $charset");
    }

    // Activity Log table
    if (cfp_should_create_table($wpdb->prefix . 'cfp_activity_log')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_activity_log (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            user_id bigint(20) NOT NULL,
            activity_type varchar(30) NOT NULL,
            details text,
            ip_address varchar(45) DEFAULT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY user_id (user_id),
            KEY activity_type (activity_type),
            KEY created_at (created_at)
        ) $charset");
    }

    // Price Alerts table
    if (cfp_should_create_table($wpdb->prefix . 'cfp_price_alerts')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_price_alerts (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            crypto varchar(10) NOT NULL,
            alert_type varchar(20) NOT NULL,
            threshold decimal(20,2) NOT NULL,
            direction varchar(10) NOT NULL,
            is_active tinyint(1) DEFAULT 1,
            notify_email tinyint(1) DEFAULT 1,
            notify_telegram tinyint(1) DEFAULT 0,
            last_triggered datetime DEFAULT NULL,
            last_trigger_price decimal(20,2) DEFAULT NULL,
            trigger_count int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY crypto (crypto),
            KEY is_active (is_active)
        ) $charset");
    }

    // API Keys table
    if (cfp_should_create_table($wpdb->prefix . 'cfp_api_keys')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_api_keys (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            name varchar(100) NOT NULL,
            key varchar(64) NOT NULL UNIQUE,
            secret_hash varchar(64) NOT NULL,
            permissions varchar(20) NOT NULL DEFAULT 'read',
            rate_limit int(11) DEFAULT 60,
            request_count bigint(20) DEFAULT 0,
            is_active tinyint(1) DEFAULT 1,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            last_regenerated datetime DEFAULT NULL,
            expires_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY key (key),
            KEY is_active (is_active)
        ) $charset");
    }

    // Bet Limits table
    if (cfp_should_create_table($wpdb->prefix . 'cfp_bet_limits')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_bet_limits (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            level int(11) NOT NULL,
            level_name varchar(50) NOT NULL,
            min_bet bigint(20) DEFAULT 1,
            max_bet bigint(20) DEFAULT 1000,
            max_daily_loss bigint(20) DEFAULT 10000,
            max_daily_bets int(11) DEFAULT 50,
            max_winning bigint(20) DEFAULT 5000,
            require_kyc tinyint(1) DEFAULT 0,
            is_active tinyint(1) DEFAULT 1,
            PRIMARY KEY  (id),
            KEY level (level)
        ) $charset");
    }

    // Referral Tiers table
    if (cfp_should_create_table($wpdb->prefix . 'cfp_referral_tiers')) {
        dbDelta("CREATE TABLE {$wpdb->prefix}cfp_referral_tiers (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            tier_level int(11) NOT NULL,
            tier_name varchar(50) NOT NULL,
            min_referrals int(11) DEFAULT 0,
            min_total_earn bigint(20) DEFAULT 0,
            commission_percent float DEFAULT 10,
            bonus_satoshis bigint(20) DEFAULT 0,
            extra_benefits text,
            is_active tinyint(1) DEFAULT 1,
            PRIMARY KEY  (id),
            KEY tier_level (tier_level)
        ) $charset");
    }

    // Trezor sweep queue table
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cfp_trezor_sweep_queue (
        id           bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        type         varchar(30)  NOT NULL DEFAULT 'auto_sweep',
        coin         varchar(20)  NOT NULL DEFAULT 'BTC',
        amount_sat   bigint(20)   NOT NULL DEFAULT 0,
        to_address   varchar(255) NOT NULL,
        status       varchar(20)  NOT NULL DEFAULT 'pending',
        faucetpay_id varchar(100) DEFAULT NULL,
        tx_hash      varchar(255) DEFAULT NULL,
        error_msg    text         DEFAULT NULL,
        note         text         DEFAULT NULL,
        attempts     tinyint(3)   NOT NULL DEFAULT 0,
        created_at   datetime     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at   datetime     DEFAULT NULL,
        PRIMARY KEY (id),
        KEY status (status),
        KEY created_at (created_at)
    ) $charset");
    update_option('cfp_trezor_sweep_db_version', '1.0.0');

    // Default settings
    $defaults = [
        'faucet_name'            => 'FreeCrypto.in',
        'faucet_tagline'         => 'Win Free Bitcoins Every Hour!',
        'claim_interval_minutes' => 60,
        'min_claim_sat'          => 98,
        'max_claim_sat'          => 200,
        'referral_percent'       => 50,
        'min_withdraw_sat'       => 30000,
        'withdraw_fee_sat'       => 1000,
        'faucet_enabled'         => 1,
        // Coinbase integration
        'blockchain_enabled'      => 0,
        'blockchain_api_key'      => '',
        'blockchain_currency'     => 'BTC',
        'blockchain_ipn_secret'   => '',
        'blockchain_auto_withdraw' => 1,
        'blockchain_min_withdraw' => 1000,
        'blockchain_fee_sat'      => 0,
        'captcha_enabled'        => 0,
        'recaptcha_site_key'     => '',
        'recaptcha_secret_key'   => '',
        'multiply_enabled'       => 1,
        'multiply_house_edge'    => 1,
        'lottery_enabled'        => 1,
        'lottery_ticket_per_claim'=> 1,
        'lottery_prize_sat'      => 2000000,
        'savings_apy'            => 4.08,
        'savings_enabled'        => 1,
        'golden_ticket_enabled'  => 1,
        'golden_prize_usd'       => 200000,
        'golden_prize_label'     => 'Win a Lamborghini!',
        'p2p_enabled'            => 1,
        'total_users_display'    => 55977844,
        'total_games_display'    => 150955055273,
        'total_btc_display'      => '251,239.37947554',
        'faucet_currency'        => 'BTC',
        'currency_symbol'        => '₿',
        'satoshi_label'          => 'Satoshi',
        'primary_color'          => '#f7931a',
        'accent_color'           => '#ffcc02',
        'site_logo_url'          => '',
        'btc_usd_price'          => 67694,
        'monthly_contest_enabled'=> 1,
        'monthly_prize_sat'      => 32500000,
        // Revenue wallet settings
        'admin_wallet_enabled'   => 1,
        'house_edge_auto_collect'=> 1,
        'wd_fee_auto_collect'    => 1,
        'interest_spread_rate'   => 2.0,
        'fun_token_name'         => 'FUN',
        'fun_token_price_sat'    => 100,
        'fun_token_total_supply' => 1000000,
        'premium_silver_sat'     => 50000,
        'premium_gold_sat'       => 100000,
        'premium_platinum_sat'   => 200000,
        'premium_silver_days'    => 30,
        'premium_gold_days'      => 30,
        'premium_platinum_days'  => 30,
        'ad_network_name'        => 'Anonymous Ads',
        'lottery_ticket_price_sat'=> 500,
        'lottery_ticket_sale_enabled'=> 1,
        // Trezor hardware wallet
        'trezor_label'           => 'My Trezor',
        'trezor_model'           => 'Model T',
        'trezor_currency'        => 'BTC',
        'trezor_xpub'            => '',
        'trezor_addresses'       => '[]',
        'trezor_active_address'  => '',
        'trezor_sweep_threshold' => 100000,
        'trezor_auto_alert'      => 1,
        'slots_enabled'          => 1,
        'slots_house_edge'       => 5,
        'coinflip_enabled'       => 1,
        'coinflip_house_edge'    => 2,
        'dice_enabled'           => 1,
        'dice_house_edge'        => 2,
        'crash_enabled'          => 1,
        'crash_house_edge'       => 5,
        'wheel_enabled'          => 1,
        'wheel_house_edge'       => 3,
    ];
    foreach ($defaults as $k => $v) {
        $wpdb->replace(CFP_TABLE_SETTINGS, ['setting_key'=>$k,'setting_val'=>$v]);
    }

    // Create first lottery week
    $existing = $wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_LOTTERY);
    if(!$existing) {
        $wpdb->insert(CFP_TABLE_LOTTERY, [
            'week_start'     => date('Y-m-d', strtotime('monday this week')),
            'week_end'       => date('Y-m-d', strtotime('sunday this week')),
            'prize_pool_sat' => 2000000,
            'status'         => 'active',
        ]);
    }
}

/* ============================================================
   V4 TABLE ADDITIONS — run on plugin update too
   ============================================================ */
add_action('plugins_loaded', 'cfp_maybe_upgrade_tables');
function cfp_maybe_upgrade_tables() {
    if ( get_option('cfp_db_version','0') === '4.2' ) return;
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';

    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_CHAT . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        username VARCHAR(100) NOT NULL DEFAULT '',
        message VARCHAR(500) NOT NULL,
        tip_amount BIGINT NOT NULL DEFAULT 0,
        is_rain TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY created_at (created_at)
    ) $charset");

    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_XP_LOG . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        xp_amount INT NOT NULL,
        reason VARCHAR(100) NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset");

    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_VERIFY_TOKENS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        token VARCHAR(64) NOT NULL,
        type VARCHAR(20) NOT NULL DEFAULT 'email',
        expires_at DATETIME NOT NULL,
        used_at DATETIME DEFAULT NULL,
        PRIMARY KEY (id), UNIQUE KEY token (token), KEY user_id (user_id)
    ) $charset");

    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_GAME_SEEDS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        server_seed_hash VARCHAR(64) NOT NULL,
        server_seed VARCHAR(64) DEFAULT NULL,
        client_seed VARCHAR(64) NOT NULL,
        nonce INT NOT NULL DEFAULT 0,
        is_revealed TINYINT(1) NOT NULL DEFAULT 0,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset");

    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_IP_LIMITS . " (
        ip_address VARCHAR(45) NOT NULL,
        action_type VARCHAR(30) NOT NULL,
        hit_count INT NOT NULL DEFAULT 1,
        window_start DATETIME NOT NULL,
        PRIMARY KEY (ip_address, action_type)
    ) $charset");

    // Session store — replaces the old key-value hack in cfp_settings.
    // Indexed on token (lookup) and expires_at (cleanup cron).
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cfp_sessions (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        token CHAR(64) NOT NULL,
        ip_address VARCHAR(45) NOT NULL DEFAULT '',
        expires_at DATETIME NOT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY token (token),
        KEY user_id (user_id),
        KEY expires_at (expires_at)
    ) $charset");

    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_KYC . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        full_name VARCHAR(200) DEFAULT '',
        country VARCHAR(80) DEFAULT '',
        doc_type VARCHAR(40) DEFAULT '',
        doc_notes TEXT DEFAULT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        submitted_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        reviewed_at DATETIME DEFAULT NULL,
        admin_note TEXT DEFAULT NULL,
        PRIMARY KEY (id), KEY user_id (user_id), KEY status (status)
    ) $charset");

    // NOWPayments tables
    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_NP_DEPOSITS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        np_payment_id VARCHAR(128) NOT NULL,
        order_id VARCHAR(128) DEFAULT '',
        currency VARCHAR(20) NOT NULL DEFAULT 'btc',
        pay_amount DECIMAL(24,8) NOT NULL DEFAULT 0,
        amount_sat BIGINT NOT NULL DEFAULT 0,
        price_amount DECIMAL(14,4) NOT NULL DEFAULT 0,
        status VARCHAR(30) NOT NULL DEFAULT 'waiting',
        raw_ipn TEXT DEFAULT NULL,
        created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY np_payment_id (np_payment_id),
        KEY user_id (user_id),
        KEY status (status)
    ) $charset");

    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_NP_WITHDRAWALS . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        np_payout_id VARCHAR(128) DEFAULT '',
        to_address VARCHAR(200) NOT NULL,
        currency VARCHAR(20) NOT NULL DEFAULT 'btc',
        amount_sat BIGINT NOT NULL DEFAULT 0,
        pay_amount DECIMAL(24,8) NOT NULL DEFAULT 0,
        fee_sat BIGINT NOT NULL DEFAULT 0,
        status VARCHAR(30) NOT NULL DEFAULT 'pending',
        np_response TEXT DEFAULT NULL,
        raw_ipn TEXT DEFAULT NULL,
        requested_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        processed_at DATETIME DEFAULT NULL,
        PRIMARY KEY (id),
        KEY user_id (user_id),
        KEY status (status),
        KEY np_payout_id (np_payout_id)
    ) $charset");

    // Per-user game streak table — keeps streak data out of cfp_settings.
    // Using REPLACE on (user_id, game) keeps this to one row per user/game pair.
    dbDelta("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}cfp_user_streaks (
        user_id BIGINT UNSIGNED NOT NULL,
        game    VARCHAR(30) NOT NULL,
        streak  INT UNSIGNED NOT NULL DEFAULT 0,
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (user_id, game),
        KEY game (game)
    ) $charset");

    // Migrate existing streak rows out of cfp_settings (safe to run multiple times)
    $wpdb->query(
        "INSERT IGNORE INTO {$wpdb->prefix}cfp_user_streaks (user_id, game, streak)
         SELECT
             CAST(SUBSTRING_INDEX(SUBSTRING_INDEX(setting_key,'_streak_',1),'_',-1) AS UNSIGNED) AS user_id,
             SUBSTRING_INDEX(setting_key,'_streak_',-1) AS game,
             CAST(setting_val AS UNSIGNED) AS streak
         FROM " . CFP_TABLE_SETTINGS . "
         WHERE setting_key LIKE 'user\\_%\\_streak\\_%'
           AND setting_key REGEXP '^user_[0-9]+_streak_[a-z]+$'"
    );
    // Remove migrated rows from cfp_settings to keep it lean
    $wpdb->query(
        "DELETE FROM " . CFP_TABLE_SETTINGS . "
         WHERE setting_key REGEXP '^user_[0-9]+_streak_[a-z]+$'"
    );

    // Add new columns to users table if not present
    // SECURITY FIX: Validate table name and use sanitized ALTER TABLE statements
    $table_name = CFP_TABLE_USERS;

    // Verify the table exists and the prefix is valid
    $table_exists = $wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = %s",
        $table_name
    ));

    if (!$table_exists) {
        error_log('[CFP Security] Attempted to alter non-existent table: ' . $table_name);
        return;
    }

    // Get existing columns — use esc_sql for identifier escaping (compatible with WP 5.8+)
    $cols = $wpdb->get_col("SHOW COLUMNS FROM `" . esc_sql($table_name) . "`");

    // Define column additions with validation
    $column_definitions = [
        'xp_total' => 'INT NOT NULL DEFAULT 0',
        'xp_level' => 'INT NOT NULL DEFAULT 1',
        'password_hash' => 'VARCHAR(255) DEFAULT ""',
        'twofa_secret' => 'VARCHAR(32) DEFAULT ""',
        'twofa_enabled' => 'TINYINT(1) NOT NULL DEFAULT 0',
        'kyc_status' => 'VARCHAR(20) NOT NULL DEFAULT "none"',
        'current_seed_id' => 'BIGINT UNSIGNED DEFAULT NULL',
        'login_token' => 'VARCHAR(64) DEFAULT ""',
        'login_token_expires' => 'DATETIME DEFAULT NULL',
    ];

    foreach ($column_definitions as $column_name => $column_def) {
        if (!in_array($column_name, $cols, true)) {
            // Use identifier escaping for table/column names
            // Only execute if column name matches expected pattern (alphanumeric + underscore)
            if (preg_match('/^[a-z_][a-z0-9_]*$/i', $column_name)) {
                $result = $wpdb->query($wpdb->prepare(
                    "ALTER TABLE `%i` ADD COLUMN `%i` " . $column_def,
                    $table_name,
                    $column_name
                ));
                if ($result === false) {
                    error_log('[CFP Security] Failed to add column ' . $column_name . ' to ' . $table_name);
                }
            } else {
                error_log('[CFP Security] Invalid column name detected: ' . $column_name);
            }
        }
    }

    update_option('cfp_db_version', '4.2');

    // Run additional setup routines from included modules
    if ( function_exists( 'cfp_run_db_migration' ) ) {
        cfp_run_db_migration();
    }
    if ( function_exists( 'cfp_create_referral_tables' ) ) {
        cfp_create_referral_tables();
    }

    // Feature module table creation — these files were previously orphaned and
    // their tables were never created on activation. Each function is guarded
    // with function_exists() so activation is safe even if a file is removed.
    if ( function_exists( 'cfp_create_notification_tables' ) ) {
        cfp_create_notification_tables();
    }
    if ( function_exists( 'cfp_create_admin_notification_tables' ) ) {
        cfp_create_admin_notification_tables();
    }
    if ( function_exists( 'cfp_create_achievement_tables' ) ) {
        cfp_create_achievement_tables();
    }
    if ( function_exists( 'cfp_create_leaderboard_tables' ) ) {
        cfp_create_leaderboard_tables();
    }
    if ( function_exists( 'cfp_create_fraud_tables' ) ) {
        cfp_create_fraud_tables();
    }
    if ( function_exists( 'cfp_create_webhook_tables' ) ) {
        cfp_create_webhook_tables();
    }
}
