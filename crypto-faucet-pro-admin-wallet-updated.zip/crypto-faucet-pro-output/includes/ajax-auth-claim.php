<?php
/**
 * AJAX handlers: register, login, claim faucet, savings, P2P bet
 * PRODUCTION HARDENED - Full IDOR protection with session tokens
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_get_user_by_email($email) {
    global $wpdb;
    return $wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_USERS." WHERE email=%s", $email));
}

/**
 * Validate session and return authenticated user
 * CRITICAL: This prevents IDOR attacks by requiring proper session authentication
 */
function cfp_get_authenticated_user() {
    $token = sanitize_text_field($_POST['cfp_session_token'] ?? $_COOKIE['cfp_session'] ?? '');
    
    if (empty($token)) {
        return new WP_Error('no_session', 'Authentication required. Please log in.');
    }
    
    $session = cfp_validate_session($token);
    if (!$session) {
        return new WP_Error('invalid_session', 'Session expired or invalid. Please log in again.');
    }
    
    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_USERS . " WHERE id=%d AND is_banned=0",
        $session['user_id']
    ));
    
    if (!$user) {
        return new WP_Error('user_not_found', 'Account not found or suspended.');
    }
    
    return $user;
}

/**
 * Quick auth check for protected endpoints
 */
function cfp_require_auth() {
    $user = cfp_get_authenticated_user();
    if (is_wp_error($user)) {
        wp_send_json_error(['msg' => $user->get_error_message()]);
    }
    return $user;
}

/* ============================================================
   AJAX: REGISTER
   ============================================================ */
add_action('wp_ajax_nopriv_cfp_register','cfp_ajax_register');
add_action('wp_ajax_cfp_register','cfp_ajax_register');
function cfp_ajax_register() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('register');
    $ref = sanitize_text_field($_POST['ref'] ?? '');

    // Enhanced validation: format, SQL injection patterns, disposable domains
    $email_result = cfp_validate_email_enhanced($_POST['email'] ?? '');
    if (is_wp_error($email_result)) {
        wp_send_json_error(['msg' => $email_result->get_error_message()]);
    }
    $email = $email_result;
    
    global $wpdb;
    if($wpdb->get_var($wpdb->prepare("SELECT id FROM ".CFP_TABLE_USERS." WHERE email=%s",$email)))
        wp_send_json_error(['msg'=>'Email already registered. Try logging in.']);
    
    $username='user'.strtolower(substr(hash('sha256', $email),0,6));
    $ref_code=strtoupper(substr(bin2hex(random_bytes(4)),0,8));
    $wpdb->insert(CFP_TABLE_USERS,['email'=>$email,'username'=>$username,'ref_code'=>$ref_code,'referred_by'=>$ref]);
    $uid=$wpdb->insert_id;
    
    if($ref) {
        $referrer=$wpdb->get_row($wpdb->prepare("SELECT id FROM ".CFP_TABLE_USERS." WHERE ref_code=%s",$ref));
        if($referrer) $wpdb->insert(CFP_TABLE_REFERRALS,['referrer_id'=>$referrer->id,'referred_id'=>$uid]);
    }
    
    // Create session for auto-login after registration
    $session_token = cfp_create_user_session($uid);
    
    do_action('cfp_user_registered', $uid, $email);
    if (function_exists('cfp_security_log')) {
        cfp_security_log('user_registered', $uid, ['email' => $email, 'ip' => cfp_get_real_ip()]);
    }

    // Set httponly session cookie immediately so the user is logged in
    // on the next request without needing JS to replay the token.
    do_action('cfp_set_session_cookie', $session_token, $uid);

    wp_send_json_success([
        'msg'=>'✅ Account created! You can now claim free '.cfp_get_setting('faucet_currency','BTC').'!',
        'email'=>$email,
        'ref_code'=>$ref_code,
        'session_token'=>$session_token
    ]);
}

/* ============================================================
   AJAX: SESSION PING
   Called by cfpGetSessionToken() on DOMContentLoaded.
   Reads the httponly cookie server-side and returns a fresh
   token so JS can cache it in memory for same-page requests.
   Registered for both priv and nopriv — returns empty on no session.
   ============================================================ */
add_action('wp_ajax_cfp_ping_session',        'cfp_ajax_ping_session');
add_action('wp_ajax_nopriv_cfp_ping_session', 'cfp_ajax_ping_session');
function cfp_ajax_ping_session() {
    check_ajax_referer('cfp_nonce','nonce');

    $token = sanitize_text_field( $_COOKIE['cfp_session'] ?? '' );
    if ( empty($token) ) {
        wp_send_json_success(['logged_in' => false]);
    }

    $session = cfp_validate_session($token);
    if ( ! $session ) {
        wp_send_json_success(['logged_in' => false]);
    }

    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare(
        "SELECT id, username, email, balance_sat FROM " . CFP_TABLE_USERS . " WHERE id=%d AND is_banned=0",
        $session['user_id']
    ));

    if ( ! $user ) {
        wp_send_json_success(['logged_in' => false]);
    }

    wp_send_json_success([
        'logged_in'     => true,
        'session_token' => $token,   // JS caches this for same-page AJAX
        'username'      => $user->username,
        'email'         => $user->email,
        'balance_sat'   => (int) $user->balance_sat,
    ]);
}

/* ============================================================
   AJAX: LOGIN (Returns session token)
   ============================================================ */
add_action('wp_ajax_nopriv_cfp_login_session','cfp_ajax_login_session');
function cfp_ajax_login_session() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('login');
    $password = $_POST['password'] ?? '';

    // Enhanced validation: format, SQL injection patterns, disposable domains
    $email_result = cfp_validate_email_enhanced($_POST['email'] ?? '');
    if (is_wp_error($email_result)) {
        wp_send_json_error(['msg' => $email_result->get_error_message()]);
    }
    $email = $email_result;
    
    // Check brute force
    $bf_check = cfp_check_login_attempts($email);
    if (is_wp_error($bf_check)) {
        wp_send_json_error(['msg'=>$bf_check->get_error_message()]);
    }
    
    global $wpdb;
    $user=cfp_get_user_by_email($email);
    
    if (!$user) {
        cfp_record_failed_login($email);
        wp_send_json_error(['msg'=>'Invalid email or password.']);
    }

    // FIX #5: Check ban status immediately, before any session creation.
    if ($user->is_banned) {
        wp_send_json_error(['msg'=>'Account suspended. Contact support.']);
    }

    // FIX #1: Block accounts with no password — require them to set one first.
    // Accounts registered before passwords were introduced must use the
    // password-setup flow before they can log in.
    if (empty($user->password_hash)) {
        wp_send_json_error([
            'msg'              => 'Your account requires a password. Please use the "Set Password" link to secure your account before logging in.',
            'need_password_setup' => true,
        ]);
    }

    // Verify password
    if (empty($password)) {
        wp_send_json_error(['msg'=>'Password is required.']);
    }
    if (!password_verify($password, $user->password_hash)) {
        cfp_record_failed_login($email);
        wp_send_json_error(['msg'=>'Invalid email or password.']);
    }
    
    // Email verification check
    if (cfp_get_setting('email_verify_required','0') === '1' && !$user->is_verified) {
        wp_send_json_error(['msg'=>'Please verify your email first. Check your inbox for the verification link.','need_verification'=>true]);
    }
    
    // Create session only after all checks pass
    $session_token = cfp_create_user_session($user->id);
    
    // Clear failed login attempts
    cfp_clear_login_attempts($email);
    
    do_action('cfp_user_login_success', $user->id, $email);

    // Set the session as a secure httponly cookie server-side.
    // The token is also returned in the JSON body so JS can append it
    // to AJAX requests via cfpGetSessionToken() for same-page use.
    do_action('cfp_set_session_cookie', $session_token, $user->id);

    wp_send_json_success([
        'msg'=>'✅ Logged in!',
        'session_token'=>$session_token,
        'email'=>$email,
        'username'=>$user->username
    ]);
}

/* ============================================================
   AJAX: CLAIM (PROTECTED - Requires session)
   ============================================================ */
add_action('wp_ajax_cfp_claim','cfp_ajax_claim');
function cfp_ajax_claim() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('claim');
    
    // IDOR protection - require valid session
    $user = cfp_require_auth();
    
    if(!cfp_get_setting('faucet_enabled','1')) wp_send_json_error(['msg'=>'Faucet is temporarily paused. Check back soon.']);
    
    if($user->is_banned) wp_send_json_error(['msg'=>'Your account has been suspended.']);
    
    // Email verification check
    if (cfp_get_setting('email_verify_required','0') === '1' && !$user->is_verified) {
        wp_send_json_error(['msg'=>'Please verify your email first. Check your inbox.']);
    }
    
    $interval=intval(cfp_get_setting('claim_interval_minutes',60));
    if($user->last_claim) {
        $diff=current_time('timestamp')-strtotime($user->last_claim);
        $remaining=($interval*60)-$diff;
        if($remaining>0) {
            $h=floor($remaining/3600); $m=floor(($remaining%3600)/60); $s=$remaining%60;
            wp_send_json_error(['msg'=>"Next claim in ".sprintf('%02d:%02d:%02d',$h,$m,$s),'remaining'=>$remaining]);
        }
    }
    
    // Get claim amount with provably fair random
    $seed = cfp_generate_game_seed();
    $min=intval(cfp_get_setting('min_claim_sat',98)); 
    $max=intval(cfp_get_setting('max_claim_sat',200));
    $amount=random_int($min,$max);
    $ip=cfp_get_real_ip();
    
    // Lottery tickets
    $lottery_tix=intval(cfp_get_setting('lottery_ticket_per_claim',1));
    $lottery=$wpdb->get_row("SELECT id FROM ".CFP_TABLE_LOTTERY." WHERE status='active' ORDER BY id DESC LIMIT 1");
    
    $wpdb->insert(CFP_TABLE_CLAIMS,['user_id'=>$user->id,'amount_sat'=>$amount,'ip_address'=>$ip,'seed'=>$seed]);
    $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d,total_claims=total_claims+1,total_earned=total_earned+%d,last_claim=%s,lottery_tickets=lottery_tickets+%d WHERE id=%d",$amount,$amount,current_time('mysql'),$lottery_tix,$user->id));
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>'claim','amount_sat'=>$amount,'description'=>'Hourly faucet claim']);
    
    // Add lottery ticket
    if($lottery && cfp_get_setting('lottery_enabled',1)) {
        for($t=0;$t<$lottery_tix;$t++) {
            $wpdb->insert(CFP_TABLE_LOTTERY_TICKETS,['lottery_id'=>$lottery->id,'user_id'=>$user->id,'ticket_number'=>random_int(1000000,9999999)]);
        }
    }
    
    // Golden ticket (provably fair random)
    $golden_bonus='';
    $golden_seed = cfp_generate_game_seed();
    if(cfp_get_setting('golden_ticket_enabled',1) && random_int(1,500)===1) {
        $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET golden_tickets=golden_tickets+1 WHERE id=%d",$user->id));
        $golden_bonus=' 🎫 You also received a Golden Ticket!';
    }
    
    // Referral bonus
    if($user->referred_by) {
        $pct=intval(cfp_get_setting('referral_percent',50));
        $bonus=floor($amount*$pct/100);
        if($bonus>0) {
            $ref=$wpdb->get_row($wpdb->prepare("SELECT id,username FROM ".CFP_TABLE_USERS." WHERE ref_code=%s",$user->referred_by));
            if($ref) {
                $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d,total_earned=total_earned+%d WHERE id=%d",$bonus,$bonus,$ref->id));
                $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$ref->id,'type'=>'referral_bonus','amount_sat'=>$bonus,'description'=>"Referral bonus ({$pct}%) from ".$user->username]);
                $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_REFERRALS." SET bonus_paid=bonus_paid+%d WHERE referrer_id=%d AND referred_id=%d",$bonus,$ref->id,$user->id));
            }
        }
    }
    
    if (function_exists('cfp_security_log')) {
        cfp_security_log('faucet_claim', $user->id, ['amount'=>$amount, 'ip'=>$ip, 'seed'=>$seed]);
    }
    
    wp_send_json_success([
        'msg'=>"🎉 You claimed {$amount} satoshis!{$golden_bonus}",
        'amount'=>$amount,
        'next_in'=>$interval*60,
        'lottery_tickets'=>$lottery_tix,
        'seed'=>$seed // For provably fair verification
    ]);
}

/* ============================================================
   AJAX: HI-LO MULTIPLY (PROTECTED - Requires session)
   ============================================================ */
add_action('wp_ajax_cfp_multiply','cfp_ajax_multiply');
function cfp_ajax_multiply() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('game');
    
    // IDOR protection
    $user = cfp_require_auth();
    
    if(!cfp_get_setting('multiply_enabled','1')) wp_send_json_error(['msg'=>'Hi-Lo game is currently disabled.']);
    
    $amount=intval($_POST['amount']??0); 
    $choice=sanitize_text_field($_POST['choice']??'');
    
    if($amount<=0) wp_send_json_error(['msg'=>'Enter a valid bet amount.']);
    if(!in_array($choice,['hi','lo'])) wp_send_json_error(['msg'=>'Choose Hi or Lo.']);
    
    // Bet limits
    $min_bet = intval(cfp_get_setting('game_min_bet', 10));
    $max_bet = intval(cfp_get_setting('game_max_bet', 100000));
    if ($amount < $min_bet) wp_send_json_error(['msg'=>"Minimum bet is {$min_bet} sat."]);
    if ($max_bet > 0 && $amount > $max_bet) wp_send_json_error(['msg'=>"Maximum bet is {$max_bet} sat."]);
    
    global $wpdb;

    // Use atomic update to prevent race conditions
    $check = $wpdb->query($wpdb->prepare(
        "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $amount, $user->id, $amount
    ));
    if (!$check) wp_send_json_error(['msg'=>'Insufficient balance or concurrent request.']);
    
    // Provably fair roll
    $server_seed = cfp_generate_game_seed();
    $roll = random_int(1,10000) / 100; // 0.01 - 100.00 precision
    
    $edge=floatval(cfp_get_setting('multiply_house_edge',1));
    $won=($choice==='hi') ? ($roll>50) : ($roll<=50);
    $hilo_mult=floatval(cfp_get_setting('multiply_win_mult',2));
    $payout=$won?floor($amount*(1-$edge/100)*$hilo_mult):0;
    $net=$payout-$amount;
    
    $wpdb->insert(CFP_TABLE_MULTIPLY,[
        'user_id'=>$user->id,
        'bet_sat'=>$amount,
        'choice'=>$choice,
        'roll'=>$roll,
        'won'=>$won?1:0,
        'payout_sat'=>$payout,
        'server_seed'=>$server_seed
    ]);
    
    if($won) {
        $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$payout,$user->id));
        $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>'multiply_win','amount_sat'=>$payout,"description"=>"Hi-Lo win: rolled {$roll}, chose ".strtoupper($choice)]);
    }
    
    $new_bal=$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d",$user->id));
    
    // House edge
    $ggr_hilo = $amount - $payout;
    if($ggr_hilo > 0) cfp_wallet_credit_game('admin_wallet_stream_hilo', 'house_edge_hilo', $ggr_hilo, "Hi-Lo house edge: rolled {$roll}, bet {$amount}");
    
    if (function_exists('cfp_security_log')) {
        cfp_security_log('hilo_play', $user->id, ['bet'=>$amount,'roll'=>$roll,'won'=>$won,'seed'=>$server_seed]);
    }
    
    wp_send_json_success([
        'won'=>$won,
        'roll'=>round($roll,2),
        'choice'=>$choice,
        'msg'=>$won?"🎉 Rolled ".round($roll,2)." — YOU WIN! +{$payout} sat":"💥 Rolled ".round($roll,2)." — You lose. -{$amount} sat",
        'payout'=>$payout,
        'new_balance'=>$new_bal,
        'server_seed'=>$server_seed // For provably fair verification
    ]);
}

/* ============================================================
   AJAX: SAVINGS DEPOSIT/WITHDRAW (PROTECTED)
   ============================================================ */
add_action('wp_ajax_cfp_savings','cfp_ajax_savings');
function cfp_ajax_savings() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('default');
    
    $user = cfp_require_auth();
    $action=sanitize_text_field($_POST['savings_action']??''); 
    $amount=intval($_POST['amount']??0);
    
    if($amount<=0) wp_send_json_error(['msg'=>'Invalid amount.']);
    
    global $wpdb;
    
    if($action==='deposit') {
        // Atomic update
        $check = $wpdb->query($wpdb->prepare(
            "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
            $amount, $user->id, $amount
        ));
        if (!$check) wp_send_json_error(['msg'=>'Insufficient balance.']);
        
        $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET savings_sat=savings_sat+%d WHERE id=%d",$amount,$user->id));
        $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>'savings_deposit','amount_sat'=>-$amount,'description'=>'Deposited to savings']);
        wp_send_json_success(['msg'=>"✅ Deposited {$amount} sat to savings. Earning ".cfp_get_setting('savings_apy','4.08')."% APY daily!"]);
        
    } elseif($action==='withdraw') {
        // Atomic update
        $check = $wpdb->query($wpdb->prepare(
            "UPDATE ".CFP_TABLE_USERS." SET savings_sat=savings_sat-%d WHERE id=%d AND savings_sat>=%d",
            $amount, $user->id, $amount
        ));
        if (!$check) wp_send_json_error(['msg'=>'Insufficient savings balance.']);
        
        $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$amount,$user->id));
        $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>'savings_withdraw','amount_sat'=>$amount,'description'=>'Withdrawn from savings']);
        wp_send_json_success(['msg'=>"✅ Withdrawn {$amount} sat from savings."]);
    }
    wp_send_json_error(['msg'=>'Unknown action.']);
}

/* ============================================================
   AJAX: P2P BET (PROTECTED)
   ============================================================ */
add_action('wp_ajax_cfp_p2p_bet','cfp_ajax_p2p_bet');
function cfp_ajax_p2p_bet() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('default');
    
    $user = cfp_require_auth();
    $event_id=intval($_POST['event_id']??0); 
    $choice=sanitize_text_field($_POST['choice']??''); 
    $amount=intval($_POST['amount']??0);
    
    if($amount<=0||!in_array($choice,['a','b'])) wp_send_json_error(['msg'=>'Invalid bet.']);
    
    global $wpdb;
    $event=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_P2P." WHERE id=%d AND status='open'",$event_id));
    if(!$event) wp_send_json_error(['msg'=>'Event not found or already closed.']);
    
    // Atomic update
    $check = $wpdb->query($wpdb->prepare(
        "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $amount, $user->id, $amount
    ));
    if (!$check) wp_send_json_error(['msg'=>'Insufficient balance.']);
    
    $wpdb->insert(CFP_TABLE_P2P_BETS,['event_id'=>$event_id,'user_id'=>$user->id,'choice'=>$choice,'amount_sat'=>$amount]);
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>'p2p_bet','amount_sat'=>-$amount,'description'=>"P2P bet on: {$event->title}"]);
    
    if (function_exists('cfp_security_log')) {
        cfp_security_log('p2p_bet', $user->id, ['event'=>$event_id,'amount'=>$amount]);
    }
    
    wp_send_json_success(['msg'=>"✅ Bet placed! {$amount} sat on ".strtoupper($choice)."."]);
}

/* ============================================================
   AJAX: LOGOUT (Destroy session)
   FIX #9: Added check_ajax_referer to prevent CSRF logout attacks.
   ============================================================ */
add_action('wp_ajax_cfp_logout','cfp_ajax_logout');
function cfp_ajax_logout() {
    check_ajax_referer('cfp_nonce','nonce');
    $token = sanitize_text_field($_POST['cfp_session_token'] ?? '');
    if ($token) {
        cfp_destroy_session($token);
    }
    wp_send_json_success(['msg'=>'Logged out successfully.']);
}

/* ============================================================
   AJAX: GET USER DATA (PROTECTED)
   ============================================================ */
add_action('wp_ajax_cfp_get_user_data','cfp_ajax_get_user_data');
function cfp_ajax_get_user_data() {
    check_ajax_referer('cfp_nonce','nonce');
    $user = cfp_require_auth();
    
    global $wpdb;
    $remaining=0;
    if($user->last_claim) {
        $interval=intval(cfp_get_setting('claim_interval_minutes',60))*60;
        $remaining=max(0,$interval-(current_time('timestamp')-strtotime($user->last_claim)));
    }
    
    wp_send_json_success([
        'balance'        =>number_format($user->balance_sat),
        'balance_raw'    =>$user->balance_sat,
        'savings'        =>number_format($user->savings_sat),
        'savings_raw'    =>$user->savings_sat,
        'username'       =>esc_html($user->username),
        'email'          =>esc_html($user->email),
        'ref_code'       =>$user->ref_code,
        'lottery_tickets'=>$user->lottery_tickets,
        'golden_tickets' =>$user->golden_tickets,
        'total_earned'   =>number_format($user->total_earned),
        'remaining'      =>$remaining,
        'is_verified'    =>$user->is_verified,
    ]);
}

/* ============================================================
   AJAX: TRANSACTION HISTORY (PROTECTED)
   ============================================================ */
add_action('wp_ajax_cfp_get_history','cfp_ajax_get_history');
function cfp_ajax_get_history() {
    check_ajax_referer('cfp_nonce','nonce');
    $user = cfp_require_auth();
    
    global $wpdb;
    $rows=$wpdb->get_results($wpdb->prepare(
        "SELECT type,amount_sat,description,created_at FROM ".CFP_TABLE_TRANSACTIONS." 
         WHERE user_id=%d ORDER BY created_at DESC LIMIT 50",
        $user->id
    ));
    
    $data=array_map(function($r){
        return [
            'type'=>ucwords(str_replace('_',' ',esc_html($r->type))),
            'amount'=>intval($r->amount_sat),
            'desc'=>esc_html($r->description),
            'date'=>date('M j, g:ia',strtotime($r->created_at))
        ];
    }, $rows);
    
    wp_send_json_success(['rows'=>$data]);
}
