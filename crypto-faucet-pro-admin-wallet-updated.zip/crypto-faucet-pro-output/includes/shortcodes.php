<?php
/**
 * Frontend shortcodes: [cfp_faucet], [cfp_buy_tickets], [cfp_fun_token], etc.
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   SHORTCODE: [cfp_faucet]
   ============================================================ */
add_shortcode('cfp_faucet', function() {
    $min=cfp_get_setting('min_claim_sat',98); $max=cfp_get_setting('max_claim_sat',200);
    $interval=cfp_get_setting('claim_interval_minutes',60); $currency=cfp_get_setting('faucet_currency','BTC');
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-faucet-widget">
        <h2>⚡ Free <?=$currency?></h2>
        <p class="sub">Claim <?=$min?>–<?=$max?> satoshis every <?=$interval?> minutes — free!</p>
        <div id="cfp-claim-msg"></div>
        <div class="cfp-balance-box" id="cfp-main-balance" style="display:none">
            <div class="lbl">Balance</div>
            <div class="amount" id="cfp-bal-amount">0</div>
            <div style="font-size:.78rem;color:#555">satoshis</div>
        </div>
        <div id="cfp-timer-box" style="display:none" class="cfp-timer">⏱ Next claim in <span id="cfp-timer">--:--:--</span></div>
        <input class="cfp-input" type="email" id="cfp-claim-email" placeholder="Enter your email to claim">
        <button class="cfp-claim-btn" id="cfp-claim-btn" onclick="cfpDoClaim()">🪙 CLAIM FREE <?=strtoupper($currency)?></button>
        <div style="display:flex;justify-content:space-between;font-size:.76rem;color:#444;margin-top:12px">
            <span>Min: <?=$min?> sat · Max: <?=$max?> sat</span><span>Interval: <?=$interval?> min</span>
        </div>
    </div>
    <script>
    let cfpCountdown=null;
    function cfpSetTimer(seconds){
        clearInterval(cfpCountdown);
        document.getElementById('cfp-timer-box').style.display='';
        document.getElementById('cfp-claim-btn').disabled=true;
        cfpCountdown=setInterval(()=>{
            if(seconds<=0){clearInterval(cfpCountdown);document.getElementById('cfp-timer-box').style.display='none';document.getElementById('cfp-claim-btn').disabled=false;document.getElementById('cfp-timer').textContent='--:--:--';return;}
            seconds--;
            const h=String(Math.floor(seconds/3600)).padStart(2,'0');
            const m=String(Math.floor((seconds%3600)/60)).padStart(2,'0');
            const s=String(seconds%60).padStart(2,'0');
            document.getElementById('cfp-timer').textContent=`${h}:${m}:${s}`;
        },1000);
    }
    async function cfpDoClaim(){
        const email=document.getElementById('cfp-claim-email').value;
        if(!email){cfpClaimMsg('Please enter your email.','error');return;}
        document.getElementById('cfp-claim-btn').disabled=true;
        const fd=new FormData();
        fd.append('action','cfp_claim');fd.append('nonce',cfpNonce);fd.append('email',email);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});
        const d=await r.json();
        cfpClaimMsg(d.data.msg,d.success?'success':'error');
        if(d.success){
            cfpSetTimer(d.data.next_in);
            cfpRefreshBalance(email);
        } else {
            if(d.data.remaining) cfpSetTimer(d.data.remaining);
            else document.getElementById('cfp-claim-btn').disabled=false;
        }
    }
    async function cfpRefreshBalance(email){
        const fd=new FormData();fd.append('action','cfp_get_user');fd.append('nonce',cfpNonce);fd.append('email',email);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});
        const d=await r.json();
        if(d.success){
            document.getElementById('cfp-main-balance').style.display='';
            document.getElementById('cfp-bal-amount').textContent=d.data.balance;
            if(d.data.remaining>0) cfpSetTimer(d.data.remaining);
        }
    }
    function cfpClaimMsg(msg,type){document.getElementById('cfp-claim-msg').innerHTML=`<div class="cfp-msg ${type}">${msg}</div>`;}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_hilo]
   ============================================================ */
add_shortcode('cfp_hilo', function() {
    if(!cfp_get_setting('multiply_enabled','1')) return '<p style="color:#666;text-align:center">Hi-Lo game coming soon.</p>';
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-hilo-widget">
        <h2>🎲 Hi-Lo Multiply</h2>
        <p class="sub">Predict the dice roll — win up to 2x your bet!</p>
        <div id="cfp-hilo-msg"></div>
        <input class="cfp-input" type="email" id="cfp-hilo-email" placeholder="Account email">
        <input class="cfp-input" type="number" id="cfp-hilo-amount" placeholder="Bet amount (satoshis)" min="1">
        <div class="cfp-dice-display" id="cfp-dice">🎲</div>
        <div id="cfp-roll-result" style="font-family:'Oswald',sans-serif;font-size:1.4rem;text-align:center;margin:-8px 0 10px;color:#555"></div>
        <div class="cfp-hi-lo-btns">
            <button class="cfp-hi-btn" onclick="cfpBet('hi')">📈 HI (&gt;50)</button>
            <button class="cfp-lo-btn" onclick="cfpBet('lo')">📉 LO (≤50)</button>
        </div>
        <div id="cfp-hilo-balance" style="font-size:.8rem;color:#555;text-align:center"></div>
    </div>
    <script>
    const diceEmojis=['1️⃣','2️⃣','3️⃣','4️⃣','5️⃣','6️⃣','7️⃣','8️⃣','9️⃣','🔟'];
    async function cfpBet(choice){
        const email=document.getElementById('cfp-hilo-email').value;
        const amount=document.getElementById('cfp-hilo-amount').value;
        if(!email||!amount){cfpHiloMsg('Enter email and bet amount.','error');return;}
        const fd=new FormData();
        fd.append('action','cfp_multiply');fd.append('nonce',cfpNonce);fd.append('email',email);fd.append('amount',amount);fd.append('choice',choice);
        document.getElementById('cfp-dice').textContent='🌀';
        document.getElementById('cfp-roll-result').textContent='Rolling…';
        const r=await fetch(cfpAjax,{method:'POST',body:fd});
        const d=await r.json();
        if(d.success){
            const roll=d.data.roll;
            document.getElementById('cfp-dice').textContent=roll<=10?'1️⃣':roll<=20?'2️⃣':roll<=30?'3️⃣':roll<=40?'4️⃣':roll<=50?'5️⃣':roll<=60?'6️⃣':roll<=70?'7️⃣':roll<=80?'8️⃣':roll<=90?'9️⃣':'🔟';
            document.getElementById('cfp-roll-result').innerHTML=`<span style="color:#888">Roll: </span><strong style="color:${d.data.roll>50?'#22c55e':'#ef4444'}">${roll}</strong>`;
            cfpHiloMsg(d.data.msg,d.data.won?'success':'error');
            document.getElementById('cfp-hilo-balance').innerHTML=`Balance: <strong style="color:var(--cfp-p)">${d.data.new_balance.toLocaleString()} sat</strong>`;
        } else {
            document.getElementById('cfp-dice').textContent='🎲';
            document.getElementById('cfp-roll-result').textContent='';
            cfpHiloMsg(d.data.msg,'error');
        }
    }
    function cfpHiloMsg(msg,type){document.getElementById('cfp-hilo-msg').innerHTML=`<div class="cfp-msg ${type}">${msg}</div>`;}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_lottery]
   ============================================================ */
add_shortcode('cfp_lottery', function() {
    if(!cfp_get_setting('lottery_enabled','1')) return '';
    global $wpdb;
    $lottery=$wpdb->get_row("SELECT l.*,COUNT(lt.id) tc FROM ".CFP_TABLE_LOTTERY." l LEFT JOIN ".CFP_TABLE_LOTTERY_TICKETS." lt ON lt.lottery_id=l.id WHERE l.status='active' GROUP BY l.id");
    $prize=cfp_get_setting('lottery_prize_sat',2000000);
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>🎟 Weekly Lottery</h2>
        <p class="sub">Earn a ticket with every claim. Win big every week!</p>
        <div style="text-align:center;margin-bottom:16px">
            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:6px">Prize Pool</div>
            <div style="font-family:'Oswald',sans-serif;font-size:2.2rem;font-weight:900;color:var(--cfp-p)"><?=number_format($prize)?> <span style="font-size:1rem">sat</span></div>
            <?php if($lottery): ?><div style="font-size:.78rem;color:#555;margin-top:4px"><?=number_format($lottery->tc)?> tickets this week · Draw <?=date('D M j',strtotime($lottery->week_end))?></div><?php endif; ?>
        </div>
        <div style="display:flex;justify-content:center;flex-wrap:wrap;margin-bottom:14px">
            <?php for($i=0;$i<6;$i++): ?>
            <span class="cfp-lottery-ball"><?=rand(10,99)?></span>
            <?php endfor; ?>
        </div>
        <input class="cfp-input" type="email" id="cfp-lot-email" placeholder="Your email to check tickets">
        <button class="cfp-btn-full" onclick="cfpCheckTickets()">Check My Tickets</button>
        <div id="cfp-lot-result" style="margin-top:12px"></div>
    </div>
    <script>
    async function cfpCheckTickets(){
        const fd=new FormData();fd.append('action','cfp_get_user');fd.append('nonce',cfpNonce);fd.append('email',document.getElementById('cfp-lot-email').value);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});
        const d=await r.json();
        const el=document.getElementById('cfp-lot-result');
        if(d.success) el.innerHTML=`<div class="cfp-ticket-count"><div style="font-size:.72rem;text-transform:uppercase;letter-spacing:2px;color:#555">Your Tickets</div><div class="num">${d.data.lottery_tickets} 🎟</div></div>`;
        else el.innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_savings]
   ============================================================ */
add_shortcode('cfp_savings', function() {
    if(!cfp_get_setting('savings_enabled','1')) return '';
    $apy=cfp_get_setting('savings_apy','4.08'); $currency=cfp_get_setting('faucet_currency','BTC');
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>📈 <?=$currency?> Savings</h2>
        <p class="sub">Earn interest on your balance — paid daily!</p>
        <div class="cfp-savings-box">
            <div class="apy-badge"><?=$apy?>% APY</div>
            <div style="font-size:.82rem;color:#666">Compounded daily · no lock-up period</div>
            <div id="cfp-savings-bal" style="font-family:'Oswald',sans-serif;font-size:1.6rem;color:#a855f7;margin-top:8px">— sat in savings</div>
        </div>
        <div id="cfp-sav-msg"></div>
        <input class="cfp-input" type="email" id="cfp-sav-email" placeholder="Account email" onblur="cfpLoadSavings()">
        <input class="cfp-input" type="number" id="cfp-sav-amount" placeholder="Amount (satoshis)">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <button class="cfp-btn-full" style="background:#a855f7" onclick="cfpSavAction('deposit')">⬇️ Deposit</button>
            <button class="cfp-btn-full" style="background:#6d28d9" onclick="cfpSavAction('withdraw')">⬆️ Withdraw</button>
        </div>
    </div>
    <script>
    async function cfpLoadSavings(){
        const email=document.getElementById('cfp-sav-email').value;if(!email)return;
        const fd=new FormData();fd.append('action','cfp_get_user');fd.append('nonce',cfpNonce);fd.append('email',email);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});const d=await r.json();
        if(d.success) document.getElementById('cfp-savings-bal').textContent=d.data.savings+' sat in savings';
    }
    async function cfpSavAction(action){
        const email=document.getElementById('cfp-sav-email').value;
        const amount=document.getElementById('cfp-sav-amount').value;
        if(!email||!amount){cfpSavMsg('Enter email and amount.','error');return;}
        const fd=new FormData();fd.append('action','cfp_savings');fd.append('nonce',cfpNonce);fd.append('email',email);fd.append('savings_action',action);fd.append('amount',amount);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});const d=await r.json();
        cfpSavMsg(d.data.msg,d.success?'success':'error');
        if(d.success) cfpLoadSavings();
    }
    function cfpSavMsg(m,t){document.getElementById('cfp-sav-msg').innerHTML=`<div class="cfp-msg ${t}">${m}</div>`;}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_golden]
   ============================================================ */
add_shortcode('cfp_golden', function() {
    if(!cfp_get_setting('golden_ticket_enabled','1')) return '';
    $label=cfp_get_setting('golden_prize_label','Win a Lamborghini!');
    $prize=cfp_get_setting('golden_prize_usd','200000');
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>🎫 Golden Tickets</h2>
        <p class="sub"><?=esc_html($label)?> — worth $<?=number_format($prize)?>!</p>
        <div style="text-align:center;padding:20px;background:linear-gradient(135deg,#1a1000,#2a1500);border-radius:12px;border:1px solid #3a2000;margin-bottom:16px">
            <div style="font-size:3.5rem;margin-bottom:8px">🏎️</div>
            <div style="font-family:'Oswald',sans-serif;font-size:1.2rem;color:var(--cfp-a)">$<?=number_format($prize)?> PRIZE</div>
            <div style="font-size:.78rem;color:#666;margin-top:4px">Random chance each claim!</div>
        </div>
        <input class="cfp-input" type="email" id="cfp-gld-email" placeholder="Your email to check tickets">
        <button class="cfp-btn-full" style="background:linear-gradient(135deg,var(--cfp-p),var(--cfp-a))" onclick="cfpCheckGolden()">Check My Golden Tickets</button>
        <div id="cfp-gld-result" style="margin-top:12px"></div>
    </div>
    <script>
    async function cfpCheckGolden(){
        const fd=new FormData();fd.append('action','cfp_get_user');fd.append('nonce',cfpNonce);fd.append('email',document.getElementById('cfp-gld-email').value);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});const d=await r.json();
        const el=document.getElementById('cfp-gld-result');
        if(d.success) el.innerHTML=`<div class="cfp-ticket-count" style="background:linear-gradient(135deg,#1a1000,#2a1500);border-color:var(--cfp-a)"><div style="font-size:.72rem;text-transform:uppercase;letter-spacing:2px;color:#664400">Your Golden Tickets</div><div class="num" style="color:var(--cfp-a)">${d.data.golden_tickets} 🎫</div></div>`;
        else el.innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_p2p]
   ============================================================ */
add_shortcode('cfp_p2p', function() {
    if(!cfp_get_setting('p2p_enabled','1')) return '';
    global $wpdb;
    $events=$wpdb->get_results("SELECT * FROM ".CFP_TABLE_P2P." WHERE status='open' ORDER BY created_at DESC LIMIT 5");
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>🤝 P2P Event Predictions</h2>
        <p class="sub">Bet on real-world events. Win from the prize pool!</p>
        <div id="cfp-p2p-msg"></div>
        <input class="cfp-input" type="email" id="cfp-p2p-email" placeholder="Account email">
        <input class="cfp-input" type="number" id="cfp-p2p-amount" placeholder="Bet amount (satoshis)">
        <?php if(empty($events)): ?>
            <div style="text-align:center;color:#555;padding:20px;font-size:.88rem">No events open right now. Check back soon!</div>
        <?php else: ?>
            <?php foreach($events as $e):
                $pot_a=$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_P2P_BETS." WHERE event_id=%d AND choice='a'",$e->id));
                $pot_b=$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_P2P_BETS." WHERE event_id=%d AND choice='b'",$e->id));
            ?>
            <div class="cfp-p2p-event">
                <h4><?=esc_html($e->title)?></h4>
                <?php if($e->description): ?><p style="font-size:.8rem;color:#666;margin:0 0 8px"><?=esc_html($e->description)?></p><?php endif; ?>
                <div style="display:flex;justify-content:space-between;font-size:.75rem;color:#555;margin-bottom:8px">
                    <span>Option A: <?=number_format($pot_a)?> sat</span>
                    <span>Option B: <?=number_format($pot_b)?> sat</span>
                </div>
                <div class="cfp-p2p-btns">
                    <button class="cfp-p2p-a" onclick="cfpP2PBet(<?=$e->id?>,'a')">✅ <?=esc_html($e->option_a)?></button>
                    <button class="cfp-p2p-b" onclick="cfpP2PBet(<?=$e->id?>,'b')">❌ <?=esc_html($e->option_b)?></button>
                </div>
            </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <script>
    async function cfpP2PBet(eventId,choice){
        const email=document.getElementById('cfp-p2p-email').value;
        const amount=document.getElementById('cfp-p2p-amount').value;
        if(!email||!amount){cfpP2PMsg('Enter email and bet amount.','error');return;}
        const fd=new FormData();fd.append('action','cfp_p2p_bet');fd.append('nonce',cfpNonce);fd.append('email',email);fd.append('event_id',eventId);fd.append('choice',choice);fd.append('amount',amount);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});const d=await r.json();
        cfpP2PMsg(d.data.msg,d.success?'success':'error');
    }
    function cfpP2PMsg(m,t){document.getElementById('cfp-p2p-msg').innerHTML=`<div class="cfp-msg ${t}">${m}</div>`;}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_referral]
   ============================================================ */
add_shortcode('cfp_referral', function() {
    $pct=cfp_get_setting('referral_percent',50); $currency=cfp_get_setting('faucet_currency','BTC');
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>🔗 Referral Program</h2>
        <p class="sub">Earn <strong style="color:var(--cfp-p)"><?=$pct?>%</strong> of every claim your referrals make — for life!</p>
        <div id="cfp-ref-msg"></div>
        <input class="cfp-input" type="email" id="cfp-ref-email" placeholder="Your account email">
        <button class="cfp-btn-full" onclick="cfpGetRefLink()">Get My Referral Link</button>
        <div id="cfp-ref-result"></div>
    </div>
    <script>
    async function cfpGetRefLink(){
        const email=document.getElementById('cfp-ref-email').value;
        if(!email){cfpRefMsg('Enter your email.','error');return;}
        const fd=new FormData();fd.append('action','cfp_get_user');fd.append('nonce',cfpNonce);fd.append('email',email);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});const d=await r.json();
        if(d.success){
            const link=window.location.origin+window.location.pathname+'?ref='+d.data.ref_code;
            document.getElementById('cfp-ref-result').innerHTML=
                `<div class="cfp-ref-box"><div style="font-size:.75rem;color:#555;margin-bottom:6px">Your unique referral link:</div>
                <span class="cfp-ref-link">${link}</span>
                <button class="cfp-btn-full" style="margin-top:10px;font-size:.82rem" onclick="navigator.clipboard.writeText('${link}').then(()=>this.textContent='✅ Copied!')">📋 Copy Link</button>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:12px">
                    <div style="background:#0d0d0d;border-radius:8px;padding:12px;text-align:center"><div style="font-size:.68rem;color:#444;text-transform:uppercase;letter-spacing:1px">Total Earned</div><div style="color:var(--cfp-p);font-family:'Oswald',sans-serif;font-size:1.3rem">${d.data.total_earned} sat</div></div>
                    <div style="background:#0d0d0d;border-radius:8px;padding:12px;text-align:center"><div style="font-size:.68rem;color:#444;text-transform:uppercase;letter-spacing:1px">Balance</div><div style="color:var(--cfp-gr);font-family:'Oswald',sans-serif;font-size:1.3rem">${d.data.balance} sat</div></div>
                </div></div>`;
        } else cfpRefMsg(d.data.msg,'error');
    }
    function cfpRefMsg(m,t){document.getElementById('cfp-ref-msg').innerHTML=`<div class="cfp-msg ${t}">${m}</div>`;}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_withdraw]
   ============================================================ */
add_shortcode('cfp_withdraw', function() {
    $fp_enabled = cfp_get_setting('blockchain_enabled','0');
    $fp_currency= cfp_get_setting('blockchain_currency', cfp_get_setting('faucet_currency','BTC'));
    $min        = $fp_enabled ? cfp_get_setting('blockchain_min_withdraw',1000) : cfp_get_setting('min_withdraw_sat',30000);
    $fee        = $fp_enabled ? cfp_get_setting('blockchain_fee_sat',0)         : cfp_get_setting('withdraw_fee_sat',1000);
    $nonce      = wp_create_nonce('cfp_nonce');
    $ajax       = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-withdraw-widget">
        <h2>💸 Withdraw</h2>
        <?php if($fp_enabled): ?>
        <div style="background:#0a1a0a;border:1px solid #22c55e33;border-radius:10px;padding:12px 16px;margin-bottom:16px;display:flex;align-items:center;gap:10px">
            <span style="font-size:1.3rem">⛓️</span>
            <div>
                <div style="font-size:.82rem;font-weight:700;color:#22c55e">Coinbase Withdrawals</div>
                <div style="font-size:.76rem;color:#3a6a3a">Payouts sent on-chain to your wallet · Min: <?=number_format($min)?> sat<?=$fee>0?' · Fee: '.number_format($fee).' sat':' · No fee'?></div>
            </div>
        </div>
        <?php else: ?>
        <p class="sub">Min: <?=number_format($min)?> sat<?=$fee>0?' · Fee: '.number_format($fee).' sat':''?> · Processed within 24 hours</p>
        <?php endif; ?>

        <div id="cfp-wd-msg"></div>

        <input class="cfp-input" type="email" id="cfp-wd-email" placeholder="Account email" onblur="cfpWdLoadUser()">
        <div id="cfp-wd-bal-box"></div>

        <?php if($fp_enabled): ?>
        <div style="margin-bottom:12px">
            <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
                <input class="cfp-input" type="text" id="cfp-wd-addr" placeholder="Your <?=$fp_currency?> wallet address" style="margin-bottom:0;flex:1">
                <button onclick="cfpCheckFPAddr()" style="background:#1a2a1a;border:1px solid #22c55e44;color:#22c55e;padding:10px 14px;border-radius:8px;font-size:.8rem;cursor:pointer;white-space:nowrap;font-weight:600">✓ Verify</button>
            </div>
            <div id="cfp-addr-check" style="font-size:.78rem;min-height:18px"></div>
        </div>
        <?php else: ?>
        <input class="cfp-input" type="text" id="cfp-wd-addr" placeholder="<?=$fp_currency?> wallet address">
        <?php endif; ?>

        <input class="cfp-input" type="number" id="cfp-wd-amount" placeholder="Amount (satoshis)" min="<?=$min?>">

        <!-- Quick amount buttons -->
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">
            <?php foreach([1000,5000,10000,50000,100000] as $qa): ?>
            <button onclick="document.getElementById('cfp-wd-amount').value=<?=$qa?>"
                style="background:#0d0d0d;border:1px solid #1e1e1e;color:#555;padding:4px 10px;border-radius:6px;font-size:.74rem;cursor:pointer;transition:all .15s"
                onmouseover="this.style.borderColor='var(--cfp-p)';this.style.color='var(--cfp-p)'"
                onmouseout="this.style.borderColor='#1e1e1e';this.style.color='#555'">
                <?=number_format($qa)?>
            </button>
            <?php endforeach; ?>
        </div>

        <div id="cfp-wd-preview" style="display:none;padding:10px 14px;border-radius:8px;margin-bottom:12px;font-size:.84rem;text-align:center;background:#0a1a0a;border:1px solid #22c55e22;color:#22c55e"></div>

        <button class="cfp-btn-full" id="cfp-wd-btn" onclick="cfpDoWithdraw()">
            <?=$fp_enabled?'⛓️ Withdraw to Wallet':'Request Withdrawal'?>
        </button>

        <?php if($fp_enabled): ?>
        <div style="text-align:center;margin-top:12px;font-size:.74rem;color:#333">
            ⛓️ On-chain withdrawal · Sent directly to your wallet address
        </div>
        <?php endif; ?>
    </div>
    <script>
    const cfpFpEnabled=<?=$fp_enabled?'true':'false'?>;
    const cfpFpMin=<?=$min?>;
    const cfpFpFee=<?=$fee?>;
    async function cfpWdLoadUser(){
        const email=document.getElementById('cfp-wd-email').value; if(!email) return;
        const fd=new FormData(); fd.append('action','cfp_get_user');fd.append('nonce','<?=$nonce?>');fd.append('email',email);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        if(d.success){
            document.getElementById('cfp-wd-bal-box').innerHTML=
                `<div class="cfp-balance-box" style="margin-bottom:14px">
                  <div class="lbl">Available Balance</div>
                  <div class="amount">${d.data.balance}</div>
                  <div style="font-size:.75rem;color:#555">satoshis</div>
                </div>`;
        }
    }
    async function cfpCheckFPAddr(){
        const addr=document.getElementById('cfp-wd-addr').value;
        const el=document.getElementById('cfp-addr-check');
        if(!addr){el.textContent='';return;}
        el.innerHTML='<span style="color:#555">Checking…</span>';
        const fd=new FormData(); fd.append('action','cfp_check_fp_address');fd.append('nonce','<?=$nonce?>');fd.append('address',addr);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        el.innerHTML=`<span style="color:${d.success?'#22c55e':'#ef4444'}">${d.data.msg}</span>`;
    }
    document.addEventListener('DOMContentLoaded',function(){
        const amtEl=document.getElementById('cfp-wd-amount');
        if(amtEl) amtEl.addEventListener('input',function(){
            const amt=parseInt(this.value)||0;
            const prev=document.getElementById('cfp-wd-preview');
            if(amt>=cfpFpMin){
                const net=amt-cfpFpFee;
                prev.style.display='';
                prev.textContent=`You receive: ${net.toLocaleString()} sat`+(cfpFpFee>0?` (after ${cfpFpFee.toLocaleString()} sat fee)`:'');
            } else {
                prev.style.display='none';
            }
        });
    });
    async function cfpDoWithdraw(){
        const email=document.getElementById('cfp-wd-email').value;
        const addr=document.getElementById('cfp-wd-addr').value;
        const amount=document.getElementById('cfp-wd-amount').value;
        const msgEl=document.getElementById('cfp-wd-msg');
        if(!email||!addr||!amount){msgEl.innerHTML='<div class="cfp-msg error">Fill in all fields.</div>';return;}
        const btn=document.getElementById('cfp-wd-btn');
        btn.disabled=true; btn.textContent='Processing…';
        const fd=new FormData();
        fd.append('action','cfp_withdraw');fd.append('nonce','<?=$nonce?>');
        fd.append('email',email);fd.append('btc_address',addr);fd.append('amount',amount);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        msgEl.innerHTML=`<div class="cfp-msg ${d.success?'success':'error'}">${d.data.msg}</div>`;
        btn.disabled=false;
        btn.textContent=<?=$fp_enabled?'"⛓️ Withdraw to Wallet"':'"Request Withdrawal"'?>;
        if(d.success){
            document.getElementById('cfp-wd-amount').value='';
            cfpWdLoadUser();
        }
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_leaderboard]
   ============================================================ */
add_shortcode('cfp_leaderboard', function() {
    global $wpdb;
    $users=$wpdb->get_results("SELECT username,total_earned,total_claims FROM ".CFP_TABLE_USERS." WHERE is_banned=0 ORDER BY total_earned DESC LIMIT 10");
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>🏆 Top Earners</h2>
        <table style="width:100%;border-collapse:collapse">
            <thead><tr>
                <th style="padding:8px;text-align:left;color:#444;font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid #1c1c1c">#</th>
                <th style="padding:8px;text-align:left;color:#444;font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid #1c1c1c">User</th>
                <th style="padding:8px;text-align:right;color:#444;font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid #1c1c1c">Earned</th>
                <th style="padding:8px;text-align:right;color:#444;font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;border-bottom:1px solid #1c1c1c">Claims</th>
            </tr></thead>
            <tbody>
            <?php foreach($users as $i=>$u):
                $medals=['🥇','🥈','🥉'];
                $medal=$medals[$i]??($i+1);
                $colors=['#ffd700','#c0c0c0','#cd7f32'];
                $color=$colors[$i]??'#555'; ?>
            <tr style="border-bottom:1px solid #141414">
                <td style="padding:10px 8px;font-size:1.1rem"><?=$medal?></td>
                <td style="padding:10px 8px;font-weight:600;color:<?=$color?>"><?=esc_html($u->username)?></td>
                <td style="padding:10px 8px;text-align:right;color:var(--cfp-p);font-weight:700;font-family:'Oswald',sans-serif"><?=number_format($u->total_earned)?></td>
                <td style="padding:10px 8px;text-align:right;color:#555;font-size:.82rem"><?=$u->total_claims?></td>
            </tr>
            <?php endforeach; ?>
            <?php if(empty($users)): ?><tr><td colspan="4" style="text-align:center;color:#555;padding:24px;font-size:.88rem">Be the first to claim! 🚀</td></tr><?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_history]
   ============================================================ */
add_shortcode('cfp_history', function() {
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>📋 Transaction History</h2>
        <input class="cfp-input" type="email" id="cfp-hist-email" placeholder="Account email">
        <button class="cfp-btn-full" onclick="cfpGetHistory()">Load History</button>
        <div id="cfp-hist-result" style="margin-top:16px;max-height:400px;overflow-y:auto"></div>
    </div>
    <script>
    async function cfpGetHistory(){
        const fd=new FormData();fd.append('action','cfp_get_history');fd.append('nonce',cfpNonce);fd.append('email',document.getElementById('cfp-hist-email').value);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});const d=await r.json();
        if(d.success){
            let html='<table class="cfp-history-table"><thead><tr><th>Type</th><th>Description</th><th style="text-align:right">Amount</th><th>Date</th></tr></thead><tbody>';
            d.data.rows.forEach(row=>{
                const c=row.amount>0?'#22c55e':'#ef4444';
                html+=`<tr><td style="color:#888">${row.type}</td><td style="color:#555;font-size:.78rem">${row.desc}</td><td style="text-align:right;color:${c};font-weight:700">${row.amount>0?'+':''}${row.amount}</td><td style="color:#444">${row.date}</td></tr>`;
            });
            html+='</tbody></table>';
            document.getElementById('cfp-hist-result').innerHTML=d.data.rows.length?html:'<p style="text-align:center;color:#555;font-size:.88rem">No transactions yet.</p>';
        } else document.getElementById('cfp-hist-result').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_balance]
   ============================================================ */
add_shortcode('cfp_balance', function() {
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    $currency=cfp_get_setting('faucet_currency','BTC');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>💰 My Balance</h2>
        <input class="cfp-input" type="email" id="cfp-checkbal-email" placeholder="Account email">
        <button class="cfp-btn-full" onclick="cfpCheckBal()">Check Balance</button>
        <div id="cfp-bal-result" style="margin-top:14px"></div>
    </div>
    <script>
    async function cfpCheckBal(){
        const fd=new FormData();fd.append('action','cfp_get_user');fd.append('nonce',cfpNonce);fd.append('email',document.getElementById('cfp-checkbal-email').value);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});const d=await r.json();
        if(d.success) document.getElementById('cfp-bal-result').innerHTML=`<div class="cfp-balance-box"><div class="lbl">Balance</div><div class="amount">${d.data.balance}</div><div style="font-size:.78rem;color:#555">satoshis · <?=$currency?></div></div><div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px"><div style="background:#0d0d0d;border-radius:8px;padding:10px;text-align:center"><div style="font-size:.65rem;color:#444;text-transform:uppercase;letter-spacing:1px">Savings</div><div style="color:#a855f7;font-family:'Oswald',sans-serif;font-size:1.1rem">${d.data.savings}</div></div><div style="background:#0d0d0d;border-radius:8px;padding:10px;text-align:center"><div style="font-size:.65rem;color:#444;text-transform:uppercase;letter-spacing:1px">Total Earned</div><div style="color:var(--cfp-p);font-family:'Oswald',sans-serif;font-size:1.1rem">${d.data.total_earned}</div></div></div>`;
        else document.getElementById('cfp-bal-result').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_deposit]  — Coinbase Deposit Widget
   ============================================================ */
add_shortcode('cfp_deposit', function() {
    $fp_enabled  = cfp_get_setting('blockchain_enabled','0');
    $fp_currency = cfp_get_setting('blockchain_currency', cfp_get_setting('faucet_currency','BTC'));
    $nonce       = wp_create_nonce('cfp_nonce');
    $ajax        = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-deposit-widget">
        <h2>📥 Deposit <?=esc_html($fp_currency)?></h2>

        <?php if ( $fp_enabled ): ?>
        <div style="background:#0a1a0a;border:1px solid #22c55e33;border-radius:10px;padding:13px 16px;margin-bottom:16px;display:flex;align-items:center;gap:10px">
            <span style="font-size:1.4rem">⛓️</span>
            <div>
                <div style="font-size:.84rem;font-weight:700;color:#22c55e">Coinbase Deposits</div>
                <div style="font-size:.76rem;color:#3a6a3a">Send <?=esc_html($fp_currency)?> directly from any wallet — credited to your balance after confirmation</div>
            </div>
        </div>

        <div id="cfp-dep-msg"></div>

        <p style="font-size:.84rem;color:var(--cfp-mt);margin-bottom:18px">
            Enter your account email to get your deposit address. Send any amount of <?=esc_html($fp_currency)?> from any wallet and it will appear in your balance once confirmed.
        </p>

        <input class="cfp-input" type="email" id="cfp-dep-email" placeholder="Your account email">
        <button class="cfp-btn-full" onclick="cfpGetDepositAddr()">Get My Deposit Address</button>

        <div id="cfp-dep-result" style="margin-top:16px"></div>

        <div style="margin-top:18px;padding:14px;background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px">
            <div style="font-size:.76rem;font-weight:700;color:#aaa;margin-bottom:10px;text-transform:uppercase;letter-spacing:1px">How to deposit</div>
            <?php
            $steps_dep = [
                '1' => 'Enter your email and click "Get My Deposit Address"',
                '2' => 'Copy your personal deposit address',
                '3' => 'Open any crypto wallet → Send → paste the address',
                '4' => 'Your balance updates automatically once confirmed',
            ];
            foreach($steps_dep as $n => $step): ?>
            <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:8px">
                <span style="background:#1a1a1a;border:1px solid #2a2a2a;color:var(--cfp-p);font-weight:700;width:22px;height:22px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:.72rem;flex-shrink:0"><?=$n?></span>
                <span style="font-size:.8rem;color:#555;line-height:1.5"><?=esc_html($step)?></span>
            </div>
            <?php endforeach; ?>
        </div>

        <?php else: ?>
        <div style="background:#1a1000;border:1px solid #f7931a33;border-radius:10px;padding:16px;text-align:center">
            <div style="font-size:2rem;margin-bottom:8px">🔧</div>
            <div style="font-size:.88rem;color:#f7931a;font-weight:600;margin-bottom:6px">Coinbase Deposits Not Configured</div>
            <div style="font-size:.8rem;color:#664400">Contact the site admin to enable Coinbase deposits.</div>
        </div>
        <?php endif; ?>
    </div>

    <?php if($fp_enabled): ?>
    <script>
    async function cfpGetDepositAddr(){
        const email = document.getElementById('cfp-dep-email').value;
        const msgEl = document.getElementById('cfp-dep-msg');
        const resEl = document.getElementById('cfp-dep-result');
        if(!email){ msgEl.innerHTML='<div class="cfp-msg error">Enter your account email.</div>'; return; }
        const fd = new FormData();
        fd.append('action','cfp_get_user'); fd.append('nonce','<?=$nonce?>'); fd.append('email',email);
        const r = await fetch('<?=$ajax?>',{method:'POST',body:fd});
        const d = await r.json();
        if(!d.success){ msgEl.innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`; return; }
        msgEl.innerHTML='';
        const addr = d.data.fp_address || '';
        if(!addr){
            resEl.innerHTML=`<div style="background:#1a1000;border:1px solid #f7931a33;border-radius:10px;padding:16px;text-align:center">
                <div style="font-size:.84rem;color:#f7931a;font-weight:600;margin-bottom:6px">⚠️ No deposit address linked</div>
                <div style="font-size:.78rem;color:#664400;margin-bottom:12px">You haven't linked a wallet address to your account yet.</div>
                <a href="#cfp-withdraw-widget" style="background:var(--cfp-p);color:#000;padding:8px 18px;border-radius:8px;text-decoration:none;font-weight:700;font-size:.82rem">Link Address in Withdraw Widget →</a>
            </div>`;
            return;
        }
        resEl.innerHTML=`
        <div style="background:#0a1a0a;border:1px solid #22c55e44;border-radius:12px;padding:18px">
            <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:2px;color:#3a6a3a;margin-bottom:8px">Your <?='<?=esc_js($fp_currency)?>'?> Deposit Address</div>
            <div style="background:#060606;border:1px solid #1a1a1a;border-radius:8px;padding:12px;font-family:monospace;font-size:.82rem;color:#22c55e;word-break:break-all;margin-bottom:10px">${addr}</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                <button onclick="navigator.clipboard.writeText('${addr}').then(()=>{this.textContent='✅ Copied!';setTimeout(()=>this.textContent='📋 Copy Address',2000)})"
                    style="background:#1a2a1a;border:1px solid #22c55e44;color:#22c55e;padding:9px;border-radius:8px;cursor:pointer;font-weight:700;font-size:.82rem">📋 Copy Address</button>
                <div style="background:#111;border:1px solid #1e1e1e;border-radius:8px;padding:9px;text-align:center">
                    <div style="font-size:.65rem;color:#444;text-transform:uppercase;letter-spacing:1px">Balance</div>
                    <div style="color:var(--cfp-p);font-weight:800;font-size:.95rem">${d.data.balance} sat</div>
                </div>
            </div>
            <div style="font-size:.74rem;color:#3a5a3a;margin-top:10px;text-align:center">
                ⛓️ Deposits credited after confirmation
            </div>
        </div>`;
    }
    </script>
    <?php endif;
    return ob_get_clean();
});

/* ============================================================
   AJAX: LINK FAUCETPAY ADDRESS to user account
   ============================================================ */

/* ============================================================
   SHORTCODE: [cfp_np_deposit]  — Coinbase Commerce Deposit Widget
   ============================================================ */
add_shortcode('cfp_np_deposit', function() {
    $np_enabled  = cfp_np_enabled();
    $np_currency = strtoupper( cfp_np_currency() );
    $nonce       = wp_create_nonce('cfp_nonce');
    $ajax        = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-np-deposit-widget">
        <h2>📥 Deposit via Coinbase Commerce</h2>

        <?php if ( $np_enabled ): ?>
        <div style="background:#0a0e2a;border:1px solid #0052ff33;border-radius:10px;padding:13px 16px;margin-bottom:16px;display:flex;align-items:center;gap:10px">
            <span style="font-size:1.4rem">🔵</span>
            <div>
                <div style="font-size:.84rem;font-weight:700;color:#4d8eff">Coinbase Commerce On-Chain Deposit</div>
                <div style="font-size:.76rem;color:#1a3a7a">Send crypto directly to a generated address — credited to your balance on confirmation</div>
            </div>
        </div>

        <div id="cfp-np-dep-msg"></div>

        <div style="margin-bottom:14px">
            <label style="font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:#666;display:block;margin-bottom:5px">Account Email</label>
            <input class="cfp-input" type="email" id="cfp-np-dep-email" placeholder="Your account email" style="width:100%;box-sizing:border-box">
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
            <div>
                <label style="font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:#666;display:block;margin-bottom:5px">Currency</label>
                <input class="cfp-input" type="text" id="cfp-np-dep-currency" value="<?=esc_attr(strtolower($np_currency))?>" placeholder="btc" style="width:100%;box-sizing:border-box">
            </div>
            <div>
                <label style="font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:#666;display:block;margin-bottom:5px">Amount (USD)</label>
                <input class="cfp-input" type="number" id="cfp-np-dep-amount" placeholder="e.g. 5" step="0.01" min="0" style="width:100%;box-sizing:border-box">
            </div>
        </div>

        <button class="cfp-btn-full" onclick="cfpNpCreateDeposit()" style="background:#0052ff">Generate Payment Address</button>

        <div id="cfp-np-dep-result" style="margin-top:16px"></div>

        <div style="margin-top:18px;padding:14px;background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px">
            <div style="font-size:.76rem;font-weight:700;color:#aaa;margin-bottom:10px;text-transform:uppercase;letter-spacing:1px">How to deposit</div>
            <?php
            $steps = [
                '1' => 'Enter your email, select currency, and optionally set an amount',
                '2' => 'Click "Generate Payment Address" to get a unique deposit address',
                '3' => 'Send the exact crypto amount shown to that address from any wallet',
                '4' => 'Your balance is credited automatically once confirmed',
            ];
            foreach($steps as $n => $step): ?>
            <div style="display:flex;align-items:flex-start;gap:10px;margin-bottom:8px">
                <span style="background:#0a1433;border:1px solid #0052ff;color:#4d8eff;font-weight:700;width:22px;height:22px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:.72rem;flex-shrink:0"><?=$n?></span>
                <span style="font-size:.8rem;color:#555;line-height:1.5"><?=esc_html($step)?></span>
            </div>
            <?php endforeach; ?>
        </div>

        <?php else: ?>
        <div style="background:#0a0e2a;border:1px solid #0052ff33;border-radius:10px;padding:16px;text-align:center">
            <div style="font-size:2rem;margin-bottom:8px">🔧</div>
            <div style="font-size:.88rem;color:#4d8eff;font-weight:600;margin-bottom:6px">Coinbase Not Configured</div>
            <div style="font-size:.8rem;color:#1a3a7a">Contact the site admin to enable Coinbase Commerce deposits.</div>
        </div>
        <?php endif; ?>
    </div>

    <?php if($np_enabled): ?>
    <script>
    let cfpNpPollTimer = null;

    async function cfpNpCreateDeposit() {
        const email    = document.getElementById('cfp-np-dep-email').value.trim();
        const currency = document.getElementById('cfp-np-dep-currency').value.trim() || 'btc';
        const amount   = document.getElementById('cfp-np-dep-amount').value.trim();
        const msgEl    = document.getElementById('cfp-np-dep-msg');
        const resEl    = document.getElementById('cfp-np-dep-result');

        if (!email) { msgEl.innerHTML='<div class="cfp-msg error">Enter your account email.</div>'; return; }

        msgEl.innerHTML = '<div class="cfp-msg info">⏳ Creating payment invoice…</div>';
        resEl.innerHTML = '';

        const fd = new FormData();
        fd.append('action','cfp_np_create_deposit');
        fd.append('nonce','<?=$nonce?>');
        fd.append('email', email);
        fd.append('currency', currency);
        if (amount) fd.append('amount', amount);

        const r = await fetch('<?=$ajax?>', {method:'POST', body:fd});
        const d = await r.json();

        if (!d.success) {
            msgEl.innerHTML = `<div class="cfp-msg error">${d.data.msg}</div>`;
            return;
        }

        msgEl.innerHTML = '';
        const p = d.data;

        resEl.innerHTML = `
        <div style="background:#0a0e2a;border:1px solid #0052ff44;border-radius:12px;padding:18px">
            <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:2px;color:#0040cc;margin-bottom:10px">Send exactly this amount</div>

            <div style="text-align:center;margin-bottom:14px">
                <div style="font-size:1.5rem;font-weight:900;color:#4d8eff">${p.pay_amount} <span style="font-size:1rem">${p.pay_currency.toUpperCase()}</span></div>
            </div>

            ${p.qr ? `<div style="text-align:center;margin-bottom:14px"><img src="${p.qr}" style="border-radius:10px;border:3px solid #2a1a5a" width="160" height="160" alt="QR Code"></div>` : ''}

            <div style="background:#060606;border:1px solid #0040cc;border-radius:8px;padding:12px;font-family:monospace;font-size:.8rem;color:#4d8eff;word-break:break-all;margin-bottom:10px">${p.pay_address}</div>

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
                <button onclick="navigator.clipboard.writeText('${p.pay_address}').then(()=>{this.textContent='✅ Copied!';setTimeout(()=>this.textContent='📋 Copy Address',2000)})"
                    style="background:#0a1433;border:1px solid #0052ff44;color:#4d8eff;padding:9px;border-radius:8px;cursor:pointer;font-weight:700;font-size:.82rem">📋 Copy Address</button>
                <button onclick="cfpNpPollStatus('${p.payment_id}', '<?=$nonce?>', '<?=$ajax?>')"
                    style="background:#0a1a0a;border:1px solid #22c55e44;color:#22c55e;padding:9px;border-radius:8px;cursor:pointer;font-weight:700;font-size:.82rem">🔄 Check Status</button>
            </div>

            <div id="cfp-np-poll-status" style="font-size:.78rem;color:#555;text-align:center">⏳ Waiting for payment…</div>

            ${p.expiry ? `<div style="font-size:.72rem;color:#3a2a5a;text-align:center;margin-top:6px">Expires: ${p.expiry}</div>` : ''}
        </div>`;

        // Auto-poll every 15 seconds
        if (cfpNpPollTimer) clearInterval(cfpNpPollTimer);
        cfpNpPollTimer = setInterval(() => cfpNpPollStatus('${p.payment_id}', '<?=$nonce?>', '<?=$ajax?>'), 15000);
    }

    async function cfpNpPollStatus(paymentId, nonce, ajax) {
        const statusEl = document.getElementById('cfp-np-poll-status');
        if (!statusEl) return;

        const fd = new FormData();
        fd.append('action','cfp_np_check_deposit');
        fd.append('nonce', nonce);
        fd.append('payment_id', paymentId);

        const r = await fetch(ajax, {method:'POST', body:fd});
        const d = await r.json();
        if (!d.success) return;

        const s = d.data;
        statusEl.innerHTML = s.msg || s.status;

        if (s.status === 'credited' || s.status === 'finished' || s.status === 'confirmed') {
            if (cfpNpPollTimer) { clearInterval(cfpNpPollTimer); cfpNpPollTimer = null; }
            statusEl.style.color = '#22c55e';
            statusEl.style.fontWeight = '700';
        } else if (s.status === 'expired' || s.status === 'failed') {
            if (cfpNpPollTimer) { clearInterval(cfpNpPollTimer); cfpNpPollTimer = null; }
            statusEl.style.color = '#ef4444';
        }
    }
    </script>
    <?php endif;
    return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_np_withdraw]  — Coinbase Commerce Withdrawal Widget
   ============================================================ */
add_shortcode('cfp_np_withdraw', function() {
    $np_enabled  = cfp_np_enabled();
    $np_currency = strtolower( cfp_np_currency() );
    $min_sat     = intval( cfp_get_setting('np_min_withdraw_sat', 10000) );
    $fee_sat     = intval( cfp_get_setting('np_fee_sat', 0) );
    $nonce       = wp_create_nonce('cfp_nonce');
    $ajax        = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-np-withdraw-widget">
        <h2>📤 Withdraw via Coinbase Commerce</h2>

        <?php if ( $np_enabled ): ?>
        <div style="background:#0a0e2a;border:1px solid #0052ff33;border-radius:10px;padding:13px 16px;margin-bottom:16px;display:flex;align-items:center;gap:10px">
            <span style="font-size:1.4rem">🔵</span>
            <div>
                <div style="font-size:.84rem;font-weight:700;color:#4d8eff">On-Chain Withdrawal</div>
                <div style="font-size:.76rem;color:#1a3a7a">Send to any wallet address — powered by Coinbase Commerce</div>
            </div>
        </div>

        <div style="background:#0d0d0d;border:1px solid #1e1e1e;border-radius:8px;padding:12px;margin-bottom:14px;display:flex;justify-content:space-between;align-items:center">
            <span style="font-size:.78rem;color:#555">Min: <strong style="color:#f7931a"><?=number_format($min_sat)?> sat</strong></span>
            <?php if($fee_sat > 0): ?>
            <span style="font-size:.78rem;color:#555">Fee: <strong style="color:#ef4444"><?=number_format($fee_sat)?> sat</strong></span>
            <?php endif; ?>
            <span style="font-size:.78rem;color:#555">Powered by <strong style="color:#4d8eff">Coinbase Commerce</strong></span>
        </div>

        <div id="cfp-np-wd-msg"></div>

        <div style="margin-bottom:12px">
            <label style="font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:#666;display:block;margin-bottom:5px">Account Email</label>
            <input class="cfp-input" type="email" id="cfp-np-wd-email" placeholder="Your account email" style="width:100%;box-sizing:border-box">
        </div>

        <div style="margin-bottom:12px">
            <label style="font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:#666;display:block;margin-bottom:5px">Wallet Address</label>
            <input class="cfp-input" type="text" id="cfp-np-wd-address" placeholder="Your on-chain <?=esc_attr(strtoupper($np_currency))?> wallet address" style="width:100%;box-sizing:border-box">
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
            <div>
                <label style="font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:#666;display:block;margin-bottom:5px">Currency</label>
                <input class="cfp-input" type="text" id="cfp-np-wd-currency" value="<?=esc_attr($np_currency)?>" placeholder="btc" style="width:100%;box-sizing:border-box">
            </div>
            <div>
                <label style="font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:#666;display:block;margin-bottom:5px">Amount (sat)</label>
                <input class="cfp-input" type="number" id="cfp-np-wd-amount" placeholder="<?=number_format($min_sat)?>" min="<?=$min_sat?>" style="width:100%;box-sizing:border-box">
            </div>
        </div>

        <button class="cfp-btn-full" onclick="cfpNpWithdraw()" style="background:#0052ff">🚀 Send Withdrawal</button>

        <div style="margin-top:14px;padding:11px 14px;background:#0d0d0d;border:1px solid #1a1a1a;border-radius:8px;font-size:.76rem;color:#555;line-height:1.6">
            ⚠️ Withdrawals are sent on-chain via Coinbase Commerce. Processing time depends on network congestion. Ensure your wallet address is correct — transactions cannot be reversed.
        </div>

        <?php else: ?>
        <div style="background:#0a0e2a;border:1px solid #0052ff33;border-radius:10px;padding:16px;text-align:center">
            <div style="font-size:2rem;margin-bottom:8px">🔧</div>
            <div style="font-size:.88rem;color:#4d8eff;font-weight:600;margin-bottom:6px">Coinbase Not Configured</div>
            <div style="font-size:.8rem;color:#1a3a7a">Contact the site admin to enable Coinbase Commerce withdrawals.</div>
        </div>
        <?php endif; ?>
    </div>

    <?php if($np_enabled): ?>
    <script>
    async function cfpNpWithdraw() {
        const email    = document.getElementById('cfp-np-wd-email').value.trim();
        const address  = document.getElementById('cfp-np-wd-address').value.trim();
        const currency = document.getElementById('cfp-np-wd-currency').value.trim() || '<?=esc_js($np_currency)?>';
        const amount   = parseInt(document.getElementById('cfp-np-wd-amount').value, 10);
        const msgEl    = document.getElementById('cfp-np-wd-msg');

        if (!email)   { msgEl.innerHTML='<div class="cfp-msg error">Enter your account email.</div>'; return; }
        if (!address) { msgEl.innerHTML='<div class="cfp-msg error">Enter your wallet address.</div>'; return; }
        if (!amount || amount < <?=$min_sat?>) {
            msgEl.innerHTML='<div class="cfp-msg error">Minimum withdrawal is <?=number_format($min_sat)?> sat.</div>'; return;
        }

        if (!confirm(`Send ${amount.toLocaleString()} sat (${currency.toUpperCase()}) to:\n${address}\n\nThis cannot be undone. Proceed?`)) return;

        msgEl.innerHTML = '<div class="cfp-msg info">⏳ Processing withdrawal…</div>';

        const fd = new FormData();
        fd.append('action','cfp_np_withdraw');
        fd.append('nonce','<?=$nonce?>');
        fd.append('email', email);
        fd.append('np_address', address);
        fd.append('currency', currency);
        fd.append('amount', amount);

        const r = await fetch('<?=$ajax?>', {method:'POST', body:fd});
        const d = await r.json();

        if (d.success) {
            msgEl.innerHTML = `<div class="cfp-msg success">${d.data.msg}</div>`;
            document.getElementById('cfp-np-wd-amount').value = '';
            document.getElementById('cfp-np-wd-address').value = '';
        } else {
            msgEl.innerHTML = `<div class="cfp-msg error">${d.data.msg}</div>`;
        }
    }
    </script>
    <?php endif;
    return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_blackjack]
   ============================================================ */
add_shortcode('cfp_blackjack', function() {
    if ( cfp_get_setting('blackjack_enabled','1') !== '1' ) return '<p style="color:#666;text-align:center">Blackjack coming soon.</p>';
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-blackjack-widget">
        <h2>🃏 Blackjack</h2>
        <p class="sub">Beat the dealer — get closer to 21 without busting!</p>
        <div id="cfp-bj-msg"></div>
        <input class="cfp-input" type="email" id="cfp-bj-email" placeholder="Account email">
        <input class="cfp-input" type="number" id="cfp-bj-bet" placeholder="Bet amount (satoshis)" min="1">
        <div id="cfp-bj-table" style="display:none">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:16px">
                <div style="background:#0d0d0d;border:1px solid #1e1e1e;border-radius:10px;padding:14px;text-align:center">
                    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:1px;color:#555;margin-bottom:6px">Dealer</div>
                    <div id="cfp-bj-dealer-cards" style="font-size:1.4rem;min-height:36px;letter-spacing:4px"></div>
                    <div id="cfp-bj-dealer-sum" style="font-size:.8rem;color:#555;margin-top:4px"></div>
                </div>
                <div style="background:#0d0d0d;border:1px solid #22c55e33;border-radius:10px;padding:14px;text-align:center">
                    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:1px;color:#555;margin-bottom:6px">You</div>
                    <div id="cfp-bj-player-cards" style="font-size:1.4rem;min-height:36px;letter-spacing:4px"></div>
                    <div id="cfp-bj-player-sum" style="font-size:.8rem;color:#22c55e;margin-top:4px"></div>
                </div>
            </div>
            <div id="cfp-bj-actions" style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
                <button class="cfp-btn-full" style="background:#22c55e" onclick="cfpBjAction('hit')">👊 Hit</button>
                <button class="cfp-btn-full" style="background:#ef4444" onclick="cfpBjAction('stand')">✋ Stand</button>
                <button class="cfp-btn-full" id="cfp-bj-double-btn" style="background:#f7931a" onclick="cfpBjAction('double')">✌️ Double</button>
            </div>
        </div>
        <button class="cfp-btn-full" id="cfp-bj-deal-btn" onclick="cfpBjDeal()" style="margin-top:10px">🃏 Deal Cards</button>
        <div id="cfp-bj-balance" style="font-size:.8rem;color:#555;text-align:center;margin-top:10px"></div>
    </div>
    <script>
    let cfpBjGameId = null;
    const cfpBjSuits = { h:'♥', d:'♦', c:'♣', s:'♠' };
    function cfpBjCardLabel(code) {
        const val = code.slice(0, -2), suit = code.slice(-1);
        const face = { A:'A', J:'J', Q:'Q', K:'K' };
        return (face[val] || val) + (cfpBjSuits[suit] || suit);
    }
    function cfpBjCards(codes) {
        return codes.map(c => `<span style="display:inline-block;background:#fff;color:${c.slice(-1)==='h'||c.slice(-1)==='d'?'#ef4444':'#111'};border-radius:5px;padding:3px 7px;margin:2px;font-weight:700;font-size:1.1rem;font-family:monospace">${cfpBjCardLabel(c)}</span>`).join('');
    }
    async function cfpBjDeal() {
        const email = document.getElementById('cfp-bj-email').value;
        const bet   = document.getElementById('cfp-bj-bet').value;
        if (!email || !bet) { cfpBjMsg('Enter email and bet.', 'error'); return; }
        document.getElementById('cfp-bj-deal-btn').disabled = true;
        const fd = new FormData();
        fd.append('action','cfp_blackjack'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',email); fd.append('bet',bet); fd.append('game_action','bet');
        const r = await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d = await r.json();
        if (!d.success) { cfpBjMsg(d.data.msg,'error'); document.getElementById('cfp-bj-deal-btn').disabled=false; return; }
        cfpBjGameId = d.data.game_id;
        document.getElementById('cfp-bj-table').style.display = '';
        document.getElementById('cfp-bj-deal-btn').style.display = 'none';
        document.getElementById('cfp-bj-email').disabled = true;
        document.getElementById('cfp-bj-bet').disabled = true;
        document.getElementById('cfp-bj-dealer-cards').innerHTML = cfpBjCards([d.data.dealer_up,'back']);
        document.getElementById('cfp-bj-dealer-sum').textContent = '?';
        document.getElementById('cfp-bj-player-cards').innerHTML = cfpBjCards(d.data.player_cards || []);
        document.getElementById('cfp-bj-player-sum').textContent = d.data.player_sum;
        document.getElementById('cfp-bj-double-btn').style.display = d.data.can_double ? '' : 'none';
        cfpBjMsg(d.data.msg || 'Hit or Stand?', '');
        if (d.data.result) cfpBjFinish(d.data);
    }
    async function cfpBjAction(action) {
        if (!cfpBjGameId) return;
        document.querySelectorAll('#cfp-bj-actions button').forEach(b=>b.disabled=true);
        const fd = new FormData();
        fd.append('action','cfp_blackjack'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',document.getElementById('cfp-bj-email').value);
        fd.append('bet',document.getElementById('cfp-bj-bet').value);
        fd.append('game_action',action); fd.append('game_id',cfpBjGameId);
        const r = await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d = await r.json();
        if (!d.success) { cfpBjMsg(d.data.msg,'error'); document.querySelectorAll('#cfp-bj-actions button').forEach(b=>b.disabled=false); return; }
        if (d.data.player_cards) document.getElementById('cfp-bj-player-cards').innerHTML = cfpBjCards(d.data.player_cards);
        if (d.data.player_sum) document.getElementById('cfp-bj-player-sum').textContent = d.data.player_sum;
        if (d.data.result) { cfpBjFinish(d.data); return; }
        cfpBjMsg(d.data.msg || 'Hit or Stand?', '');
        document.getElementById('cfp-bj-double-btn').style.display = 'none';
        document.querySelectorAll('#cfp-bj-actions button').forEach(b=>b.disabled=false);
    }
    function cfpBjFinish(data) {
        document.getElementById('cfp-bj-actions').innerHTML = '<button class="cfp-btn-full" onclick="cfpBjReset()" style="grid-column:span 3;background:var(--cfp-p)">🔄 New Hand</button>';
        if (data.dealer_cards) document.getElementById('cfp-bj-dealer-cards').innerHTML = cfpBjCards(data.dealer_cards);
        if (data.dealer_sum) document.getElementById('cfp-bj-dealer-sum').textContent = data.dealer_sum;
        const colors = { win:'#22c55e', blackjack:'#ffd700', push:'#888', bust:'#ef4444', lose:'#ef4444' };
        const type = data.result in colors ? (data.result==='win'||data.result==='blackjack'||data.result==='push' ? 'success':'error') : '';
        cfpBjMsg(data.msg, type);
        document.getElementById('cfp-bj-balance').innerHTML = `Balance: <strong style="color:var(--cfp-p)">${Number(data.new_balance).toLocaleString()} sat</strong>`;
        cfpBjGameId = null;
    }
    function cfpBjReset() {
        cfpBjGameId = null;
        document.getElementById('cfp-bj-table').style.display='none';
        document.getElementById('cfp-bj-deal-btn').style.display='';
        document.getElementById('cfp-bj-deal-btn').disabled=false;
        document.getElementById('cfp-bj-email').disabled=false;
        document.getElementById('cfp-bj-bet').disabled=false;
        document.getElementById('cfp-bj-actions').innerHTML='<button class="cfp-btn-full" style="background:#22c55e" onclick="cfpBjAction(\'hit\')">👊 Hit</button><button class="cfp-btn-full" style="background:#ef4444" onclick="cfpBjAction(\'stand\')">✋ Stand</button><button class="cfp-btn-full" id="cfp-bj-double-btn" style="background:#f7931a" onclick="cfpBjAction(\'double\')">✌️ Double</button>';
        cfpBjMsg('','');
    }
    function cfpBjMsg(m,t) { document.getElementById('cfp-bj-msg').innerHTML = m ? `<div class="cfp-msg ${t}">${m}</div>` : ''; }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_roulette]
   ============================================================ */
add_shortcode('cfp_roulette', function() {
    if ( cfp_get_setting('roulette_enabled','1') !== '1' ) return '<p style="color:#666;text-align:center">Roulette coming soon.</p>';
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    $reds  = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-roulette-widget">
        <h2>🎡 Roulette</h2>
        <p class="sub">European roulette — 37 pockets, single zero.</p>
        <div id="cfp-rl-msg"></div>
        <input class="cfp-input" type="email" id="cfp-rl-email" placeholder="Account email">
        <input class="cfp-input" type="number" id="cfp-rl-bet" placeholder="Bet amount (satoshis)" min="1">

        <div style="margin-bottom:12px">
            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1px;color:#666;margin-bottom:6px">Bet Type</div>
            <div style="display:flex;flex-wrap:wrap;gap:6px" id="cfp-rl-bet-types">
                <?php
                $types=[['red','🔴 Red',2],['black','⚫ Black',2],['even','Even',2],['odd','Odd',2],['low','1–18',2],['high','19–36',2],['dozen1','1st 12',3],['dozen2','2nd 12',3],['dozen3','3rd 12',3],['single','Single #',36]];
                foreach($types as [$val,$label,$mult]):?>
                <button class="cfp-rl-type-btn" data-type="<?=$val?>" onclick="cfpRlSelectType(this)"
                    style="background:#0d0d0d;border:1px solid #1e1e1e;color:#777;padding:6px 12px;border-radius:8px;font-size:.78rem;cursor:pointer;transition:all .15s">
                    <?=$label?> <span style="color:#444">(<?=$mult?>:1)</span>
                </button>
                <?php endforeach; ?>
            </div>
            <div id="cfp-rl-single-wrap" style="display:none;margin-top:8px">
                <input class="cfp-input" type="number" id="cfp-rl-single-num" placeholder="Pick a number (0–36)" min="0" max="36" style="margin-bottom:0">
            </div>
        </div>

        <div id="cfp-rl-wheel-display" style="text-align:center;padding:20px 0;font-size:3rem;display:none">🎡</div>

        <button class="cfp-btn-full" id="cfp-rl-spin-btn" onclick="cfpRlSpin()">🎡 Spin</button>
        <div id="cfp-rl-balance" style="font-size:.8rem;color:#555;text-align:center;margin-top:10px"></div>
    </div>
    <script>
    let cfpRlSelectedType = 'red';
    function cfpRlSelectType(btn) {
        document.querySelectorAll('.cfp-rl-type-btn').forEach(b=>{
            b.style.borderColor='#1e1e1e'; b.style.color='#777'; b.style.background='#0d0d0d';
        });
        btn.style.borderColor='var(--cfp-p)'; btn.style.color='var(--cfp-p)'; btn.style.background='#0d0d1a';
        cfpRlSelectedType = btn.dataset.type;
        document.getElementById('cfp-rl-single-wrap').style.display = (cfpRlSelectedType==='single') ? '' : 'none';
    }
    document.querySelector('[data-type="red"]')?.click();
    async function cfpRlSpin() {
        const email = document.getElementById('cfp-rl-email').value;
        const bet   = document.getElementById('cfp-rl-bet').value;
        if (!email||!bet) { cfpRlMsg('Enter email and bet.','error'); return; }
        const betValue = cfpRlSelectedType==='single' ? (document.getElementById('cfp-rl-single-num').value||'0') : '';
        const btn = document.getElementById('cfp-rl-spin-btn');
        btn.disabled=true; btn.textContent='🌀 Spinning…';
        const wd = document.getElementById('cfp-rl-wheel-display');
        wd.style.display=''; wd.textContent='🌀';
        const fd = new FormData();
        fd.append('action','cfp_roulette'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',email); fd.append('bet',bet);
        fd.append('bet_type',cfpRlSelectedType); fd.append('bet_value',betValue);
        const r = await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d = await r.json();
        const colorMap={red:'🔴',black:'⚫',green:'💚'};
        wd.textContent = d.success ? (colorMap[d.data.color]||'⚪')+' '+d.data.spin : '❓';
        cfpRlMsg(d.data?.msg || (d.success?'':'Error'), d.success?(d.data.won?'success':'error'):'error');
        if (d.success) document.getElementById('cfp-rl-balance').innerHTML=`Balance: <strong style="color:var(--cfp-p)">${Number(d.data.new_balance).toLocaleString()} sat</strong>`;
        btn.disabled=false; btn.textContent='🎡 Spin';
    }
    function cfpRlMsg(m,t){document.getElementById('cfp-rl-msg').innerHTML=`<div class="cfp-msg ${t}">${m}</div>`;}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_baccarat]
   ============================================================ */
add_shortcode('cfp_baccarat', function() {
    if ( cfp_get_setting('baccarat_enabled','1') !== '1' ) return '<p style="color:#666;text-align:center">Baccarat coming soon.</p>';
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-baccarat-widget">
        <h2>🎴 Baccarat</h2>
        <p class="sub">Bet on Player, Banker, or Tie — closest to 9 wins.</p>
        <div id="cfp-bac-msg"></div>
        <input class="cfp-input" type="email" id="cfp-bac-email" placeholder="Account email">
        <input class="cfp-input" type="number" id="cfp-bac-bet" placeholder="Bet amount (satoshis)" min="1">
        <div style="margin-bottom:14px">
            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1px;color:#666;margin-bottom:6px">Your Bet</div>
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
                <button class="cfp-bac-choice" data-choice="player" onclick="cfpBacSelect(this)"
                    style="background:#0d0d0d;border:1px solid #1e1e1e;color:#777;padding:10px;border-radius:10px;cursor:pointer;text-align:center;font-weight:600;font-size:.84rem">
                    <div>🟦 Player</div><div style="font-size:.7rem;color:#444">1:1</div>
                </button>
                <button class="cfp-bac-choice" data-choice="banker" onclick="cfpBacSelect(this)"
                    style="background:#0d0d0d;border:1px solid #1e1e1e;color:#777;padding:10px;border-radius:10px;cursor:pointer;text-align:center;font-weight:600;font-size:.84rem">
                    <div>🟥 Banker</div><div style="font-size:.7rem;color:#444">1:1</div>
                </button>
                <button class="cfp-bac-choice" data-choice="tie" onclick="cfpBacSelect(this)"
                    style="background:#0d0d0d;border:1px solid #1e1e1e;color:#777;padding:10px;border-radius:10px;cursor:pointer;text-align:center;font-weight:600;font-size:.84rem">
                    <div>🟩 Tie</div><div style="font-size:.7rem;color:#444">8:1</div>
                </button>
            </div>
        </div>
        <div id="cfp-bac-result-table" style="display:none;margin-bottom:14px">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                <div style="background:#0d0d0d;border:1px solid #1e1e1e;border-radius:10px;padding:12px;text-align:center">
                    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:1px;color:#3b82f6;margin-bottom:4px">Player</div>
                    <div id="cfp-bac-player-score" style="font-family:'Oswald',sans-serif;font-size:2rem;color:#3b82f6">—</div>
                </div>
                <div style="background:#0d0d0d;border:1px solid #1e1e1e;border-radius:10px;padding:12px;text-align:center">
                    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:1px;color:#ef4444;margin-bottom:4px">Banker</div>
                    <div id="cfp-bac-banker-score" style="font-family:'Oswald',sans-serif;font-size:2rem;color:#ef4444">—</div>
                </div>
            </div>
        </div>
        <button class="cfp-btn-full" id="cfp-bac-deal-btn" onclick="cfpBacDeal()">🎴 Deal</button>
        <div id="cfp-bac-balance" style="font-size:.8rem;color:#555;text-align:center;margin-top:10px"></div>
    </div>
    <script>
    let cfpBacChoice = 'player';
    function cfpBacSelect(btn) {
        document.querySelectorAll('.cfp-bac-choice').forEach(b=>{ b.style.borderColor='#1e1e1e'; b.style.color='#777'; b.style.background='#0d0d0d'; });
        const colors={player:'#3b82f6',banker:'#ef4444',tie:'#22c55e'};
        const c=colors[btn.dataset.choice]||'var(--cfp-p)';
        btn.style.borderColor=c; btn.style.color=c; btn.style.background='rgba(255,255,255,.03)';
        cfpBacChoice=btn.dataset.choice;
    }
    document.querySelector('[data-choice="player"]')?.click();
    async function cfpBacDeal() {
        const email=document.getElementById('cfp-bac-email').value;
        const bet=document.getElementById('cfp-bac-bet').value;
        if(!email||!bet){cfpBacMsg('Enter email and bet.','error');return;}
        const btn=document.getElementById('cfp-bac-deal-btn');
        btn.disabled=true; btn.textContent='🃏 Dealing…';
        const fd=new FormData();
        fd.append('action','cfp_baccarat'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',email); fd.append('bet',bet); fd.append('bet_type',cfpBacChoice);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        document.getElementById('cfp-bac-result-table').style.display='';
        document.getElementById('cfp-bac-player-score').textContent=d.data?.player_score??'?';
        document.getElementById('cfp-bac-banker-score').textContent=d.data?.banker_score??'?';
        cfpBacMsg(d.data?.msg||'Error',d.success?(d.data.won?'success':'error'):'error');
        if(d.success) document.getElementById('cfp-bac-balance').innerHTML=`Balance: <strong style="color:var(--cfp-p)">${Number(d.data.new_balance).toLocaleString()} sat</strong>`;
        btn.disabled=false; btn.textContent='🎴 Deal';
    }
    function cfpBacMsg(m,t){document.getElementById('cfp-bac-msg').innerHTML=`<div class="cfp-msg ${t}">${m}</div>`;}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_videopoker]
   ============================================================ */
add_shortcode('cfp_videopoker', function() {
    if ( cfp_get_setting('videopoker_enabled','1') !== '1' ) return '<p style="color:#666;text-align:center">Video Poker coming soon.</p>';
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-vp-widget">
        <h2>🂡 Video Poker</h2>
        <p class="sub">Jacks or Better — hold cards, draw, and make the best hand!</p>
        <div style="background:#0d0d0d;border:1px solid #1e1e1e;border-radius:10px;padding:10px 14px;margin-bottom:14px;font-size:.76rem">
            <div style="color:#555;margin-bottom:4px;text-transform:uppercase;letter-spacing:1px;font-size:.66rem">Pay Table</div>
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:4px 8px;color:#666">
                <span>Royal Flush: <b style="color:var(--cfp-a)">250x</b></span>
                <span>Str. Flush: <b style="color:#a855f7">50x</b></span>
                <span>4 of a Kind: <b style="color:#22c55e">25x</b></span>
                <span>Full House: <b style="color:#3b82f6">9x</b></span>
                <span>Flush: <b style="color:#f7931a">6x</b></span>
                <span>Straight: <b style="color:#eab308">4x</b></span>
                <span>3 of a Kind: <b style="color:#06b6d4">3x</b></span>
                <span>Two Pair: <b style="color:#8b5cf6">2x</b></span>
                <span>Jacks+: <b style="color:#555">1x</b></span>
            </div>
        </div>
        <div id="cfp-vp-msg"></div>
        <input class="cfp-input" type="email" id="cfp-vp-email" placeholder="Account email">
        <input class="cfp-input" type="number" id="cfp-vp-bet" placeholder="Bet amount (satoshis)" min="1">
        <div id="cfp-vp-hand" style="display:none;margin-bottom:14px">
            <div style="display:flex;justify-content:center;gap:8px;flex-wrap:wrap;margin-bottom:10px" id="cfp-vp-cards"></div>
            <div style="text-align:center;font-size:.72rem;color:#555">Tap cards to HOLD them</div>
        </div>
        <button class="cfp-btn-full" id="cfp-vp-deal-btn" onclick="cfpVpDeal()">🃏 Deal</button>
        <button class="cfp-btn-full" id="cfp-vp-draw-btn" style="display:none;background:#a855f7" onclick="cfpVpDraw()">🔄 Draw</button>
        <div id="cfp-vp-balance" style="font-size:.8rem;color:#555;text-align:center;margin-top:10px"></div>
    </div>
    <script>
    let cfpVpHeld = [];
    let cfpVpCurrentHand = [];
    const cfpVpSuits = { h:'♥', d:'♦', c:'♣', s:'♠' };
    function cfpVpCardHtml(code, idx) {
        const val=code.slice(0,-2), suit=code.slice(-1);
        const face={A:'A',J:'J',Q:'Q',K:'K'};
        const label=(face[val]||val)+(cfpVpSuits[suit]||suit);
        const red=suit==='h'||suit==='d';
        const held=cfpVpHeld.includes(idx);
        return `<div id="cfp-vp-card-${idx}" onclick="cfpVpToggleHold(${idx})" style="cursor:pointer;text-align:center;transition:transform .15s;transform:${held?'translateY(-10px)':'none'}">
            <div style="background:#fff;color:${red?'#ef4444':'#111'};border-radius:8px;padding:10px 14px;font-weight:700;font-size:1.2rem;font-family:monospace;border:2px solid ${held?'#22c55e':'transparent'};min-width:44px">${label}</div>
            <div style="font-size:.65rem;color:${held?'#22c55e':'#333'};margin-top:3px;text-transform:uppercase;letter-spacing:1px">${held?'HELD':' '}</div>
        </div>`;
    }
    function cfpVpToggleHold(idx) {
        if (cfpVpHeld.includes(idx)) cfpVpHeld=cfpVpHeld.filter(i=>i!==idx);
        else cfpVpHeld.push(idx);
        document.getElementById('cfp-vp-cards').innerHTML = cfpVpCurrentHand.map((c,i)=>cfpVpCardHtml(c,i)).join('');
    }
    async function cfpVpDeal() {
        const email=document.getElementById('cfp-vp-email').value;
        const bet=document.getElementById('cfp-vp-bet').value;
        if(!email||!bet){cfpVpMsg('Enter email and bet.','error');return;}
        const btn=document.getElementById('cfp-vp-deal-btn');
        btn.disabled=true;
        const fd=new FormData();
        fd.append('action','cfp_videopoker'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',email); fd.append('bet',bet); fd.append('vp_action','deal');
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        if(!d.success){cfpVpMsg(d.data.msg,'error');btn.disabled=false;return;}
        cfpVpCurrentHand=d.data.hand; cfpVpHeld=[];
        document.getElementById('cfp-vp-hand').style.display='';
        document.getElementById('cfp-vp-cards').innerHTML=cfpVpCurrentHand.map((c,i)=>cfpVpCardHtml(c,i)).join('');
        document.getElementById('cfp-vp-deal-btn').style.display='none';
        document.getElementById('cfp-vp-draw-btn').style.display='';
        document.getElementById('cfp-vp-email').disabled=true;
        document.getElementById('cfp-vp-bet').disabled=true;
        cfpVpMsg(d.data.msg||'Choose which cards to hold, then Draw.','');
    }
    async function cfpVpDraw() {
        const btn=document.getElementById('cfp-vp-draw-btn');
        btn.disabled=true; btn.textContent='Drawing…';
        const fd=new FormData();
        fd.append('action','cfp_videopoker'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',document.getElementById('cfp-vp-email').value);
        fd.append('bet',document.getElementById('cfp-vp-bet').value);
        fd.append('vp_action','draw'); fd.append('hold',cfpVpHeld.join(','));
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        if(d.success){
            cfpVpCurrentHand=d.data.hand; cfpVpHeld=[];
            document.getElementById('cfp-vp-cards').innerHTML=cfpVpCurrentHand.map((c,i)=>cfpVpCardHtml(c,i)).join('');
            cfpVpMsg(d.data.msg,d.data.won?'success':'error');
            document.getElementById('cfp-vp-balance').innerHTML=`Balance: <strong style="color:var(--cfp-p)">${Number(d.data.new_balance).toLocaleString()} sat</strong>`;
        } else cfpVpMsg(d.data.msg,'error');
        btn.textContent='🔄 New Hand'; btn.disabled=false;
        btn.onclick=function(){ cfpVpReset(); };
    }
    function cfpVpReset() {
        cfpVpHeld=[]; cfpVpCurrentHand=[];
        document.getElementById('cfp-vp-hand').style.display='none';
        document.getElementById('cfp-vp-deal-btn').style.display=''; document.getElementById('cfp-vp-deal-btn').disabled=false;
        document.getElementById('cfp-vp-draw-btn').style.display='none'; document.getElementById('cfp-vp-draw-btn').textContent='🔄 Draw'; document.getElementById('cfp-vp-draw-btn').onclick=cfpVpDraw;
        document.getElementById('cfp-vp-email').disabled=false; document.getElementById('cfp-vp-bet').disabled=false;
        cfpVpMsg('','');
    }
    function cfpVpMsg(m,t){document.getElementById('cfp-vp-msg').innerHTML=m?`<div class="cfp-msg ${t}">${m}</div>`:''}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_keno]
   ============================================================ */
add_shortcode('cfp_keno', function() {
    if ( cfp_get_setting('keno_enabled','1') !== '1' ) return '<p style="color:#666;text-align:center">Keno coming soon.</p>';
    $nonce  = wp_create_nonce('cfp_nonce');
    $ajax   = admin_url('admin-ajax.php');
    $spots  = intval( cfp_get_setting('keno_spots_default', 5) );
    $maxs   = intval( cfp_get_setting('keno_max_spots', 10) );
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-keno-widget">
        <h2>🎱 Keno</h2>
        <p class="sub">Pick up to <?=$maxs?> numbers — 20 drawn from 80. Match to win!</p>
        <div id="cfp-keno-msg"></div>
        <input class="cfp-input" type="email" id="cfp-keno-email" placeholder="Account email">
        <input class="cfp-input" type="number" id="cfp-keno-bet" placeholder="Bet amount (satoshis)" min="1">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
            <div style="font-size:.72rem;color:#555">Pick <span id="cfp-keno-pick-count">0</span> / <?=$maxs?> numbers</div>
            <button onclick="cfpKenoClear()" style="background:transparent;border:1px solid #333;color:#555;padding:3px 10px;border-radius:6px;cursor:pointer;font-size:.72rem">Clear</button>
        </div>
        <div id="cfp-keno-grid" style="display:grid;grid-template-columns:repeat(10,1fr);gap:4px;margin-bottom:14px">
            <?php for($i=1;$i<=80;$i++): ?>
            <button class="cfp-keno-num" data-num="<?=$i?>" onclick="cfpKenoToggle(this,<?=$i?>)"
                style="background:#0d0d0d;border:1px solid #1e1e1e;color:#555;padding:6px 0;border-radius:6px;font-size:.74rem;cursor:pointer;transition:all .1s"><?=$i?></button>
            <?php endfor; ?>
        </div>
        <button class="cfp-btn-full" id="cfp-keno-play-btn" onclick="cfpKenoPlay()" style="background:#ec4899">🎱 Play Keno</button>
        <div id="cfp-keno-balance" style="font-size:.8rem;color:#555;text-align:center;margin-top:10px"></div>
    </div>
    <script>
    const cfpKenoSelected = new Set();
    const cfpKenoMax = <?=$maxs?>;
    function cfpKenoToggle(btn, num) {
        if (btn.dataset.drawn) return;
        if (cfpKenoSelected.has(num)) {
            cfpKenoSelected.delete(num);
            btn.style.background='#0d0d0d'; btn.style.borderColor='#1e1e1e'; btn.style.color='#555';
        } else {
            if (cfpKenoSelected.size >= cfpKenoMax) { cfpKenoMsg(`Max ${cfpKenoMax} numbers.`,'error'); return; }
            cfpKenoSelected.add(num);
            btn.style.background='#0a0a2a'; btn.style.borderColor='#ec4899'; btn.style.color='#ec4899';
        }
        document.getElementById('cfp-keno-pick-count').textContent=cfpKenoSelected.size;
    }
    function cfpKenoClear() {
        cfpKenoSelected.clear();
        document.querySelectorAll('.cfp-keno-num').forEach(b=>{
            b.style.background='#0d0d0d'; b.style.borderColor='#1e1e1e'; b.style.color='#555';
            delete b.dataset.drawn; delete b.dataset.hit;
        });
        document.getElementById('cfp-keno-pick-count').textContent=0;
        cfpKenoMsg('','');
    }
    async function cfpKenoPlay() {
        const email=document.getElementById('cfp-keno-email').value;
        const bet=document.getElementById('cfp-keno-bet').value;
        if(!email||!bet){cfpKenoMsg('Enter email and bet.','error');return;}
        if(cfpKenoSelected.size<1){cfpKenoMsg('Pick at least 1 number.','error');return;}
        const btn=document.getElementById('cfp-keno-play-btn');
        btn.disabled=true; btn.textContent='Drawing…';
        const fd=new FormData();
        fd.append('action','cfp_keno'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',email); fd.append('bet',bet);
        fd.append('spots',cfpKenoSelected.size);
        fd.append('selected',[...cfpKenoSelected].join(','));
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        if(d.success){
            const drawn=new Set(d.data.drawn);
            const selected=cfpKenoSelected;
            // Animate drawn numbers
            let i=0;
            const drawInterval=setInterval(()=>{
                if(i>=d.data.drawn.length){clearInterval(drawInterval);return;}
                const num=d.data.drawn[i++];
                const b=document.querySelector(`.cfp-keno-num[data-num="${num}"]`);
                if(b){
                    const isHit=selected.has(num);
                    b.dataset.drawn='1';
                    b.style.background=isHit?'#052505':'#1a0505';
                    b.style.borderColor=isHit?'#22c55e':'#3a0000';
                    b.style.color=isHit?'#22c55e':'#555';
                    if(isHit) b.style.fontWeight='700';
                }
            },60);
            cfpKenoMsg(d.data.msg,d.data.won?'success':'error');
            document.getElementById('cfp-keno-balance').innerHTML=`Balance: <strong style="color:var(--cfp-p)">${Number(d.data.new_balance).toLocaleString()} sat</strong>`;
        } else cfpKenoMsg(d.data.msg,'error');
        btn.disabled=false; btn.textContent='🔄 Play Again';
        btn.onclick=function(){ cfpKenoClear(); btn.textContent='🎱 Play Keno'; btn.onclick=cfpKenoPlay; };
    }
    function cfpKenoMsg(m,t){document.getElementById('cfp-keno-msg').innerHTML=m?`<div class="cfp-msg ${t}">${m}</div>`:''}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_plinko]
   ============================================================ */
add_shortcode('cfp_plinko', function() {
    if ( cfp_get_setting('plinko_enabled','1') !== '1' ) return '<p style="color:#666;text-align:center">Plinko coming soon.</p>';
    $nonce       = wp_create_nonce('cfp_nonce');
    $ajax        = admin_url('admin-ajax.php');
    $default_rows= intval( cfp_get_setting('plinko_default_rows', 8) );
    $mults_8     = cfp_get_setting('plinko_row_8_mults','0.5,0.7,1.0,1.5,3.0,1.5,1.0,0.7,0.5');
    $mults_10    = cfp_get_setting('plinko_row_10_mults','0.3,0.5,0.7,1.0,1.5,2.0,1.5,1.0,0.7,0.5,0.3');
    $mults_12    = cfp_get_setting('plinko_row_12_mults','0.2,0.3,0.5,0.7,1.0,2.0,2.0,1.0,0.7,0.5,0.3,0.2');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-plinko-widget">
        <h2>🔽 Plinko</h2>
        <p class="sub">Drop the ball and watch it bounce to a multiplier!</p>
        <div id="cfp-plinko-msg"></div>
        <input class="cfp-input" type="email" id="cfp-plinko-email" placeholder="Account email">
        <input class="cfp-input" type="number" id="cfp-plinko-bet" placeholder="Bet amount (satoshis)" min="1">
        <div style="margin-bottom:12px">
            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1px;color:#666;margin-bottom:6px">Rows</div>
            <div style="display:flex;gap:8px">
                <?php foreach([8,10,12] as $r): ?>
                <button class="cfp-plinko-row-btn" data-rows="<?=$r?>" onclick="cfpPlinkoSelectRows(this,<?=$r?>)"
                    style="flex:1;background:<?=$r==$default_rows?'#0a0a1a':'#0d0d0d'?>;border:1px solid <?=$r==$default_rows?'var(--cfp-p)':'#1e1e1e'?>;color:<?=$r==$default_rows?'var(--cfp-p)':'#555'?>;padding:8px;border-radius:8px;cursor:pointer;font-weight:600"><?=$r?> Rows</button>
                <?php endforeach; ?>
            </div>
        </div>
        <canvas id="cfp-plinko-canvas" width="340" height="260"
            style="width:100%;max-width:340px;display:block;margin:0 auto 14px;border-radius:10px;background:#060606;border:1px solid #1a1a1a"></canvas>
        <div id="cfp-plinko-mults" style="display:flex;justify-content:center;gap:3px;margin-bottom:14px;flex-wrap:wrap"></div>
        <button class="cfp-btn-full" id="cfp-plinko-drop-btn" onclick="cfpPlinkoDrop()" style="background:#f97316">🔽 Drop Ball</button>
        <div id="cfp-plinko-balance" style="font-size:.8rem;color:#555;text-align:center;margin-top:10px"></div>
    </div>
    <script>
    const cfpPlinkoMults = {
        8: [<?=$mults_8?>],
        10:[<?=$mults_10?>],
        12:[<?=$mults_12?>]
    };
    let cfpPlinkoRows = <?=$default_rows?>;
    function cfpPlinkoSelectRows(btn,rows){
        document.querySelectorAll('.cfp-plinko-row-btn').forEach(b=>{b.style.borderColor='#1e1e1e';b.style.color='#555';b.style.background='#0d0d0d';});
        btn.style.borderColor='var(--cfp-p)'; btn.style.color='var(--cfp-p)'; btn.style.background='#0a0a1a';
        cfpPlinkoRows=rows; cfpPlinkoRenderMults();
    }
    function cfpPlinkoMultColor(m){
        if(m>=3) return '#ffd700';
        if(m>=1.5) return '#22c55e';
        if(m>=1) return '#f7931a';
        return '#ef4444';
    }
    function cfpPlinkoRenderMults(highlightIdx=-1){
        const mults=cfpPlinkoMults[cfpPlinkoRows]||cfpPlinkoMults[8];
        document.getElementById('cfp-plinko-mults').innerHTML=mults.map((m,i)=>
            `<div style="flex:1;min-width:28px;text-align:center;padding:5px 2px;border-radius:6px;font-size:.7rem;font-weight:700;color:${cfpPlinkoMultColor(m)};background:${i===highlightIdx?'rgba(255,255,255,.1)':'#0d0d0d'};border:1px solid ${i===highlightIdx?cfpPlinkoMultColor(m):'#1a1a1a'};transition:all .3s">${m}x</div>`
        ).join('');
    }
    cfpPlinkoRenderMults();

    function cfpPlinkoAnimate(path, rows, callback) {
        const canvas=document.getElementById('cfp-plinko-canvas');
        const ctx=canvas.getContext('2d');
        const W=canvas.width, H=canvas.height;
        const pegR=4, ballR=8;
        const cols=rows+1;
        const padX=24, padY=24;
        const cellW=(W-padX*2)/rows;
        const cellH=(H-padY*2-40)/(rows+1);

        function getPegPos(row, col){ return { x: padX + col*cellW + (row%2===0?cellW/2:0), y: padY + row*cellH }; }
        function drawBoard() {
            ctx.clearRect(0,0,W,H);
            ctx.fillStyle='#060606'; ctx.fillRect(0,0,W,H);
            for(let row=0;row<rows;row++){
                const pegs=(row%2===0)?rows:(rows+1);
                for(let col=0;col<pegs;col++){
                    const p=getPegPos(row,col);
                    ctx.beginPath(); ctx.arc(p.x,p.y,pegR,0,Math.PI*2);
                    ctx.fillStyle='#333'; ctx.fill();
                }
            }
        }
        // Animate ball along path
        let step=0; let subStep=0; const subSteps=12;
        let ballX=W/2, ballY=padY-ballR*2;
        const interval=setInterval(()=>{
            drawBoard();
            if(step<path.length){
                const targetX=padX+path[step]*cellW;
                const targetY=padY+step*cellH;
                ballX+=(targetX-ballX)/subSteps*(subStep+1);
                ballY+=(targetY-ballY)/subSteps*(subStep+1);
                subStep++;
                if(subStep>=subSteps){step++;subStep=0;}
            } else {
                ballY=Math.min(ballY+5, H-padY);
                if(ballY>=H-padY){ clearInterval(interval); callback(); }
            }
            ctx.beginPath(); ctx.arc(ballX,ballY,ballR,0,Math.PI*2);
            ctx.fillStyle='#f97316'; ctx.fill();
            ctx.strokeStyle='#ffd700'; ctx.lineWidth=2; ctx.stroke();
        },30);
    }

    async function cfpPlinkoDrop(){
        const email=document.getElementById('cfp-plinko-email').value;
        const bet=document.getElementById('cfp-plinko-bet').value;
        if(!email||!bet){cfpPlinkoMsg('Enter email and bet.','error');return;}
        const btn=document.getElementById('cfp-plinko-drop-btn');
        btn.disabled=true; btn.textContent='Dropping…';
        const fd=new FormData();
        fd.append('action','cfp_plinko'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',email); fd.append('bet',bet); fd.append('rows',cfpPlinkoRows);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        if(!d.success){cfpPlinkoMsg(d.data.msg,'error');btn.disabled=false;btn.textContent='🔽 Drop Ball';return;}
        const mults=cfpPlinkoMults[cfpPlinkoRows]||cfpPlinkoMults[8];
        const bucketIdx=Math.round(d.data.path[d.data.path.length-1]);
        cfpPlinkoAnimate(d.data.path, cfpPlinkoRows, ()=>{
            cfpPlinkoRenderMults(bucketIdx);
            cfpPlinkoMsg(d.data.msg,d.data.won?'success':'error');
            document.getElementById('cfp-plinko-balance').innerHTML=`Balance: <strong style="color:var(--cfp-p)">${Number(d.data.new_balance).toLocaleString()} sat</strong>`;
            btn.disabled=false; btn.textContent='🔽 Drop Ball';
        });
    }
    function cfpPlinkoMsg(m,t){document.getElementById('cfp-plinko-msg').innerHTML=m?`<div class="cfp-msg ${t}">${m}</div>`:''}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_mines]
   ============================================================ */
add_shortcode('cfp_mines', function() {
    if ( cfp_get_setting('mines_enabled','1') !== '1' ) return '<p style="color:#666;text-align:center">Mines coming soon.</p>';
    $nonce    = wp_create_nonce('cfp_nonce');
    $ajax     = admin_url('admin-ajax.php');
    $def_mines= intval( cfp_get_setting('mines_default_mines', 3) );
    $max_mines= intval( cfp_get_setting('mines_max_mines', 24) );
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-mines-widget">
        <h2>💎 Mines</h2>
        <p class="sub">Reveal gems, avoid mines — cashout anytime to keep your winnings!</p>
        <div id="cfp-mines-msg"></div>
        <div id="cfp-mines-setup">
            <input class="cfp-input" type="email" id="cfp-mines-email" placeholder="Account email">
            <input class="cfp-input" type="number" id="cfp-mines-bet" placeholder="Bet amount (satoshis)" min="1">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
                <label style="font-size:.78rem;color:#555;white-space:nowrap">Mines:</label>
                <input type="range" id="cfp-mines-count" min="1" max="<?=$max_mines?>" value="<?=$def_mines?>" oninput="document.getElementById('cfp-mines-count-lbl').textContent=this.value" style="flex:1">
                <span id="cfp-mines-count-lbl" style="font-size:.88rem;color:var(--cfp-p);font-weight:700;min-width:24px;text-align:right"><?=$def_mines?></span>
            </div>
            <button class="cfp-btn-full" id="cfp-mines-start-btn" onclick="cfpMinesStart()" style="background:#06b6d4">💎 Start Game</button>
        </div>
        <div id="cfp-mines-game" style="display:none">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
                <div style="font-size:.8rem;color:#555">💣 Mines: <strong id="cfp-mines-mine-count" style="color:#ef4444"></strong></div>
                <div style="font-size:.8rem;color:#555">💎 Found: <strong id="cfp-mines-gems-found" style="color:#22c55e">0</strong></div>
                <div style="font-size:.8rem;color:#555">Mult: <strong id="cfp-mines-mult" style="color:var(--cfp-p)">1.00x</strong></div>
            </div>
            <div id="cfp-mines-grid" style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin-bottom:14px"></div>
            <button class="cfp-btn-full" id="cfp-mines-cashout-btn" onclick="cfpMinesCashout()" style="background:#22c55e;display:none">💰 Cashout</button>
        </div>
        <div id="cfp-mines-balance" style="font-size:.8rem;color:#555;text-align:center;margin-top:10px"></div>
    </div>
    <script>
    let cfpMinesGameId=null, cfpMinesMinePositions=[], cfpMinesRevealed=new Set();
    let cfpMinesGemsFound=0, cfpMinesMines=<?=$def_mines?>, cfpMinesBet=0;
    function cfpMinesCalcMult(gems, mines) {
        if(gems===0) return 1.00;
        const safe=25-mines;
        let mult=1;
        for(let i=0;i<gems;i++) mult *= (safe-i)/(safe-mines-i+mines);
        return Math.max(1, parseFloat((mult*0.96).toFixed(2)));
    }
    async function cfpMinesStart(){
        const email=document.getElementById('cfp-mines-email').value;
        const bet=document.getElementById('cfp-mines-bet').value;
        const mines=document.getElementById('cfp-mines-count').value;
        if(!email||!bet){cfpMinesMsg('Enter email and bet.','error');return;}
        const btn=document.getElementById('cfp-mines-start-btn');
        btn.disabled=true;
        const fd=new FormData();
        fd.append('action','cfp_mines'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',email); fd.append('bet',bet); fd.append('mines',mines); fd.append('mine_action','start');
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        if(!d.success){cfpMinesMsg(d.data.msg,'error');btn.disabled=false;return;}
        cfpMinesGameId=d.data.game_id;
        cfpMinesMinePositions=new Set(d.data.mine_positions||[]);
        cfpMinesRevealed=new Set();
        cfpMinesGemsFound=0;
        cfpMinesMines=parseInt(mines);
        cfpMinesBet=parseInt(bet);
        document.getElementById('cfp-mines-setup').style.display='none';
        document.getElementById('cfp-mines-game').style.display='';
        document.getElementById('cfp-mines-mine-count').textContent=mines;
        document.getElementById('cfp-mines-gems-found').textContent='0';
        document.getElementById('cfp-mines-mult').textContent='1.00x';
        cfpMinesRenderGrid();
        cfpMinesMsg('Find gems — cashout anytime!','');
    }
    function cfpMinesRenderGrid(){
        const grid=document.getElementById('cfp-mines-grid');
        grid.innerHTML='';
        for(let i=0;i<25;i++){
            const btn=document.createElement('button');
            btn.dataset.tile=i;
            btn.style.cssText='background:#0d0d0d;border:1px solid #1e1e1e;border-radius:8px;padding:0;height:52px;cursor:pointer;font-size:1.4rem;transition:all .15s';
            if(cfpMinesRevealed.has(i)){
                if(cfpMinesMinePositions.has(i)){ btn.textContent='💣'; btn.style.background='#1a0000'; btn.style.borderColor='#ef4444'; }
                else { btn.textContent='💎'; btn.style.background='#001a0a'; btn.style.borderColor='#22c55e'; }
                btn.disabled=true;
            } else {
                btn.textContent='❓';
                btn.onclick=()=>cfpMinesReveal(i,btn);
            }
            grid.appendChild(btn);
        }
    }
    function cfpMinesReveal(tile, btn) {
        if(cfpMinesRevealed.has(tile)) return;
        cfpMinesRevealed.add(tile);
        if(cfpMinesMinePositions.has(tile)){
            btn.textContent='💣'; btn.style.background='#1a0000'; btn.style.borderColor='#ef4444';
            document.querySelectorAll('#cfp-mines-grid button').forEach(b=>b.disabled=true);
            document.getElementById('cfp-mines-cashout-btn').style.display='none';
            cfpMinesMsg(`💥 BOOM! Mine hit. You lost ${cfpMinesBet.toLocaleString()} sat.`,'error');
            // Reveal all mines
            cfpMinesMinePositions.forEach(pos=>{
                const b=document.getElementById('cfp-mines-grid').children[pos];
                if(b){ b.textContent='💣'; b.style.background='#1a0000'; b.style.borderColor='#ef4444'; b.disabled=true; }
            });
            setTimeout(()=>cfpMinesReset(),2500);
        } else {
            cfpMinesGemsFound++;
            btn.textContent='💎'; btn.style.background='#001a0a'; btn.style.borderColor='#22c55e'; btn.disabled=true;
            const mult=cfpMinesCalcMult(cfpMinesGemsFound, cfpMinesMines);
            document.getElementById('cfp-mines-gems-found').textContent=cfpMinesGemsFound;
            document.getElementById('cfp-mines-mult').textContent=mult.toFixed(2)+'x';
            document.getElementById('cfp-mines-cashout-btn').style.display='';
            const potentialWin=Math.floor(cfpMinesBet*mult);
            cfpMinesMsg(`💎 Gem! Potential win: ${potentialWin.toLocaleString()} sat`,'success');
        }
    }
    async function cfpMinesCashout(){
        const btn=document.getElementById('cfp-mines-cashout-btn');
        btn.disabled=true; btn.textContent='Processing…';
        const fd=new FormData();
        fd.append('action','cfp_mines'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',document.getElementById('cfp-mines-email').value);
        fd.append('bet',cfpMinesBet); fd.append('mine_action','cashout'); fd.append('game_id',cfpMinesGameId);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        cfpMinesMsg(d.data?.msg||'Cashout processed.',d.success?'success':'error');
        if(d.success) document.getElementById('cfp-mines-balance').innerHTML=`Balance: <strong style="color:var(--cfp-p)">${Number(d.data.new_balance).toLocaleString()} sat</strong>`;
        setTimeout(()=>cfpMinesReset(),2000);
    }
    function cfpMinesReset(){
        cfpMinesGameId=null; cfpMinesMinePositions=new Set(); cfpMinesRevealed=new Set(); cfpMinesGemsFound=0;
        document.getElementById('cfp-mines-setup').style.display='';
        document.getElementById('cfp-mines-game').style.display='none';
        document.getElementById('cfp-mines-start-btn').disabled=false;
        document.getElementById('cfp-mines-cashout-btn').style.display='none';
        cfpMinesMsg('','');
    }
    function cfpMinesMsg(m,t){document.getElementById('cfp-mines-msg').innerHTML=m?`<div class="cfp-msg ${t}">${m}</div>`:''}
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_raffle]
   ============================================================ */
add_shortcode('cfp_raffle', function() {
    if ( cfp_get_setting('raffle_enabled','1') !== '1' ) return '';
    $nonce   = wp_create_nonce('cfp_nonce');
    $ajax    = admin_url('admin-ajax.php');
    $min_bet = intval( cfp_get_setting('raffle_min_bet', 100) );
    $max_bet = intval( cfp_get_setting('raffle_max_bet', 10000) );
    $edge    = floatval( cfp_get_setting('raffle_house_edge', 10) );
    $pool    = intval( cfp_get_setting('raffle_pool_sat', 0) );
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-raffle-widget">
        <h2>🎟 Instant Raffle</h2>
        <p class="sub">Buy tickets, get a provably fair draw — win the prize pool instantly!</p>
        <div style="text-align:center;margin-bottom:18px">
            <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:6px">Current Prize Pool</div>
            <div style="font-family:'Oswald',sans-serif;font-size:2.2rem;font-weight:900;color:var(--cfp-a)"><?=number_format($pool)?> <span style="font-size:1rem;color:#555">sat</span></div>
            <div style="font-size:.74rem;color:#444;margin-top:4px"><?=round(100-$edge)?>% of bets go to the prize pool</div>
        </div>
        <div id="cfp-raffle-msg"></div>
        <input class="cfp-input" type="email" id="cfp-raffle-email" placeholder="Account email">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
            <input class="cfp-input" type="number" id="cfp-raffle-bet" placeholder="Bet per ticket (<?=number_format($min_bet)?>–<?=number_format($max_bet)?>)" min="<?=$min_bet?>" max="<?=$max_bet?>" style="margin-bottom:0;flex:1">
            <div style="white-space:nowrap">
                <label style="font-size:.74rem;color:#555">Tickets:</label>
                <select id="cfp-raffle-tickets" style="background:#0d0d0d;border:1px solid #1e1e1e;color:#aaa;padding:10px 8px;border-radius:8px;font-size:.82rem">
                    <?php for($t=1;$t<=10;$t++) echo "<option value=\"$t\">$t</option>"; ?>
                </select>
            </div>
        </div>
        <div id="cfp-raffle-preview" style="text-align:center;font-size:.78rem;color:#555;margin-bottom:10px">Total: — sat</div>
        <button class="cfp-btn-full" id="cfp-raffle-buy-btn" onclick="cfpRaffleBuy()" style="background:linear-gradient(135deg,var(--cfp-p),var(--cfp-a))">🎟 Buy &amp; Draw</button>
        <div id="cfp-raffle-result" style="margin-top:14px"></div>
    </div>
    <script>
    (function(){
        const betEl=document.getElementById('cfp-raffle-bet');
        const tickEl=document.getElementById('cfp-raffle-tickets');
        const prev=document.getElementById('cfp-raffle-preview');
        function updatePreview(){ const t=parseInt(tickEl.value)||1, b=parseInt(betEl.value)||0; prev.textContent=`Total: ${(t*b).toLocaleString()} sat`; }
        betEl.addEventListener('input',updatePreview); tickEl.addEventListener('change',updatePreview);
    })();
    async function cfpRaffleBuy(){
        const email=document.getElementById('cfp-raffle-email').value;
        const bet=document.getElementById('cfp-raffle-bet').value;
        const tickets=document.getElementById('cfp-raffle-tickets').value;
        if(!email||!bet){cfpRaffleMsg('Enter email and bet.','error');return;}
        const btn=document.getElementById('cfp-raffle-buy-btn');
        btn.disabled=true; btn.textContent='🎲 Drawing…';
        const fd=new FormData();
        fd.append('action','cfp_raffle'); fd.append('nonce','<?=$nonce?>');
        fd.append('email',email); fd.append('bet',bet); fd.append('tickets',tickets);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        const el=document.getElementById('cfp-raffle-result');
        if(d.success){
            const ticketList=(d.data.tickets||[]).map(t=>`<span style="background:#0d0d0d;border:1px solid #2a2a2a;border-radius:6px;padding:4px 10px;font-family:monospace;color:#666;font-size:.8rem">#${t}</span>`).join(' ');
            el.innerHTML=`<div class="${d.data.won?'cfp-msg success':'cfp-msg error'}" style="margin-bottom:10px">${d.data.msg}</div>
            <div style="text-align:center;margin-top:8px">
                <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:1px;color:#555;margin-bottom:6px">Your Tickets</div>
                <div style="display:flex;flex-wrap:wrap;gap:4px;justify-content:center">${ticketList}</div>
            </div>
            <div style="text-align:center;margin-top:10px;font-size:.8rem;color:#555">Balance: <strong style="color:var(--cfp-p)">${Number(d.data.new_balance).toLocaleString()} sat</strong></div>`;
            cfpRaffleMsg('','');
        } else cfpRaffleMsg(d.data.msg,'error');
        btn.disabled=false; btn.textContent='🎟 Buy &amp; Draw';
    }
    function cfpRaffleMsg(m,t){document.getElementById('cfp-raffle-msg').innerHTML=m?`<div class="cfp-msg ${t}">${m}</div>`:''}
    </script>
    <?php return ob_get_clean();
});
