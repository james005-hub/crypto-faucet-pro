<?php
/**
 * NOWPayments API: create invoices/payment links, process IPN webhooks,
 * handle withdrawals (mass payouts), and check payment status.
 *
 * HOW DEPOSITS WORK:
 *   1. User requests a deposit — plugin calls NOWPayments to create a payment invoice
 *   2. NOWPayments returns a payment address specific to that invoice
 *   3. User sends crypto to that address on-chain
 *   4. NOWPayments POSTs an IPN to this plugin when payment is detected/confirmed
 *   5. Plugin verifies the IPN signature, credits the user's balance
 *
 * HOW WITHDRAWALS WORK:
 *   1. User submits a withdrawal request with their on-chain wallet address
 *   2. Plugin calls NOWPayments Mass Payout API to send funds
 *   3. NOWPayments processes the payout; IPN callback updates the record status
 *
 * NOWPayments API docs: https://documenter.getpostman.com/view/7907941/2s93JusNJt
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'CFP_NP_API_BASE', 'https://api.nowpayments.io/v1' );

/* ============================================================
   HELPER: GET NOWPAYMENTS SETTINGS
   ============================================================ */
function cfp_np_api_key()    { return cfp_get_setting( 'np_api_key', '' ); }
function cfp_np_ipn_secret() { return cfp_get_setting( 'np_ipn_secret', '' ); }
function cfp_np_enabled()    { return (bool) cfp_get_setting( 'np_enabled', '0' ); }
function cfp_np_currency()   { return strtolower( cfp_get_setting( 'np_currency', 'btc' ) ); }

/* ============================================================
   HELPER: AUTHENTICATED HTTP REQUEST TO NOWPAYMENTS
   ============================================================ */
function cfp_np_request( $endpoint, $method = 'GET', $body = null ) {
    $api_key = cfp_np_api_key();
    if ( empty( $api_key ) ) return ['error' => 'NOWPayments API key not configured.'];

    $args = [
        'timeout' => 25,
        'headers' => [
            'x-api-key'    => $api_key,
            'Content-Type' => 'application/json',
        ],
        'method' => strtoupper( $method ),
    ];

    if ( $body !== null ) {
        $args['body'] = wp_json_encode( $body );
    }

    $response = wp_remote_request( CFP_NP_API_BASE . $endpoint, $args );

    if ( is_wp_error( $response ) ) {
        return ['error' => $response->get_error_message()];
    }

    $decoded = json_decode( wp_remote_retrieve_body( $response ), true );
    return $decoded ?? ['error' => 'Invalid JSON from NOWPayments'];
}

/* ============================================================
   CREATE PAYMENT INVOICE (deposit)
   Returns the payment object including `pay_address`, `payment_id`, etc.
   ============================================================ */
function cfp_np_create_payment( $amount_usd, $currency = null, $order_id = '', $order_desc = '' ) {
    $currency = $currency ?? cfp_np_currency();

    $payload = [
        'price_amount'    => (float) $amount_usd,
        'price_currency'  => 'usd',
        'pay_currency'    => strtolower( $currency ),
        'order_id'        => $order_id,
        'order_description' => $order_desc ?: 'Crypto Faucet Pro Deposit',
        'ipn_callback_url'  => cfp_np_ipn_url(),
    ];

    return cfp_np_request( '/payment', 'POST', $payload );
}

/* ============================================================
   CREATE PAYMENT INVOICE BY CRYPTO AMOUNT (not USD)
   Useful when you want to deposit exactly X sat worth of crypto.
   ============================================================ */
function cfp_np_create_payment_crypto( $pay_amount, $pay_currency, $price_currency = 'usd', $order_id = '', $order_desc = '' ) {
    $payload = [
        'price_amount'      => (float) $pay_amount,
        'price_currency'    => strtolower( $pay_currency ),
        'pay_currency'      => strtolower( $pay_currency ),
        'pay_amount'        => (float) $pay_amount,
        'order_id'          => $order_id,
        'order_description' => $order_desc ?: 'Crypto Faucet Pro Deposit',
        'ipn_callback_url'  => cfp_np_ipn_url(),
    ];

    return cfp_np_request( '/payment', 'POST', $payload );
}

/* ============================================================
   GET PAYMENT STATUS
   ============================================================ */
function cfp_np_get_payment( $payment_id ) {
    return cfp_np_request( '/payment/' . intval( $payment_id ) );
}

/* ============================================================
   GET AVAILABLE CURRENCIES
   ============================================================ */
function cfp_np_get_currencies() {
    $cached = get_transient( 'cfp_np_currencies' );
    if ( $cached ) return $cached;

    $result = cfp_np_request( '/currencies' );
    if ( ! empty( $result['currencies'] ) ) {
        set_transient( 'cfp_np_currencies', $result['currencies'], HOUR_IN_SECONDS * 6 );
        return $result['currencies'];
    }
    return [];
}

/* ============================================================
   GET MINIMUM PAYMENT AMOUNT FOR A CURRENCY
   ============================================================ */
function cfp_np_get_min_amount( $from_currency, $to_currency = 'usd' ) {
    $result = cfp_np_request( '/min-amount?currency_from=' . urlencode( $from_currency ) . '&currency_to=' . urlencode( $to_currency ) );
    return $result['min_amount'] ?? null;
}

/* ============================================================
   GET NOWPAYMENTS ACCOUNT BALANCE (admin)
   ============================================================ */
function cfp_np_get_balance() {
    return cfp_np_request( '/balance' );
}

/* ============================================================
   MASS PAYOUT (withdrawal)
   Sends crypto to a user's external wallet address.
   ============================================================ */
function cfp_np_send_payout( $to_address, $amount, $currency, $extra_id = '' ) {
    $payload = [
        'withdrawals' => [[
            'address'    => $to_address,
            'currency'   => strtolower( $currency ),
            'amount'     => (float) $amount,
            'extra_id'   => $extra_id,
            'ipn_callback_url' => cfp_np_ipn_url(),
        ]],
    ];

    return cfp_np_request( '/payout', 'POST', $payload );
}

/* ============================================================
   IPN URL HELPERS
   ============================================================ */
function cfp_np_ipn_url() {
    return rest_url( 'cfp/v1/nowpayments-ipn' );
}

/* ============================================================
   REGISTER REST IPN ENDPOINT
   ============================================================ */
add_action( 'rest_api_init', function () {
    register_rest_route( 'cfp/v1', '/nowpayments-ipn', [
        'methods'             => ['POST'],
        'callback'            => 'cfp_np_handle_ipn_rest',
        'permission_callback' => '__return_true',
    ] );
} );

function cfp_np_handle_ipn_rest( $request ) {
    // NOWPayments sends JSON body
    $raw_body = $request->get_body();
    $data     = json_decode( $raw_body, true );

    // Verify HMAC-SHA512 signature.
    // SECURITY: Reject ALL IPNs when no secret is configured — an unconfigured
    // secret would allow any forged IPN to credit user balances with fake payments.
    $secret     = cfp_np_ipn_secret();
    $sig_header = $_SERVER['HTTP_X_NOWPAYMENTS_SIG'] ?? '';

    if ( empty( $secret ) ) {
        cfp_np_log_ipn_failure( 'IPN secret not configured — rejecting webhook', $data );
        return new WP_REST_Response( ['status' => 'NOT_CONFIGURED'], 500 );
    }

    if ( empty( $sig_header ) ) {
        cfp_np_log_ipn_failure( 'Missing X-NOWPayments-Sig header', $data );
        return new WP_REST_Response( ['status' => 'MISSING_SIGNATURE'], 403 );
    }

    $sorted_data  = $data;
    ksort( $sorted_data );
    $expected_sig = hash_hmac( 'sha512', json_encode( $sorted_data ), $secret );
    if ( ! hash_equals( $expected_sig, strtolower( $sig_header ) ) ) {
        cfp_np_log_ipn_failure( 'HMAC mismatch', $data );
        return new WP_REST_Response( ['status' => 'INVALID_SIGNATURE'], 403 );
    }

    $result = cfp_np_process_ipn( $data );
    return new WP_REST_Response( ['status' => $result], 200 );
}

/* ============================================================
   ALSO SUPPORT QUERY-STRING IPN URL (fallback)
   ============================================================ */
add_action( 'init', 'cfp_np_register_query_ipn' );
function cfp_np_register_query_ipn() {
    if ( isset( $_GET['cfp_np_ipn'] ) ) {
        $raw  = file_get_contents( 'php://input' );
        $data = json_decode( $raw, true ) ?? array_merge( $_GET, $_POST );

        // Signature check — hard-fail if secret is unconfigured (mirrors REST handler fix).
        $secret = cfp_np_ipn_secret();
        $sig    = $_SERVER['HTTP_X_NOWPAYMENTS_SIG'] ?? '';
        if ( empty( $secret ) ) {
            cfp_np_log_ipn_failure( 'IPN secret not configured — rejecting query IPN', $data );
            status_header( 500 );
            exit( 'NOT_CONFIGURED' );
        }
        if ( empty( $sig ) ) {
            cfp_np_log_ipn_failure( 'Missing X-NOWPayments-Sig header (query)', $data );
            status_header( 403 );
            exit( 'MISSING_SIGNATURE' );
        }
        $sorted = $data;
        ksort( $sorted );
        $expected = hash_hmac( 'sha512', json_encode( $sorted ), $secret );
        if ( ! hash_equals( $expected, strtolower( $sig ) ) ) {
            cfp_np_log_ipn_failure( 'HMAC mismatch (query)', $data );
            status_header( 403 );
            exit( 'INVALID_SIGNATURE' );
        }

        cfp_np_process_ipn( $data );
        exit( 'OK' );
    }
}

/* ============================================================
   MAIN IPN PROCESSOR
   Handles both deposit confirmations and payout status updates.
   ============================================================ */
function cfp_np_process_ipn( $data ) {
    if ( empty( $data ) ) return 'EMPTY_PAYLOAD';

    global $wpdb;

    $payment_id     = sanitize_text_field( $data['payment_id']     ?? '' );
    $payment_status = sanitize_text_field( $data['payment_status'] ?? '' );
    $order_id       = sanitize_text_field( $data['order_id']       ?? '' );
    $pay_amount     = floatval( $data['actually_paid']             ?? $data['pay_amount'] ?? 0 );
    $pay_currency   = strtolower( sanitize_text_field( $data['pay_currency'] ?? '' ) );
    $price_amount   = floatval( $data['price_amount']              ?? 0 );
    $outcome_amount = floatval( $data['outcome_amount']            ?? 0 );

    if ( empty( $payment_id ) ) return 'NO_PAYMENT_ID';

    // ── HANDLE PAYOUT / WITHDRAWAL IPN ──────────────────────
    // Payout IPNs have a 'batch_withdrawal_id' or 'withdrawal_id'
    if ( ! empty( $data['batch_withdrawal_id'] ) || ! empty( $data['withdrawal_id'] ) ) {
        return cfp_np_process_payout_ipn( $data );
    }

    // ── HANDLE DEPOSIT IPN ───────────────────────────────────
    // Only credit on 'finished' or 'confirmed' statuses
    if ( ! in_array( $payment_status, ['finished', 'confirmed', 'partially_paid'], true ) ) {
        // Update our record status if it exists
        $wpdb->update(
            CFP_TABLE_NP_DEPOSITS,
            ['status' => $payment_status, 'raw_ipn' => json_encode( $data )],
            ['np_payment_id' => $payment_id]
        );
        return 'STATUS_UPDATED_NOT_CREDITED';
    }

    // Check for duplicate credit
    $existing = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_NP_DEPOSITS . " WHERE np_payment_id=%s", $payment_id
    ) );

    if ( $existing && $existing->status === 'credited' ) {
        return 'DUPLICATE_IGNORED';
    }

    // Find the user by order_id (we embed user_id in order_id as "cfp_user_123")
    $user_id = 0;
    if ( preg_match( '/cfp_user_(\d+)/', $order_id, $m ) ) {
        $user_id = intval( $m[1] );
    }

    if ( ! $user_id && $existing ) {
        $user_id = (int) $existing->user_id;
    }

    if ( ! $user_id ) {
        cfp_np_log_ipn_failure( 'Cannot resolve user from order_id: ' . $order_id, $data );
        return 'USER_NOT_FOUND';
    }

    $user = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . CFP_TABLE_USERS . " WHERE id=%d", $user_id ) );
    if ( ! $user ) return 'USER_NOT_FOUND';
    if ( $user->is_banned ) return 'USER_BANNED';

    // Convert the paid crypto amount to satoshis equivalent for the balance
    // We store the USD value and let the admin set a sat-per-usd rate, OR
    // we use price_amount (USD) and convert at the faucet's configured BTC price.
    $sat_amount = cfp_np_convert_to_sat( $pay_amount, $pay_currency, $price_amount );

    if ( $sat_amount <= 0 ) {
        cfp_np_log_ipn_failure( 'Zero sat conversion for ' . $pay_amount . ' ' . $pay_currency, $data );
        return 'ZERO_SAT';
    }

    // Credit balance
    $wpdb->query( $wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
        $sat_amount, $user_id
    ) );

    // Upsert deposit record
    if ( $existing ) {
        $wpdb->update(
            CFP_TABLE_NP_DEPOSITS,
            ['status' => 'credited', 'amount_sat' => $sat_amount, 'raw_ipn' => json_encode( $data )],
            ['np_payment_id' => $payment_id]
        );
    } else {
        $wpdb->insert( CFP_TABLE_NP_DEPOSITS, [
            'user_id'       => $user_id,
            'np_payment_id' => $payment_id,
            'order_id'      => $order_id,
            'currency'      => $pay_currency,
            'pay_amount'    => $pay_amount,
            'amount_sat'    => $sat_amount,
            'price_amount'  => $price_amount,
            'status'        => 'credited',
            'raw_ipn'       => json_encode( $data ),
        ] );
    }

    // Transaction log
    $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
        'user_id'     => $user_id,
        'type'        => 'nowpayments_deposit',
        'amount_sat'  => $sat_amount,
        'description' => "NOWPayments deposit ({$pay_amount} {$pay_currency}) ID:{$payment_id}",
    ] );

    // Referral bonus on first NP deposit
    $referral_bonus_pct = floatval( cfp_get_setting( 'referral_deposit_bonus_pct', 0 ) );
    if ( $referral_bonus_pct > 0 && ! empty( $user->referred_by ) ) {
        $deposit_count = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM " . CFP_TABLE_NP_DEPOSITS . " WHERE user_id=%d AND status='credited'", $user_id
        ) );
        if ( (int) $deposit_count === 1 ) {
            $ref = $wpdb->get_row( $wpdb->prepare(
                "SELECT * FROM " . CFP_TABLE_USERS . " WHERE ref_code=%s", $user->referred_by
            ) );
            if ( $ref && ! $ref->is_banned ) {
                $bonus = (int) floor( $sat_amount * $referral_bonus_pct / 100 );
                if ( $bonus > 0 ) {
                    $wpdb->query( $wpdb->prepare(
                        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
                        $bonus, $ref->id
                    ) );
                    $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
                        'user_id'     => $ref->id,
                        'type'        => 'referral_deposit_bonus',
                        'amount_sat'  => $bonus,
                        'description' => "Referral deposit bonus ({$referral_bonus_pct}%) from NP deposit by user #{$user_id}",
                    ] );
                }
            }
        }
    }

    return 'CREDITED';
}

/* ============================================================
   PROCESS PAYOUT (WITHDRAWAL) IPN
   ============================================================ */
function cfp_np_process_payout_ipn( $data ) {
    global $wpdb;
    $withdrawal_id = sanitize_text_field( $data['withdrawal_id'] ?? $data['batch_withdrawal_id'] ?? '' );
    $status        = sanitize_text_field( $data['status'] ?? '' );

    if ( empty( $withdrawal_id ) ) return 'NO_WITHDRAWAL_ID';

    $rec = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_NP_WITHDRAWALS . " WHERE np_payout_id=%s", $withdrawal_id
    ) );

    if ( ! $rec ) return 'WITHDRAWAL_NOT_FOUND';

    $mapped_status = match( $status ) {
        'COMPLETED', 'DONE' => 'paid',
        'FAILED', 'REJECTED' => 'failed',
        default => $status,
    };

    $wpdb->update(
        CFP_TABLE_NP_WITHDRAWALS,
        ['status' => $mapped_status, 'raw_ipn' => json_encode( $data ), 'processed_at' => current_time( 'mysql' )],
        ['np_payout_id' => $withdrawal_id]
    );

    // If failed, refund the user
    if ( $mapped_status === 'failed' ) {
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
            $rec->amount_sat + $rec->fee_sat, $rec->user_id
        ) );
        $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
            'user_id'     => $rec->user_id,
            'type'        => 'nowpayments_withdrawal_refund',
            'amount_sat'  => $rec->amount_sat + $rec->fee_sat,
            'description' => "NOWPayments payout failed — refunded (ID:{$withdrawal_id})",
        ] );
    }

    return 'PAYOUT_STATUS_UPDATED';
}

/* ============================================================
   CONVERT CRYPTO AMOUNT TO SATOSHIS (internal balance unit)
   Uses the stored BTC live price or a fixed sat-per-USD rate.
   ============================================================ */
function cfp_np_convert_to_sat( $pay_amount, $currency, $price_amount_usd = 0 ) {
    // Strategy 1: if currency is BTC or SAT, convert directly
    $currency = strtolower( $currency );
    if ( $currency === 'btc' ) {
        return (int) round( $pay_amount * 100000000 );
    }
    if ( $currency === 'sat' || $currency === 'sats' ) {
        return (int) round( $pay_amount );
    }

    // Strategy 2: admin-configured sat-per-USD rate
    $sat_per_usd = floatval( cfp_get_setting( 'np_sat_per_usd', 0 ) );
    if ( $sat_per_usd > 0 && $price_amount_usd > 0 ) {
        return (int) round( $price_amount_usd * $sat_per_usd );
    }

    // Strategy 3: use the live BTC price from our live-price module
    $btc_price_usd = floatval( get_transient( 'cfp_btc_price_usd' ) );
    if ( $btc_price_usd > 0 && $price_amount_usd > 0 ) {
        $btc_amount = $price_amount_usd / $btc_price_usd;
        return (int) round( $btc_amount * 100000000 );
    }

    // Fallback: return 0 and let admin handle manually
    return 0;
}

/* ============================================================
   LOG IPN FAILURES (security audit trail)
   ============================================================ */
function cfp_np_log_ipn_failure( $reason, $data ) {
    $log = get_option( 'cfp_np_ipn_failure_log', [] );
    array_unshift( $log, [
        'time'   => current_time( 'mysql' ),
        'reason' => $reason,
        'fields' => array_intersect_key( (array) $data, array_flip( ['payment_id','order_id','payment_status','pay_currency','actually_paid'] ) ),
    ] );
    $log = array_slice( $log, 0, 100 );
    update_option( 'cfp_np_ipn_failure_log', $log, false );
}
