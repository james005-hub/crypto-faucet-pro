<?php
/**
 * Provably Fair — server seed + client seed + nonce system.
 * Every game roll is verifiable by the player after the round.
 *
 * Flow:
 *  1. On first play (or seed rotation), a new server seed is generated.
 *     Only its SHA-256 hash is shown to the player upfront.
 *  2. Player can set their own client seed.
 *  3. Each roll = HMAC-SHA256(server_seed, client_seed:nonce), converted to a number.
 *  4. After rotating seeds, the old server seed is revealed so the player
 *     can verify every past roll was fair.
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   CORE PROVABLY FAIR FUNCTIONS
   ============================================================ */

function cfp_pf_get_or_create_seed( $user_id ) {
    global $wpdb;
    $seed = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_GAME_SEEDS . " WHERE user_id=%d AND is_revealed=0 ORDER BY id DESC LIMIT 1",
        $user_id
    ));
    if ( $seed ) return $seed;
    return cfp_pf_new_seed( $user_id );
}

function cfp_pf_new_seed( $user_id, $client_seed = null ) {
    global $wpdb;
    // Reveal existing active seed first
    $wpdb->query( $wpdb->prepare(
        "UPDATE " . CFP_TABLE_GAME_SEEDS . " SET is_revealed=1 WHERE user_id=%d AND is_revealed=0",
        $user_id
    ));
    // Expose server_seed on old records now
    $wpdb->query( $wpdb->prepare(
        "UPDATE " . CFP_TABLE_GAME_SEEDS . " SET server_seed=server_seed_hash WHERE user_id=%d AND is_revealed=1 AND server_seed IS NULL",
        $user_id
    ));

    $server_seed = bin2hex( random_bytes(32) );
    $server_hash = hash('sha256', $server_seed);
    $client      = $client_seed ?? bin2hex( random_bytes(8) );
    $wpdb->insert( CFP_TABLE_GAME_SEEDS, [
        'user_id'          => $user_id,
        'server_seed_hash' => $server_hash,
        'server_seed'      => null, // hidden until rotated
        'client_seed'      => $client,
        'nonce'            => 0,
        'is_revealed'      => 0,
    ]);
    $id = $wpdb->insert_id;
    // Store actual seed separately in options (server-side only, never exposed until revealed)
    update_option( "cfp_ss_{$id}", $server_seed, false );
    // Update user's active seed
    $wpdb->update( CFP_TABLE_USERS, ['current_seed_id' => $id], ['id' => $user_id] );
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . CFP_TABLE_GAME_SEEDS . " WHERE id=%d", $id ) );
}

function cfp_pf_roll( $user_id, $max = 100 ) {
    global $wpdb;
    $seed = cfp_pf_get_or_create_seed( $user_id );
    $server_seed = get_option( "cfp_ss_{$seed->id}", '' );
    $combined    = $seed->client_seed . ':' . $seed->nonce;
    $hmac        = hash_hmac( 'sha256', $combined, $server_seed );
    // Take first 8 hex chars → integer → mod max
    $num  = hexdec( substr($hmac, 0, 8) );
    $roll = ($num % $max) + 1;
    // Increment nonce
    $wpdb->query( $wpdb->prepare(
        "UPDATE " . CFP_TABLE_GAME_SEEDS . " SET nonce=nonce+1 WHERE id=%d",
        $seed->id
    ));
    return [
        'roll'        => $roll,
        'seed_id'     => $seed->id,
        'nonce'       => $seed->nonce,
        'client_seed' => $seed->client_seed,
        'server_hash' => $seed->server_seed_hash,
    ];
}

function cfp_pf_reveal_and_rotate( $user_id, $new_client_seed = null ) {
    global $wpdb;
    $seed = cfp_pf_get_or_create_seed( $user_id );
    $server_seed = get_option( "cfp_ss_{$seed->id}", '' );
    // Write server seed into the row so it's visible
    $wpdb->update( CFP_TABLE_GAME_SEEDS,
        ['is_revealed' => 1, 'server_seed' => $server_seed],
        ['id' => $seed->id]
    );
    delete_option( "cfp_ss_{$seed->id}" );
    $new = cfp_pf_new_seed( $user_id, $new_client_seed );
    return ['old_server_seed' => $server_seed, 'new' => $new];
}

/* ============================================================
   AJAX: GET SEED INFO (shown in widget) - PROTECTED
   ============================================================ */
add_action('wp_ajax_cfp_pf_info', 'cfp_ajax_pf_info');
function cfp_ajax_pf_info() {
    check_ajax_referer('cfp_nonce','nonce');
    $user = cfp_require_auth();
    $seed = cfp_pf_get_or_create_seed( $user->id );
    wp_send_json_success([
        'server_hash' => $seed->server_seed_hash,
        'client_seed' => $seed->client_seed,
        'nonce'       => $seed->nonce,
        'seed_id'     => $seed->id,
    ]);
}

/* ============================================================
   AJAX: ROTATE SEED (player changes client seed) - PROTECTED
   ============================================================ */
add_action('wp_ajax_cfp_pf_rotate', 'cfp_ajax_pf_rotate');
function cfp_ajax_pf_rotate() {
    check_ajax_referer('cfp_nonce','nonce');
    $user = cfp_require_auth();
    $cs   = sanitize_text_field( substr( $_POST['client_seed'] ?? '', 0, 64 ) );
    
    // Validate client seed format
    if (!empty($cs) && !preg_match('/^[a-f0-9]{8,64}$/i', $cs)) {
        wp_send_json_error(['msg'=>'Invalid client seed format. Use 8-64 hex characters.']);
    }
    
    $result = cfp_pf_reveal_and_rotate( $user->id, $cs ?: null );
    wp_send_json_success([
        'msg'             => '✅ Seeds rotated. Old server seed revealed below.',
        'old_server_seed' => $result['old_server_seed'],
        'new_server_hash' => $result['new']->server_seed_hash,
        'new_client_seed' => $result['new']->client_seed,
    ]);
}

/* ============================================================
   AJAX: VERIFY A PAST ROLL - PUBLIC (anyone can verify)
   ============================================================ */
add_action('wp_ajax_cfp_pf_verify', 'cfp_ajax_pf_verify');
function cfp_ajax_pf_verify() {
    check_ajax_referer('cfp_nonce','nonce');
    $server_seed = sanitize_text_field( $_POST['server_seed'] ?? '' );
    $client_seed = sanitize_text_field( $_POST['client_seed'] ?? '' );
    $nonce       = intval( $_POST['nonce'] ?? 0 );
    $max         = intval( $_POST['max'] ?? 100 );
    
    // Validate input
    if ( empty($server_seed) || empty($client_seed) )
        wp_send_json_error(['msg'=>'Enter both seeds.']);
    if (strlen($server_seed) < 64 || strlen($client_seed) < 4)
        wp_send_json_error(['msg'=>'Invalid seed lengths.']);
    if ($max < 2 || $max > 1000000)
        wp_send_json_error(['msg'=>'Invalid max value.']);
    
    $combined = $client_seed . ':' . $nonce;
    $hmac     = hash_hmac('sha256', $combined, $server_seed);
    $roll     = (hexdec(substr($hmac,0,8)) % $max) + 1;
    $hash     = hash('sha256', $server_seed);
    wp_send_json_success([
        'roll'        => $roll,
        'hmac'        => $hmac,
        'server_hash' => $hash,
        'msg'         => "✅ Verified! Roll = {$roll} (out of {$max}). Server hash: " . substr($hash,0,16) . '…',
    ]);
}

/* ============================================================
   SHORTCODE: [cfp_provably_fair]
   ============================================================ */
add_shortcode('cfp_provably_fair', function() {
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-pf-widget">
        <h2>🔐 Provably Fair</h2>
        <p class="sub">Every game result is cryptographically verifiable. You can confirm no roll was manipulated.</p>
        <div id="cfp-pf-info">
            <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:10px;padding:14px;margin-bottom:14px">
                <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:4px">Server Seed Hash (SHA-256)</div>
                <div id="cfp-pf-hash" style="font-family:monospace;font-size:.78rem;color:#f7931a;word-break:break-all">Loading...</div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
                <div>
                    <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:#555;margin-bottom:4px">Client Seed</div>
                    <input class="cfp-input" type="text" id="cfp-pf-cs" style="margin-bottom:0;font-family:monospace;font-size:.8rem">
                </div>
                <div>
                    <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:#555;margin-bottom:4px">Nonce</div>
                    <input class="cfp-input" type="text" id="cfp-pf-nonce" readonly style="margin-bottom:0;font-family:monospace;font-size:.8rem;opacity:.6">
                </div>
            </div>
            <button class="cfp-btn-full" onclick="cfpPfRotate()" style="margin-bottom:10px">🔄 Rotate Seeds (reveals old server seed)</button>
            <div id="cfp-pf-reveal" style="display:none;background:#0a1a0a;border:1px solid #22c55e33;border-radius:10px;padding:14px;margin-bottom:14px">
                <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:#22c55e;margin-bottom:6px">Revealed Server Seed</div>
                <div id="cfp-pf-old-seed" style="font-family:monospace;font-size:.78rem;color:#22c55e;word-break:break-all"></div>
            </div>
        </div>
        <div id="cfp-pf-login-required" style="display:none;background:#1a0a0a;border:1px solid #ef444433;border-radius:10px;padding:14px;text-align:center">
            <p style="color:#ef4444;margin:0">Please log in to view your provably fair seeds.</p>
        </div>
        <div style="border-top:1px solid #1c1c1c;margin-top:18px;padding-top:18px">
            <h3 style="font-family:'Oswald',sans-serif;color:#fff;font-size:1rem;margin:0 0 12px;text-transform:uppercase;letter-spacing:1px">🔍 Verify a Past Roll</h3>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
                <input class="cfp-input" type="text" id="cfp-vfy-ss" placeholder="Server seed (after reveal)" style="font-family:monospace;font-size:.78rem">
                <input class="cfp-input" type="text" id="cfp-vfy-cs" placeholder="Client seed" style="font-family:monospace;font-size:.78rem">
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px">
                <input class="cfp-input" type="number" id="cfp-vfy-nonce" placeholder="Nonce" style="font-family:monospace">
                <input class="cfp-input" type="number" id="cfp-vfy-max" placeholder="Max (e.g. 100)" value="100" style="font-family:monospace">
            </div>
            <button class="cfp-btn-full" onclick="cfpPfVerify()" style="background:#3b82f6">Verify Roll</button>
            <div id="cfp-vfy-result" style="margin-top:10px;font-size:.85rem"></div>
        </div>
        <div id="cfp-pf-msg" style="margin-top:10px"></div>
    </div>
    <script>
    const cfpPfAjax='<?=esc_js($ajax)?>'; const cfpPfNonce='<?=esc_js($nonce)?>';
    function cfpPfLoad(){
        const fd=new FormData(); fd.append('action','cfp_pf_info'); fd.append('nonce',cfpPfNonce);
        if(typeof cfpGetSessionToken === 'function') fd.append('cfp_session_token',cfpGetSessionToken());
        fetch(cfpPfAjax,{method:'POST',body:fd}).then(r=>r.json()).then(d=>{
            if(d.success){
                document.getElementById('cfp-pf-hash').textContent=d.data.server_hash;
                document.getElementById('cfp-pf-cs').value=d.data.client_seed;
                document.getElementById('cfp-pf-nonce').value=d.data.nonce;
                document.getElementById('cfp-pf-info').style.display='';
                document.getElementById('cfp-pf-login-required').style.display='none';
            } else {
                document.getElementById('cfp-pf-info').style.display='none';
                document.getElementById('cfp-pf-login-required').style.display='';
            }
        });
    }
    async function cfpPfRotate(){
        const cs=document.getElementById('cfp-pf-cs').value;
        const fd=new FormData(); fd.append('action','cfp_pf_rotate'); fd.append('nonce',cfpPfNonce); fd.append('client_seed',cs);
        if(typeof cfpGetSessionToken === 'function') fd.append('cfp_session_token',cfpGetSessionToken());
        const r=await fetch(cfpPfAjax,{method:'POST',body:fd}); const d=await r.json();
        if(!d.success){ document.getElementById('cfp-pf-msg').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`; return; }
        document.getElementById('cfp-pf-hash').textContent=d.data.new_server_hash;
        document.getElementById('cfp-pf-cs').value=d.data.new_client_seed;
        document.getElementById('cfp-pf-nonce').value='0';
        document.getElementById('cfp-pf-old-seed').textContent=d.data.old_server_seed;
        document.getElementById('cfp-pf-reveal').style.display='';
        document.getElementById('cfp-pf-msg').innerHTML=`<div class="cfp-msg success">${d.data.msg}</div>`;
    }
    async function cfpPfVerify(){
        const ss=document.getElementById('cfp-vfy-ss').value;
        const cs=document.getElementById('cfp-vfy-cs').value;
        const nc=document.getElementById('cfp-vfy-nonce').value;
        const mx=document.getElementById('cfp-vfy-max').value;
        const fd=new FormData(); fd.append('action','cfp_pf_verify'); fd.append('nonce',cfpPfNonce);
        fd.append('server_seed',ss); fd.append('client_seed',cs); fd.append('nonce',nc); fd.append('max',mx);
        const r=await fetch(cfpPfAjax,{method:'POST',body:fd}); const d=await r.json();
        const el=document.getElementById('cfp-vfy-result');
        el.innerHTML=`<div class="cfp-msg ${d.success?'success':'error'}">${d.success?d.data.msg:d.data.msg}</div>`;
    }
    cfpPfLoad();
    </script>
    <?php return ob_get_clean();
});
