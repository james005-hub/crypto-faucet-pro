<?php
/**
 * Security HTTP Headers
 *
 * Implements modern security headers to protect against XSS, clickjacking,
 * MIME-sniffing, and other common web vulnerabilities.
 *
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   SEND SECURITY HEADERS
   ============================================================ */

/**
 * Add security headers to all plugin responses
 */
function cfp_send_security_headers() {
    // Skip if headers already sent or in admin
    if (headers_sent() || is_admin()) {
        return;
    }

    // Check if security headers are enabled
    if (cfp_get_setting('security_headers_enabled', '1') !== '1') {
        return;
    }

    // 1. Content Security Policy (CSP)
    // Prevents XSS attacks by controlling which resources can be loaded
    $csp_enabled = cfp_get_setting('csp_enabled', '1');
    if ($csp_enabled === '1') {
        $csp_policy = cfp_build_csp_policy();
        header("Content-Security-Policy: {$csp_policy}");
    }

    // 2. X-Frame-Options
    // Prevents clickjacking attacks
    $frame_options = cfp_get_setting('x_frame_options', 'SAMEORIGIN');
    if (!empty($frame_options)) {
        header("X-Frame-Options: {$frame_options}");
    }

    // 3. X-Content-Type-Options
    // Prevents MIME-sniffing attacks
    header('X-Content-Type-Options: nosniff');

    // 4. X-XSS-Protection (legacy but still useful for old browsers)
    header('X-XSS-Protection: 1; mode=block');

    // 5. Referrer-Policy
    // Controls referrer information sent with requests
    $referrer_policy = cfp_get_setting('referrer_policy', 'strict-origin-when-cross-origin');
    header("Referrer-Policy: {$referrer_policy}");

    // 6. Permissions-Policy (formerly Feature-Policy)
    // Restricts browser features and APIs
    $permissions_policy = cfp_get_setting('permissions_policy', 'geolocation=(), microphone=(), camera=()');
    if (!empty($permissions_policy)) {
        header("Permissions-Policy: {$permissions_policy}");
    }

    // 7. Strict-Transport-Security (HSTS) - only if HTTPS
    if (is_ssl() && cfp_get_setting('hsts_enabled', '1') === '1') {
        $max_age = cfp_get_setting('hsts_max_age', '31536000'); // 1 year default
        $include_subdomains = cfp_get_setting('hsts_include_subdomains', '1') === '1' ? '; includeSubDomains' : '';
        $preload = cfp_get_setting('hsts_preload', '0') === '1' ? '; preload' : '';
        header("Strict-Transport-Security: max-age={$max_age}{$include_subdomains}{$preload}");
    }

    // 8. Cross-Origin-Opener-Policy
    // Protects against Spectre-like attacks
    header('Cross-Origin-Opener-Policy: same-origin-allow-popups');

    // 9. Cross-Origin-Resource-Policy
    header('Cross-Origin-Resource-Policy: same-site');

    // 10. Cross-Origin-Embedder-Policy (optional, can break embeds)
    if (cfp_get_setting('coep_enabled', '0') === '1') {
        header('Cross-Origin-Embedder-Policy: require-corp');
    }
}

// Hook to send headers early
add_action('send_headers', 'cfp_send_security_headers');
add_action('template_redirect', 'cfp_send_security_headers', 1);

/* ============================================================
   CONTENT SECURITY POLICY BUILDER
   ============================================================ */

/**
 * Build CSP policy based on plugin needs
 */
function cfp_build_csp_policy() {
    // Get custom CSP or use default
    $custom_csp = cfp_get_setting('custom_csp', '');

    if (!empty($custom_csp)) {
        return $custom_csp;
    }

    // Build default CSP for crypto faucet
    $directives = [];

    // Default-src: Fallback for other directives
    $directives[] = "default-src 'self'";

    // Script-src: JavaScript sources
    // Note: 'unsafe-inline' needed for WordPress inline scripts, consider using nonces in production
    $script_src = ["'self'", "'unsafe-inline'"];

    // Allow reCAPTCHA if enabled
    if (cfp_get_setting('captcha_enabled', '0') === '1') {
        $script_src[] = 'https://www.google.com';
        $script_src[] = 'https://www.grecaptcha.net';
    }

    // Allow CDNs if configured
    $allowed_cdns = cfp_get_setting('csp_allowed_cdns', '');
    if (!empty($allowed_cdns)) {
        $cdns = array_filter(array_map('trim', explode("\n", $allowed_cdns)));
        $script_src = array_merge($script_src, $cdns);
    }

    $directives[] = "script-src " . implode(' ', $script_src);

    // Style-src: CSS sources
    $directives[] = "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com";

    // Img-src: Image sources (allow data: for inline images)
    $directives[] = "img-src 'self' data: https:";

    // Font-src: Font sources
    $directives[] = "font-src 'self' data: https://fonts.gstatic.com";

    // Connect-src: AJAX/WebSocket/EventSource
    $connect_src = ["'self'"];

    // Allow Coinbase API
    if (cfp_get_setting('blockchain_enabled', '0') === '1') {
        $connect_src[] = 'https://faucetpay.io';
    }

    // Allow NOWPayments API
    if (cfp_get_setting('nowpayments_enabled', '0') === '1') {
        $connect_src[] = 'https://api.nowpayments.io';
    }

    // Allow price APIs
    $connect_src[] = 'https://blockchain.info';
    $connect_src[] = 'https://api.coinbase.com';

    $directives[] = "connect-src " . implode(' ', $connect_src);

    // Frame-src: Frames/iframes
    $frame_src = ["'self'"];
    if (cfp_get_setting('captcha_enabled', '0') === '1') {
        $frame_src[] = 'https://www.google.com';
        $frame_src[] = 'https://www.grecaptcha.net';
    }
    $directives[] = "frame-src " . implode(' ', $frame_src);

    // Object-src: Plugins (Flash, etc.)
    $directives[] = "object-src 'none'";

    // Base-uri: Restrict base tag
    $directives[] = "base-uri 'self'";

    // Form-action: Restrict form submissions
    $directives[] = "form-action 'self'";

    // Frame-ancestors: Who can embed this site
    $directives[] = "frame-ancestors 'self'";

    // Upgrade-insecure-requests: Auto-upgrade HTTP to HTTPS
    if (is_ssl()) {
        $directives[] = "upgrade-insecure-requests";
    }

    // Block-all-mixed-content: Don't load HTTP resources on HTTPS pages
    if (is_ssl() && cfp_get_setting('block_mixed_content', '1') === '1') {
        $directives[] = "block-all-mixed-content";
    }

    return implode('; ', $directives);
}

/* ============================================================
   REMOVE SENSITIVE HEADERS
   ============================================================ */

/**
 * Remove WordPress version and other sensitive headers
 */
function cfp_remove_sensitive_headers($headers) {
    // Remove X-Powered-By if present
    unset($headers['X-Powered-By']);

    // Remove Server header (requires server config)
    unset($headers['Server']);

    return $headers;
}
add_filter('wp_headers', 'cfp_remove_sensitive_headers');

// Remove WordPress version from HTML
remove_action('wp_head', 'wp_generator');

// Remove WordPress version from RSS feeds
add_filter('the_generator', '__return_empty_string');

/* ============================================================
   ADMIN: SECURITY HEADERS CONFIGURATION
   ============================================================ */

add_action('cfp_security_extra_cards', function() {
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🛡️ Security Headers</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">
            HTTP security headers protect against XSS, clickjacking, and other attacks.
        </p>

        <table class="cfp-table">
            <thead>
                <tr>
                    <th>Header</th>
                    <th>Status</th>
                    <th>Protection</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><strong>Content-Security-Policy</strong></td>
                    <td><?=cfp_get_setting('csp_enabled', '1') === '1' ? '<span style="color:#0f0">✓ Enabled</span>' : '<span style="color:#f00">✗ Disabled</span>'?></td>
                    <td>XSS, injection attacks</td>
                </tr>
                <tr>
                    <td><strong>X-Frame-Options</strong></td>
                    <td><span style="color:#0f0">✓ Enabled</span></td>
                    <td>Clickjacking</td>
                </tr>
                <tr>
                    <td><strong>X-Content-Type-Options</strong></td>
                    <td><span style="color:#0f0">✓ Enabled</span></td>
                    <td>MIME-sniffing</td>
                </tr>
                <tr>
                    <td><strong>Strict-Transport-Security</strong></td>
                    <td><?=is_ssl() && cfp_get_setting('hsts_enabled', '1') === '1' ? '<span style="color:#0f0">✓ Enabled</span>' : '<span style="color:#f90">⚠ Requires HTTPS</span>'?></td>
                    <td>MITM attacks</td>
                </tr>
                <tr>
                    <td><strong>Referrer-Policy</strong></td>
                    <td><span style="color:#0f0">✓ Enabled</span></td>
                    <td>Information leakage</td>
                </tr>
                <tr>
                    <td><strong>Permissions-Policy</strong></td>
                    <td><span style="color:#0f0">✓ Enabled</span></td>
                    <td>Unauthorized feature access</td>
                </tr>
            </tbody>
        </table>

        <?php if (!is_ssl()): ?>
        <div style="margin-top:16px;padding:12px;background:#3a1f00;border-left:4px solid #f90;border-radius:4px">
            <strong style="color:#f90">⚠️ HTTPS Not Detected</strong>
            <p style="margin:8px 0 0;font-size:.85rem;color:#bbb">
                Your site is not using HTTPS. For production use, HTTPS is REQUIRED for:
            </p>
            <ul style="margin:8px 0 0 20px;font-size:.85rem;color:#bbb">
                <li>Secure session cookies</li>
                <li>HSTS header protection</li>
                <li>Payment API compliance</li>
                <li>SEO and user trust</li>
            </ul>
        </div>
        <?php endif; ?>

        <div style="margin-top:16px;padding:12px;background:#1a1a1a;border-radius:8px">
            <label style="display:flex;align-items:center;cursor:pointer">
                <input type="checkbox" id="cfp-headers-enabled"
                       <?=cfp_get_setting('security_headers_enabled','1')==='1'?'checked':''?>
                       onchange="cfpSaveHeaderSetting('security_headers_enabled', this.checked)">
                <span style="margin-left:8px;font-weight:700">Enable Security Headers (Recommended)</span>
            </label>
        </div>
    </div>

    <script>
    async function cfpSaveHeaderSetting(key, enabled) {
        const fd = new FormData();
        fd.append('action', 'cfp_admin_save_setting');
        fd.append('nonce', '<?=wp_create_nonce('cfp_admin_action')?>');
        fd.append('key', key);
        fd.append('value', enabled ? '1' : '0');

        try {
            await fetch('<?=admin_url('admin-ajax.php')?>', {method: 'POST', body: fd});
            alert('Setting saved');
        } catch(e) {
            alert('Error saving setting');
        }
    }
    </script>
    <?php
}, 15);

/* ============================================================
   SECURITY HEADER TESTING
   ============================================================ */

/**
 * Test security headers configuration
 * Call from browser console or admin page
 */
function cfp_test_security_headers() {
    $headers = headers_list();

    echo "<h3>Current Security Headers:</h3>";
    echo "<pre>";
    foreach ($headers as $header) {
        $lower = strtolower($header);
        if (strpos($lower, 'content-security-policy') !== false ||
            strpos($lower, 'x-frame-options') !== false ||
            strpos($lower, 'x-content-type') !== false ||
            strpos($lower, 'strict-transport') !== false ||
            strpos($lower, 'referrer-policy') !== false ||
            strpos($lower, 'permissions-policy') !== false) {
            echo htmlspecialchars($header) . "\n";
        }
    }
    echo "</pre>";
}
