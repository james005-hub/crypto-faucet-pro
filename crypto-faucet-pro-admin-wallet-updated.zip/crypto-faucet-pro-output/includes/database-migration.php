<?php
/**
 * Database Security & Performance Optimization
 *
 * Adds indexes, constraints, and migration for better security and performance.
 * Runs automatically on plugin activation.
 *
 * To trigger manually (e.g. after a major upgrade):
 *   1. Add to wp-config.php:  define( 'CFP_RUN_MIGRATION', true );
 *   2. Load any admin page once to fire the migration.
 *   3. IMPORTANT: Remove the constant from wp-config.php immediately after.
 *      Leaving it defined causes the migration to re-run on every admin page
 *      load, which adds unnecessary database overhead in production.
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// NOTE: cfp_run_db_migration() is called from cfp_activate() in activation.php
add_action( 'cfp_run_db_migration', 'cfp_run_db_migration' );

/**
 * Allow one-shot manual trigger via CFP_RUN_MIGRATION constant.
 * Fires on the first admin_init after the constant is defined, then
 * logs a warning reminding the operator to remove it.
 */
add_action( 'admin_init', function () {
    if ( ! defined( 'CFP_RUN_MIGRATION' ) || ! CFP_RUN_MIGRATION ) return;
    if ( ! current_user_can( 'manage_options' ) ) return;

    cfp_run_db_migration();

    // Warn loudly in the admin so the constant doesn't get forgotten.
    add_action( 'admin_notices', function () {
        echo '<div class="notice notice-warning is-dismissible"><p>'
           . '<strong>Crypto Faucet Pro — Migration complete.</strong> '
           . 'Please remove <code>define( \'CFP_RUN_MIGRATION\', true );</code> '
           . 'from your <code>wp-config.php</code> immediately. '
           . 'Leaving it defined will re-run the migration on every admin page load.'
           . '</p></div>';
    } );
} );

function cfp_run_db_migration() {
    global $wpdb;
    
    $charset_collate = $wpdb->get_charset_collate();
    $table_prefix = $wpdb->prefix;
    
    $migrations = [];
    
    // Users table indexes
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_users_email ON {$table_prefix}cfp_users(email)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_users_ref_code ON {$table_prefix}cfp_users(ref_code)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_users_is_banned ON {$table_prefix}cfp_users(is_banned)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_users_last_claim ON {$table_prefix}cfp_users(last_claim)";
    
    // Claims table indexes
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_claims_user_id ON {$table_prefix}cfp_claims(user_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_claims_ip ON {$table_prefix}cfp_claims(ip_address)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_claims_created ON {$table_prefix}cfp_claims(created_at)";
    
    // Transactions table indexes
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_tx_user_id ON {$table_prefix}cfp_transactions(user_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_tx_type ON {$table_prefix}cfp_transactions(type)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_tx_created ON {$table_prefix}cfp_transactions(created_at)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_tx_user_created ON {$table_prefix}cfp_transactions(user_id, created_at)";
    
    // Game tables indexes
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_slots_user ON {$table_prefix}cfp_slots_games(user_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_coinflip_user ON {$table_prefix}cfp_coinflip_games(user_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_dice_user ON {$table_prefix}cfp_dice_games(user_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_crash_user ON {$table_prefix}cfp_crash_games(user_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_wheel_user ON {$table_prefix}cfp_wheel_games(user_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_multiply_user ON {$table_prefix}cfp_multiply_games(user_id)";
    
    // Withdrawals indexes
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_withdraw_user ON {$table_prefix}cfp_withdrawals(user_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_withdraw_status ON {$table_prefix}cfp_withdrawals(status)";
    
    // IP limits indexes
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_ip_limits_ip ON {$table_prefix}cfp_ip_limits(ip_address)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_ip_limits_window ON {$table_prefix}cfp_ip_limits(window_start)";
    
    // Settings indexes
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_settings_key ON {$table_prefix}cfp_settings(setting_key(64))";
    
    // Chat indexes
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_chat_user ON {$table_prefix}cfp_chat(user_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_chat_created ON {$table_prefix}cfp_chat(created_at)";
    
    // P2P indexes
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_p2p_bets_event ON {$table_prefix}cfp_p2p_bets(event_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_p2p_bets_user ON {$table_prefix}cfp_p2p_bets(user_id)";
    
    // Game seeds indexes
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_game_seeds_user ON {$table_prefix}cfp_game_seeds(user_id)";
    $migrations[] = "CREATE INDEX IF NOT EXISTS idx_game_seeds_revealed ON {$table_prefix}cfp_game_seeds(is_revealed)";
    
    // Run migrations
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    
    $success_count = 0;
    $error_count = 0;
    $errors = [];
    
    foreach ($migrations as $sql) {
        $result = $wpdb->query($sql);
        if ($result === false) {
            $error_count++;
            $errors[] = $wpdb->last_error;
        } else {
            $success_count++;
        }
    }
    
    // Add columns if they don't exist
    $users_table = $table_prefix . 'cfp_users';
    
    // Check if password_hash column exists
    $has_password_hash = $wpdb->get_var("SELECT COUNT(*) FROM information_schema.columns 
        WHERE table_schema = DATABASE() AND table_name = '$users_table' AND column_name = 'password_hash'");
    
    if (!$has_password_hash) {
        $wpdb->query("ALTER TABLE $users_table 
            ADD COLUMN password_hash VARCHAR(255) AFTER email,
            ADD COLUMN is_verified TINYINT(1) DEFAULT 0 AFTER password_hash,
            ADD COLUMN twofa_enabled TINYINT(1) DEFAULT 0 AFTER is_verified,
            ADD COLUMN twofa_secret VARCHAR(64) AFTER twofa_enabled,
            ADD COLUMN login_token VARCHAR(64) AFTER twofa_secret,
            ADD COLUMN login_token_expires DATETIME AFTER login_token,
            ADD COLUMN last_login DATETIME AFTER login_token_expires,
            ADD COLUMN current_seed_id INT AFTER last_login,
            ADD COLUMN xp_level INT DEFAULT 1 AFTER current_seed_id,
            ADD COLUMN xp_total INT DEFAULT 0 AFTER xp_level");
    }
    
    // Verify tokens table
    $verify_table = $table_prefix . 'cfp_verify_tokens';
    $has_verify_table = $wpdb->get_var("SELECT COUNT(*) FROM information_schema.tables 
        WHERE table_schema = DATABASE() AND table_name = '$verify_table'");
    
    if (!$has_verify_table) {
        $sql = "CREATE TABLE $verify_table (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            token VARCHAR(255) NOT NULL,
            type VARCHAR(20) NOT NULL,
            expires_at DATETIME NOT NULL,
            used_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_token (token(64)),
            INDEX idx_user (user_id)
        ) $charset_collate";
        dbDelta($sql);
    }
    
    // Update settings table for session storage
    $settings_table = $table_prefix . 'cfp_settings';
    $has_session_col = $wpdb->get_var("SELECT COUNT(*) FROM information_schema.columns 
        WHERE table_schema = DATABASE() AND table_name = '$settings_table' AND column_name = 'autoload'");
    
    if ($has_session_col) {
        // Add index for sessions
        $wpdb->query("CREATE INDEX idx_settings_session ON $settings_table (setting_key(32))");
    }

    // Add missing columns to claims table
    $claims_table = $table_prefix . 'cfp_claims';
    $has_seed_col = $wpdb->get_var("SELECT COUNT(*) FROM information_schema.columns 
        WHERE table_schema = DATABASE() AND table_name = '$claims_table' AND column_name = 'seed'");
    
    if (!$has_seed_col) {
        $wpdb->query("ALTER TABLE $claims_table ADD COLUMN seed VARCHAR(64) AFTER ip_address");
    }

    // Add missing columns to multiply games table
    $multiply_table = $table_prefix . 'cfp_multiply_games';
    $has_server_seed_col = $wpdb->get_var("SELECT COUNT(*) FROM information_schema.columns 
        WHERE table_schema = DATABASE() AND table_name = '$multiply_table' AND column_name = 'server_seed'");
    
    if (!$has_server_seed_col) {
        $wpdb->query("ALTER TABLE $multiply_table ADD COLUMN server_seed VARCHAR(64) AFTER payout_sat");
    }

    // Add missing column to users table for kyc_status if not exists
    $has_kyc_status = $wpdb->get_var("SELECT COUNT(*) FROM information_schema.columns 
        WHERE table_schema = DATABASE() AND table_name = '$users_table' AND column_name = 'kyc_status'");
    
    if (!$has_kyc_status) {
        $wpdb->query("ALTER TABLE $users_table ADD COLUMN kyc_status VARCHAR(20) DEFAULT NULL AFTER xp_total");
    }
    
    // Log migration results
    if (defined('WP_DEBUG') && WP_DEBUG) {
        error_log(sprintf(
            '[CFP Migration] Completed: %d success, %d errors',
            $success_count,
            $error_count
        ));
        if (!empty($errors)) {
            error_log('[CFP Migration] Errors: ' . implode(', ', array_slice($errors, 0, 5)));
        }
    }
    
    // Update plugin version
    update_option('cfp_db_version', '4.3');
    
    return [
        'success' => $success_count,
        'errors' => $error_count,
        'messages' => $errors
    ];
}

/**
 * Get migration status
 */
function cfp_get_migration_status() {
    $current_version = get_option('cfp_db_version', '0');
    return [
        'current' => $current_version,
        'required' => '4.3',
        'needs_update' => version_compare($current_version, '4.3', '<')
    ];
}

/**
 * Scheduled cleanup of old data
 */
add_action( 'init', function() {
    if ( ! wp_next_scheduled( 'cfp_daily_cleanup' ) ) {
        wp_schedule_event( time(), 'daily', 'cfp_daily_cleanup' );
    }
} );

add_action('cfp_daily_cleanup', 'cfp_cleanup_old_data');

function cfp_cleanup_old_data() {
    global $wpdb;
    $retention = intval(cfp_get_setting('audit_log_retention_days', 90));
    
    // Clean expired sessions from dedicated sessions table (replaces old settings-table hack)
    $wpdb->query( "DELETE FROM {$wpdb->prefix}cfp_sessions WHERE expires_at < NOW()" );

    // One-time cleanup: remove any legacy session_ rows that were stored in cfp_settings
    // before the 4.3 migration. Safe to run repeatedly — does nothing once cleared.
    $wpdb->query(
        "DELETE FROM " . CFP_TABLE_SETTINGS . "
         WHERE setting_key LIKE 'session_%'"
    );
    
    // Also purge legacy audit_ rows from settings (now written to error_log only)
    if ($retention > 0) {
        $wpdb->query($wpdb->prepare(
            "DELETE FROM " . CFP_TABLE_SETTINGS . "
             WHERE setting_key LIKE 'audit_%'
             AND setting_val LIKE '%\"timestamp\":\"%'
             AND DATE(JSON_EXTRACT(setting_val, '$.timestamp')) < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $retention
        ));
    }
    
    // Clean old IP limit records
    $wpdb->query(
        "DELETE FROM " . CFP_TABLE_IP_LIMITS . " 
         WHERE window_start < DATE_SUB(NOW(), INTERVAL 2 HOUR)"
    );
    
    // Clean unverified accounts (if enabled)
    $purge_days = intval(cfp_get_setting('unverified_purge_days', 0));
    if ($purge_days > 0) {
        $wpdb->query($wpdb->prepare(
            "DELETE FROM " . CFP_TABLE_USERS . " 
             WHERE is_verified = 0 
             AND balance_sat = 0 
             AND created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $purge_days
        ));
    }
    
    // Clean expired verify tokens
    $wpdb->query(
        "DELETE FROM " . CFP_TABLE_VERIFY_TOKENS . " 
         WHERE expires_at < NOW() 
         AND used_at IS NULL"
    );
}
