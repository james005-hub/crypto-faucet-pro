<?php
/**
 * Admin Notification System
 *
 * @package CryptoFaucetPro
 */

if (!defined('ABSPATH')) exit;

/* ============================================================
   ADMIN NOTIFICATION TABLES
   ============================================================ */
function cfp_create_admin_notification_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $table = $wpdb->prefix . 'cfp_admin_notifications';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table'") != $table) {
        $wpdb->query("
            CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                type enum('warning','alert','info','success') DEFAULT 'info',
                title varchar(200) NOT NULL,
                message text NOT NULL,
                is_read tinyint(1) DEFAULT 0,
                priority int(11) DEFAULT 0,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY is_read (is_read),
                KEY priority (priority),
                KEY created_at (created_at)
            ) $charset
        ");
    }
}

/* ============================================================
   CREATE ADMIN NOTIFICATION
   ============================================================ */
function cfp_create_admin_notification($type, $title, $message, $priority = 0) {
    global $wpdb;
    return $wpdb->insert($wpdb->prefix . 'cfp_admin_notifications', [
        'type' => $type,
        'title' => $title,
        'message' => $message,
        'priority' => $priority
    ]);
}

function cfp_admin_notify($type, $title, $message) {
    cfp_create_admin_notification($type, $title, $message, 0);
}

function cfp_admin_alert($title, $message) {
    cfp_create_admin_notification('alert', $title, $message, 10);
}

function cfp_admin_warning($title, $message) {
    cfp_create_admin_notification('warning', $title, $message, 5);
}

/* ============================================================
   TRIGGER ADMIN NOTIFICATIONS
   ============================================================ */
add_action('cfp_daily_interest_hook', 'cfp_check_admin_notifications');
function cfp_check_admin_notifications() {
    global $wpdb;
    
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    $total_claims = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . CFP_TABLE_CLAIMS . " WHERE DATE(created_at) = %s", $yesterday
    ));
    
    if ($total_claims < 10) {
        cfp_admin_warning('Low Activity', "Only {$total_claims} claims yesterday. Consider checking faucet settings.");
    }
    
    $failed_withdrawals = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . CFP_TABLE_WITHDRAWALS . " 
        WHERE DATE(created_at) = %s AND status = 'failed'", $yesterday
    ));
    
    if ($failed_withdrawals > 5) {
        cfp_admin_alert('High Withdrawal Failures', "{$failed_withdrawals} withdrawals failed yesterday. Check Coinbase/API settings.");
    }
    
    $new_users = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . CFP_TABLE_USERS . " WHERE DATE(created_at) = %s", $yesterday
    ));
    
    if ($new_users > 100) {
        cfp_create_admin_notification('success', 'High Signups', "{$new_users} new users registered yesterday!", 3);
    }
}

add_action('cfp_user_registered', function($user_id, $email, $username) {
    $banned_users = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_USERS . " WHERE is_banned = 1");
    
    if ($banned_users > 50) {
        cfp_admin_alert('High Ban Count', "There are {$banned_users} banned users. Review if any bans were false positives.");
    }
}, 10, 3);

/* ============================================================
   AJAX: Get Admin Notifications
   ============================================================ */
add_action('wp_ajax_cfp_get_admin_notifications', 'cfp_ajax_get_admin_notifications');
function cfp_ajax_get_admin_notifications() {
    check_ajax_referer('cfp_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['msg' => 'Unauthorized']);
    }
    
    global $wpdb;
    $notifications = $wpdb->get_results("
        SELECT * FROM " . $wpdb->prefix . "cfp_admin_notifications 
        ORDER BY priority DESC, created_at DESC LIMIT 20
    ");
    
    $unread_count = (int)$wpdb->get_var(
        "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_admin_notifications WHERE is_read = 0"
    );
    
    wp_send_json_success([
        'notifications' => $notifications,
        'unread_count' => $unread_count
    ]);
}

add_action('wp_ajax_cfp_dismiss_admin_notification', 'cfp_ajax_dismiss_admin_notification');
function cfp_ajax_dismiss_admin_notification() {
    check_ajax_referer('cfp_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['msg' => 'Unauthorized']);
    }
    
    $notification_id = intval($_POST['notification_id']);
    
    global $wpdb;
    $wpdb->query($wpdb->prepare(
        "UPDATE " . $wpdb->prefix . "cfp_admin_notifications SET is_read = 1 WHERE id = %d",
        $notification_id
    ));
    
    wp_send_json_success();
}

/* ============================================================
   ADMIN MENU BADGE
   ============================================================ */
function cfp_admin_notification_badge() {
    global $wpdb;
    $count = (int)$wpdb->get_var(
        "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_admin_notifications WHERE is_read = 0"
    );
    return $count;
}

add_action('admin_menu', function() {
    $badge = cfp_admin_notification_badge();
    $title = $badge > 0 ? "Notifications ({$badge})" : 'Notifications';
    
    add_menu_page(
        'Admin Notifications',
        $title,
        'manage_options',
        'cfp-admin-notifications',
        'cfp_render_admin_notifications_page',
        'dashicons-bell',
        3
    );
});

function cfp_render_admin_notifications_page() {
    global $wpdb;
    
    $notifications = $wpdb->get_results("
        SELECT * FROM " . $wpdb->prefix . "cfp_admin_notifications 
        ORDER BY priority DESC, created_at DESC LIMIT 50
    ");
    ?>
    <div class="wrap">
        <h1>🔔 Admin Notifications</h1>
        
        <div style="display:flex;gap:16px;margin-bottom:20px">
            <button onclick="cfpMarkAllRead()" class="button button-primary">Mark All as Read</button>
            <button onclick="cfpClearAll()" class="button">Clear All</button>
        </div>
        
        <div id="cfp-admin-notif-list" style="max-width:800px">
            <?php foreach($notifications as $n): ?>
            <div class="cfp-admin-notif <?=$n->is_read ? 'read' : 'unread'?>" 
                 style="background:#<?=$n->is_read ? '0a0a0a' : '1a1a1a'?>;border-left:4px solid <?php
                    echo $n->type === 'alert' ? '#ff4444' : 
                        ($n->type === 'warning' ? '#ffaa00' : 
                        ($n->type === 'success' ? '#00cc66' : '#4444ff'));
                 ?>;padding:16px;margin-bottom:12px;border-radius:0 8px 8px 0"
                 data-id="<?=$n->id?>">
                <div style="display:flex;justify-content:space-between;align-items:start">
                    <div>
                        <div style="font-weight:700;font-size:1rem"><?=esc_html($n->title)?></div>
                        <div style="color:#888;margin-top:4px;font-size:.9rem"><?=esc_html($n->message)?></div>
                    </div>
                    <div style="text-align:right">
                        <span style="font-size:.75rem;color:#555"><?=$n->created_at?></span>
                        <?php if(!$n->is_read): ?>
                        <button onclick="cfpDismissNotif(<?=$n->id?>)" class="button button-small" style="margin-top:8px">Dismiss</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    
    <script>
    function cfpDismissNotif(id) {
        const fd = new FormData();
        fd.append('action', 'cfp_dismiss_admin_notification');
        fd.append('nonce', '<?=wp_create_nonce('cfp_nonce')?>');
        fd.append('notification_id', id);
        
        fetch('<?=admin_url('admin-ajax.php')?>', {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    const el = document.querySelector('[data-id="' + id + '"]');
                    if(el) el.remove();
                }
            });
    }
    
    function cfpMarkAllRead() {
        document.querySelectorAll('.cfp-admin-notif.unread').forEach(el => {
            cfpDismissNotif(el.dataset.id);
        });
    }
    
    function cfpClearAll() {
        if(confirm('Clear all notifications?')) {
            location.reload();
        }
    }
    </script>
    <?php
}
