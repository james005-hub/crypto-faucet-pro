<?php
/**
 * Enhanced Security Layer for Crypto Faucet Pro
 * 
 * Security improvements:
 * - Session-based authentication (fixes IDOR vulnerabilities)
 * - Cloudflare-only IP validation (prevents IP spoofing)
 * - Cryptographically secure random number generation
 * - Request signing and replay protection
 * - Enhanced input validation and sanitization
 * - Admin action CSRF protection
 * - Brute force protection for login
 * 
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   SESSION-BASED AUTHENTICATION
   Replaces email-only identification with proper session tokens
   ============================================================ */

function cfp_generate_session_token() {
    return bin2hex(random_bytes(32));
}

function cfp_create_user_session($user_id) {
    global $wpdb;
    $token   = cfp_generate_session_token();
    $expires = time() + ( 7 * DAY_IN_SECONDS );
    $ip      = cfp_get_real_ip();

    // Prune expired sessions for this user before inserting (keeps table lean)
    $wpdb->query( $wpdb->prepare(
        "DELETE FROM {$wpdb->prefix}cfp_sessions WHERE user_id = %d AND expires_at < NOW()",
        $user_id
    ) );

    $wpdb->insert( "{$wpdb->prefix}cfp_sessions", [
        'user_id'    => $user_id,
        'token'      => $token,
        'ip_address' => $ip,
        'expires_at' => date( 'Y-m-d H:i:s', $expires ),
        'created_at' => current_time( 'mysql' ),
    ] );

    return $token;
}

function cfp_validate_session($token) {
    // SECURITY FIX: Enhanced token validation
    if ( empty( $token ) || strlen( $token ) !== 64 ) return null;

    // Validate token is hexadecimal only (prevent injection attempts)
    if ( ! ctype_xdigit( $token ) ) {
        error_log('[CFP Security] Invalid session token format detected');
        return null;
    }

    global $wpdb;
    $row = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}cfp_sessions WHERE token = %s AND expires_at > NOW()",
        $token
    ) );

    if ( ! $row ) return null;

    // SECURITY FIX: IP binding now ENABLED by default (changed from '0' to '1')
    // This prevents session hijacking attacks
    if ( cfp_get_setting( 'session_ip_strict', '1' ) === '1' ) {
        if ( $row->ip_address !== cfp_get_real_ip_secure() ) {
            cfp_security_log('session_ip_mismatch', $row->user_id, [
                'stored_ip' => $row->ip_address,
                'current_ip' => cfp_get_real_ip_secure()
            ], 'warning');
            cfp_destroy_session( $token );
            return null;
        }
    }

    return [ 'user_id' => (int) $row->user_id, 'ip' => $row->ip_address ];
}

function cfp_destroy_session($token) {
    global $wpdb;
    $wpdb->delete( "{$wpdb->prefix}cfp_sessions", [ 'token' => $token ] );
}

function cfp_get_session_user($token) {
    $session = cfp_validate_session($token);
    if (!$session) return null;

    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_USERS . " WHERE id=%d AND is_banned=0",
        $session['user_id']
    ));

    return $user; // null if not found or banned
}

function cfp_require_authentication() {
    $token = sanitize_text_field($_POST['cfp_session_token'] ?? $_COOKIE['cfp_session'] ?? '');
    
    if (empty($token)) {
        wp_send_json_error(['msg' => 'Authentication required. Please log in.']);
    }
    
    $user = cfp_get_session_user($token);
    if (!$user) {
        wp_send_json_error(['msg' => 'Session expired. Please log in again.']);
    }
    
    if ($user->is_banned) {
        wp_send_json_error(['msg' => 'Account suspended.']);
    }
    
    return $user;
}

/* ============================================================
   CLOUDFLARE IP VALIDATION
   Only trust Cloudflare headers when request is from Cloudflare
   ============================================================ */

function cfp_get_real_ip_secure() {
    // SECURITY FIX: Updated Cloudflare IP ranges (March 2026)
    // Source: https://www.cloudflare.com/ips/
    $cloudflare_ips_v4 = [
        '173.245.48.0/20', '103.21.244.0/22', '103.22.200.0/22',
        '103.31.4.0/22', '141.101.64.0/18', '108.162.192.0/18',
        '190.93.240.0/20', '188.114.96.0/20', '197.234.240.0/22',
        '198.41.128.0/17', '162.158.0.0/15', '104.16.0.0/13',
        '104.24.0.0/14', '172.64.0.0/13', '131.0.72.0/22'
    ];

    $cloudflare_ips_v6 = [
        '2400:cb00::/32', '2606:4700::/32', '2803:f800::/32',
        '2405:b500::/32', '2405:8100::/32', '2a06:98c0::/29',
        '2c0f:f248::/32'
    ];

    $remote_addr = $_SERVER['REMOTE_ADDR'] ?? '';

    // SECURITY FIX: Only trust CF headers if request actually comes from Cloudflare
    $is_cloudflare = false;

    // Check IPv4
    if (filter_var($remote_addr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        $is_cloudflare = cfp_ip_in_cidr_list($remote_addr, $cloudflare_ips_v4);
    }
    // Check IPv6
    elseif (filter_var($remote_addr, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6)) {
        $is_cloudflare = cfp_ip_in_cidr_list($remote_addr, $cloudflare_ips_v6);
    }

    if ($is_cloudflare) {
        // Cloudflare-specific headers (in order of preference)
        $cf_ip = $_SERVER['HTTP_CF_CONNECTING_IP'] ?? '';

        // Additional CF header validation
        $cf_ray = $_SERVER['HTTP_CF_RAY'] ?? '';
        $cf_visitor = $_SERVER['HTTP_CF_VISITOR'] ?? '';

        // SECURITY: Log if CF headers are missing (possible spoofing attempt)
        if (empty($cf_ray) && cfp_get_setting('log_cf_anomalies', '1') === '1') {
            error_log('[CFP Security] Request from Cloudflare IP but missing CF-RAY header: ' . $remote_addr);
        }

        if (!empty($cf_ip)) {
            $ip = trim(explode(',', $cf_ip)[0]);

            // Validate IP format
            if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                return sanitize_text_field($ip);
            } else {
                // Invalid IP in CF header - log and fall back
                cfp_security_log('invalid_cf_ip', 0, [
                    'cf_ip' => $cf_ip,
                    'remote_addr' => $remote_addr
                ], 'warning');
            }
        }
    } else {
        // NOT from Cloudflare - check if someone is trying to spoof CF headers
        if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) {
            cfp_security_log('cf_header_spoof_attempt', 0, [
                'claimed_ip' => $_SERVER['HTTP_CF_CONNECTING_IP'],
                'remote_addr' => $remote_addr
            ], 'critical');
            // Continue with trusted proxy check below
        }
    }
    
    // X-Forwarded-For: only trust when REMOTE_ADDR is a known reverse proxy/load balancer.
    // Trusting it unconditionally lets any attacker spoof their IP by setting the header.
    $trusted_proxies = array_filter( array_map( 'trim',
        explode( "\n", cfp_get_setting( 'trusted_proxy_ips', '' ) )
    ) );

    if ( ! empty( $trusted_proxies ) && in_array( $remote_addr, $trusted_proxies, true ) ) {
        if ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
            $forwarded_ips = array_map( 'trim', explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] ) );
            foreach ( $forwarded_ips as $ip ) {
                if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) ) {
                    return sanitize_text_field( $ip );
                }
            }
        }

        if ( ! empty( $_SERVER['HTTP_X_REAL_IP'] ) ) {
            $ip = trim( $_SERVER['HTTP_X_REAL_IP'] );
            if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                return sanitize_text_field( $ip );
            }
        }
    }
    
    return sanitize_text_field($remote_addr);
}

function cfp_ip_in_cidr_list($ip, $cidrs) {
    foreach ($cidrs as $cidr) {
        if (cfp_ip_in_cidr($ip, $cidr)) {
            return true;
        }
    }
    return false;
}


/* ============================================================
   SECURE RANDOM NUMBER GENERATION
   Replaces rand() with random_int() for cryptographic security
   ============================================================ */

function cfp_secure_random_int($min, $max) {
    return random_int($min, $max);
}

function cfp_secure_random_float() {
    return random_int(0, PHP_INT_MAX) / PHP_INT_MAX;
}

function cfp_generate_game_seed() {
    return bin2hex(random_bytes(32));
}

function cfp_hash_game_result($seed, $user_id, $action) {
    return hash('sha256', $seed . $user_id . $action . time());
}

/* ============================================================
   REQUEST SIGNING AND REPLAY PROTECTION
   ============================================================ */

function cfp_generate_request_signature($data, $secret) {
    ksort($data);
    $payload = json_encode($data);
    return hash_hmac('sha256', $payload, $secret);
}

function cfp_validate_request_signature($data, $signature, $secret) {
    ksort($data);
    $payload = json_encode($data);
    $expected = hash_hmac('sha256', $payload, $secret);
    return hash_equals($expected, $signature);
}

function cfp_check_request_replay($request_id, $ttl = 300) {
    $key = 'cfp_request_' . md5($request_id);
    if (get_transient($key) !== false) {
        return false;
    }
    set_transient($key, 1, $ttl);
    return true;
}

/* ============================================================
   ENHANCED INPUT VALIDATION
   ============================================================ */

function cfp_validate_email($email) {
    if (!is_email($email)) return false;
    
    $email = sanitize_email($email);
    
    $result = apply_filters('cfp_validate_email_security', true, $email);
    return $result;
}

function cfp_validate_btc_address($address, $currency = 'BTC') {
    $patterns = [
        'BTC' => '/^(bc1|[13])[a-zA-HJ-NP-Z0-9]{25,62}$/',
        'LTC' => '/^[LM3][a-km-zA-HJ-NP-Z1-9]{26,33}$/',
        'DOGE' => '/^D[5-9A-HJ-NP-U][1-9A-HJ-NP-Za-km-z]{32}$/',
        'ETH' => '/^0x[a-fA-F0-9]{40}$/',
        'TRX' => '/^T[a-zA-Z0-9]{33}$/'
    ];
    
    $pattern = $patterns[$currency] ?? $patterns['BTC'];
    return preg_match($pattern, $address) === 1;
}

function cfp_sanitize_amount($amount) {
    $amount = intval($amount);
    return max(0, $amount);
}

function cfp_validate_amount_range($amount, $min, $max) {
    $amount = cfp_sanitize_amount($amount);
    return $amount >= $min && ($max === 0 || $amount <= $max);
}

/* ============================================================
   ENHANCED INPUT VALIDATION
   ============================================================ */

/**
 * Validate username format
 * Only alphanumeric, underscore, hyphen. 3-20 characters.
 */
function cfp_validate_username($username) {
    $username = trim($username);

    if (strlen($username) < 3 || strlen($username) > 20) {
        return new WP_Error('invalid_username', 'Username must be 3-20 characters');
    }

    if (!preg_match('/^[a-zA-Z0-9_-]+$/', $username)) {
        return new WP_Error('invalid_username', 'Username can only contain letters, numbers, underscore, and hyphen');
    }

    // Block SQL injection patterns
    $sql_patterns = ['select', 'union', 'drop', 'insert', 'update', 'delete', '--', '/*', '*/', 'xp_', 'sp_'];
    foreach ($sql_patterns as $pattern) {
        if (stripos($username, $pattern) !== false) {
            cfp_security_log('suspicious_username', 0, ['username' => $username], 'warning');
            return new WP_Error('invalid_username', 'Username contains invalid characters');
        }
    }

    return true;
}

/**
 * Enhanced email validation with disposable email detection
 */
function cfp_validate_email_enhanced($email) {
    $email = sanitize_email(trim($email));

    if (!is_email($email)) {
        return new WP_Error('invalid_email', 'Invalid email address format');
    }

    // Check for SQL injection patterns
    if (preg_match('/[\'";\\\\<>]/', $email)) {
        cfp_security_log('suspicious_email', 0, ['email' => $email], 'warning');
        return new WP_Error('invalid_email', 'Email contains invalid characters');
    }

    // Disposable email check
    if (cfp_get_setting('block_disposable_email', '1') === '1') {
        $domain = explode('@', $email)[1] ?? '';
        $disposable_domains = cfp_get_disposable_domains();

        if (in_array(strtolower($domain), $disposable_domains, true)) {
            cfp_security_log('disposable_email_blocked', 0, ['email' => $email], 'info');
            return new WP_Error('disposable_email', 'Disposable email addresses are not allowed');
        }
    }

    return $email;
}

/**
 * Validate bet/withdrawal amounts with overflow protection
 */
function cfp_validate_bet_amount($amount, $min = 1, $max = PHP_INT_MAX) {
    // Strict integer validation
    if (!is_numeric($amount)) {
        return new WP_Error('invalid_amount', 'Amount must be numeric');
    }

    $amount = filter_var($amount, FILTER_VALIDATE_INT);

    if ($amount === false) {
        return new WP_Error('invalid_amount', 'Invalid amount format');
    }

    // Range check
    if ($amount < $min) {
        return new WP_Error('amount_too_small', "Minimum amount is {$min} satoshis");
    }

    if ($amount > $max) {
        return new WP_Error('amount_too_large', "Maximum amount is {$max} satoshis");
    }

    // Prevent integer overflow attacks
    if ($amount > 21000000 * 100000000) { // Max Bitcoin supply in satoshis
        cfp_security_log('overflow_attempt', 0, ['amount' => $amount], 'critical');
        return new WP_Error('amount_invalid', 'Amount exceeds maximum possible value');
    }

    return (int) $amount;
}

/**
 * Validate crypto address format
 */
function cfp_validate_crypto_address_secure($address, $currency = 'BTC') {
    $address = trim($address);

    // Length check
    if (strlen($address) < 26 || strlen($address) > 90) {
        return new WP_Error('invalid_address', 'Invalid address length');
    }

    // Check for dangerous characters
    if (preg_match('/[^a-zA-Z0-9]/', $address)) {
        cfp_security_log('suspicious_address', 0, ['address' => substr($address, 0, 10) . '...'], 'warning');
        return new WP_Error('invalid_address', 'Address contains invalid characters');
    }

    // Currency-specific validation
    $is_valid = cfp_validate_btc_address($address, $currency);

    if (!$is_valid) {
        return new WP_Error('invalid_address', "Invalid {$currency} address format");
    }

    return $address;
}

/**
 * Sanitize and validate transaction description
 */
function cfp_sanitize_description($description, $max_length = 255) {
    $description = sanitize_text_field($description);
    $description = substr($description, 0, $max_length);

    // Remove potentially dangerous patterns
    $description = str_replace(['<script', 'javascript:', 'onerror=', 'onclick='], '', $description);

    return $description;
}

/**
 * Get common disposable email domains
 */
function cfp_get_disposable_domains() {
    return [
        'tempmail.com', 'guerrillamail.com', 'mailinator.com',
        '10minutemail.com', 'throwaway.email', 'fakeinbox.com',
        'temp-mail.org', 'getnada.com', 'trashmail.com',
        'maildrop.cc', 'yopmail.com', 'sharklasers.com',
        'grr.la', 'guerrillamail.biz', 'guerrillamail.de',
        'spam4.me', 'tmpeml.info', 'mytemp.email',
        'mohmal.com', 'emailondeck.com', 'mintemail.com'
    ];
}

/* ============================================================
   BRUTE FORCE PROTECTION
   ============================================================ */

function cfp_check_login_attempts($identifier) {
    $key = 'cfp_login_attempts_' . md5($identifier);
    $attempts = get_transient($key) ?: 0;
    
    if ($attempts >= 5) {
        $timeout = get_transient($key . '_timeout');
        if ($timeout && time() < $timeout) {
            $remaining = $timeout - time();
            return new WP_Error('brute_force', 
                sprintf('Too many login attempts. Try again in %d seconds.', $remaining)
            );
        }
    }
    
    return true;
}

function cfp_record_failed_login($identifier) {
    $key = 'cfp_login_attempts_' . md5($identifier);
    $attempts = get_transient($key) ?: 0;
    $attempts++;
    
    set_transient($key, $attempts, 15 * MINUTE_IN_SECONDS);
    
    if ($attempts >= 5) {
        set_transient($key . '_timeout', time() + (5 * MINUTE_IN_SECONDS), 30 * MINUTE_IN_SECONDS);
    }
}

function cfp_clear_login_attempts($identifier) {
    $key = 'cfp_login_attempts_' . md5($identifier);
    delete_transient($key);
    delete_transient($key . '_timeout');
}

/* ============================================================
   CSRF PROTECTION FOR ADMIN ACTIONS
   ============================================================ */

function cfp_admin_verify_nonce($action = 'cfp_admin_action') {
    if (!current_user_can('manage_options')) {
        wp_die('Insufficient permissions.');
    }
    
    if (!isset($_POST['cfp_admin_nonce']) || !wp_verify_nonce($_POST['cfp_admin_nonce'], $action)) {
        wp_die('Security check failed. Please try again.');
    }
}

function cfp_admin_generate_nonce($action = 'cfp_admin_action') {
    return wp_create_nonce($action);
}

/* ============================================================
   AUDIT LOGGING
   ============================================================ */

function cfp_security_log($event_type, $user_id, $details = [], $severity = 'info') {
    // Write to PHP error log for all severities (aggregated by host log tooling)
    $ip         = cfp_get_real_ip_secure();
    $user_agent = sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown' );

    error_log( sprintf(
        '[CFP Security] [%s] User #%d | %s | IP:%s | UA:%s | %s',
        strtoupper( $severity ),
        $user_id,
        $event_type,
        $ip,
        substr( $user_agent, 0, 120 ),
        json_encode( $details )
    ) );

    // For critical events also email admin
    if ( $severity === 'critical' ) {
        $admin_email = get_option( 'admin_email' );
        wp_mail(
            $admin_email,
            '[CFP CRITICAL] ' . $event_type,
            "User #{$user_id} | IP: {$ip}\n\n" . json_encode( $details, JSON_PRETTY_PRINT )
        );
    }
}

/* ============================================================
   HOOK INTO EXISTING HANDLERS
   ============================================================ */

add_action('init', function() {
    if (isset($_COOKIE['cfp_session'])) {
        $session = cfp_validate_session($_COOKIE['cfp_session']);
        if ($session) {
            wp_set_current_user($session['user_id']);
        }
    }
}, 1);

add_filter('cfp_validate_email_security', function($valid, $email) {
    $disposable_domains = [
        'tempmail.com', 'guerrillamail.com', 'mailinator.com', 
        '10minutemail.com', 'throwaway.email', 'fakeinbox.com'
    ];
    
    $domain = explode('@', $email)[1] ?? '';
    if (in_array(strtolower($domain), $disposable_domains)) {
        if (cfp_get_setting('block_disposable_email', '0') === '1') {
            return false;
        }
    }
    
    return $valid;
}, 10, 2);

add_action('cfp_user_login_success', function($user_id, $email) {
    cfp_clear_login_attempts($email);
    cfp_security_log('login_success', $user_id, ['email' => $email]);
}, 10, 2);

add_action('cfp_user_login_failed', function($email, $reason) {
    cfp_record_failed_login($email);
    cfp_security_log('login_failed', 0, ['email' => $email, 'reason' => $reason], 'warning');
}, 10, 2);

add_action('cfp_withdrawal_request', function($user_id, $amount, $address) {
    cfp_security_log('withdrawal_request', $user_id, [
        'amount' => $amount,
        'address' => substr($address, 0, 10) . '...'
    ]);
}, 10, 3);

add_action('cfp_large_balance_change', function($user_id, $amount, $type) {
    cfp_security_log('large_balance_change', $user_id, [
        'amount' => $amount,
        'type' => $type
    ], 'warning');
}, 10, 3);

/* ============================================================
   SECURE COOKIE SETTINGS
   ============================================================ */

add_action('init', function() {
    if (!is_admin() && cfp_get_setting('secure_cookies', '1') === '1') {
        @ini_set('session.cookie_httponly', 1);
        @ini_set('session.cookie_secure', is_ssl() ? 1 : 0);
        @ini_set('session.cookie_samesite', 'Strict');
    }
});

add_action('cfp_set_session_cookie', function($token, $user_id) {
    setcookie('cfp_session', $token, [
        'expires' => time() + WEEK_IN_SECONDS,
        'path' => '/',
        'domain' => '',
        'secure' => is_ssl(),
        'httponly' => true,
        'samesite' => 'Strict'
    ]);
});

add_action('wp_logout', function() {
    if (isset($_COOKIE['cfp_session'])) {
        cfp_destroy_session($_COOKIE['cfp_session']);
        setcookie('cfp_session', '', time() - 3600, '/');
    }
});
