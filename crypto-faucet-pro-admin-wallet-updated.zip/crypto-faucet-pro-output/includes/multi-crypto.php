<?php
/**
 * Multi-Crypto Support — allows simultaneous operation of multiple currencies.
 * Each currency has its own faucet, claim amounts, wallet address, and balances.
 *
 * Coinbase supports 30+ coins. This module lets the admin enable multiple coins
 * so users can choose which currency to earn and withdraw.
 *
 * User balances are stored per-currency in a separate table.
 * The main balance_sat column is kept as the "primary" currency.
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// Multi-currency balances table
define('CFP_TABLE_MC_BALANCES', $GLOBALS['wpdb']->prefix . 'cfp_mc_balances');

// Create table on plugins_loaded if not exists
add_action('plugins_loaded', function() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_MC_BALANCES . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        currency VARCHAR(10) NOT NULL,
        balance_sat BIGINT NOT NULL DEFAULT 0,
        fp_address VARCHAR(128) DEFAULT '',
        updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        UNIQUE KEY user_currency (user_id, currency),
        KEY user_id (user_id)
    ) {$charset}");
}, 20);

/* ============================================================
   SUPPORTED CURRENCIES (full Coinbase list subset)
   ============================================================ */
function cfp_mc_currencies() {
    return [
        'BTC'   => ['name'=>'Bitcoin',     'icon'=>'₿',  'color'=>'#f7931a', 'min_sat'=>100,  'decimals'=>8],
        'ETH'   => ['name'=>'Ethereum',    'icon'=>'Ξ',  'color'=>'#627eea', 'min_sat'=>1000, 'decimals'=>18],
        'LTC'   => ['name'=>'Litecoin',    'icon'=>'Ł',  'color'=>'#bfbbbb', 'min_sat'=>1000, 'decimals'=>8],
        'DOGE'  => ['name'=>'Dogecoin',    'icon'=>'Ð',  'color'=>'#c2a633', 'min_sat'=>1000, 'decimals'=>8],
        'DASH'  => ['name'=>'Dash',        'icon'=>'Đ',  'color'=>'#008ce7', 'min_sat'=>1000, 'decimals'=>8],
        'TRX'   => ['name'=>'TRON',        'icon'=>'T',  'color'=>'#ef0027', 'min_sat'=>1000, 'decimals'=>6],
        'BNB'   => ['name'=>'BNB',         'icon'=>'B',  'color'=>'#f3ba2f', 'min_sat'=>1000, 'decimals'=>8],
        'SOL'   => ['name'=>'Solana',      'icon'=>'◎',  'color'=>'#9945ff', 'min_sat'=>1000, 'decimals'=>9],
        'MATIC' => ['name'=>'Polygon',     'icon'=>'⬡',  'color'=>'#8247e5', 'min_sat'=>1000, 'decimals'=>18],
        'XRP'   => ['name'=>'Ripple',      'icon'=>'✕',  'color'=>'#346aa9', 'min_sat'=>1000, 'decimals'=>6],
        'USDT'  => ['name'=>'Tether',      'icon'=>'₮',  'color'=>'#26a17b', 'min_sat'=>1000, 'decimals'=>6],
        'BCH'   => ['name'=>'Bitcoin Cash','icon'=>'₿',  'color'=>'#8dc351', 'min_sat'=>1000, 'decimals'=>8],
        'ZEC'   => ['name'=>'Zcash',       'icon'=>'ⓩ',  'color'=>'#ecb244', 'min_sat'=>1000, 'decimals'=>8],
    ];
}

function cfp_mc_enabled_currencies() {
    $all     = cfp_mc_currencies();
    $enabled = json_decode(cfp_get_setting('mc_enabled_currencies', '["BTC"]'), true) ?: ['BTC'];
    return array_filter($all, fn($k) => in_array($k, $enabled), ARRAY_FILTER_USE_KEY);
}

function cfp_mc_get_balance($user_id, $currency) {
    global $wpdb;
    $currency = strtoupper($currency);
    // Primary currency uses main balance_sat column
    if ($currency === strtoupper(cfp_get_setting('blockchain_currency','BTC'))) {
        return (int)$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d",$user_id));
    }
    $row = $wpdb->get_row($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_MC_BALANCES." WHERE user_id=%d AND currency=%s",$user_id,$currency));
    return $row ? (int)$row->balance_sat : 0;
}

function cfp_mc_credit($user_id, $currency, $amount, $description='') {
    global $wpdb;
    $currency = strtoupper($currency);
    if ($amount <= 0) return;
    $primary = strtoupper(cfp_get_setting('blockchain_currency','BTC'));
    if ($currency === $primary) {
        $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$amount,$user_id));
    } else {
        $wpdb->query($wpdb->prepare(
            "INSERT INTO ".CFP_TABLE_MC_BALANCES." (user_id,currency,balance_sat) VALUES(%d,%s,%d)
             ON DUPLICATE KEY UPDATE balance_sat=balance_sat+%d",
            $user_id, $currency, $amount, $amount
        ));
    }
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user_id,'type'=>'mc_credit','amount_sat'=>$amount,'description'=>"{$currency}: {$description}"]);
}

function cfp_mc_debit($user_id, $currency, $amount, $description='') {
    global $wpdb;
    $currency = strtoupper($currency);
    $primary  = strtoupper(cfp_get_setting('blockchain_currency','BTC'));
    if ($amount <= 0) return false;
    if ($currency === $primary) {
        $rows = $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",$amount,$user_id,$amount));
    } else {
        $rows = $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_MC_BALANCES." SET balance_sat=balance_sat-%d WHERE user_id=%d AND currency=%s AND balance_sat>=%d",$amount,$user_id,$currency,$amount));
    }
    if ($rows) $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user_id,'type'=>'mc_debit','amount_sat'=>-$amount,'description'=>"{$currency}: {$description}"]);
    return (bool)$rows;
}

/* ============================================================
   AJAX: Get all balances for a user
   ============================================================ */
add_action('wp_ajax_cfp_mc_balances',        'cfp_ajax_mc_balances');
add_action('wp_ajax_nopriv_cfp_mc_balances', 'cfp_ajax_mc_balances');
function cfp_ajax_mc_balances() {
    check_ajax_referer('cfp_nonce','nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    $user  = cfp_get_user_by_email($email);
    if (!$user) wp_send_json_error(['msg'=>'Account not found.']);
    $currencies = cfp_mc_enabled_currencies();
    $balances   = [];
    foreach ($currencies as $code => $info) {
        $balances[$code] = [
            'balance' => cfp_mc_get_balance($user->id, $code),
            'name'    => $info['name'],
            'icon'    => $info['icon'],
            'color'   => $info['color'],
        ];
    }
    wp_send_json_success(['balances'=>$balances]);
}

/* ============================================================
   AJAX: Multi-currency withdraw
   ============================================================ */
add_action('wp_ajax_cfp_mc_withdraw',        'cfp_ajax_mc_withdraw');
add_action('wp_ajax_nopriv_cfp_mc_withdraw', 'cfp_ajax_mc_withdraw');
function cfp_ajax_mc_withdraw() {
    check_ajax_referer('cfp_nonce','nonce');
    $email    = sanitize_email($_POST['email'] ?? '');
    $currency = strtoupper(sanitize_text_field($_POST['currency'] ?? ''));
    $address  = sanitize_text_field($_POST['address'] ?? '');
    $amount   = intval($_POST['amount'] ?? 0);
    $user = cfp_get_user_by_email($email);
    if (!$user) wp_send_json_error(['msg'=>'Account not found.']);
    if ($user->is_banned) wp_send_json_error(['msg'=>'Account suspended.']);
    $currencies = cfp_mc_enabled_currencies();
    if (!isset($currencies[$currency])) wp_send_json_error(['msg'=>'Currency not supported.']);
    $min = intval(cfp_get_setting("mc_min_withdraw_{$currency}", cfp_get_setting('blockchain_min_withdraw',1000)));
    if ($amount < $min) wp_send_json_error(['msg'=>"Minimum {$currency} withdrawal is ".number_format($min)." sat."]);
    $bal = cfp_mc_get_balance($user->id, $currency);
    if ($bal < $amount) wp_send_json_error(['msg'=>'Insufficient balance.']);
    // Basic on-chain address sanity check
    if ( strlen(trim($address)) < 25 || strpos($address, ' ') !== false ) {
        wp_send_json_error(['msg' => "Invalid {$currency} address. Please double-check and try again."]);
    }
    // Deduct balance atomically before firing payout
    if (!cfp_mc_debit($user->id, $currency, $amount, "Withdrawal to {$address}")) {
        wp_send_json_error(['msg' => 'Balance deduction failed. Please refresh and try again.']);
    }
    // Fire on-chain payout via NOWPayments
    $amount_coin = $amount / 1e8;
    $result = cfp_np_send_payout($address, $amount_coin, strtolower($currency));
    $payout_id = $result['id'] ?? ($result['withdrawals'][0]['id'] ?? '');
    $success   = !empty($payout_id) || isset($result['status']);
    if ($success) {
        wp_send_json_success(['msg' => "✅ Sent {$amount} sat {$currency} on-chain! ID: " . $payout_id]);
    } else {
        // Refund on failure
        global $wpdb;
        $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
            $amount, $user->id
        ));
        $err = $result['message'] ?? ($result['error'] ?? 'Unknown error');
        wp_send_json_error(['msg' => 'Coinbase error: ' . $err]);
    }
}

/* ============================================================
   SHORTCODE: [cfp_multi_wallet] — shows all currency balances
   ============================================================ */
add_shortcode('cfp_multi_wallet', function() {
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    $currencies = cfp_mc_enabled_currencies();
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-mc-widget">
        <h2>💼 Multi-Currency Wallet</h2>
        <p class="sub">Your balances across all enabled cryptocurrencies.</p>
        <input class="cfp-input" type="email" id="cfp-mc-email" placeholder="Account email" onblur="cfpLoadMcBalances()">
        <div id="cfp-mc-balances" style="display:none;margin-top:14px">
            <div id="cfp-mc-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(140px,1fr));gap:10px;margin-bottom:14px"></div>
            <!-- Withdraw panel -->
            <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:10px;padding:14px">
                <h3 style="font-family:'Oswald',sans-serif;color:#fff;font-size:.95rem;margin:0 0 12px;text-transform:uppercase;letter-spacing:1px">💸 Withdraw</h3>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:8px">
                    <select class="cfp-input" id="cfp-mc-wd-cur" style="background:#111;margin-bottom:0">
                        <?php foreach($currencies as $code=>$info): ?>
                        <option value="<?=esc_attr($code)?>"><?=esc_html($info['icon'])?> <?=esc_html($code)?> — <?=esc_html($info['name'])?></option>
                        <?php endforeach; ?>
                    </select>
                    <input class="cfp-input" type="number" id="cfp-mc-wd-amt" placeholder="Amount (sat)" style="margin-bottom:0">
                </div>
                <input class="cfp-input" type="text" id="cfp-mc-wd-addr" placeholder="Wallet address">
                <button class="cfp-btn-full" onclick="cfpMcWithdraw()">⚡ Withdraw</button>
            </div>
        </div>
        <div id="cfp-mc-msg" style="margin-top:10px"></div>
    </div>
    <script>
    async function cfpLoadMcBalances(){
        const email=document.getElementById('cfp-mc-email').value; if(!email) return;
        const fd=new FormData(); fd.append('action','cfp_mc_balances'); fd.append('nonce','<?=esc_js($nonce)?>'); fd.append('email',email);
        const r=await fetch('<?=esc_js($ajax)?>',{method:'POST',body:fd}); const d=await r.json();
        if(!d.success){document.getElementById('cfp-mc-msg').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;return;}
        const grid=document.getElementById('cfp-mc-grid');
        grid.innerHTML='';
        Object.entries(d.data.balances).forEach(([code,info])=>{
            grid.innerHTML+=`<div style="background:#111;border:1px solid #1c1c1c;border-radius:10px;padding:12px;text-align:center">
                <div style="font-size:1.6rem;color:${info.color}">${info.icon}</div>
                <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:#555;margin:4px 0">${code}</div>
                <div style="font-family:'Oswald',sans-serif;font-size:1.1rem;font-weight:700;color:${info.color}">${info.balance.toLocaleString()}</div>
                <div style="font-size:.65rem;color:#333">sat</div>
            </div>`;
        });
        document.getElementById('cfp-mc-balances').style.display='';
    }
    async function cfpMcWithdraw(){
        const email=document.getElementById('cfp-mc-email').value;
        const currency=document.getElementById('cfp-mc-wd-cur').value;
        const amount=document.getElementById('cfp-mc-wd-amt').value;
        const address=document.getElementById('cfp-mc-wd-addr').value;
        const fd=new FormData(); fd.append('action','cfp_mc_withdraw'); fd.append('nonce','<?=esc_js($nonce)?>');
        fd.append('email',email); fd.append('currency',currency); fd.append('amount',amount); fd.append('address',address);
        const r=await fetch('<?=esc_js($ajax)?>',{method:'POST',body:fd}); const d=await r.json();
        document.getElementById('cfp-mc-msg').innerHTML=`<div class="cfp-msg ${d.success?'success':'error'}">${d.data.msg}</div>`;
        if(d.success) cfpLoadMcBalances();
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   ADMIN: Multi-currency settings
   ============================================================ */
function cfp_admin_multicurrency_settings() {
    $saved = false;
    if (isset($_POST['cfp_save_mc']) && check_admin_referer('cfp_mc')) {
        $enabled = array_map('sanitize_text_field', $_POST['mc_currencies'] ?? ['BTC']);
        cfp_update_setting('mc_enabled_currencies', json_encode(array_values($enabled)));
        // Save per-currency min withdrawals
        foreach (cfp_mc_currencies() as $code => $_) {
            if (isset($_POST["mc_min_withdraw_{$code}"])) {
                cfp_update_setting("mc_min_withdraw_{$code}", intval($_POST["mc_min_withdraw_{$code}"]));
            }
        }
        $saved = true;
    }
    $enabled_raw = json_decode(cfp_get_setting('mc_enabled_currencies','["BTC"]'), true) ?: ['BTC'];
    $all = cfp_mc_currencies();
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🪙 Multi-Crypto — Enabled Currencies</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Select which cryptocurrencies users can earn and withdraw. Add IPN URL to each currency in your Coinbase dashboard.</p>
        <form method="post">
        <?php wp_nonce_field('cfp_mc'); ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;margin-bottom:18px">
        <?php foreach ($all as $code => $info): $chk = in_array($code, $enabled_raw); ?>
        <label style="display:flex;align-items:center;gap:10px;background:#111;border:1px solid <?=$chk?'var(--g)':'#2a2a2a'?>;border-radius:10px;padding:12px;cursor:pointer;transition:border-color .15s">
            <input type="checkbox" name="mc_currencies[]" value="<?=esc_attr($code)?>" <?=$chk?'checked':''?> style="width:16px;height:16px;accent-color:var(--g)">
            <div>
                <div style="font-size:1.2rem;color:<?=esc_attr($info['color'])?>"><?=esc_html($info['icon'])?></div>
                <div style="font-weight:700;color:#fff;font-size:.9rem"><?=esc_html($code)?></div>
                <div style="font-size:.72rem;color:#555"><?=esc_html($info['name'])?></div>
            </div>
        </label>
        <?php endforeach; ?>
        </div>
        <h3 style="color:#aaa;font-size:.83rem;text-transform:uppercase;letter-spacing:1px;margin:0 0 12px">Minimum Withdrawal per Currency (sat)</h3>
        <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:10px;margin-bottom:16px">
        <?php foreach ($all as $code => $info): ?>
        <div class="cfp-field">
            <label><?=esc_html($info['icon'])?> <?=esc_html($code)?></label>
            <input type="number" name="mc_min_withdraw_<?=esc_attr($code)?>" value="<?=esc_attr(cfp_get_setting("mc_min_withdraw_{$code}",1000))?>" min="1">
        </div>
        <?php endforeach; ?>
        </div>
        <button type="submit" name="cfp_save_mc" class="cfp-btn cfp-btn-gold">💾 Save Multi-Crypto Settings</button>
        </form>
        <?php if($saved): ?><div class="cfp-notice success" style="margin-top:12px">✅ Saved!</div><?php endif; ?>
        <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:8px;padding:12px;margin-top:16px;font-size:.82rem;color:#777">
            💡 Shortcodes: <code>[cfp_multi_wallet]</code> — shows all balances + withdraw. <code>[cfp_price_ticker]</code> — live price. Each currency auto-detects from Coinbase IPN by the <code>currency</code> field in the webhook.
        </div>
    </div>
    <?php
}
