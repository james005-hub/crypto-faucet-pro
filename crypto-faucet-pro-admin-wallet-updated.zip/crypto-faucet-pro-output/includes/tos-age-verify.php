<?php
/**
 * Terms of Service & Age Verification Gate
 *
 * Features:
 *  1. [cfp_tos_gate] shortcode — wraps any content behind a TOS/age acceptance wall.
 *     Acceptance is stored in a signed cookie (not just a session var) so it
 *     survives page reloads without a DB hit.
 *  2. AJAX handler cfp_accept_tos — records acceptance in the DB (user row + log).
 *  3. cfp_user_has_accepted_tos() — utility function used by claim/game handlers
 *     to block play until TOS is accepted.
 *  4. Admin toggle: tos_enabled, tos_minimum_age, tos_text (custom HTML allowed).
 *  5. [cfp_tos_text] shortcode — renders the full TOS document.
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   UTILITY: check if current visitor has accepted TOS
   ============================================================ */
function cfp_user_has_accepted_tos( $email = '' ) {
    if ( cfp_get_setting('tos_enabled','1') !== '1' ) return true;

    // Check signed cookie first (fast path, no DB)
    $cookie_name = 'cfp_tos_accepted';
    if ( ! empty($_COOKIE[$cookie_name]) ) {
        $val  = $_COOKIE[$cookie_name];
        $sig  = hash_hmac('sha256', 'cfp_tos_v1', wp_salt('auth'));
        if ( hash_equals($sig, $val) ) return true;
    }

    // Check DB if email provided
    if ( $email ) {
        global $wpdb;
        $accepted = $wpdb->get_var( $wpdb->prepare(
            "SELECT tos_accepted FROM " . CFP_TABLE_USERS . " WHERE email=%s",
            sanitize_email($email)
        ));
        if ( $accepted ) return true;
    }

    return false;
}

/* ============================================================
   AJAX: Accept TOS
   ============================================================ */
add_action('wp_ajax_cfp_accept_tos',        'cfp_ajax_accept_tos');
add_action('wp_ajax_nopriv_cfp_accept_tos', 'cfp_ajax_accept_tos');
function cfp_ajax_accept_tos() {
    check_ajax_referer('cfp_nonce','nonce');

    $email       = sanitize_email($_POST['email'] ?? '');
    $age_confirm = ( $_POST['age_confirm'] ?? '' ) === '1';
    $tos_confirm = ( $_POST['tos_confirm'] ?? '' ) === '1';
    $min_age     = intval( cfp_get_setting('tos_minimum_age', 18) );

    if ( ! $tos_confirm ) wp_send_json_error(['msg'=>'You must accept the Terms of Service.']);
    if ( ! $age_confirm  ) wp_send_json_error(['msg'=>"You must confirm you are at least {$min_age} years old."]);

    // Set signed cookie (1 year)
    $sig = hash_hmac('sha256', 'cfp_tos_v1', wp_salt('auth'));
    setcookie('cfp_tos_accepted', $sig, time() + YEAR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);

    // Update DB if email provided and user exists
    if ( $email ) {
        global $wpdb;
        $user = cfp_get_user_by_email($email);
        if ( $user ) {
            $wpdb->update( CFP_TABLE_USERS, ['tos_accepted'=>1,'tos_accepted_at'=>current_time('mysql')], ['id'=>$user->id] );
            $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
                'user_id'     => $user->id,
                'type'        => 'tos_accepted',
                'amount_sat'  => 0,
                'description' => "ToS accepted (age {$min_age}+) from IP " . (function_exists('cfp_get_real_ip') ? cfp_get_real_ip() : ''),
            ]);
        }
    }

    wp_send_json_success(['msg'=>'✅ Thank you! You can now play and claim.','accepted'=>true]);
}

/* ============================================================
   AJAX: Enforce TOS on game/claim actions
   ============================================================ */
function cfp_gate_tos_check( $email = '' ) {
    if ( ! cfp_user_has_accepted_tos($email) ) {
        wp_send_json_error(['msg'=>'📜 Please accept our Terms of Service before playing.','tos_required'=>true]);
    }
}

// Hook into games at priority 2 (after nonce check at 1, before handler at 10)
$tos_gated_actions = ['cfp_slots','cfp_coinflip','cfp_coinflip_don','cfp_dice_roll','cfp_crash','cfp_wheel','cfp_multiply','cfp_claim'];
foreach ( $tos_gated_actions as $a ) {
    add_action("wp_ajax_{$a}",        function() { cfp_gate_tos_check(sanitize_email($_POST['email']??'')); }, 2);
    add_action("wp_ajax_nopriv_{$a}", function() { cfp_gate_tos_check(sanitize_email($_POST['email']??'')); }, 2);
}

/* ============================================================
   SHORTCODE: [cfp_tos_gate]
   Wraps content — if TOS not accepted, shows the acceptance modal instead.
   Usage: [cfp_tos_gate]...[/cfp_tos_gate]
   ============================================================ */
add_shortcode('cfp_tos_gate', function($atts, $content='') {
    if ( cfp_get_setting('tos_enabled','1') !== '1' ) return do_shortcode($content);
    if ( cfp_user_has_accepted_tos() ) return do_shortcode($content);

    $min_age  = intval( cfp_get_setting('tos_minimum_age', 18) );
    $site     = get_bloginfo('name');
    $tos_url  = cfp_get_setting('tos_page_url','#');
    $pp_url   = cfp_get_setting('privacy_page_url','#');
    $nonce    = wp_create_nonce('cfp_nonce');
    ob_start(); ?>
    <div id="cfp-tos-gate-wrap" style="font-family:'Source Sans 3',sans-serif">
        <!-- Blur overlay over the content -->
        <div style="filter:blur(6px);pointer-events:none;user-select:none;opacity:.3;max-height:260px;overflow:hidden">
            <?=do_shortcode($content)?>
        </div>
        <!-- TOS modal -->
        <div style="background:#111;border:1px solid #2a2a2a;border-radius:16px;padding:30px;max-width:480px;margin:24px auto 0;text-align:center">
            <div style="font-size:3rem;margin-bottom:12px">📜</div>
            <h2 style="font-family:'Oswald',sans-serif;color:#fff;font-size:1.5rem;margin-bottom:8px">Welcome to <?=esc_html($site)?></h2>
            <p style="color:#777;font-size:.88rem;margin-bottom:20px;line-height:1.6">
                Before you can play and earn, please confirm you meet our eligibility requirements.
            </p>
            <div id="cfp-tos-msg"></div>
            <input class="cfp-input" type="email" id="cfp-tos-email" placeholder="Your account email (optional)">
            <label style="display:flex;align-items:flex-start;gap:10px;text-align:left;margin-bottom:12px;cursor:pointer">
                <input type="checkbox" id="cfp-tos-age" style="margin-top:3px;accent-color:var(--cfp-p)">
                <span style="color:#aaa;font-size:.85rem">I confirm that I am at least <strong style="color:#fff"><?=$min_age?> years old</strong> and legally permitted to participate in online gaming in my jurisdiction.</span>
            </label>
            <label style="display:flex;align-items:flex-start;gap:10px;text-align:left;margin-bottom:20px;cursor:pointer">
                <input type="checkbox" id="cfp-tos-agree" style="margin-top:3px;accent-color:var(--cfp-p)">
                <span style="color:#aaa;font-size:.85rem">I have read and agree to the
                    <a href="<?=esc_url($tos_url)?>" target="_blank" style="color:var(--cfp-p)">Terms of Service</a> and
                    <a href="<?=esc_url($pp_url)?>" target="_blank" style="color:var(--cfp-p)">Privacy Policy</a>.
                    I understand this site involves real cryptocurrency and I am responsible for my actions.
                </span>
            </label>
            <button class="cfp-claim-btn" id="cfp-tos-btn" onclick="cfpAcceptTos()" style="width:100%">
                ✅ I Agree — Enter Site
            </button>
            <p style="color:#444;font-size:.72rem;margin-top:14px">
                By clicking above you confirm eligibility. Minors are strictly prohibited.
            </p>
        </div>
    </div>
    <script>
    async function cfpAcceptTos(){
        const age  = document.getElementById('cfp-tos-age').checked;
        const tos  = document.getElementById('cfp-tos-agree').checked;
        const email= document.getElementById('cfp-tos-email').value;
        if(!age||!tos){
            document.getElementById('cfp-tos-msg').innerHTML='<div class="cfp-msg error" style="margin-bottom:12px">Please check both boxes to continue.</div>';
            return;
        }
        document.getElementById('cfp-tos-btn').disabled=true;
        document.getElementById('cfp-tos-btn').textContent='Processing…';
        const fd=new FormData();
        fd.append('action','cfp_accept_tos');fd.append('nonce',cfpNonce);
        fd.append('age_confirm','1');fd.append('tos_confirm','1');fd.append('email',email);
        const r=await fetch(cfpAjax,{method:'POST',body:fd}); const d=await r.json();
        if(d.success){
            document.getElementById('cfp-tos-gate-wrap').style.filter='none';
            document.getElementById('cfp-tos-gate-wrap').innerHTML=<?=json_encode(do_shortcode($content))?>;
        } else {
            document.getElementById('cfp-tos-msg').innerHTML=`<div class="cfp-msg error" style="margin-bottom:12px">${d.data.msg}</div>`;
            document.getElementById('cfp-tos-btn').disabled=false;
            document.getElementById('cfp-tos-btn').textContent='✅ I Agree — Enter Site';
        }
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_tos_text]  — renders the TOS document
   Admin sets the TOS content in Security settings (tos_content field).
   ============================================================ */
add_shortcode('cfp_tos_text', function() {
    $content = cfp_get_setting('tos_content','');
    if ( empty($content) ) {
        $site = get_bloginfo('name');
        $content = "<h2>Terms of Service — {$site}</h2>
<p><strong>Last updated:</strong> " . date('F j, Y') . "</p>
<h3>1. Eligibility</h3>
<p>You must be at least 18 years old (or the age of majority in your jurisdiction) to use this platform. By accessing our services you confirm you meet this requirement.</p>
<h3>2. Nature of Service</h3>
<p>This platform provides a cryptocurrency faucet and games of chance. All games use a provably fair system. Past results do not guarantee future outcomes.</p>
<h3>3. No Warranty</h3>
<p>The service is provided \"as is\" without warranty of any kind. We are not responsible for losses arising from use of the platform.</p>
<h3>4. Prohibited Conduct</h3>
<p>You may not use bots, scripts, VPNs to circumvent limits, or multiple accounts. Violations result in immediate account termination.</p>
<h3>5. Cryptocurrency Risk</h3>
<p>Cryptocurrency values fluctuate. You accept all risk associated with holding or transacting in cryptocurrency.</p>
<h3>6. Responsible Gambling</h3>
<p>If you feel you may have a gambling problem, please seek help at <a href='https://www.begambleaware.org' target='_blank'>BeGambleAware.org</a>.</p>
<h3>7. Changes</h3>
<p>We reserve the right to modify these terms at any time. Continued use constitutes acceptance.</p>";
    }
    return '<div class="cfp-widget" style="text-align:left;line-height:1.7">' . wp_kses_post($content) . '</div>';
});

/* ============================================================
   ADMIN UI: TOS settings card
   Registers fields; saved by existing cfp_save_security handler.
   ============================================================ */
add_action('cfp_security_extra_cards', 'cfp_tos_admin_ui', 5);
function cfp_tos_admin_ui() {
    $gs = fn($k,$d='') => cfp_get_setting($k,$d);
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>📜 Terms of Service & Age Verification</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Gate access behind a TOS + age confirmation wall. Required for regulatory compliance.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>TOS Gate</label>
                <select name="tos_enabled" style="background:#111">
                    <option value="1" <?=selected($gs('tos_enabled','1'),'1',false)?>>✅ Enabled — show gate before playing</option>
                    <option value="0" <?=selected($gs('tos_enabled','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Minimum age (years)</label>
                <input type="number" name="tos_minimum_age" value="<?=esc_attr($gs('tos_minimum_age',18))?>" min="13" max="21">
                <span class="hint">18 is standard for most jurisdictions.</span>
            </div>
            <div class="cfp-field">
                <label>Terms of Service page URL</label>
                <input type="url" name="tos_page_url" value="<?=esc_attr($gs('tos_page_url','#'))?>">
                <span class="hint">Full URL linked in the acceptance modal. Use shortcode [cfp_tos_text] on the page.</span>
            </div>
            <div class="cfp-field">
                <label>Privacy Policy page URL</label>
                <input type="url" name="privacy_page_url" value="<?=esc_attr($gs('privacy_page_url','#'))?>">
            </div>
        </div>
        <div class="cfp-field" style="margin-top:14px">
            <label>Custom TOS content (HTML allowed) — leave blank for default</label>
            <textarea name="tos_content" rows="8" style="background:#111;border:1px solid #222;border-radius:8px;padding:8px 12px;color:#ccc;font-size:.8rem;width:100%;box-sizing:border-box"><?=esc_textarea($gs('tos_content',''))?></textarea>
            <span class="hint">Rendered by [cfp_tos_text] shortcode. Leave blank to use the built-in default template.</span>
        </div>
        <p style="color:#555;font-size:.8rem;margin-top:10px">
            Usage: wrap your games lobby with <code>[cfp_tos_gate][cfp_games_lobby][/cfp_tos_gate]</code>
        </p>
    </div>
    <?php
}

/* ============================================================
   PATCH admin-security.php to call extra cards hook
   (This fires at the bottom of the Security page form, before save button)
   ============================================================ */
add_action('cfp_security_form_bottom', function() {
    do_action('cfp_security_extra_cards');
});
