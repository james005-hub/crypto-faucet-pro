<?php
/**
 * Notification System
 *
 * @package CryptoFaucetPro
 */

if (!defined('ABSPATH')) exit;

/* ============================================================
   NOTIFICATION TABLES
   ============================================================ */
function cfp_create_notification_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $table_notifications = $wpdb->prefix . 'cfp_notifications';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_notifications'") != $table_notifications) {
        $wpdb->query("
            CREATE TABLE $table_notifications (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                type enum('system','claim','game','withdrawal','referral','achievement','promo','security') DEFAULT 'system',
                title varchar(200) NOT NULL,
                message text NOT NULL,
                link varchar(500) DEFAULT NULL,
                is_read tinyint(1) DEFAULT 0,
                is_dismissed tinyint(1) DEFAULT 0,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY user_id (user_id),
                KEY type (type),
                KEY is_read (is_read),
                KEY created_at (created_at)
            ) $charset
        ");
    }

    $table_notification_prefs = $wpdb->prefix . 'cfp_notification_prefs';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_notification_prefs'") != $table_notification_prefs) {
        $wpdb->query("
            CREATE TABLE $table_notification_prefs (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL UNIQUE,
                email_claims tinyint(1) DEFAULT 1,
                email_games tinyint(1) DEFAULT 1,
                email_withdrawals tinyint(1) DEFAULT 1,
                email_referrals tinyint(1) DEFAULT 1,
                email_achievements tinyint(1) DEFAULT 1,
                email_promo tinyint(1) DEFAULT 1,
                push_claims tinyint(1) DEFAULT 1,
                push_games tinyint(1) DEFAULT 1,
                push_withdrawals tinyint(1) DEFAULT 1,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY user_id (user_id)
            ) $charset
        ");
    }
}

/* ============================================================
   CREATE NOTIFICATION
   ============================================================ */
function cfp_create_notification($user_id, $type, $title, $message, $link = null) {
    global $wpdb;
    return $wpdb->insert($wpdb->prefix . 'cfp_notifications', [
        'user_id' => $user_id,
        'type' => $type,
        'title' => $title,
        'message' => $message,
        'link' => $link
    ]);
}

function cfp_notify_user($user_id, $type, $title, $message, $link = null) {
    global $wpdb;
    
    cfp_create_notification($user_id, $type, $title, $message, $link);
    
    $prefs = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . $wpdb->prefix . "cfp_notification_prefs WHERE user_id = %d", $user_id
    ));
    
    if (!$prefs) {
        $prefs = (object)[
            'email_claims' => 1, 'email_games' => 1, 'email_withdrawals' => 1,
            'email_referrals' => 1, 'email_achievements' => 1, 'email_promo' => 1
        ];
    }
    
    $send_email = false;
    switch ($type) {
        case 'claim': $send_email = $prefs->email_claims; break;
        case 'game': $send_email = $prefs->email_games; break;
        case 'withdrawal': $send_email = $prefs->email_withdrawals; break;
        case 'referral': $send_email = $prefs->email_referrals; break;
        case 'achievement': $send_email = $prefs->email_achievements; break;
        case 'promo': $send_email = $prefs->email_promo; break;
    }
    
    if ($send_email) {
        $user = $wpdb->get_row($wpdb->prepare("SELECT email FROM " . CFP_TABLE_USERS . " WHERE id = %d", $user_id));
        if ($user && is_email($user->email)) {
            wp_mail($user->email, $title, $message);
        }
    }
}

function cfp_broadcast_notification($type, $title, $message, $link = null) {
    global $wpdb;
    $users = $wpdb->get_col("SELECT id FROM " . CFP_TABLE_USERS . " WHERE is_banned = 0");
    
    foreach ($users as $user_id) {
        cfp_create_notification($user_id, $type, $title, $message, $link);
    }
    
    return count($users);
}

/* ============================================================
   AJAX: Get Notifications
   ============================================================ */
add_action('wp_ajax_cfp_get_notifications', 'cfp_ajax_get_notifications');
add_action('wp_ajax_nopriv_cfp_get_notifications', 'cfp_ajax_get_notifications');
function cfp_ajax_get_notifications() {
    check_ajax_referer('cfp_nonce', 'nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    $limit = intval($_POST['limit'] ?? 20);
    
    if (!is_email($email)) wp_send_json_error(['msg' => 'Invalid email']);
    
    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare("SELECT id FROM " . CFP_TABLE_USERS . " WHERE email = %s", $email));
    
    if (!$user) wp_send_json_error(['msg' => 'User not found']);
    
    $notifications = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM " . $wpdb->prefix . "cfp_notifications 
        WHERE user_id = %d AND is_dismissed = 0 
        ORDER BY created_at DESC LIMIT %d",
        $user->id, $limit
    ));
    
    $unread_count = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_notifications 
        WHERE user_id = %d AND is_read = 0 AND is_dismissed = 0", $user->id
    ));
    
    wp_send_json_success([
        'notifications' => $notifications,
        'unread_count' => $unread_count
    ]);
}

add_action('wp_ajax_cfp_mark_notification_read', 'cfp_ajax_mark_notification_read');
function cfp_ajax_mark_notification_read() {
    check_ajax_referer('cfp_nonce', 'nonce');
    $notification_id = intval($_POST['notification_id']);
    $user_id = cfp_get_current_user_id();
    
    if (!$user_id) wp_send_json_error(['msg' => 'Not authenticated']);
    
    global $wpdb;
    $wpdb->query($wpdb->prepare(
        "UPDATE " . $wpdb->prefix . "cfp_notifications SET is_read = 1 WHERE id = %d AND user_id = %d",
        $notification_id, $user_id
    ));
    
    wp_send_json_success();
}

add_action('wp_ajax_cfp_dismiss_notification', 'cfp_ajax_dismiss_notification');
function cfp_ajax_dismiss_notification() {
    check_ajax_referer('cfp_nonce', 'nonce');
    $notification_id = intval($_POST['notification_id']);
    $user_id = cfp_get_current_user_id();
    
    if (!$user_id) wp_send_json_error(['msg' => 'Not authenticated']);
    
    global $wpdb;
    $wpdb->query($wpdb->prepare(
        "UPDATE " . $wpdb->prefix . "cfp_notifications SET is_dismissed = 1 WHERE id = %d AND user_id = %d",
        $notification_id, $user_id
    ));
    
    wp_send_json_success();
}

/* ============================================================
   AJAX: Update Notification Preferences
   ============================================================ */
add_action('wp_ajax_cfp_update_notification_prefs', 'cfp_ajax_update_notification_prefs');
function cfp_ajax_update_notification_prefs() {
    check_ajax_referer('cfp_nonce', 'nonce');
    $user_id = cfp_get_current_user_id();
    
    if (!$user_id) wp_send_json_error(['msg' => 'Not authenticated']);
    
    global $wpdb;
    $prefs = [
        'user_id' => $user_id,
        'email_claims' => isset($_POST['email_claims']) ? 1 : 0,
        'email_games' => isset($_POST['email_games']) ? 1 : 0,
        'email_withdrawals' => isset($_POST['email_withdrawals']) ? 1 : 0,
        'email_referrals' => isset($_POST['email_referrals']) ? 1 : 0,
        'email_achievements' => isset($_POST['email_achievements']) ? 1 : 0,
        'email_promo' => isset($_POST['email_promo']) ? 1 : 0,
        'push_claims' => isset($_POST['push_claims']) ? 1 : 0,
        'push_games' => isset($_POST['push_games']) ? 1 : 0,
        'push_withdrawals' => isset($_POST['push_withdrawals']) ? 1 : 0,
    ];
    
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM " . $wpdb->prefix . "cfp_notification_prefs WHERE user_id = %d", $user_id
    ));
    
    if ($existing) {
        unset($prefs['user_id']);
        $wpdb->update($wpdb->prefix . 'cfp_notification_prefs', $prefs, ['user_id' => $user_id]);
    } else {
        $wpdb->insert($wpdb->prefix . 'cfp_notification_prefs', $prefs);
    }
    
    wp_send_json_success(['msg' => 'Preferences updated']);
}

/* ============================================================
   SHORTCODE: [cfp_notifications]
   ============================================================ */
add_shortcode('cfp_notifications', function() {
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax = admin_url('admin-ajax.php');
    
    ob_start();
    ?>
    <div class="cfp-widget" id="cfp-notifications-widget">
        <h2>🔔 Notifications</h2>
        
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
            <span id="cfp-notif-count" style="background:var(--g);color:#000;padding:2px 8px;border-radius:10px;font-size:.75rem;font-weight:700">0</span>
            <button onclick="cfpLoadNotifications()" style="background:transparent;border:1px solid #444;color:#888;padding:4px 8px;border-radius:4px;font-size:.7rem;cursor:pointer">Refresh</button>
        </div>
        
        <div id="cfp-notif-list" style="max-height:300px;overflow-y:auto">
            <div style="color:#555;text-align:center;padding:20px">Loading...</div>
        </div>
    </div>
    
    <script>
    let cfpNotifUserEmail = '';
    
    function cfpLoadNotifications(email) {
        if(email) cfpNotifUserEmail = email;
        if(!cfpNotifUserEmail) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_get_notifications');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('email', cfpNotifUserEmail);
        
        fetch('<?=$ajax?>', {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    document.getElementById('cfp-notif-count').textContent = d.data.unread_count;
                    
                    const list = document.getElementById('cfp-notif-list');
                    if(d.data.notifications.length === 0) {
                        list.innerHTML = '<div style="color:#555;text-align:center;padding:20px">No notifications</div>';
                        return;
                    }
                    
                    list.innerHTML = d.data.notifications.map(n => `
                        <div class="cfp-notif-item" style="background:${n.is_read ? '#111' : '#1a1a1a'};border-left:3px solid ${n.is_read ? '#333' : 'var(--g)'};padding:12px;margin-bottom:8px;border-radius:0 6px 6px 0;cursor:pointer" onclick="cfpMarkRead(${n.id})">
                            <div style="font-weight:700;font-size:.85rem">${n.title}</div>
                            <div style="color:#777;font-size:.75rem;margin-top:4px">${n.message}</div>
                            <div style="color:#444;font-size:.65rem;margin-top:6px">${new Date(n.created_at).toLocaleString()}</div>
                        </div>
                    `).join('');
                }
            });
    }
    
    function cfpMarkRead(id) {
        const fd = new FormData();
        fd.append('action', 'cfp_mark_notification_read');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('notification_id', id);
        fetch('<?=$ajax?>', {method: 'POST', body: fd});
    }
    
    window.cfpNotifInit = function(email) { cfpLoadNotifications(email); };
    </script>
    <?php
    return ob_get_clean();
});

/* ============================================================
   HOOK: Notify on claim
   ============================================================ */
add_action('cfp_after_claim', function($user_id, $amount) {
    cfp_notify_user($user_id, 'claim', '💰 Claim Received!', 'You received ' . number_format($amount) . ' satoshis!');
}, 10, 2);

/* ============================================================
   HOOK: Notify on game win
   ============================================================ */
add_action('cfp_after_game_win', function($user_id, $amount, $game) {
    cfp_notify_user($user_id, 'game', '🎮 ' . ucfirst($game) . ' Win!', 'You won ' . number_format($amount) . ' satoshis!');
}, 10, 3);

/* ============================================================
   HOOK: Notify on withdrawal
   ============================================================ */
add_action('cfp_after_withdrawal', function($user_id, $amount) {
    cfp_notify_user($user_id, 'withdrawal', '💸 Withdrawal Processed', 'Your withdrawal of ' . number_format($amount) . ' satoshis has been processed!');
}, 10, 2);

/* ============================================================
   HOOK: Notify on referral signup
   ============================================================ */
add_action('cfp_after_referral_signup', function($referrer_id, $referred_id) {
    cfp_notify_user($referrer_id, 'referral', '👥 New Referral!', 'A new user signed up using your referral link!');
}, 10, 2);
