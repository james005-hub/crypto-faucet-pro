<?php
/**
 * AJAX handlers: withdraw, check FP address, get user, get history, link FP address
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: FAUCETPAY WITHDRAW (instant via API)
   FIX #10: Restored missing opening comment delimiter (parse error).
   FIX #3:  Replaced email-only lookup with cfp_require_auth() session check.
   FIX #2:  Balance is now deducted atomically BEFORE firing the payout,
            then refunded if the API call fails (eliminates TOCTOU race).
   ============================================================ */
add_action('wp_ajax_cfp_withdraw','cfp_ajax_withdraw');
// Note: nopriv hook intentionally absent — withdrawals require an authenticated session.
function cfp_ajax_withdraw() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('withdrawal');

    // FIX #3: Authenticate via session token — no email param accepted.
    $user    = cfp_require_auth();
    $address = sanitize_text_field($_POST['btc_address'] ?? '');
    $amount  = intval($_POST['amount']  ?? 0);
    $currency= strtoupper(sanitize_text_field($_POST['currency'] ?? cfp_get_setting('blockchain_currency','BTC')));

    global $wpdb;

    // Withdrawal controls gate (cooling period, daily cap, fraud checks)
    do_action('cfp_before_withdraw', $user, $amount);

    $fp_enabled = cfp_get_setting('blockchain_enabled','0');

    if ( $fp_enabled ) {
        // ── BLOCKCHAIN ON-CHAIN WITHDRAWAL (via NOWPayments) ──────────────────────
        $min = intval(cfp_get_setting('blockchain_min_withdraw', 1000));
        $fee = intval(cfp_get_setting('blockchain_fee_sat', 0));
        if ( $amount < $min )   wp_send_json_error(['msg' => "Minimum withdrawal is " . number_format($min) . " sat."]);
        if ( empty($address) )  wp_send_json_error(['msg' => 'Enter your wallet address.']);

        // Basic on-chain address sanity check (length + no spaces)
        if ( strlen(trim($address)) < 25 || strpos($address, ' ') !== false ) {
            wp_send_json_error(['msg' => '❌ Invalid address. Please double-check and try again.']);
        }

        $total_deduct = $amount + $fee;

        // Deduct balance atomically BEFORE firing the payout to prevent race conditions.
        $rows = $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
            $total_deduct, $user->id, $total_deduct
        ));
        if ( $rows === 0 ) {
            wp_send_json_error(['msg' => 'Insufficient balance. Please refresh and try again.']);
        }

        // Convert satoshis to coin float for the NOWPayments API
        $amount_coin = $amount / 1e8;
        $np_currency = strtolower($currency);

        // Fire the on-chain payout via NOWPayments
        $result = cfp_np_send_payout($address, $amount_coin, $np_currency);

        $payout_id = $result['id'] ?? ($result['withdrawals'][0]['id'] ?? '');
        $success   = ! empty($payout_id) || isset($result['status']);

        if ( $success ) {
            // Log to the NP withdrawals table so the IPN callback can update status
            $wpdb->insert(CFP_TABLE_NP_WITHDRAWALS, [
                'user_id'     => $user->id,
                'np_payout_id'=> (string) $payout_id,
                'to_address'  => $address,
                'currency'    => $np_currency,
                'amount_sat'  => $amount,
                'fee_sat'     => $fee,
                'status'      => 'sending',
                'np_response' => json_encode($result),
                'created_at'  => current_time('mysql'),
            ]);
            $wpdb->insert(CFP_TABLE_TRANSACTIONS, [
                'user_id'     => $user->id,
                'type'        => 'coinbase_withdrawal',
                'amount_sat'  => -$total_deduct,
                'description' => "On-chain withdrawal {$amount} sat {$currency} → {$address} (ID:{$payout_id})",
            ]);
            // Revenue: withdrawal fee goes directly to admin wallet (sweepable to hardware wallet)
            if ( $fee > 0 ) {
                cfp_wallet_credit_game(
                    'admin_wallet_stream_withdraw_fee',
                    'withdraw_fee',
                    $fee,
                    "Coinbase withdrawal fee from user #{$user->id}"
                );
            }
            wp_send_json_success([
                'msg'       => "✅ Withdrawal of {$amount} sat sent on-chain! Payout ID: {$payout_id}.",
                'payout_id' => $payout_id,
            ]);
        } else {
            // Refund the user if the API call fails
            $wpdb->query($wpdb->prepare(
                "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
                $total_deduct, $user->id
            ));
            $error_msg = $result['message'] ?? ($result['error'] ?? 'Unknown error. Please try again.');
            wp_send_json_error(['msg' => 'Coinbase payout error: ' . $error_msg]);
        }
    } else {
        // ── MANUAL WITHDRAWAL ─────────────────────────────────
        $min = intval(cfp_get_setting('min_withdraw_sat',30000));
        $fee = intval(cfp_get_setting('withdraw_fee_sat',1000));
        if ( $amount < $min ) wp_send_json_error(['msg'=>"Minimum withdrawal is ".number_format($min)." sat."]);
        if ( strlen($address) < 20 )  wp_send_json_error(['msg'=>'Invalid wallet address.']);

        // Lock full amount (including fee) immediately so user cannot double-spend
        // while the request is pending admin approval.
        $total_hold = $amount + $fee;

        // Block duplicate pending requests — one pending at a time
        $already_pending = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . CFP_TABLE_WITHDRAWALS . " WHERE user_id=%d AND status='pending' LIMIT 1",
            $user->id
        ));
        if ( $already_pending ) {
            wp_send_json_error(['msg'=>'You already have a pending withdrawal request. Please wait for it to be processed before submitting another.']);
        }

        // Deduct from balance immediately (funds held until approved or returned on reject)
        $rows = $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
            $total_hold, $user->id, $total_hold
        ));
        if ( $rows === 0 ) {
            wp_send_json_error(['msg'=>'Insufficient balance. Please refresh and try again.']);
        }

        // Log the hold as a pending transaction
        $wpdb->insert(CFP_TABLE_TRANSACTIONS, [
            'user_id'     => $user->id,
            'type'        => 'withdrawal_pending',
            'amount_sat'  => -$total_hold,
            'description' => "Withdrawal request pending — {$amount} sat to {$address} (fee: {$fee} sat)",
        ]);

        // Create withdrawal record
        $wpdb->insert(CFP_TABLE_WITHDRAWALS, [
            'user_id'    => $user->id,
            'btc_address'=> $address,
            'amount_sat' => $amount,
            'fee_sat'    => $fee,
            'status'     => 'pending',
        ]);

        // Credit fee to admin wallet immediately (admin earns fee regardless of outcome)
        if ( $fee > 0 ) cfp_wallet_credit_game('admin_wallet_stream_withdraw_fee', 'withdraw_fee', $fee, "Withdrawal fee from user #{$user->id} ({$amount} sat request)");

        wp_send_json_success(['msg'=>"✅ Withdrawal request submitted! {$total_hold} sat has been held from your balance and will be sent within 24 hours."]);
    }
}

/* ============================================================
   AJAX: CHECK FAUCETPAY ADDRESS
   ============================================================ */
add_action('wp_ajax_cfp_check_fp_address','cfp_check_fp_address_ajax');
add_action('wp_ajax_nopriv_cfp_check_fp_address','cfp_check_fp_address_ajax');
function cfp_check_fp_address_ajax() {
    check_ajax_referer('cfp_nonce','nonce');
    $address  = sanitize_text_field($_POST['address']  ?? '');
    $currency = strtoupper(sanitize_text_field($_POST['currency'] ?? cfp_get_setting('blockchain_currency','BTC')));
    if ( empty($address) ) wp_send_json_error(['msg'=>'Enter an address.']);
    // Validate as a basic on-chain address (length + no spaces; deep validation happens at payout time)
    $valid = strlen(trim($address)) >= 25 && strpos($address, ' ') === false;
    if ( $valid ) wp_send_json_success(['msg' => '✅ Valid address!']);
    else wp_send_json_error(['msg' => '❌ Address not recognised. Please check and try again.']);
}

/* ============================================================
   AJAX: GET BALANCE + USER DATA
   FIX #6: Requires session auth. Removed nopriv hook — balance/ticket
           data must not be accessible to unauthenticated callers.
   FIX #14: Generic error message prevents email enumeration.
   ============================================================ */
add_action('wp_ajax_cfp_get_user','cfp_ajax_get_user');
function cfp_ajax_get_user() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('default');
    $user = cfp_require_auth();

    global $wpdb;
    $remaining=0;
    if($user->last_claim) {
        $interval=intval(cfp_get_setting('claim_interval_minutes',60))*60;
        $remaining=max(0,$interval-(current_time('timestamp')-strtotime($user->last_claim)));
    }
    wp_send_json_success([
        'balance'        =>number_format($user->balance_sat),
        'balance_raw'    =>$user->balance_sat,
        'savings'        =>number_format($user->savings_sat),
        'savings_raw'    =>$user->savings_sat,
        'username'       =>esc_html($user->username),
        'ref_code'       =>$user->ref_code,
        'lottery_tickets'=>$user->lottery_tickets,
        'golden_tickets' =>$user->golden_tickets,
        'total_earned'   =>number_format($user->total_earned),
        'remaining'      =>$remaining,
    ]);
}

/* ============================================================
   AJAX: TRANSACTION HISTORY
   FIX #6: Requires session auth. Removed nopriv hook.
   ============================================================ */
add_action('wp_ajax_cfp_get_history','cfp_ajax_get_history_user');
function cfp_ajax_get_history_user() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('default');
    $user = cfp_require_auth();

    global $wpdb;
    $rows=$wpdb->get_results($wpdb->prepare(
        "SELECT type,amount_sat,description,created_at FROM ".CFP_TABLE_TRANSACTIONS." WHERE user_id=%d ORDER BY created_at DESC LIMIT 50",
        $user->id
    ));
    $data=array_map(fn($r)=>[
        'type'  =>ucwords(str_replace('_',' ',esc_html($r->type))),
        'amount'=>intval($r->amount_sat),
        'desc'  =>esc_html($r->description),
        'date'  =>date('M j, g:ia',strtotime($r->created_at))
    ],$rows);
    wp_send_json_success(['rows'=>$data]);
}

/* ============================================================
   SHORTCODE: [cfp_landing] — Full FreeBitco.in Style Landing Page
   FIX #12: All DB-sourced settings now escaped with esc_html() before
            output. JS string literals use esc_js().
   ============================================================ */
add_shortcode('cfp_landing', function($atts) {
    $name     = cfp_get_setting('faucet_name','FreeCrypto.in');
    $tagline  = cfp_get_setting('faucet_tagline','Win Free Bitcoins Every Hour!');
    $currency = cfp_get_setting('faucet_currency','BTC');
    $min      = cfp_get_setting('min_claim_sat',98);
    $max      = cfp_get_setting('max_claim_sat',200);
    $ref_pct  = cfp_get_setting('referral_percent',50);
    $apy      = cfp_get_setting('savings_apy','4.08');
    $golden_l = cfp_get_setting('golden_prize_label','Win a Lamborghini!');
    $golden_v = cfp_get_setting('golden_prize_usd','200000');
    $monthly  = cfp_get_setting('monthly_prize_sat',32500000);
    $users_d  = number_format(cfp_get_setting('total_users_display',55977844));
    $games_d  = number_format(cfp_get_setting('total_games_display',150955055273));
    $btc_d    = cfp_get_setting('total_btc_display','251,239.37947554');
    $btc_price= number_format(cfp_get_setting('btc_usd_price',67694));
    $interval = cfp_get_setting('claim_interval_minutes',60);
    $logo     = cfp_get_setting('site_logo_url','');
    $nonce    = wp_create_nonce('cfp_nonce');
    $ajax     = admin_url('admin-ajax.php');
    $ref_param= sanitize_text_field($_GET['ref']??'');

    // Pre-escape all setting values for safe HTML output.
    $e_name      = esc_html($name);
    $e_tagline   = esc_html($tagline);
    $e_currency  = esc_html($currency);
    $e_ref_pct   = esc_html($ref_pct);
    $e_apy       = esc_html($apy);
    $e_golden_l  = esc_html($golden_l);
    $e_golden_v  = esc_html(number_format($golden_v));
    $e_monthly   = esc_html(number_format($monthly));
    $e_users_d   = esc_html($users_d);
    $e_games_d   = esc_html($games_d);
    $e_btc_d     = esc_html($btc_d);
    $e_btc_price = esc_html($btc_price);
    $e_btc_d     = esc_html($btc_d);
    $max_usd     = esc_html(number_format($max*intval($btc_price)/100000000,0));

    ob_start(); ?>
    <div class="cfp-page">

    <!-- ── NAVBAR ──────────────────────────── -->
    <div style="background:#000;border-bottom:1px solid #1a1a1a;padding:0 20px;">
        <div style="max-width:1100px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;height:54px">
            <div style="font-family:'Oswald',sans-serif;font-size:1.5rem;font-weight:900;color:var(--cfp-p)">
                <?php if($logo): ?><img src="<?=esc_url($logo)?>" style="height:36px;vertical-align:middle"><?php else: ?>
                <?=$e_name?><?php endif; ?>
            </div>
            <div style="display:flex;align-items:center;gap:6px">
                <span style="font-size:.75rem;color:#555;font-family:'Oswald',sans-serif">1 <?=$e_currency?>≈$<?=$e_btc_price?></span>
                <a href="#cfp-register" style="background:var(--cfp-p);color:#000;padding:7px 16px;border-radius:4px;font-weight:700;font-size:.82rem;text-decoration:none;font-family:'Oswald',sans-serif;letter-spacing:1px">SIGN UP</a>
                <a href="#cfp-faucet-section" style="border:1px solid #333;color:#aaa;padding:7px 14px;border-radius:4px;font-size:.82rem;text-decoration:none;font-family:'Oswald',sans-serif;letter-spacing:1px">LOGIN</a>
            </div>
        </div>
    </div>

    <!-- ── HERO ──────────────────────────────── -->
    <div class="cfp-hero">
        <div class="cfp-hero-inner">
            <div class="cfp-hero-left">
                <h1><?=$e_tagline?><br><span><?=$e_currency?> EVERY HOUR</span></h1>
                <ul class="cfp-feature-list">
                    <li>Win up to <span class="hi">$<?=$max_usd?></span> in free <?=$e_currency?>s</li>
                    <li>Multiply your <?=$e_currency?> playing <span class="hi">HI-LO</span></li>
                    <li>Win Hi-Lo jackpots up to <span class="hi">1 <?=$e_currency?></span></li>
                    <li><span class="hi">Free weekly lottery</span> with big prizes</li>
                    <li><?=$e_golden_l?> with <span class="hi">Golden Tickets</span></li>
                    <li><?=$e_currency?> savings account with <span class="hi"><?=$e_apy?>% daily interest</span></li>
                    <li><span class="hi"><?=$e_ref_pct?>% referral commissions</span> for life</li>
                </ul>
                <a href="#cfp-faucet-section" class="cfp-play-btn">⚡ PLAY NOW</a>
            </div>

            <div id="cfp-register" class="cfp-reg-card">
                <h3>Create an Account</h3>
                <div id="cfp-reg-msg"></div>
                <input class="cfp-reg-input" type="email" id="cfp-signup-email" placeholder="E-mail Address">
                <div style="font-size:.8rem;color:#888;margin-bottom:10px">Password (optional) — we use email login</div>
                <input class="cfp-reg-input" type="text" id="cfp-signup-ref" placeholder="Your Referrer" value="<?=esc_attr($ref_param)?>">
                <div id="cfp-captcha-holder" style="margin-bottom:12px"></div>
                <button class="cfp-reg-btn" onclick="cfpDoRegister()">SIGN UP!</button>
                <p style="font-size:.72rem;color:#aaa;text-align:center;margin-top:12px">Already have an account? <a href="#cfp-faucet-section" style="color:var(--cfp-p)">Claim here</a></p>
            </div>
        </div>
    </div>

    <!-- ── STATS BAR ──────────────────────────── -->
    <div class="cfp-stats-bar">
        <div class="cfp-stats-bar-inner">
            <div>
                <div class="cfp-stat-icon">🕴️</div>
                <div class="cfp-stat-label">Registered Users</div>
                <div class="cfp-stat-number" id="cfp-users-counter"><?=$e_users_d?></div>
            </div>
            <div>
                <div class="cfp-stat-icon" style="font-size:1.5rem;font-family:'Oswald',sans-serif;color:var(--cfp-p)">HI<br>LO</div>
                <div class="cfp-stat-label">Games Played</div>
                <div class="cfp-stat-number"><?=$e_games_d?></div>
            </div>
            <div>
                <div class="cfp-stat-icon">₿</div>
                <div class="cfp-stat-label"><?=$e_currency?>s Won By Users</div>
                <div class="cfp-stat-number"><?=$e_btc_d?></div>
            </div>
        </div>
    </div>

    <!-- ── PLAY NOW BANNER ───────────────────── -->
    <div class="cfp-play-banner">
        <a href="#cfp-faucet-section">⚡ PLAY NOW</a>
    </div>

    <!-- ── FEATURES GRID ─────────────────────── -->
    <div class="cfp-features-section">
        <h2>Features</h2>
        <div class="cfp-features-grid">
            <div class="cfp-feature-card">
                <div class="cfp-feature-img">₿</div>
                <div>
                    <h3>Free <?=$e_currency?> Every Hour</h3>
                    <p>Try your luck with our free to play game and win up to $<?=$max_usd?> in free <?=$e_currency?> every hour!</p>
                </div>
            </div>
            <div class="cfp-feature-card">
                <div class="cfp-feature-img" style="font-family:'Oswald',sans-serif;font-size:1.2rem;color:var(--cfp-p)">HI<br>LO</div>
                <div>
                    <h3>Provably Fair Hi-Lo Game</h3>
                    <p>Play a simple provably fair Hi-Lo game and win big. Auto-play available for a hands-free experience.</p>
                </div>
            </div>
            <div class="cfp-feature-card">
                <div class="cfp-feature-img">🏆</div>
                <div>
                    <h3>Monthly Contest</h3>
                    <p>Play the Hi-Lo game or your favorite P2P events. Rank in the top 10 users to win up to <?=$e_monthly?> sat every month!</p>
                </div>
            </div>
            <div class="cfp-feature-card">
                <div class="cfp-feature-img">📈</div>
                <div>
                    <h3>Earn Interest on Your Deposits</h3>
                    <p>Deposit <?=$e_currency?> in your wallet and earn <?=$e_apy?>% annual interest, compounded daily — completely free.</p>
                </div>
            </div>
            <div class="cfp-feature-card">
                <div class="cfp-feature-img">🤝</div>
                <div>
                    <h3>Peer-to-Peer (P2P) Event Prediction</h3>
                    <p>Multiply your <?=$e_currency?> by predicting your favorite events on our Peer-to-Peer games platform.</p>
                </div>
            </div>
            <div class="cfp-feature-card">
                <div class="cfp-feature-img">🔗</div>
                <div>
                    <h3>Earn Passive <?=$e_currency?> with Referrals</h3>
                    <p>Increase your free <?=$e_currency?> earnings by inviting friends. Earn <?=$e_ref_pct?>% of your friends' free <?=$e_currency?> earnings for a lifetime.</p>
                </div>
            </div>
        </div>
    </div>

    <!-- ── PLAY NOW BANNER 2 ─────────────────── -->
    <div class="cfp-play-banner">
        <a href="#cfp-faucet-section">⚡ PLAY NOW</a>
    </div>

    <!-- ── GOLDEN TICKET ──────────────────────── -->
    <?php if(cfp_get_setting('golden_ticket_enabled',1)): ?>
    <div class="cfp-golden-section">
        <div class="cfp-golden-inner">
            <div class="cfp-golden-img">🏎️</div>
            <div class="cfp-golden-text">
                <div class="eyebrow">Golden Ticket Contest</div>
                <h2><?=strtoupper($e_golden_l)?></h2>
                <div class="cfp-golden-prize">$<?=$e_golden_v?> IN <?=$e_currency?></div>
                <p style="color:#888;font-size:.9rem">Earn Golden Tickets with every claim. The more tickets you have, the higher your chances of winning!</p>
                <a href="#cfp-faucet-section" class="cfp-play-btn" style="display:inline-block;margin-top:16px;font-size:1.1rem;padding:14px 40px">🎫 CLAIM TICKETS</a>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <!-- ── FAUCET SECTION ─────────────────────── -->
    <div id="cfp-faucet-section" style="padding:60px 20px;background:#0a0a0a">
        <div style="max-width:1100px;margin:0 auto">
            <h2 style="font-family:'Oswald',sans-serif;font-size:2rem;font-weight:700;text-align:center;color:#fff;text-transform:uppercase;letter-spacing:3px;margin:0 0 40px">FREE <?=$e_currency?> FAUCET</h2>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:30px;max-width:900px;margin:0 auto">
                <?=do_shortcode('[cfp_faucet]')?>
                <?=do_shortcode('[cfp_hilo]')?>
            </div>
        </div>
    </div>

    <!-- ── LOTTERY + SAVINGS ─────────────────── -->
    <div style="padding:40px 20px;background:#080808">
        <div style="max-width:1100px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr 1fr;gap:26px">
            <?=do_shortcode('[cfp_lottery]')?>
            <?=do_shortcode('[cfp_savings]')?>
            <?=do_shortcode('[cfp_golden]')?>
        </div>
    </div>

    <!-- ── P2P + REFERRAL ────────────────────── -->
    <div style="padding:40px 20px;background:#0a0a0a">
        <div style="max-width:1100px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr;gap:26px">
            <?=do_shortcode('[cfp_p2p]')?>
            <?=do_shortcode('[cfp_referral]')?>
        </div>
    </div>

    <!-- ── LEADERBOARD ───────────────────────── -->
    <div style="padding:40px 20px;background:#080808">
        <div style="max-width:600px;margin:0 auto">
            <?=do_shortcode('[cfp_leaderboard]')?>
        </div>
    </div>

    <!-- ── WHAT IS BITCOIN ───────────────────── -->
    <div style="padding:60px 20px;background:#0a0a0a;max-width:900px;margin:0 auto;text-align:center">
        <h2 style="font-family:'Oswald',sans-serif;font-size:1.8rem;color:#fff;text-transform:uppercase;letter-spacing:3px;margin-bottom:20px">What is Bitcoin?</h2>
        <p style="color:#666;line-height:1.7;font-size:.93rem">Bitcoin is an innovative payment network and a new kind of money. Bitcoin uses peer-to-peer technology to operate with no central authority. Managing transactions and issuing of bitcoins is carried out collectively by the network. <strong style="color:#888">Bitcoin is open-source; its design is public, nobody owns or controls Bitcoin and everyone can take part.</strong></p>
        <a href="#" style="color:var(--cfp-p);font-size:.85rem;text-transform:uppercase;letter-spacing:1px;text-decoration:none;border-bottom:1px solid var(--cfp-p)">Read More…</a>
    </div>

    <!-- ── PLAY NOW BANNER 3 ─────────────────── -->
    <div class="cfp-play-banner">
        <a href="#cfp-faucet-section">⚡ PLAY NOW</a>
    </div>

    <!-- ── FOOTER ────────────────────────────── -->
    <div style="background:#000;padding:40px 20px;border-top:1px solid #111">
        <div style="max-width:1100px;margin:0 auto;display:grid;grid-template-columns:repeat(3,1fr);gap:30px;margin-bottom:30px">
            <div>
                <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:2px;color:#444;margin-bottom:10px">Games</div>
                <?php foreach(['Bitcoin Casino','BTC Dice Game','Lotto','Bitcoin','Bitcoin News'] as $l): ?>
                <div style="margin-bottom:6px"><a href="#" style="color:#555;text-decoration:none;font-size:.82rem;transition:color .15s" onmouseover="this.style.color='var(--cfp-p)'" onmouseout="this.style.color='#555'"><?=esc_html($l)?></a></div>
                <?php endforeach; ?>
            </div>
            <div>
                <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:2px;color:#444;margin-bottom:10px">Account</div>
                <?php foreach(['Promotions','Sign Up','Online Betting','Bitcoin Price','Bitcoin Wallet','Bitcoin Account'] as $l): ?>
                <div style="margin-bottom:6px"><a href="#" style="color:#555;text-decoration:none;font-size:.82rem"><?=esc_html($l)?></a></div>
                <?php endforeach; ?>
            </div>
            <div>
                <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:2px;color:#444;margin-bottom:10px">More</div>
                <?php foreach(['Fun Token','XFUN Wallet','DPlay Casino','XFUN Bet'] as $l): ?>
                <div style="margin-bottom:6px"><a href="#" style="color:#555;text-decoration:none;font-size:.82rem"><?=esc_html($l)?></a></div>
                <?php endforeach; ?>
            </div>
        </div>
        <div style="border-top:1px solid #111;padding-top:20px;text-align:center;color:#333;font-size:.78rem">
            © 2013–<?=date('Y')?>, <?=$e_name?> — All rights reserved.
        </div>
    </div>
    </div>

    <script>
    const cfpAjax='<?=esc_js($ajax)?>';
    const cfpNonce='<?=esc_js($nonce)?>';
    async function cfpDoRegister(){
        const email=document.getElementById('cfp-signup-email').value;
        const ref=document.getElementById('cfp-signup-ref').value;
        if(!email){cfpRegMsg('Please enter your email.','error');return;}
        const fd=new FormData();
        fd.append('action','cfp_register');fd.append('nonce',cfpNonce);fd.append('email',email);fd.append('ref',ref);
        const r=await fetch(cfpAjax,{method:'POST',body:fd});
        const d=await r.json();
        cfpRegMsg(d.data.msg,d.success?'success':'error');
        if(d.success){document.getElementById('cfp-signup-email').value='';setTimeout(()=>{document.getElementById('cfp-faucet-section').scrollIntoView({behavior:'smooth'})},1500);}
    }
    function cfpRegMsg(msg,type){
        document.getElementById('cfp-reg-msg').innerHTML=`<div style="padding:10px 14px;border-radius:6px;margin-bottom:12px;font-size:.85rem;background:${type==='success'?'#d1fae5':'#fee2e2'};color:${type==='success'?'#065f46':'#991b1b'}">${msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});
