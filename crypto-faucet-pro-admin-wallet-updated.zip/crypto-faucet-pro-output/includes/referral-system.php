<?php
/**
 * Advanced Referral System with tiered bonuses, levels, and tracking
 *
 * @package CryptoFaucetPro
 */

if (!defined('ABSPATH')) exit;

/* ============================================================
   REFERRAL TABLES
   ============================================================ */
function cfp_create_referral_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    // Referral levels table
    $table_levels = $wpdb->prefix . 'cfp_referral_levels';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_levels'") != $table_levels) {
        $wpdb->query("
            CREATE TABLE $table_levels (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                level int(11) NOT NULL,
                name varchar(100) NOT NULL,
                min_referrals int(11) DEFAULT 0,
                min_earnings bigint(20) DEFAULT 0,
                bonus_percent decimal(5,2) DEFAULT 0,
                is_active tinyint(1) DEFAULT 1,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY level (level)
            ) $charset
        ");
        
        // Insert default levels
        $wpdb->query("
            INSERT INTO $table_levels (level, name, min_referrals, min_earnings, bonus_percent) VALUES
            (1, 'Bronze', 0, 0, 5),
            (2, 'Silver', 5, 100000, 10),
            (3, 'Gold', 15, 500000, 15),
            (4, 'Platinum', 30, 2000000, 20),
            (5, 'Diamond', 50, 5000000, 25)
        ");
    }

    // Referral payouts table
    $table_payouts = $wpdb->prefix . 'cfp_referral_payouts';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_payouts'") != $table_payouts) {
        $wpdb->query("
            CREATE TABLE $table_payouts (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                referrer_id bigint(20) NOT NULL,
                referred_id bigint(20) NOT NULL,
                amount_sat bigint(20) NOT NULL,
                level_at_payout int(11) DEFAULT 1,
                type enum('claim','game','deposit') DEFAULT 'claim',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY referrer_id (referrer_id),
                KEY referred_id (referred_id)
            ) $charset
        ");
    }
}

// NOTE: cfp_create_referral_tables() is called from cfp_activate() in activation.php

/* ============================================================
   AJAX: Get Referral Info
   ============================================================ */
add_action('wp_ajax_cfp_get_referral_stats', 'cfp_ajax_get_referral_stats');
add_action('wp_ajax_nopriv_cfp_get_referral_stats', 'cfp_ajax_get_referral_stats');
function cfp_ajax_get_referral_stats() {
    check_ajax_referer('cfp_nonce', 'nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    
    if (!is_email($email)) wp_send_json_error(['msg' => 'Invalid email']);
    
    global $wpdb;
    $user = cfp_get_user_by_email($email);
    
    if (!$user) wp_send_json_error(['msg' => 'User not found']);
    
    // Get referral stats
    $total_referrals = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . CFP_TABLE_REFERRALS . " WHERE referrer_id = %d", $user->id
    ));
    
    $active_referrals = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . CFP_TABLE_REFERRALS . " r
         LEFT JOIN " . CFP_TABLE_USERS . " u ON r.referred_id = u.id
         WHERE r.referrer_id = %d AND u.is_banned = 0", $user->id
    ));
    
    $total_earned = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount_sat), 0) FROM " . $wpdb->prefix . "cfp_referral_payouts WHERE referrer_id = %d", $user->id
    ));
    
    // Calculate current level
    $current_level = cfp_calculate_referral_level($total_referrals, $total_earned);
    $next_level = cfp_get_next_referral_level($current_level);
    
    // Get recent referrals
    $recent = $wpdb->get_results($wpdb->prepare("
        SELECT u.username, u.total_earned, r.created_at
        FROM " . CFP_TABLE_REFERRALS . " r
        LEFT JOIN " . CFP_TABLE_USERS . " u ON r.referred_id = u.id
        WHERE r.referrer_id = %d
        ORDER BY r.created_at DESC LIMIT 5
    ", $user->id));
    
    wp_send_json_success([
        'ref_code' => $user->ref_code,
        'total_referrals' => $total_referrals,
        'active_referrals' => $active_referrals,
        'total_earned' => number_format($total_earned),
        'total_earned_raw' => $total_earned,
        'current_level' => $current_level,
        'next_level' => $next_level,
        'recent' => $recent
    ]);
}

/* ============================================================
   HELPER: Calculate Referral Level
   ============================================================ */
function cfp_calculate_referral_level($referrals, $earnings) {
    global $wpdb;
    $levels = $wpdb->get_results("
        SELECT * FROM " . $wpdb->prefix . "cfp_referral_levels
        WHERE is_active = 1
        ORDER BY level DESC
    ");
    
    foreach ($levels as $level) {
        if ($referrals >= $level->min_referrals && $earnings >= $level->min_earnings) {
            return $level;
        }
    }
    
    return $levels[0] ?? null;
}

function cfp_get_next_referral_level($current) {
    if (!$current) return null;
    
    global $wpdb;
    $next = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . $wpdb->prefix . "cfp_referral_levels
        WHERE level = %d AND is_active = 1",
        $current->level + 1
    ));
    
    return $next;
}

/* ============================================================
   PROCESS REFERRAL BONUS
   ============================================================ */
function cfp_process_referral_bonus($referred_id, $amount, $type = 'claim') {
    global $wpdb;
    
    // Get referrer
    $referrer = $wpdb->get_row($wpdb->prepare(
        "SELECT referrer_id FROM " . CFP_TABLE_REFERRALS . " WHERE referred_id = %d", $referred_id
    ));
    
    if (!$referrer) return;
    
    // Get referrer user
    $referrer_user = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_USERS . " WHERE id = %d", $referrer->referrer_id
    ));
    
    if (!$referrer_user || $referrer_user->is_banned) return;
    
    // Get referrer's current level
    $total_referrals = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . CFP_TABLE_REFERRALS . " WHERE referrer_id = %d", $referrer->referrer_id
    ));
    
    $total_earned = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COALESCE(SUM(amount_sat), 0) FROM " . $wpdb->prefix . "cfp_referral_payouts WHERE referrer_id = %d", $referrer->referrer_id
    ));
    
    $level = cfp_calculate_referral_level($total_referrals, $total_earned);
    
    // Calculate bonus (base % + level bonus)
    $base_percent = floatval(cfp_get_setting('referral_percent', 50));
    $level_bonus = $level ? floatval($level->bonus_percent) : 0;
    $total_percent = $base_percent + $level_bonus;
    
    $bonus = floor($amount * ($total_percent / 100));
    
    if ($bonus <= 0) return;
    
    // Credit referrer
    $wpdb->query($wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat = balance_sat + %d WHERE id = %d",
        $bonus, $referrer->referrer_id
    ));
    
    // Record payout
    $wpdb->insert($wpdb->prefix . 'cfp_referral_payouts', [
        'referrer_id' => $referrer->referrer_id,
        'referred_id' => $referred_id,
        'amount_sat' => $bonus,
        'level_at_payout' => $level ? $level->level : 1,
        'type' => $type
    ]);
    
    // Record transaction
    $wpdb->insert(CFP_TABLE_TRANSACTIONS, [
        'user_id' => $referrer->referrer_id,
        'type' => 'referral_bonus',
        'amount_sat' => $bonus,
        'description' => "Referral bonus from user #{$referred_id} ({$type})"
    ]);
    
    // Update referrer total
    $wpdb->query($wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET total_earned = total_earned + %d WHERE id = %d",
        $bonus, $referrer->referrer_id
    ));
}

/* ============================================================
   SHORTCODE: [cfp_referral_dashboard]
   ============================================================ */
add_shortcode('cfp_referral_dashboard', function() {
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax = admin_url('admin-ajax.php');
    
    ob_start();
    ?>
    <div class="cfp-widget" id="cfp-referral-widget">
        <h2>🎯 Referral Program</h2>
        <p class="sub">Invite friends and earn up to 25% bonus on their earnings!</p>
        
        <div id="cfp-ref-msg"></div>
        
        <input type="email" id="cfp-ref-email" placeholder="Your account email" class="cfp-input" onblur="cfpLoadRefStats()">
        
        <div id="cfp-ref-stats" style="display:none">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin:16px 0">
                <div style="background:#111;border-radius:8px;padding:14px;text-align:center">
                    <div style="font-size:1.5rem;font-weight:800;color:var(--g)"><span id="cfp-ref-total">0</span></div>
                    <div style="font-size:.7rem;color:#555;text-transform:uppercase">Total Referrals</div>
                </div>
                <div style="background:#111;border-radius:8px;padding:14px;text-align:center">
                    <div style="font-size:1.5rem;font-weight:800;color:#f7931a"><span id="cfp-ref-earned">0</span></div>
                    <div style="font-size:.7rem;color:#555;text-transform:uppercase">Earned (sat)</div>
                </div>
            </div>
            
            <div style="background:#111;border-radius:8px;padding:14px;margin-bottom:12px">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
                    <span style="font-weight:700" id="cfp-ref-level">Bronze</span>
                    <span style="font-size:.75rem;color:#555" id="cfp-ref-next">Next: Silver (5 refs)</span>
                </div>
                <div style="height:6px;background:#222;border-radius:3px;overflow:hidden">
                    <div id="cfp-ref-progress" style="width:30%;height:100%;background:linear-gradient(90deg,#cd7f32,#ffd700)"></div>
                </div>
            </div>
            
            <div style="background:#0d0d0d;border:1px solid #222;border-radius:8px;padding:14px;margin-bottom:12px">
                <div style="font-size:.7rem;text-transform:uppercase;color:#555;margin-bottom:6px">Your Referral Code</div>
                <div style="display:flex;gap:8px">
                    <input type="text" id="cfp-ref-code" readonly style="flex:1;background:#111;border:1px solid #333;color:var(--g);padding:10px;border-radius:6px;font-family:monospace;font-size:1rem;text-align:center;font-weight:700">
                    <button onclick="cfpCopyRefCode()" style="background:#222;border:1px solid #444;color:#fff;padding:10px 14px;border-radius:6px;cursor:pointer">📋</button>
                </div>
            </div>
            
            <div style="font-size:.8rem;color:#555;margin-bottom:8px">Your Referral Link</div>
            <div style="display:flex;gap:8px">
                <input type="text" id="cfp-ref-link" readonly style="flex:1;background:#111;border:1px solid #333;color:#fff;padding:10px;border-radius:6px;font-size:.85rem">
                <button onclick="cfpCopyRefLink()" style="background:#222;border:1px solid #444;color:#fff;padding:10px 14px;border-radius:6px;cursor:pointer">📋</button>
            </div>
        </div>
    </div>
    
    <script>
    const cfpSiteUrl = '<?=home_url()?>';
    
    async function cfpLoadRefStats() {
        const email = document.getElementById('cfp-ref-email').value;
        if(!email) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_get_referral_stats');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('email', email);
        
        try {
            const r = await fetch('<?=$ajax?>', {method: 'POST', body: fd});
            const d = await r.json();
            
            if(d.success) {
                document.getElementById('cfp-ref-stats').style.display = 'block';
                document.getElementById('cfp-ref-code').value = d.data.ref_code;
                document.getElementById('cfp-ref-link').value = cfpSiteUrl + '/?ref=' + d.data.ref_code;
                document.getElementById('cfp-ref-total').textContent = d.data.total_referrals;
                document.getElementById('cfp-ref-earned').textContent = d.data.total_earned;
                document.getElementById('cfp-ref-level').textContent = d.data.current_level.name;
                
                if(d.data.next_level) {
                    document.getElementById('cfp-ref-next').textContent = 'Next: ' + d.data.next_level.name + 
                        ' (' + d.data.next_level.min_referrals + ' refs)';
                } else {
                    document.getElementById('cfp-ref-next').textContent = 'Max level reached!';
                }
            }
        } catch(e) {}
    }
    
    function cfpCopyRefCode() {
        const code = document.getElementById('cfp-ref-code').value;
        navigator.clipboard.writeText(code);
        alert('Referral code copied!');
    }
    
    function cfpCopyRefLink() {
        const link = document.getElementById('cfp-ref-link').value;
        navigator.clipboard.writeText(link);
        alert('Referral link copied!');
    }
    </script>
    <?php
    return ob_get_clean();
});

/* ============================================================
   ADMIN: REFERRAL SETTINGS
   ============================================================ */
add_action('cfp_security_extra_cards', function() {
    global $wpdb;
    $levels = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "cfp_referral_levels WHERE is_active = 1 ORDER BY level");
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🎯 Referral System Levels</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Configure tiered referral bonuses based on referrer activity.</p>
        
        <table class="cfp-table">
            <thead>
                <tr>
                    <th>Level</th>
                    <th>Name</th>
                    <th>Min Referrals</th>
                    <th>Min Earnings (sat)</th>
                    <th>Bonus %</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($levels as $level): ?>
                <tr>
                    <td><?=$level->level?></td>
                    <td><?=esc_html($level->name)?></td>
                    <td><?=$level->min_referrals?></td>
                    <td><?=number_format($level->min_earnings)?></td>
                    <td style="color:var(--g);font-weight:700">+<?=$level->bonus_percent?>%</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <?php
});
