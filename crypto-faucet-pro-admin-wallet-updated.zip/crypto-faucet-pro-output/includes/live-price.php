<?php
/**
 * Live crypto price fetcher — uses CoinGecko free API, cached in WP transients.
 * Fallback to admin-set static price if API fails.
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_get_live_price( $coin_id = null, $vs = 'usd' ) {
    $coin_id  = $coin_id ?? cfp_coingecko_id();
    $cache_key = "cfp_price_{$coin_id}_{$vs}";
    $cached    = get_transient($cache_key);
    if ( $cached !== false ) return (float) $cached;

    $url = "https://api.coingecko.com/api/v3/simple/price?ids={$coin_id}&vs_currencies={$vs}";
    $res = wp_remote_get($url, ['timeout'=>8,'user-agent'=>'CryptoFaucetPro/4.0']);
    if ( is_wp_error($res) ) return cfp_static_price();

    $body  = json_decode(wp_remote_retrieve_body($res), true);
    $price = $body[$coin_id][$vs] ?? null;
    if ( ! $price ) return cfp_static_price();

    set_transient($cache_key, $price, 120); // cache 2 minutes
    cfp_update_setting('btc_usd_price', $price); // keep static fallback up to date
    return (float) $price;
}

function cfp_static_price() {
    return (float) cfp_get_setting('btc_usd_price', 67000);
}

function cfp_coingecko_id() {
    $currency = strtolower(cfp_get_setting('blockchain_currency','BTC'));
    $map = ['btc'=>'bitcoin','eth'=>'ethereum','ltc'=>'litecoin','doge'=>'dogecoin',
            'dash'=>'dash','bch'=>'bitcoin-cash','trx'=>'tron','bnb'=>'binancecoin',
            'sol'=>'solana','matic'=>'matic-network','usdt'=>'tether'];
    return $map[$currency] ?? 'bitcoin';
}

// AJAX: get live price for frontend ticker
add_action('wp_ajax_cfp_live_price',        'cfp_ajax_live_price');
add_action('wp_ajax_nopriv_cfp_live_price', 'cfp_ajax_live_price');
function cfp_ajax_live_price() {
    check_ajax_referer('cfp_nonce','nonce');
    $coin  = sanitize_text_field($_POST['coin'] ?? '');
    $price = cfp_get_live_price($coin ?: null);
    $currency = strtoupper(cfp_get_setting('blockchain_currency','BTC'));
    wp_send_json_success([
        'price'    => $price,
        'currency' => $currency,
        'formatted'=> '$'.number_format($price, 2),
    ]);
}

// Auto-refresh price every 5 minutes via cron
add_action('cfp_refresh_price_hook', 'cfp_cron_refresh_price');
function cfp_cron_refresh_price() {
    cfp_get_live_price(); // fetches fresh and caches
}
add_action( 'init', function() {
    if ( ! wp_next_scheduled( 'cfp_refresh_price_hook' ) ) {
        wp_schedule_event( time(), 'cfp_5min', 'cfp_refresh_price_hook' );
    }
} );

// Register custom 5-minute cron interval
add_filter('cron_schedules', function($schedules) {
    $schedules['cfp_5min'] = ['interval'=>300,'display'=>'Every 5 minutes'];
    return $schedules;
});

/* ============================================================
   SHORTCODE: [cfp_price_ticker]
   ============================================================ */
add_shortcode('cfp_price_ticker', function() {
    $nonce    = wp_create_nonce('cfp_nonce');
    $ajax     = admin_url('admin-ajax.php');
    $currency = strtoupper(cfp_get_setting('blockchain_currency','BTC'));
    $price    = cfp_get_live_price();
    ob_start(); ?>
    <div id="cfp-ticker" style="display:inline-flex;align-items:center;gap:8px;background:#111;border:1px solid #1c1c1c;border-radius:8px;padding:7px 14px;font-family:'Oswald',sans-serif">
        <span style="font-size:.75rem;color:#555;text-transform:uppercase"><?=esc_html($currency)?>/USD</span>
        <span id="cfp-ticker-price" style="font-size:1.1rem;font-weight:700;color:var(--cfp-p)">$<?=number_format($price,2)?></span>
        <span id="cfp-ticker-dot" style="width:6px;height:6px;border-radius:50%;background:#22c55e;display:inline-block"></span>
    </div>
    <script>
    (async function cfpTickerLoop(){
        const fd=new FormData(); fd.append('action','cfp_live_price'); fd.append('nonce','<?=esc_js($nonce)?>');
        try{
            const r=await fetch('<?=esc_js($ajax)?>',{method:'POST',body:fd}); const d=await r.json();
            if(d.success){
                document.getElementById('cfp-ticker-price').textContent=d.data.formatted;
                const dot=document.getElementById('cfp-ticker-dot');
                dot.style.background='#22c55e';
                setTimeout(()=>dot.style.background='#555',400);
            }
        }catch(e){}
        setTimeout(cfpTickerLoop, 120000); // refresh every 2 min
    })();
    </script>
    <?php return ob_get_clean();
});
