<?php
/**
 * Admin Wallet Controller — Customize, collect, and withdraw admin revenue
 *
 * Features:
 * 1. Custom withdrawal fees (percentage + fixed sat fee)
 * 2. Balance sweep to admin wallet (manual or auto)
 * 3. Revenue streams from transactions with full tracking
 * 4. Auto-sweep to onchain (NOWPayments) — ALL revenue streams convert to onchain automatically
 * 5. Admin UI for configuration and withdrawal
 * 6. INSTANT onchain conversion — convert revenue immediately when earned (not threshold-based)
 * 7. On-chain wallet balance tracking for admin
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   REVENUE CREDIT: Generic function to credit admin wallet from any transaction
   Revenue is stored in admin wallet - admin can withdraw manually via NOWPayments
   ============================================================ */
function cfp_revenue_credit( $stream, $amount_sat, $description = '', $ref_id = null ) {
    if ( $amount_sat <= 0 ) return;
    if ( ! cfp_get_setting('admin_wallet_enabled', '1') ) return;
    
    global $wpdb;
    $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
        'stream'       => $stream,
        'amount_sat'  => $amount_sat,
        'description' => $description,
        'ref_id'      => $ref_id,
    ]);
    
    do_action( 'cfp_after_wallet_credit', $stream, $amount_sat );
}

/* ============================================================
   GET REAL ONCHAIN BALANCE FROM NOWPAYMENTS
   Returns actual crypto balance from your NOWPayments wallet
   ============================================================ */
function cfp_get_onchain_balance_display() {
    if ( ! function_exists('cfp_np_enabled') || ! cfp_np_enabled() ) {
        return ['error' => 'NOWPayments not enabled'];
    }
    
    if ( ! function_exists('cfp_np_get_balance') ) {
        return ['error' => 'NOWPayments API not loaded'];
    }
    
    $balance = cfp_np_get_balance();
    
    if ( ! empty( $balance['error'] ) ) {
        return ['error' => $balance['error']];
    }
    
    return $balance;
}

/* ============================================================
   AUTO ONCHAIN SWEEP — Immediately convert revenue to onchain when threshold met
   ============================================================ */
function cfp_maybe_auto_sweep_onchain( $stream = '' ) {
    $auto_sweep_enabled = cfp_get_setting('revenue_auto_sweep_onchain', '0');
    if ( $auto_sweep_enabled !== '1' ) return;
    
    if ( ! function_exists('cfp_np_enabled') || ! cfp_np_enabled() ) return;
    
    $sweep_address = cfp_get_setting('revenue_onchain_address', '');
    if ( empty( $sweep_address ) ) return;
    
    $threshold = intval( cfp_get_setting('revenue_onchain_threshold', 10000) );
    if ( $threshold <= 0 ) $threshold = 10000;
    
    global $wpdb;
    
    if ( ! empty( $stream ) ) {
        $stream_total = intval( $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE stream = %s AND amount_sat > 0",
            $stream
        )));
        
        if ( $stream_total >= $threshold ) {
            cfp_do_onchain_sweep( $stream, $stream_total, $sweep_address );
        }
    } else {
        $total_in = intval( $wpdb->get_var(
            "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE amount_sat > 0"
        ));
        
        if ( $total_in >= $threshold ) {
            cfp_do_onchain_sweep( 'revenue_auto_sweep', $total_in, $sweep_address );
        }
    }
}

function cfp_do_onchain_sweep( $stream, $amount_sat, $to_address ) {
    if ( $amount_sat <= 0 || empty( $to_address ) ) return;
    
    $currency = strtolower( cfp_get_setting('revenue_onchain_currency', 'btc') );
    
    if ( $currency === 'btc' ) {
        $amount_coin = round( $amount_sat / 100000000, 8 );
    } else {
        $sat_per_usd = floatval( cfp_get_setting( 'np_sat_per_usd', 0 ) );
        if ( $sat_per_usd > 0 ) {
            $amount_coin = round( $amount_sat / $sat_per_usd, 6 );
        } else {
            $btc_price_usd = floatval( get_transient( 'cfp_btc_price_usd' ) );
            if ( $btc_price_usd > 0 ) {
                $btc_amount = $amount_sat / 100000000;
                $amount_coin = round( $btc_amount * $btc_price_usd, 6 );
            } else {
                return;
            }
        }
    }
    
    if ( $amount_coin <= 0.00000001 ) return;
    
    $result = cfp_np_send_payout( $to_address, $amount_coin, $currency, "auto_sweep_{$stream}_" . time() );
    
    global $wpdb;
    if ( ! empty( $result['error'] ) ) {
        $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
            'stream'       => 'revenue_onchain_failed',
            'amount_sat'  => -$amount_sat,
            'description' => "Auto-sweep FAILED to {$to_address}: " . $result['error'],
        ]);
        return;
    }
    
    $payout_id = $result['withdrawals'][0]['id'] ?? 'unknown';
    
    $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
        'stream'       => 'revenue_onchain_sweep',
        'amount_sat'  => -$amount_sat,
        'description' => "Auto-sweep: {$amount_sat} sat ({$amount_coin} {$currency}) to " . substr( $to_address, 0, 12 ) . "... via NOWPayments. Payout ID: {$payout_id}",
    ]);
}

/* ============================================================
   SCHEDULED CRON — Check all streams for sweep eligibility
   ============================================================ */
add_action( 'cfp_revenue_onchain_cron', 'cfp_revenue_onchain_cron_run' );
function cfp_revenue_onchain_cron_run() {
    $auto_sweep_enabled = cfp_get_setting('revenue_auto_sweep_onchain', '0');
    if ( $auto_sweep_enabled !== '1' ) return;
    
    if ( ! function_exists('cfp_np_enabled') || ! cfp_np_enabled() ) return;
    
    $sweep_address = cfp_get_setting('revenue_onchain_address', '');
    if ( empty( $sweep_address ) ) return;
    
    $threshold = intval( cfp_get_setting('revenue_onchain_threshold', 10000) );
    if ( $threshold <= 0 ) $threshold = 10000;
    
    global $wpdb;
    
    $streams = [
        'revenue_withdraw_fee_pct', 'revenue_balance_sweep', 'revenue_deposits',
        'revenue_claims', 'revenue_game_wins', 'revenue_game_losses',
        'revenue_referral_bonus', 'revenue_game_addon', 'revenue_fun_token_fee',
    ];
    
    foreach ( $streams as $stream ) {
        $stream_total = intval( $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE stream = %s AND amount_sat > 0",
            $stream
        )));
        
        if ( $stream_total >= $threshold ) {
            cfp_do_onchain_sweep( $stream, $stream_total, $sweep_address );
        }
    }
}

add_action( 'init', function() {
    if ( ! wp_next_scheduled( 'cfp_revenue_onchain_cron' ) ) {
        wp_schedule_event( time(), 'hourly', 'cfp_revenue_onchain_cron' );
    }
});

/* ============================================================
   CUSTOM WITHDRAWAL FEE: Apply to all withdrawal types
   Hooks into existing withdrawal functions
   ============================================================ */
add_action('cfp_before_withdraw', 'cfp_apply_custom_withdraw_fee', 10, 2);
function cfp_apply_custom_withdraw_fee( $user, $amount ) {
    $pct_fee = floatval( cfp_get_setting('revenue_withdraw_pct_fee', 0) );
    $fixed_fee = intval( cfp_get_setting('revenue_withdraw_fixed_fee', 0) );
    
    if ( $pct_fee > 0 || $fixed_fee > 0 ) {
        $pct_amount = floor( $amount * $pct_fee / 100 );
        $total_fee = $pct_amount + $fixed_fee;
        
        if ( $total_fee > 0 ) {
            global $wpdb;
            $wpdb->update( CFP_TABLE_USERS, 
                ['balance_sat' => $user->balance_sat - $total_fee],
                ['id' => $user->id]
            );
            
            cfp_revenue_credit(
                'revenue_withdraw_fee_pct',
                $total_fee,
                "Custom withdrawal fee: {$pct_amount} sat ({$pct_fee}%) + {$fixed_fee} sat fixed from user #{$user->id}"
            );
        }
    }
}

/* ============================================================
   FUN TOKEN EXTRA FEE: Add extra fee on top of token purchases
   Hooks into existing fun token purchase
   ============================================================ */
add_action('cfp_after_fun_token_purchase', 'cfp_apply_fun_token_extra_fee', 10, 4);
function cfp_apply_fun_token_extra_fee( $user_id, $amount, $price_sat, $total_cost ) {
    $pct_fee = floatval( cfp_get_setting('revenue_fun_token_pct_fee', 0) );
    $fixed_fee = intval( cfp_get_setting('revenue_fun_token_fixed_fee', 0) );
    
    if ( $pct_fee > 0 || $fixed_fee > 0 ) {
        $pct_amount = floor( $total_cost * $pct_fee / 100 );
        $total_fee = $pct_amount + $fixed_fee;
        
        if ( $total_fee > 0 ) {
            global $wpdb;
            $wpdb->query( $wpdb->prepare(
                "UPDATE " . CFP_TABLE_USERS . " SET balance_sat = balance_sat - %d WHERE id = %d",
                $total_fee, $user_id
            ));
            
            $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
                'user_id'     => $user_id,
                'type'       => 'fun_token_fee',
                'amount_sat'  => -$total_fee,
                'description'=> "FUN token extra fee: {$pct_amount} sat ({$pct_fee}%) + {$fixed_fee} sat fixed"
            ]);
            
            cfp_revenue_credit(
                'revenue_fun_token_fee',
                $total_fee,
                "FUN token extra fee: {$pct_amount} sat ({$pct_fee}%) + {$fixed_fee} sat from user #{$user_id}"
            );
        }
    }
}

/* ============================================================
   BALANCE SWEEP: Sweep user balance to admin wallet
   Can be triggered manually or via cron
   ============================================================ */
function cfp_sweep_user_balance( $user_id, $amount_sat, $reason = '' ) {
    if ( $amount_sat <= 0 ) return false;
    
    global $wpdb;
    $user = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_USERS . " WHERE id = %d AND balance_sat >= %d",
        $user_id, $amount_sat
    ));
    
    if ( ! $user ) return false;
    
    $wpdb->query( $wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat = balance_sat - %d WHERE id = %d",
        $amount_sat, $user_id
    ));
    
    $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
        'user_id'     => $user_id,
        'type'       => 'balance_sweep_to_admin',
        'amount_sat' => -$amount_sat,
        'description'=> $reason ?: "Balance sweep to admin wallet: {$amount_sat} sat"
    ]);
    
    cfp_revenue_credit(
        'revenue_balance_sweep',
        $amount_sat,
        $reason ?: "Balance sweep from user #{$user_id}: {$amount_sat} sat"
    );
    
    return true;
}

/* ============================================================
   BALANCE SWEEP: Sweep user balance to admin wallet
   Can be triggered manually or via cron
   ============================================================ */
add_action('cfp_daily_revenue_sweep', 'cfp_daily_revenue_sweep_cron');
function cfp_daily_revenue_sweep_cron() {
    if ( ! cfp_get_setting('revenue_auto_sweep_enabled', '0') ) return;
    if ( ! cfp_get_setting('admin_wallet_enabled', '1') ) return;
    
    $threshold = intval( cfp_get_setting('revenue_sweep_threshold', 0) );
    $pct_sweep = floatval( cfp_get_setting('revenue_sweep_pct', 0) );
    
    if ( $pct_sweep <= 0 ) return;
    
    global $wpdb;
    $users = $wpdb->get_results( "SELECT id, balance_sat FROM " . CFP_TABLE_USERS . " WHERE balance_sat >= " . intval( $threshold ) );
    
    foreach ( $users as $u ) {
        $sweep_amt = floor( $u->balance_sat * $pct_sweep / 100 );
        if ( $sweep_amt > 0 ) {
            cfp_sweep_user_balance( $u->id, $sweep_amt, "Auto daily sweep: {$pct_sweep}% of balance" );
        }
    }
}

add_action('init', function() {
    if ( ! wp_next_scheduled('cfp_daily_revenue_sweep') ) {
        wp_schedule_event( time(), 'daily', 'cfp_daily_revenue_sweep' );
    }
});

/* ============================================================
   TRANSACTION REVENUE: Credit revenue from various transactions
   ============================================================ */
function cfp_credit_transaction_revenue( $user_id, $type, $amount_sat, $description = '' ) {
    $stream = '';
    
    switch ( $type ) {
        case 'deposit':
            $stream = 'revenue_deposits';
            $pct = floatval( cfp_get_setting('revenue_deposit_pct', 0) );
            break;
        case 'game_win':
            $stream = 'revenue_game_wins';
            $pct = floatval( cfp_get_setting('revenue_game_win_pct', 0) );
            break;
        case 'game_loss':
            $stream = 'revenue_game_losses';
            $pct = floatval( cfp_get_setting('revenue_game_loss_pct', 0) );
            break;
        case 'claim':
            $stream = 'revenue_claims';
            $pct = floatval( cfp_get_setting('revenue_claim_pct', 0) );
            break;
        case 'referral_bonus':
            $stream = 'revenue_referral_bonus';
            $pct = floatval( cfp_get_setting('revenue_referral_pct', 0) );
            break;
        // NEW STREAMS
        case 'premium_sale':
            $stream = 'revenue_premium_sales';
            $pct = floatval( cfp_get_setting('revenue_premium_pct', 0) );
            break;
        case 'lottery_ticket':
            $stream = 'revenue_lottery_tickets';
            $pct = floatval( cfp_get_setting('revenue_lottery_pct', 0) );
            break;
        case 'ad_click':
            $stream = 'revenue_ad_clicks';
            $pct = floatval( cfp_get_setting('revenue_ad_pct', 0) );
            break;
        case 'fun_token':
            $stream = 'revenue_fun_token_fee';
            $pct = floatval( cfp_get_setting('revenue_fun_token_pct', 0) );
            break;
        case 'withdraw_fee':
            $stream = 'revenue_withdraw_fee_pct';
            $pct = floatval( cfp_get_setting('revenue_withdraw_pct', 0) );
            break;
        default:
            return;
    }
    
    if ( $pct > 0 ) {
        $revenue = floor( $amount_sat * $pct / 100 );
        if ( $revenue > 0 ) {
            cfp_revenue_credit( $stream, $revenue, $description ?: "Revenue from {$type}: {$revenue} sat", $user_id );
        }
    }
}

/* ============================================================
   AUTO-CREDIT REVENUE FROM ALL TRANSACTIONS
   Hook into all existing transaction types
   ============================================================ */

// Premium membership revenue
add_action('cfp_after_premium_purchase', 'cfp_auto_credit_premium_revenue', 10, 3);
function cfp_auto_credit_premium_revenue( $user_id, $tier, $price_sat ) {
    $pct = floatval( cfp_get_setting('revenue_premium_pct', 0) );
    if ( $pct > 0 ) {
        $revenue = floor( $price_sat * $pct / 100 );
        if ( $revenue > 0 ) {
            cfp_revenue_credit( 'revenue_premium_sales', $revenue, "Premium {$tier} sale: {$price_sat} sat from user #{$user_id}", $user_id );
        }
    }
}

// Lottery ticket revenue
add_action('cfp_after_lottery_ticket_purchase', 'cfp_auto_credit_lottery_revenue', 10, 3);
function cfp_auto_credit_lottery_revenue( $user_id, $quantity, $price_sat ) {
    $pct = floatval( cfp_get_setting('revenue_lottery_pct', 0) );
    if ( $pct > 0 ) {
        $revenue = floor( $price_sat * $pct / 100 );
        if ( $revenue > 0 ) {
            cfp_revenue_credit( 'revenue_lottery_tickets', $revenue, "Lottery tickets: {$quantity} tickets ({$price_sat} sat) from user #{$user_id}", $user_id );
        }
    }
}

// Ad revenue
add_action('cfp_after_ad_click', 'cfp_auto_credit_ad_revenue', 10, 2);
function cfp_auto_credit_ad_revenue( $user_id, $earn_amount ) {
    $pct = floatval( cfp_get_setting('revenue_ad_pct', 0) );
    if ( $pct > 0 ) {
        $revenue = floor( $earn_amount * $pct / 100 );
        if ( $revenue > 0 ) {
            cfp_revenue_credit( 'revenue_ad_clicks', $revenue, "Ad click revenue: {$earn_amount} sat", $user_id );
        }
    }
}

// FUN token revenue
add_action('cfp_after_fun_token_purchase', 'cfp_auto_credit_fun_token_revenue', 10, 3);
function cfp_auto_credit_fun_token_revenue( $user_id, $amount, $price_sat ) {
    $pct = floatval( cfp_get_setting('revenue_fun_token_pct', 0) );
    if ( $pct > 0 ) {
        $revenue = floor( $price_sat * $pct / 100 );
        if ( $revenue > 0 ) {
            cfp_revenue_credit( 'revenue_fun_token_fee', $revenue, "FUN token purchase: {$price_sat} sat from user #{$user_id}", $user_id );
        }
    }
}

/* ============================================================
   GAME REVENUE: Already handled by cfp_wallet_credit_game
   This adds percentage-based revenue on top
   ============================================================ */
add_action('cfp_after_game_result', 'cfp_game_revenue_addon', 10, 4);
function cfp_game_revenue_addon( $user_id, $game, $bet, $payout ) {
    $pct = floatval( cfp_get_setting('revenue_game_pct', 0) );
    if ( $pct <= 0 ) return;
    
    $net = $bet - $payout;
    if ( $net <= 0 ) return;
    
    $revenue = floor( $net * $pct / 100 );
    if ( $revenue > 0 ) {
        cfp_revenue_credit(
            'revenue_game_addon',
            $revenue,
            "Game revenue addon ({$pct}%): {$game} net {$net} sat from user #{$user_id}"
        );
    }
}

/* ============================================================
   ADMIN SETTINGS UI
   ============================================================ */
add_action('cfp_security_extra_cards', 'cfp_revenue_admin_settings_ui');
function cfp_revenue_admin_settings_ui() {
    $gs = fn( $k, $d = '' ) => cfp_get_setting( $k, $d );
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>💰 Admin Wallet Controller</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Customize revenue streams, fees, and balance sweeps. All revenue goes to your admin wallet and can be withdrawn.</p>
        
        <!-- Withdrawal Fees -->
        <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px;padding:16px;margin-bottom:16px">
            <h3 style="color:#f7931a;font-size:.95rem;margin-bottom:12px">💸 Custom Withdrawal Fees</h3>
            <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px">
                <div class="cfp-field">
                    <label>Percentage Fee (%)</label>
                    <input type="number" name="revenue_withdraw_pct_fee" value="<?= esc_attr( $gs('revenue_withdraw_pct_fee', 0) ) ?>" min="0" max="100" step="0.1">
                    <span class="hint">% of withdrawal amount</span>
                </div>
                <div class="cfp-field">
                    <label>Fixed Fee (sat)</label>
                    <input type="number" name="revenue_withdraw_fixed_fee" value="<?= esc_attr( $gs('revenue_withdraw_fixed_fee', 0) ) ?>" min="0">
                    <span class="hint">Additional fixed fee</span>
                </div>
            </div>
        </div>
        
        <!-- FUN Token Fee -->
        <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px;padding:16px;margin-bottom:16px">
            <h3 style="color:#ff6b6b;font-size:.95rem;margin-bottom:12px">🎟️ FUN Token Extra Fee</h3>
            <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px">
                <div class="cfp-field">
                    <label>Percentage Fee (%)</label>
                    <input type="number" name="revenue_fun_token_pct_fee" value="<?= esc_attr( $gs('revenue_fun_token_pct_fee', 0) ) ?>" min="0" max="100" step="0.1">
                    <span class="hint">% of token purchase price</span>
                </div>
                <div class="cfp-field">
                    <label>Fixed Fee (sat)</label>
                    <input type="number" name="revenue_fun_token_fixed_fee" value="<?= esc_attr( $gs('revenue_fun_token_fixed_fee', 0) ) ?>" min="0">
                    <span class="hint">Additional fixed fee</span>
                </div>
            </div>
        </div>
        
        <!-- Transaction Revenue -->
        <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px;padding:16px;margin-bottom:16px">
            <h3 style="color:#a855f7;font-size:.95rem;margin-bottom:12px">📊 ALL Transaction Revenue Percentages</h3>
                <div class="cfp-field">
                    <label>Threshold (sat)</label>
                    <input type="number" name="revenue_onchain_threshold" value="<?= esc_attr( $gs('revenue_onchain_threshold', 10000) ) ?>" min="100">
                    <span class="hint">Min amount to trigger sweep</span>
                </div>
                <div class="cfp-field">
                    <label>Currency</label>
                    <select name="revenue_onchain_currency" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                        <option value="btc" <?= selected( $gs('revenue_onchain_currency','btc'), 'btc', false ) ?>>BTC</option>
                        <option value="eth" <?= selected( $gs('revenue_onchain_currency','btc'), 'eth', false ) ?>>ETH</option>
                        <option value="ltc" <?= selected( $gs('revenue_onchain_currency','btc'), 'ltc', false ) ?>>LTC</option>
                        <option value="doge" <?= selected( $gs('revenue_onchain_currency','btc'), 'doge', false ) ?>>DOGE</option>
                        <option value="usdt" <?= selected( $gs('revenue_onchain_currency','btc'), 'usdt', false ) ?>>USDT</option>
                    </select>
                    <span class="hint">Crypto to send onchain</span>
                </div>
            </div>
        </div>
        
        <!-- Balance Sweep -->
        <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px;padding:16px;margin-bottom:16px">
            <h3 style="color:#22c55e;font-size:.95rem;margin-bottom:12px">🔄 Auto Balance Sweep</h3>
            <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px">
                <div class="cfp-field">
                    <label>Enable Auto Sweep</label>
                    <select name="revenue_auto_sweep_enabled" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                        <option value="0" <?= selected( $gs('revenue_auto_sweep_enabled','0'), '0', false ) ?>>Disabled</option>
                        <option value="1" <?= selected( $gs('revenue_auto_sweep_enabled','0'), '1', false ) ?>>Enabled</option>
                    </select>
                    <span class="hint">Daily automatic sweep</span>
                </div>
                <div class="cfp-field">
                    <label>Sweep Percentage (%)</label>
                    <input type="number" name="revenue_sweep_pct" value="<?= esc_attr( $gs('revenue_sweep_pct', 0) ) ?>" min="0" max="100" step="0.1">
                    <span class="hint">% of user balance to sweep</span>
                </div>
                <div class="cfp-field">
                    <label>Minimum Balance (sat)</label>
                    <input type="number" name="revenue_sweep_threshold" value="<?= esc_attr( $gs('revenue_sweep_threshold', 10000) ) ?>" min="0">
                    <span class="hint">Min balance to trigger sweep</span>
                </div>
            </div>
        </div>
        
        <!-- Transaction Revenue -->
        <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px;padding:16px;margin-bottom:16px">
            <h3 style="color:#a855f7;font-size:.95rem;margin-bottom:12px">📊 ALL Transaction Revenue Percentages</h3>
            <p style="color:#777;font-size:.78rem;margin-bottom:12px">Set percentage to earn from each transaction type. Revenue converts onchain automatically when enabled.</p>
            <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px">
                <div class="cfp-field">
                    <label>Deposits (%)</label>
                    <input type="number" name="revenue_deposit_pct" value="<?= esc_attr( $gs('revenue_deposit_pct', 0) ) ?>" min="0" max="100" step="0.1">
                </div>
                <div class="cfp-field">
                    <label>Claims (%)</label>
                    <input type="number" name="revenue_claim_pct" value="<?= esc_attr( $gs('revenue_claim_pct', 0) ) ?>" min="0" max="100" step="0.1">
                </div>
                <div class="cfp-field">
                    <label>Game Wins (%)</label>
                    <input type="number" name="revenue_game_win_pct" value="<?= esc_attr( $gs('revenue_game_win_pct', 0) ) ?>" min="0" max="100" step="0.1">
                </div>
                <div class="cfp-field">
                    <label>Game Losses (%)</label>
                    <input type="number" name="revenue_game_loss_pct" value="<?= esc_attr( $gs('revenue_game_loss_pct', 0) ) ?>" min="0" max="100" step="0.1">
                </div>
                <div class="cfp-field">
                    <label>Referral Bonus (%)</label>
                    <input type="number" name="revenue_referral_pct" value="<?= esc_attr( $gs('revenue_referral_pct', 0) ) ?>" min="0" max="100" step="0.1">
                </div>
                <div class="cfp-field">
                    <label>Game Net (%)</label>
                    <input type="number" name="revenue_game_pct" value="<?= esc_attr( $gs('revenue_game_pct', 0) ) ?>" min="0" max="100" step="0.1">
                    <span class="hint">% of game net (bet - payout)</span>
                </div>
                <!-- NEW: Additional revenue streams -->
                <div class="cfp-field">
                    <label>Premium Sales (%)</label>
                    <input type="number" name="revenue_premium_pct" value="<?= esc_attr( $gs('revenue_premium_pct', 0) ) ?>" min="0" max="100" step="0.1">
                </div>
                <div class="cfp-field">
                    <label>Lottery Tickets (%)</label>
                    <input type="number" name="revenue_lottery_pct" value="<?= esc_attr( $gs('revenue_lottery_pct', 0) ) ?>" min="0" max="100" step="0.1">
                </div>
                <div class="cfp-field">
                    <label>Ad Revenue (%)</label>
                    <input type="number" name="revenue_ad_pct" value="<?= esc_attr( $gs('revenue_ad_pct', 0) ) ?>" min="0" max="100" step="0.1">
                </div>
                <div class="cfp-field">
                    <label>FUN Token (%)</label>
                    <input type="number" name="revenue_fun_token_pct" value="<?= esc_attr( $gs('revenue_fun_token_pct', 0) ) ?>" min="0" max="100" step="0.1">
                </div>
                <div class="cfp-field">
                    <label>Withdrawal Fee (%)</label>
                    <input type="number" name="revenue_withdraw_pct" value="<?= esc_attr( $gs('revenue_withdraw_pct', 0) ) ?>" min="0" max="100" step="0.1">
                </div>
            </div>
        </div>
    </div>
    <?php
}

/* ============================================================
   REVENUE SWEEP: Auto-sweep revenue to Trezor
   Hooks into existing cfp_after_wallet_credit → trezor auto-sweep
   ============================================================ */
add_filter('cfp_trezor_sweep_threshold_defaults', 'cfp_revenue_sweep_threshold_defaults');
function cfp_revenue_sweep_threshold_defaults( $defaults ) {
    return array_merge( $defaults, [
        'revenue_withdraw_fee_pct'    => 50000,
        'revenue_balance_sweep'      => 50000,
        'revenue_deposits'           => 75000,
        'revenue_claims'            => 75000,
        'revenue_game_wins'        => 50000,
        'revenue_game_losses'      => 50000,
        'revenue_referral_bonus'    => 75000,
        'revenue_game_addon'        => 50000,
        'revenue_fun_token_fee'      => 50000,
    ]);
}

/* ============================================================
   ADD REVENUE STREAMS TO WALLET DISPLAY
   ============================================================ */
add_filter('cfp_wallet_streams', 'cfp_revenue_wallet_streams');
function cfp_revenue_wallet_streams( $streams ) {
    return array_merge( $streams, [
        'revenue_withdraw_fee_pct'    => ['💸','Custom Withdrawal Fee', '#f7931a'],
        'revenue_balance_sweep'      => ['🔄','Balance Sweep Revenue',   '#22c55e'],
        'revenue_deposits'        => ['💳','Deposit Revenue',    '#3b82f6'],
        'revenue_claims'         => ['🚿','Claim Revenue',      '#06b6d4'],
        'revenue_game_wins'      => ['🎮','Game Win Revenue',  '#a855f7'],
        'revenue_game_losses'     => ['📉','Game Loss Revenue',  '#ef4444'],
        'revenue_referral_bonus'   => ['👥','Referral Revenue',   '#fbbf24'],
        'revenue_game_addon'     => ['➕','Game Revenue Addon','#f97316'],
        'revenue_fun_token_fee'   => ['🎟️','FUN Token Extra Fee','#ff6b6b'],
        'revenue_onchain_sweep'   => ['⛽','Onchain Sweep (out)', '#ef4444'],
        'revenue_onchain_failed' => ['❌','Onchain Fail', '#dc2626'],
        // Additional revenue streams
        'revenue_premium_sales' => ['⭐','Premium Membership Sales', '#fbbf24'],
        'revenue_lottery_tickets' => ['🎟️','Lottery Ticket Sales', '#a855f7'],
        'revenue_ad_clicks' => ['📺','Ad Revenue', '#3b82f6'],
    ]);
}

/* ============================================================
   REVENUE SUMMARY AJAX
   ============================================================ */
add_action('wp_ajax_cfp_revenue_summary', 'cfp_ajax_revenue_summary');
function cfp_ajax_revenue_summary() {
    check_ajax_referer('cfp_nonce', 'nonce');
    if ( ! current_user_can('manage_options') ) wp_send_json_error(['msg' => 'Unauthorized']);
    
    global $wpdb;
    $streams = [
        'revenue_withdraw_fee_pct', 'revenue_balance_sweep', 'revenue_deposits',
        'revenue_claims', 'revenue_game_wins', 'revenue_game_losses',
        'revenue_referral_bonus', 'revenue_game_addon'
    ];
    
    $summary = [];
    foreach ( $streams as $s ) {
        $summary[$s] = intval( $wpdb->get_var( $wpdb->prepare(
            "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE stream = %s",
            $s
        )));
    }
    
    wp_send_json_success( $summary );
}

/* ============================================================
   MANUAL BALANCE SWEEP ADMIN ACTION
   ============================================================ */
add_action('admin_init', 'cfp_admin_balance_sweep_handler');
function cfp_admin_balance_sweep_handler() {
    if ( ! isset($_GET['page']) || $_GET['page'] !== 'cfp-revenue-sweep' ) return;
    if ( ! isset($_GET['action']) || $_GET['action'] !== 'sweep' ) return;
    if ( ! isset($_GET['user_id']) || ! isset($_GET['amount']) ) return;
    if ( ! wp_verify_nonce($_GET['_wpnonce'], 'cfp_revenue_sweep') ) return;
    if ( ! current_user_can('manage_options') ) return;
    
    $user_id = intval($_GET['user_id']);
    $amount = intval($_GET['amount']);
    
    cfp_sweep_user_balance( $user_id, $amount, "Manual sweep by admin" );
    
    wp_safe_redirect( add_query_arg(['page' => 'cfp-revenue-sweep', 'swept' => '1'], admin_url('admin.php')) );
    exit;
}