<?php
/**
 * Achievement/Badge System
 *
 * @package CryptoFaucetPro
 */

if (!defined('ABSPATH')) exit;

/* ============================================================
   ACHIEVEMENT TABLES
   ============================================================ */
function cfp_create_achievement_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $table_badges = $wpdb->prefix . 'cfp_badges';
    // SECURITY FIX: Use prepared statement for table existence check
    $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_badges));
    if ($table_exists != $table_badges) {
        // Use esc_sql for WP 5.8+ compatibility (avoid %i which requires WP 6.2+)
        $wpdb->query("
            CREATE TABLE `" . esc_sql($table_badges) . "` (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                slug varchar(50) NOT NULL UNIQUE,
                name varchar(100) NOT NULL,
                description text,
                icon varchar(50) DEFAULT 'trophy',
                category enum('claims','games','referrals','social','special') DEFAULT 'special',
                requirement_type varchar(30) NOT NULL,
                requirement_value bigint(20) NOT NULL,
                reward_xp int(11) DEFAULT 0,
                reward_tokens int(11) DEFAULT 0,
                rarity enum('common','uncommon','rare','epic','legendary') DEFAULT 'common',
                is_active tinyint(1) DEFAULT 1,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY slug (slug),
                KEY category (category)
            ) $charset
        ");

        $default_badges = [
            ['first_claim', 'First Claim', 'Complete your first claim', 'star', 'claims', 'total_claims', 1, 10, 0, 'common'],
            ['claim_10', 'Getting Started', 'Complete 10 claims', 'medal', 'claims', 'total_claims', 10, 25, 0, 'common'],
            ['claim_100', 'Regular Visitor', 'Complete 100 claims', 'award', 'claims', 'total_claims', 100, 50, 0, 'uncommon'],
            ['claim_500', 'Dedicated Faucet User', 'Complete 500 claims', 'crown', 'claims', 'total_claims', 500, 100, 0, 'rare'],
            ['claim_1000', 'Faucet Master', 'Complete 1000 claims', 'gem', 'claims', 'total_claims', 1000, 200, 0, 'epic'],
            ['claim_5000', 'Faucet Legend', 'Complete 5000 claims', 'lightning', 'claims', 'total_claims', 5000, 500, 0, 'legendary'],
            ['win_1_game', 'First Win', 'Win your first game', 'gamepad', 'games', 'total_wins', 1, 15, 0, 'common'],
            ['win_50_games', 'Game Enthusiast', 'Win 50 games', 'trophy', 'games', 'total_wins', 50, 50, 0, 'uncommon'],
            ['win_200_games', 'High Roller', 'Win 200 games', 'crown', 'games', 'total_wins', 200, 150, 0, 'rare'],
            ['win_1000_games', 'Casino Pro', 'Win 1000 games', 'diamond', 'games', 'total_wins', 1000, 300, 0, 'epic'],
            ['refer_1', 'First Referral', 'Refer your first user', 'users', 'referrals', 'total_referrals', 1, 25, 0, 'common'],
            ['refer_10', 'Network Builder', 'Refer 10 users', 'share', 'referrals', 'total_referrals', 10, 75, 0, 'uncommon'],
            ['refer_50', 'Affiliate Pro', 'Refer 50 users', 'globe', 'referrals', 'total_referrals', 50, 200, 0, 'rare'],
            ['refer_100', 'Empire Builder', 'Refer 100 users', 'rocket', 'referrals', 'total_referrals', 100, 500, 0, 'epic'],
            ['earn_100k', 'Sat Collector', 'Earn 100,000 satoshis', 'bitcoin', 'special', 'total_earned', 100000, 100, 0, 'uncommon'],
            ['earn_1m', 'Millionaire', 'Earn 1,000,000 satoshis', 'money', 'special', 'total_earned', 1000000, 250, 0, 'rare'],
            ['earn_10m', 'Crypto Whale', 'Earn 10,000,000 satoshis', 'whale', 'special', 'total_earned', 10000000, 1000, 0, 'legendary'],
            ['streak_7', 'Weekly Streak', 'Claim 7 days in a row', 'fire', 'special', 'claim_streak', 7, 50, 0, 'uncommon'],
            ['streak_30', 'Monthly Streak', 'Claim 30 days in a row', 'flame', 'special', 'claim_streak', 30, 150, 0, 'rare'],
            ['streak_100', 'Unstoppable', 'Claim 100 days in a row', 'bolt', 'special', 'claim_streak', 100, 500, 0, 'legendary'],
            ['verify_email', 'Verified', 'Verify your email address', 'check', 'special', 'email_verified', 1, 25, 0, 'common'],
            ['enable_2fa', 'Security Conscious', 'Enable two-factor authentication', 'shield', 'special', '2fa_enabled', 1, 50, 0, 'uncommon'],
        ];

        foreach ($default_badges as $badge) {
            $wpdb->insert($table_badges, [
                'slug' => $badge[0],
                'name' => $badge[1],
                'description' => $badge[2],
                'icon' => $badge[3],
                'category' => $badge[4],
                'requirement_type' => $badge[5],
                'requirement_value' => $badge[6],
                'reward_xp' => $badge[7],
                'reward_tokens' => $badge[8],
                'rarity' => $badge[9]
            ]);
        }
    }

    $table_user_badges = $wpdb->prefix . 'cfp_user_badges';
    // SECURITY FIX: Use prepared statement for table existence check
    $table_exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_user_badges));
    if ($table_exists != $table_user_badges) {
        // Use esc_sql for WP 5.8+ compatibility (avoid %i which requires WP 6.2+)
        $wpdb->query("
            CREATE TABLE `" . esc_sql($table_user_badges) . "` (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                badge_id bigint(20) NOT NULL,
                earned_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                UNIQUE KEY user_badge (user_id, badge_id),
                KEY user_id (user_id),
                KEY badge_id (badge_id)
            ) $charset
        ");
    }
}

/* ============================================================
   CHECK & AWARD BADGES
   ============================================================ */
function cfp_check_user_badges($user_id) {
    global $wpdb;
    
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . CFP_TABLE_USERS . " WHERE id = %d", $user_id));
    if (!$user) return [];

    $earned_ids = $wpdb->get_col($wpdb->prepare(
        "SELECT badge_id FROM " . $wpdb->prefix . "cfp_user_badges WHERE user_id = %d", $user_id
    ));

    // SECURITY FIX: Use prepared statement for SELECT query
    $badges = $wpdb->get_results("SELECT * FROM `" . esc_sql($wpdb->prefix . "cfp_badges") . "` WHERE is_active = 1");
    $newly_earned = [];

    foreach ($badges as $badge) {
        if (in_array($badge->id, $earned_ids)) continue;

        $qualifies = false;
        switch ($badge->requirement_type) {
            case 'total_claims':
                $qualifies = $user->total_claims >= $badge->requirement_value;
                break;
            case 'total_wins':
                $qualifies = $user->total_wins >= $badge->requirement_value;
                break;
            case 'total_referrals':
                $ref_count = (int)$wpdb->get_var($wpdb->prepare(
                    "SELECT COUNT(*) FROM " . CFP_TABLE_REFERRALS . " WHERE referrer_id = %d", $user_id
                ));
                $qualifies = $ref_count >= $badge->requirement_value;
                break;
            case 'total_earned':
                $qualifies = $user->total_earned >= $badge->requirement_value;
                break;
            case 'claim_streak':
                $qualifies = $user->claim_streak >= $badge->requirement_value;
                break;
            case 'email_verified':
                $qualifies = $user->email_verified == 1;
                break;
            case '2fa_enabled':
                $qualifies = get_user_meta($user->wp_user_id, 'cfp_2fa_enabled', true) == 1;
                break;
        }

        if ($qualifies) {
            $wpdb->insert($wpdb->prefix . 'cfp_user_badges', [
                'user_id' => $user_id,
                'badge_id' => $badge->id
            ]);

            if ($badge->reward_xp > 0) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE " . CFP_TABLE_USERS . " SET xp = xp + %d WHERE id = %d",
                    $badge->reward_xp, $user_id
                ));
            }

            if ($badge->reward_tokens > 0) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE " . CFP_TABLE_USERS . " SET balance_sat = balance_sat + %d WHERE id = %d",
                    $badge->reward_tokens * 100000000, $user_id
                ));
            }

            $newly_earned[] = $badge;
        }
    }

    return $newly_earned;
}

/* ============================================================
   AJAX: Get User Badges
   ============================================================ */
add_action('wp_ajax_cfp_get_user_badges', 'cfp_ajax_get_user_badges');
add_action('wp_ajax_nopriv_cfp_get_user_badges', 'cfp_ajax_get_user_badges');
function cfp_ajax_get_user_badges() {
    check_ajax_referer('cfp_nonce', 'nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    
    if (!is_email($email)) wp_send_json_error(['msg' => 'Invalid email']);
    
    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare("SELECT id FROM " . CFP_TABLE_USERS . " WHERE email = %s", $email));
    
    if (!$user) wp_send_json_error(['msg' => 'User not found']);
    
    $badges = $wpdb->get_results($wpdb->prepare("
        SELECT b.*, ub.earned_at FROM " . $wpdb->prefix . "cfp_badges b
        LEFT JOIN " . $wpdb->prefix . "cfp_user_badges ub ON b.id = ub.badge_id AND ub.user_id = %d
        WHERE b.is_active = 1
        ORDER BY b.rarity DESC, b.requirement_value
    ", $user->id));
    
    $earned_count = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_user_badges WHERE user_id = %d", $user->id
    ));
    
    // SECURITY FIX: Use prepared statement
    $total_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM `" . esc_sql($wpdb->prefix . "cfp_badges") . "` WHERE is_active = 1");
    
    wp_send_json_success([
        'badges' => $badges,
        'earned_count' => $earned_count,
        'total_count' => $total_count
    ]);
}

/* ============================================================
   SHORTCODE: [cfp_achievements]
   ============================================================ */
add_shortcode('cfp_achievements', function() {
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax = admin_url('admin-ajax.php');
    
    ob_start();
    ?>
    <div class="cfp-widget" id="cfp-achievements-widget">
        <h2>🏆 Achievements</h2>
        <p class="sub">Earn badges and rewards!</p>
        
        <div id="cfp-badge-msg"></div>
        
        <input type="email" id="cfp-badge-email" placeholder="Your account email" class="cfp-input" onblur="cfpLoadBadges()">
        
        <div id="cfp-badge-stats" style="display:none">
            <div style="background:#111;border-radius:8px;padding:14px;margin:16px 0;text-align:center">
                <div style="font-size:1.5rem;font-weight:800;color:var(--g)">
                    <span id="cfp-badge-earned">0</span> / <span id="cfp-badge-total">0</span>
                </div>
                <div style="font-size:.7rem;color:#555;text-transform:uppercase">Badges Earned</div>
            </div>
            
            <div id="cfp-badges-grid" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(80px,1fr));gap:10px;margin-top:16px"></div>
        </div>
    </div>
    
    <script>
    async function cfpLoadBadges() {
        const email = document.getElementById('cfp-badge-email').value;
        if(!email) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_get_user_badges');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('email', email);
        
        try {
            const r = await fetch('<?=$ajax?>', {method: 'POST', body: fd});
            const d = await r.json();
            
            if(d.success) {
                document.getElementById('cfp-badge-stats').style.display = 'block';
                document.getElementById('cfp-badge-earned').textContent = d.data.earned_count;
                document.getElementById('cfp-badge-total').textContent = d.data.total_count;
                
                const grid = document.getElementById('cfp-badges-grid');
                grid.innerHTML = '';
                
                d.data.badges.forEach(badge => {
                    const earned = badge.earned_at !== null;
                    const rarityColors = {
                        'common': '#888',
                        'uncommon': '#1eff00',
                        'rare': '#0070dd',
                        'epic': '#a335ee',
                        'legendary': '#ff8000'
                    };
                    
                    const div = document.createElement('div');
                    div.style.cssText = 'background:' + (earned ? '#1a1a1a' : '#111') + ';border-radius:8px;padding:12px;text-align:center;opacity:' + (earned ? '1' : '0.4');
                    div.title = badge.name + ': ' + badge.description + (badge.earned_at ? '\nEarned: ' + badge.earned_at : '');
                    div.innerHTML = `
                        <div style="font-size:1.5rem;margin-bottom:4px">${earned ? '🏅' : '🔒'}</div>
                        <div style="font-size:.65rem;color:${rarityColors[badge.rarity]};font-weight:700">${badge.name}</div>
                    `;
                    grid.appendChild(div);
                });
            }
        } catch(e) {}
    }
    </script>
    <?php
    return ob_get_clean();
});

/* ============================================================
   ADMIN: BADGE MANAGEMENT
   ============================================================ */
add_action('cfp_security_extra_cards', function() {
    global $wpdb;
    // SECURITY FIX: Use prepared statement
    $badges = $wpdb->get_results("SELECT * FROM `" . esc_sql($wpdb->prefix . "cfp_badges") . "` ORDER BY category, requirement_value");
    $categories = ['claims', 'games', 'referrals', 'special'];
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🏆 Achievement Badges</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Manage achievement badges and rewards.</p>
        
        <?php foreach($categories as $cat): ?>
        <h3 style="color:var(--g);margin:16px 0 8px;text-transform:capitalize"><?=$cat?> Badges</h3>
        <table class="cfp-table">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Requirement</th>
                    <th>XP</th>
                    <th>Rarity</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach(array_filter($badges, function($b) use($cat) { return $b->category == $cat; }) as $badge): ?>
                <tr>
                    <td><?=esc_html($badge->name)?></td>
                    <td><?=$badge->requirement_value?> (<?=$badge->requirement_type?>)</td>
                    <td><?=$badge->reward_xp?></td>
                    <td style="color:<?=$badge->rarity == 'legendary' ? '#ff8000' : '#888'?>;font-weight:700"><?=$badge->rarity?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php endforeach; ?>
    </div>
    <?php
});
