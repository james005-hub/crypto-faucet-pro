<?php
/**
 * Traffic Analytics System
 *
 * @package CryptoFaucetPro
 */

if (!defined('ABSPATH')) exit;

/* ============================================================
   TRAFFIC ANALYTICS TABLES
   ============================================================ */
function cfp_create_traffic_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $table_sessions = $wpdb->prefix . 'cfp_traffic_sessions';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_sessions'") != $table_sessions) {
        $wpdb->query("
            CREATE TABLE $table_sessions (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                session_id varchar(64) NOT NULL UNIQUE,
                user_id bigint(20) DEFAULT NULL,
                ip_address varchar(45) NOT NULL,
                country varchar(2) DEFAULT NULL,
                city varchar(100) DEFAULT NULL,
                referrer varchar(500) DEFAULT NULL,
                user_agent text,
                device_type varchar(20) DEFAULT 'desktop',
                browser varchar(50) DEFAULT NULL,
                os varchar(50) DEFAULT NULL,
                is_bot tinyint(1) DEFAULT 0,
                page_views int(11) DEFAULT 0,
                time_on_site int(11) DEFAULT 0,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                last_activity datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY session_id (session_id),
                KEY user_id (user_id),
                KEY ip_address (ip_address),
                KEY created_at (created_at)
            ) $charset
        ");
    }

    $table_pageviews = $wpdb->prefix . 'cfp_traffic_pageviews';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_pageviews'") != $table_pageviews) {
        $wpdb->query("
            CREATE TABLE $table_pageviews (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                session_id varchar(64) NOT NULL,
                path varchar(500) NOT NULL,
                title varchar(200) DEFAULT NULL,
                query_string varchar(500) DEFAULT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY session_id (session_id),
                KEY created_at (created_at)
            ) $charset
        ");
    }

    $table_traffic_summary = $wpdb->prefix . 'cfp_traffic_summary';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_traffic_summary'") != $table_traffic_summary) {
        $wpdb->query("
            CREATE TABLE $table_traffic_summary (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                date date NOT NULL,
                unique_visitors int(11) DEFAULT 0,
                page_views int(11) DEFAULT 0,
                bounces int(11) DEFAULT 0,
                new_visitors int(11) DEFAULT 0,
                returning_visitors int(11) DEFAULT 0,
                avg_time_on_site int(11) DEFAULT 0,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                UNIQUE KEY date (date)
            ) $charset
        ");
    }
}

/* ============================================================
   TRACK PAGE VIEW
   ============================================================ */
function cfp_track_page_view($path = '') {
    if (is_admin() || wp_doing_cron()) return;
    
    // NOTE: uses cfp_analytics_sid (not cfp_session) to avoid colliding with the auth session cookie.
    $session_id = isset($_COOKIE['cfp_analytics_sid']) ? sanitize_text_field($_COOKIE['cfp_analytics_sid']) : wp_generate_password(32, false);

    if (!isset($_COOKIE['cfp_analytics_sid'])) {
        setcookie('cfp_analytics_sid', $session_id, time() + (86400 * 30), '/');
    }
    
    $ip = cfp_get_client_ip();
    $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $is_bot = cfp_detect_bot($user_agent);
    
    if ($is_bot) return;
    
    global $wpdb;
    
    $existing = $wpdb->get_row($wpdb->prepare(
        "SELECT id, page_views FROM " . $wpdb->prefix . "cfp_traffic_sessions WHERE session_id = %s",
        $session_id
    ));
    
    if ($existing) {
        $wpdb->query($wpdb->prepare(
            "UPDATE " . $wpdb->prefix . "cfp_traffic_sessions SET 
            page_views = page_views + 1, 
            last_activity = %s 
            WHERE id = %d",
            current_time('mysql'), $existing->id
        ));
    } else {
        $country = cfp_get_country_from_ip($ip);
        $device = cfp_detect_device($user_agent);
        $browser = cfp_detect_browser($user_agent);
        $os = cfp_detect_os($user_agent);
        
        $wpdb->insert($wpdb->prefix . 'cfp_traffic_sessions', [
            'session_id' => $session_id,
            'ip_address' => $ip,
            'country' => $country,
            'user_agent' => $user_agent,
            'device_type' => $device,
            'browser' => $browser,
            'os' => $os,
            'is_bot' => $is_bot ? 1 : 0,
            'page_views' => 1
        ]);
    }
    
    $wpdb->insert($wpdb->prefix . 'cfp_traffic_pageviews', [
        'session_id' => $session_id,
        'path' => $path ?: $_SERVER['REQUEST_URI'] ?? '/',
        'title' => get_the_title() ?: ''
    ]);
}

add_action('wp', function() {
    cfp_track_page_view();
});

/* ============================================================
   HELPER FUNCTIONS
   ============================================================ */
function cfp_detect_bot($user_agent) {
    $bots = ['bot', 'spider', 'crawl', 'slurp', 'mediapartners', 'googlebot', 'bingbot', 'yandex', 'baiduspider', 'facebookexternalhit', 'twitterbot', 'rogerbot', 'linkedinbot', 'embedly', 'quora link preview', 'showyoubot', 'outbrain', 'pinterest'];
    $ua = strtolower($user_agent);
    foreach ($bots as $bot) {
        if (strpos($ua, $bot) !== false) return true;
    }
    return false;
}

function cfp_detect_device($user_agent) {
    $ua = strtolower($user_agent);
    if (preg_match('/mobile|android|iphone|ipod|windows phone/i', $ua)) return 'mobile';
    if (preg_match('/tablet|ipad|playbook|silk/i', $ua)) return 'tablet';
    return 'desktop';
}

function cfp_detect_browser($user_agent) {
    $ua = strtolower($user_agent);
    if (strpos($ua, 'firefox') !== false) return 'Firefox';
    if (strpos($ua, 'chrome') !== false) return 'Chrome';
    if (strpos($ua, 'safari') !== false) return 'Safari';
    if (strpos($ua, 'edge') !== false) return 'Edge';
    if (strpos($ua, 'opera') !== false) return 'Opera';
    return 'Other';
}

function cfp_detect_os($user_agent) {
    $ua = strtolower($user_agent);
    if (strpos($ua, 'windows') !== false) return 'Windows';
    if (strpos($ua, 'mac') !== false) return 'MacOS';
    if (strpos($ua, 'linux') !== false) return 'Linux';
    if (strpos($ua, 'android') !== false) return 'Android';
    if (strpos($ua, 'iphone') !== false || strpos($ua, 'ios') !== false) return 'iOS';
    return 'Other';
}

function cfp_get_country_from_ip($ip) {
    if (empty($ip) || $ip === '127.0.0.1' || $ip === '::1') return 'XX';
    
    $transient = get_transient('cfp_country_' . $ip);
    if ($false !== $transient) return $transient;
    
    $response = wp_remote_get('http://ip-api.com/json/' . $ip . '?fields=countryCode');
    
    if (!is_wp_error($response)) {
        $data = json_decode(wp_remote_retrieve_body($response));
        $country = $data->countryCode ?? 'XX';
        set_transient('cfp_country_' . $ip, $country, 86400);
        return $country;
    }
    
    return 'XX';
}

/* ============================================================
   DAILY SUMMARY
   ============================================================ */
add_action('cfp_daily_traffic_summary_hook', 'cfp_generate_traffic_summary');
add_action( 'init', function() {
    if ( ! wp_next_scheduled( 'cfp_daily_traffic_summary_hook' ) ) {
        wp_schedule_event( strtotime( 'midnight' ), 'daily', 'cfp_daily_traffic_summary_hook' );
    }
} );

function cfp_generate_traffic_summary() {
    global $wpdb;
    $yesterday = date('Y-m-d', strtotime('-1 day'));
    $yesterday_start = $yesterday . ' 00:00:00';
    $yesterday_end = $yesterday . ' 23:59:59';
    
    $unique_visitors = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT session_id) FROM " . $wpdb->prefix . "cfp_traffic_sessions 
        WHERE created_at BETWEEN %s AND %s",
        $yesterday_start, $yesterday_end
    ));
    
    $page_views = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_traffic_pageviews 
        WHERE created_at BETWEEN %s AND %s",
        $yesterday_start, $yesterday_end
    ));
    
    $bounces = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_traffic_sessions 
        WHERE created_at BETWEEN %s AND %s AND page_views = 1",
        $yesterday_start, $yesterday_end
    ));
    
    $new_visitors = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_traffic_sessions 
        WHERE created_at BETWEEN %s AND %s AND user_id IS NULL",
        $yesterday_start, $yesterday_end
    ));
    
    $returning_visitors = $unique_visitors - $new_visitors;
    
    $avg_time = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT AVG(time_on_site) FROM " . $wpdb->prefix . "cfp_traffic_sessions 
        WHERE created_at BETWEEN %s AND %s AND time_on_site > 0",
        $yesterday_start, $yesterday_end
    ));
    
    $existing = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM " . $wpdb->prefix . "cfp_traffic_summary WHERE date = %s", $yesterday
    ));
    
    if ($existing) {
        $wpdb->update($wpdb->prefix . 'cfp_traffic_summary', [
            'unique_visitors' => $unique_visitors,
            'page_views' => $page_views,
            'bounces' => $bounces,
            'new_visitors' => $new_visitors,
            'returning_visitors' => $returning_visitors,
            'avg_time_on_site' => $avg_time
        ], ['date' => $yesterday]);
    } else {
        $wpdb->insert($wpdb->prefix . 'cfp_traffic_summary', [
            'date' => $yesterday,
            'unique_visitors' => $unique_visitors,
            'page_views' => $page_views,
            'bounces' => $bounces,
            'new_visitors' => $new_visitors,
            'returning_visitors' => $returning_visitors,
            'avg_time_on_site' => $avg_time
        ]);
    }
}

/* ============================================================
   AJAX: Get Traffic Stats
   ============================================================ */
add_action('wp_ajax_cfp_get_traffic_stats', 'cfp_ajax_get_traffic_stats');
function cfp_ajax_get_traffic_stats() {
    check_ajax_referer('cfp_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['msg' => 'Unauthorized']);
    }
    
    $days = intval($_POST['days'] ?? 7);
    
    global $wpdb;
    $summary = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM " . $wpdb->prefix . "cfp_traffic_summary 
        ORDER BY date DESC LIMIT %d",
        $days
    ));
    
    $top_pages = $wpdb->get_results($wpdb->prepare(
        "SELECT path, COUNT(*) as views FROM " . $wpdb->prefix . "cfp_traffic_pageviews 
        WHERE created_at >= %s 
        GROUP BY path ORDER BY views DESC LIMIT 10",
        date('Y-m-d H:i:s', strtotime("-{$days} days"))
    ));
    
    $top_countries = $wpdb->get_results($wpdb->prepare(
        "SELECT country, COUNT(*) as visitors FROM " . $wpdb->prefix . "cfp_traffic_sessions 
        WHERE created_at >= %s AND country != 'XX'
        GROUP BY country ORDER BY visitors DESC LIMIT 10",
        date('Y-m-d H:i:s', strtotime("-{$days} days"))
    ));
    
    $top_devices = $wpdb->get_results($wpdb->prepare(
        "SELECT device_type, COUNT(*) as visitors FROM " . $wpdb->prefix . "cfp_traffic_sessions 
        WHERE created_at >= %s 
        GROUP BY device_type",
        date('Y-m-d H:i:s', strtotime("-{$days} days"))
    ));
    
    wp_send_json_success([
        'summary' => array_reverse($summary),
        'top_pages' => $top_pages,
        'top_countries' => $top_countries,
        'top_devices' => $top_devices
    ]);
}

/* ============================================================
   ADMIN: Traffic Analytics Dashboard
   ============================================================ */
add_action('cfp_security_extra_cards', function() {
    global $wpdb;
    
    $today = date('Y-m-d');
    $this_month = date('Y-m-01');
    
    $today_visitors = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT session_id) FROM " . $wpdb->prefix . "cfp_traffic_sessions 
        WHERE DATE(created_at) = %s",
        $today
    ));
    
    $today_pageviews = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_traffic_pageviews 
        WHERE DATE(created_at) = %s",
        $today
    ));
    
    $month_visitors = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT session_id) FROM " . $wpdb->prefix . "cfp_traffic_sessions 
        WHERE created_at >= %s",
        $this_month
    ));
    
    $month_pageviews = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_traffic_pageviews 
        WHERE created_at >= %s",
        $this_month
    ));
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>📊 Traffic Analytics</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Real-time visitor tracking and analytics.</p>
        
        <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:20px">
            <div style="background:#111;border-radius:8px;padding:16px;text-align:center">
                <div style="font-size:1.5rem;font-weight:800;color:var(--g)"><?=number_format($today_visitors)?></div>
                <div style="font-size:.7rem;color:#555;text-transform:uppercase">Today's Visitors</div>
            </div>
            <div style="background:#111;border-radius:8px;padding:16px;text-align:center">
                <div style="font-size:1.5rem;font-weight:800;color:var(--g)"><?=number_format($today_pageviews)?></div>
                <div style="font-size:.7rem;color:#555;text-transform:uppercase">Today's Page Views</div>
            </div>
            <div style="background:#111;border-radius:8px;padding:16px;text-align:center">
                <div style="font-size:1.5rem;font-weight:800;color:#f7931a"><?=number_format($month_visitors)?></div>
                <div style="font-size:.7rem;color:#555;text-transform:uppercase">Month Visitors</div>
            </div>
            <div style="background:#111;border-radius:8px;padding:16px;text-align:center">
                <div style="font-size:1.5rem;font-weight:800;color:#f7931a"><?=number_format($month_pageviews)?></div>
                <div style="font-size:.7rem;color:#555;text-transform:uppercase">Month Page Views</div>
            </div>
        </div>
        
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">
            <div style="background:#111;border-radius:8px;padding:16px">
                <h3 style="color:var(--g);margin-bottom:12px;font-size:.9rem">Top Pages</h3>
                <div id="cfp-top-pages"></div>
            </div>
            <div style="background:#111;border-radius:8px;padding:16px">
                <h3 style="color:var(--g);margin-bottom:12px;font-size:.9rem">Traffic by Country</h3>
                <div id="cfp-top-countries"></div>
            </div>
        </div>
    </div>
    
    <script>
    function cfpLoadTrafficStats() {
        const fd = new FormData();
        fd.append('action', 'cfp_get_traffic_stats');
        fd.append('nonce', '<?=wp_create_nonce('cfp_nonce')?>');
        fd.append('days', 30);
        
        fetch('<?=admin_url('admin-ajax.php')?>', {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    const pages = d.data.top_pages.map(p => 
                        '<div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #222;font-size:.8rem"><span style="overflow:hidden;text-overflow:ellipsis;max-width:200px">' + p.path + '</span><span style="color:var(--g)">' + p.views + '</span></div>'
                    ).join('');
                    document.getElementById('cfp-top-pages').innerHTML = pages || 'No data';
                    
                    const countries = d.data.top_countries.map(c => 
                        '<div style="display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #222;font-size:.8rem"><span>' + c.country + '</span><span style="color:var(--g)">' + c.visitors + '</span></div>'
                    ).join('');
                    document.getElementById('cfp-top-countries').innerHTML = countries || 'No data';
                }
            });
    }
    
    cfpLoadTrafficStats();
    </script>
    <?php
});
