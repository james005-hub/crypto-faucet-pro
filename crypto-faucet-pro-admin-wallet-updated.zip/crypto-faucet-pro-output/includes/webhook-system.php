<?php
/**
 * Webhook System
 *
 * @package CryptoFaucetPro
 */

if (!defined('ABSPATH')) exit;

/* ============================================================
   WEBHOOK TABLES
   ============================================================ */
function cfp_create_webhook_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $table_webhooks = $wpdb->prefix . 'cfp_webhooks';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_webhooks'") != $table_webhooks) {
        $wpdb->query("
            CREATE TABLE $table_webhooks (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                url varchar(500) NOT NULL,
                events text NOT NULL,
                secret_key varchar(64) NOT NULL,
                is_active tinyint(1) DEFAULT 1,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                last_triggered datetime DEFAULT NULL,
                failure_count int(11) DEFAULT 0,
                PRIMARY KEY  (id),
                KEY is_active (is_active)
            ) $charset
        ");
    }

    $table_webhook_log = $wpdb->prefix . 'cfp_webhook_log';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_webhook_log'") != $table_webhook_log) {
        $wpdb->query("
            CREATE TABLE $table_webhook_log (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                webhook_id bigint(20) NOT NULL,
                event_type varchar(50) NOT NULL,
                payload text,
                response_code int(11) DEFAULT NULL,
                response_body text,
                success tinyint(1) DEFAULT 0,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY webhook_id (webhook_id),
                KEY created_at (created_at)
            ) $charset
        ");
    }
}

/* ============================================================
   SEND WEBHOOK
   ============================================================ */
function cfp_send_webhook($event_type, $data) {
    global $wpdb;
    
    $webhooks = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM " . $wpdb->prefix . "cfp_webhooks WHERE is_active = 1"
    ));
    
    foreach ($webhooks as $webhook) {
        $events = json_decode($webhook->events, true);
        if (!in_array($event_type, $events) && !in_array('*', $events)) {
            continue;
        }
        
        $payload = json_encode([
            'event' => $event_type,
            'timestamp' => current_time('c'),
            'data' => $data
        ]);
        
        $signature = hash_hmac('sha256', $payload, $webhook->secret_key);
        
        $response = wp_remote_post($webhook->url, [
            'method' => 'POST',
            'headers' => [
                'Content-Type' => 'application/json',
                'X-Webhook-Signature' => $signature,
                'X-Webhook-Event' => $event_type
            ],
            'body' => $payload,
            'timeout' => 30
        ]);
        
        $success = !is_wp_error($response) && wp_remote_retrieve_response_code($response) >= 200 && wp_remote_retrieve_response_code($response) < 300;
        
        $wpdb->insert($wpdb->prefix . 'cfp_webhook_log', [
            'webhook_id' => $webhook->id,
            'event_type' => $event_type,
            'payload' => $payload,
            'response_code' => is_wp_error($response) ? 0 : wp_remote_retrieve_response_code($response),
            'response_body' => is_wp_error($response) ? $response->get_error_message() : wp_remote_retrieve_body($response),
            'success' => $success ? 1 : 0
        ]);
        
        if (!$success) {
            $wpdb->query($wpdb->prepare(
                "UPDATE " . $wpdb->prefix . "cfp_webhooks SET failure_count = failure_count + 1 WHERE id = %d",
                $webhook->id
            ));
            
            if ($webhook->failure_count >= 5) {
                $wpdb->query($wpdb->prepare(
                    "UPDATE " . $wpdb->prefix . "cfp_webhooks SET is_active = 0 WHERE id = %d",
                    $webhook->id
                ));
            }
        } else {
            $wpdb->query($wpdb->prepare(
                "UPDATE " . $wpdb->prefix . "cfp_webhooks SET last_triggered = %s, failure_count = 0 WHERE id = %d",
                current_time('mysql'), $webhook->id
            ));
        }
    }
}

/* ============================================================
   HOOKS: Trigger Webhooks
   ============================================================ */
add_action('cfp_after_claim', function($user_id, $amount) {
    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . CFP_TABLE_USERS . " WHERE id = %d", $user_id));
    
    cfp_send_webhook('claim.completed', [
        'user_id' => $user_id,
        'username' => $user->username ?? '',
        'amount_sat' => $amount,
        'amount_btc' => $amount / 100000000,
        'balance_after' => $user->balance_sat ?? 0
    ]);
}, 10, 2);

add_action('cfp_after_game_win', function($user_id, $amount, $game) {
    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . CFP_TABLE_USERS . " WHERE id = %d", $user_id));
    
    cfp_send_webhook('game.win', [
        'user_id' => $user_id,
        'username' => $user->username ?? '',
        'game' => $game,
        'amount_sat' => $amount,
        'amount_btc' => $amount / 100000000,
        'balance_after' => $user->balance_sat ?? 0
    ]);
}, 10, 3);

add_action('cfp_after_game_loss', function($user_id, $amount, $game) {
    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . CFP_TABLE_USERS . " WHERE id = %d", $user_id));
    
    cfp_send_webhook('game.loss', [
        'user_id' => $user_id,
        'username' => $user->username ?? '',
        'game' => $game,
        'amount_sat' => $amount,
        'amount_btc' => $amount / 100000000,
        'balance_after' => $user->balance_sat ?? 0
    ]);
}, 10, 3);

add_action('cfp_after_withdrawal', function($user_id, $amount) {
    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . CFP_TABLE_USERS . " WHERE id = %d", $user_id));
    
    cfp_send_webhook('withdrawal.completed', [
        'user_id' => $user_id,
        'username' => $user->username ?? '',
        'amount_sat' => $amount,
        'amount_btc' => $amount / 100000000,
        'balance_after' => $user->balance_sat ?? 0
    ]);
}, 10, 2);

add_action('cfp_user_registered', function($user_id, $email, $username) {
    cfp_send_webhook('user.registered', [
        'user_id' => $user_id,
        'email' => $email,
        'username' => $username
    ]);
}, 10, 3);

/* ============================================================
   AJAX: Manage Webhooks
   ============================================================ */
add_action('wp_ajax_cfp_save_webhook', 'cfp_ajax_save_webhook');
function cfp_ajax_save_webhook() {
    check_ajax_referer('cfp_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['msg' => 'Unauthorized']);
    }
    
    $url = esc_url_raw($_POST['url'] ?? '');
    $events = isset($_POST['events']) ? array_map('sanitize_text_field', $_POST['events']) : [];
    $webhook_id = intval($_POST['webhook_id'] ?? 0);
    
    if (empty($url) || empty($events)) {
        wp_send_json_error(['msg' => 'URL and events required']);
    }
    
    global $wpdb;
    $secret_key = wp_generate_password(32, false);
    
    if ($webhook_id > 0) {
        $wpdb->update($wpdb->prefix . 'cfp_webhooks', [
            'url' => $url,
            'events' => json_encode($events)
        ], ['id' => $webhook_id]);
    } else {
        $wpdb->insert($wpdb->prefix . 'cfp_webhooks', [
            'url' => $url,
            'events' => json_encode($events),
            'secret_key' => $secret_key
        ]);
    }
    
    wp_send_json_success(['msg' => 'Webhook saved']);
}

add_action('wp_ajax_cfp_delete_webhook', 'cfp_ajax_delete_webhook');
function cfp_ajax_delete_webhook() {
    check_ajax_referer('cfp_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['msg' => 'Unauthorized']);
    }
    
    $webhook_id = intval($_POST['webhook_id']);
    
    global $wpdb;
    $wpdb->query($wpdb->prepare("DELETE FROM " . $wpdb->prefix . "cfp_webhooks WHERE id = %d", $webhook_id));
    
    wp_send_json_success();
}

add_action('wp_ajax_cfp_toggle_webhook', 'cfp_ajax_toggle_webhook');
function cfp_ajax_toggle_webhook() {
    check_ajax_referer('cfp_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['msg' => 'Unauthorized']);
    }
    
    $webhook_id = intval($_POST['webhook_id']);
    $is_active = intval($_POST['is_active']);
    
    global $wpdb;
    $wpdb->update($wpdb->prefix . 'cfp_webhooks', ['is_active' => $is_active], ['id' => $webhook_id]);
    
    wp_send_json_success();
}

/* ============================================================
   ADMIN: Webhook Management
   ============================================================ */
add_action('cfp_security_extra_cards', function() {
    global $wpdb;
    $webhooks = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "cfp_webhooks ORDER BY id DESC");
    $events = ['claim.completed', 'game.win', 'game.loss', 'withdrawal.completed', 'user.registered', 'user.banned'];
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🪝 Webhooks</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Configure webhooks to receive real-time notifications.</p>
        
        <div style="background:#111;border-radius:8px;padding:16px;margin-bottom:20px">
            <h3 style="color:var(--g);margin-bottom:12px">Add New Webhook</h3>
            <div style="margin-bottom:12px">
                <input type="url" id="cfp-webhook-url" placeholder="https://your-server.com/webhook" style="width:100%;padding:10px;background:#0d0d0d;border:1px solid #333;color:#fff;border-radius:4px">
            </div>
            <div style="margin-bottom:12px">
                <div style="font-size:.75rem;color:#555;margin-bottom:6px">Events to trigger:</div>
                <div style="display:flex;flex-wrap:wrap;gap:8px">
                    <?php foreach($events as $event): ?>
                    <label style="display:flex;align-items:center;gap:4px;cursor:pointer">
                        <input type="checkbox" class="cfp-webhook-event" value="<?=$event?>">
                        <span style="font-size:.8rem"><?=$event?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>
            <button onclick="cfpSaveWebhook()" class="cfp-btn">Add Webhook</button>
        </div>
        
        <h3 style="color:var(--g);margin-bottom:12px">Active Webhooks</h3>
        <table class="cfp-table">
            <thead>
                <tr>
                    <th>URL</th>
                    <th>Events</th>
                    <th>Status</th>
                    <th>Failures</th>
                    <th>Last Triggered</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody id="cfp-webhooks-list">
                <?php foreach($webhooks as $wh): ?>
                <tr>
                    <td style="max-width:200px;overflow:hidden;text-overflow:ellipsis"><?=esc_html($wh->url)?></td>
                    <td><?=implode(', ', json_decode($wh->events))?></td>
                    <td>
                        <span class="cfp-status <?=$wh->is_active ? 'active' : 'inactive'?>">
                            <?=$wh->is_active ? 'Active' : 'Disabled'?>
                        </span>
                    </td>
                    <td style="color:<?=$wh->failure_count > 0 ? '#ff6b6b' : 'inherit'?>"><?=$wh->failure_count?></td>
                    <td><?=$wh->last_triggered ? $wh->last_triggered : '-' ?></td>
                    <td>
                        <button onclick="cfpToggleWebhook(<?=$wh->id?>, <?=$wh->is_active ? 0 : 1?>)" class="cfp-btn-sm"><?=$wh->is_active ? 'Disable' : 'Enable'?></button>
                        <button onclick="cfpDeleteWebhook(<?=$wh->id?>)" class="cfp-btn-sm" style="background:#ff4444">Delete</button>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    
    <script>
    function cfpSaveWebhook() {
        const url = document.getElementById('cfp-webhook-url').value;
        const events = Array.from(document.querySelectorAll('.cfp-webhook-event:checked')).map(e => e.value);
        
        if(!url || events.length === 0) {
            alert('Please enter URL and select at least one event');
            return;
        }
        
        const fd = new FormData();
        fd.append('action', 'cfp_save_webhook');
        fd.append('nonce', '<?=wp_create_nonce('cfp_nonce')?>');
        fd.append('url', url);
        fd.append('events', events);
        
        fetch('<?=admin_url('admin-ajax.php')?>', {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) location.reload();
                else alert(d.error_msg);
            });
    }
    
    function cfpToggleWebhook(id, active) {
        const fd = new FormData();
        fd.append('action', 'cfp_toggle_webhook');
        fd.append('nonce', '<?=wp_create_nonce('cfp_nonce')?>');
        fd.append('webhook_id', id);
        fd.append('is_active', active);
        
        fetch('<?=admin_url('admin-ajax.php')?>', {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => { if(d.success) location.reload(); });
    }
    
    function cfpDeleteWebhook(id) {
        if(!confirm('Delete this webhook?')) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_delete_webhook');
        fd.append('nonce', '<?=wp_create_nonce('cfp_nonce')?>');
        fd.append('webhook_id', id);
        
        fetch('<?=admin_url('admin-ajax.php')?>', {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => { if(d.success) location.reload(); });
    }
    </script>
    <?php
});
