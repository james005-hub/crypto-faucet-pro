<?php
/**
 * Anti-Fraud System
 *
 * @package CryptoFaucetPro
 */

if (!defined('ABSPATH')) exit;

/* ============================================================
   FRAUD DETECTION TABLES
   ============================================================ */
function cfp_create_fraud_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();

    $table = $wpdb->prefix . 'cfp_fraud_logs';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table)) != $table) {
        $wpdb->query("
            CREATE TABLE $table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) DEFAULT NULL,
                ip_address varchar(45) NOT NULL,
                event_type varchar(50) NOT NULL,
                risk_score int(11) DEFAULT 0,
                details text,
                action_taken varchar(50) DEFAULT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY user_id (user_id),
                KEY ip_address (ip_address),
                KEY risk_score (risk_score),
                KEY created_at (created_at)
            ) $charset
        ");
    }

    $table_suspects = $wpdb->prefix . 'cfp_fraud_suspects';
    if ($wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table_suspects)) != $table_suspects) {
        $wpdb->query("
            CREATE TABLE $table_suspects (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                ip_address varchar(45) NOT NULL,
                email varchar(100) DEFAULT NULL,
                user_agent varchar(500) DEFAULT NULL,
                violation_count int(11) DEFAULT 1,
                risk_level enum('low','medium','high','critical') DEFAULT 'low',
                first_seen datetime DEFAULT CURRENT_TIMESTAMP,
                last_seen datetime DEFAULT CURRENT_TIMESTAMP,
                notes text,
                PRIMARY KEY  (id),
                UNIQUE KEY ip_address (ip_address),
                KEY risk_level (risk_level)
            ) $charset
        ");
    }
}

/* ============================================================
   FRAUD SCORING
   ============================================================ */
function cfp_calculate_fraud_score($user_id = null, $ip = null) {
    $score = 0;
    $reasons = [];
    global $wpdb;
    
    if ($ip) {
        $same_ip_users = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(DISTINCT id) FROM " . CFP_TABLE_USERS . " WHERE ip_address = %s", $ip
        ));
        
        if ($same_ip_users > 3) {
            $score += 20;
            $reasons[] = "Multiple accounts from same IP ({$same_ip_users})";
        }
        
        $recent_claims = (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . CFP_TABLE_CLAIMS . " 
            WHERE ip_address = %s AND created_at >= %s",
            $ip, date('Y-m-d H:i:s', strtotime('-1 hour'))
        ));
        
        if ($recent_claims > 10) {
            $score += 30;
            $reasons[] = "High claim frequency ({$recent_claims}/hour)";
        }
        
        $vpn_check = cfp_check_vpn_proxy($ip);
        if ($vpn_check) {
            $score += 25;
            $reasons[] = "VPN/Proxy detected";
        }
    }
    
    if ($user_id) {
        $user = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . CFP_TABLE_USERS . " WHERE id = %d", $user_id
        ));
        
        if ($user) {
            $claim_streak = $user->claim_streak ?? 0;
            if ($claim_streak > 0) {
                $avg_daily_claims = $claim_streak / max(1, (time() - strtotime($user->created_at)) / 86400);
                if ($avg_daily_claims > 24) {
                    $score += 15;
                    $reasons[] = "Unrealistic claim pattern";
                }
            }
            
            if ($user->total_claims > 0 && $user->total_earned > 0) {
                $avg_claim = $user->total_earned / $user->total_claims;
                $min_payout = floatval(cfp_get_setting('faucet_min_payout_sat', 1));
                if ($avg_claim < $min_payout * 0.1) {
                    $score += 10;
                    $reasons[] = "Abnormally low claim amounts";
                }
            }
        }
    }
    
    return ['score' => min($score, 100), 'reasons' => $reasons];
}

function cfp_check_vpn_proxy($ip) {
    if (empty($ip) || $ip === '127.0.0.1' || $ip === '::1') return false;
    
    $check_ips = ['172.16.', '172.17.', '172.18.', '172.19.', '172.20.', '172.21.', '172.22.', '172.23.', '172.24.', '172.25.', '172.26.', '172.27.', '172.28.', '172.29.', '172.30.', '172.31.', '10.', '192.168.'];
    
    foreach ($check_ips as $range) {
        if (strpos($ip, $range) === 0) return true;
    }
    
    return false;
}

/* ============================================================
   LOG FRAUD EVENT
   ============================================================ */
function cfp_log_fraud_event($user_id, $ip, $event_type, $risk_score, $details = '', $action = null) {
    global $wpdb;
    
    $wpdb->insert($wpdb->prefix . 'cfp_fraud_logs', [
        'user_id' => $user_id,
        'ip_address' => $ip,
        'event_type' => $event_type,
        'risk_score' => $risk_score,
        'details' => $details,
        'action_taken' => $action
    ]);
    
    if ($risk_score >= 50) {
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM " . $wpdb->prefix . "cfp_fraud_suspects WHERE ip_address = %s", $ip
        ));
        
        $risk_level = $risk_score >= 80 ? 'critical' : ($risk_score >= 60 ? 'high' : 'medium');
        
        if ($existing) {
            $wpdb->query($wpdb->prepare(
                "UPDATE " . $wpdb->prefix . "cfp_fraud_suspects SET 
                violation_count = violation_count + 1, 
                risk_level = %s,
                last_seen = %s 
                WHERE id = %d",
                $risk_level, current_time('mysql'), $existing
            ));
        } else {
            $wpdb->insert($wpdb->prefix . 'cfp_fraud_suspects', [
                'ip_address' => $ip,
                'violation_count' => 1,
                'risk_level' => $risk_level
            ]);
        }
        
        if ($risk_score >= 80 && $user_id) {
            $wpdb->query($wpdb->prepare(
                "UPDATE " . CFP_TABLE_USERS . " SET is_banned = 1 WHERE id = %d", $user_id
            ));
            
            cfp_admin_alert('Auto-Banned', "User #{$user_id} banned due to high fraud risk score ({$risk_score})");
        }
    }
}

/* ============================================================
   FRAUD CHECK ON REGISTRATION
   ============================================================ */
add_action('cfp_before_user_register', function($email, $username, $ip) {
    global $wpdb;
    
    $fraud = cfp_calculate_fraud_score(null, $ip);
    
    if ($fraud['score'] >= 60) {
        cfp_log_fraud_event(null, $ip, 'registration_blocked', $fraud['score'], implode('; ', $fraud['reasons']), 'blocked');
        
        return new WP_Error('fraud_detected', 'Registration blocked due to suspicious activity');
    }
    
    if ($fraud['score'] > 0) {
        cfp_log_fraud_event(null, $ip, 'registration', $fraud['score'], implode('; ', $fraud['reasons']));
    }
    
    return true;
}, 10, 3);

/* ============================================================
   FRAUD CHECK ON CLAIM
   ============================================================ */
add_action('cfp_before_claim', function($user_id) {
    global $wpdb;
    
    $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM " . CFP_TABLE_USERS . " WHERE id = %d", $user_id));
    if (!$user) return true;
    
    $ip = $user->ip_address;
    $fraud = cfp_calculate_fraud_score($user_id, $ip);
    
    if ($fraud['score'] >= 70) {
        cfp_log_fraud_event($user_id, $ip, 'claim_blocked', $fraud['score'], implode('; ', $fraud['reasons']), 'blocked');
        return new WP_Error('fraud_detected', 'Claim blocked due to suspicious activity');
    }
    
    if ($fraud['score'] > 30) {
        cfp_log_fraud_event($user_id, $ip, 'claim', $fraud['score'], implode('; ', $fraud['reasons']));
    }
    
    return true;
});

/* ============================================================
   AJAX: Get Fraud Stats
   ============================================================ */
add_action('wp_ajax_cfp_get_fraud_stats', 'cfp_ajax_get_fraud_stats');
function cfp_ajax_get_fraud_stats() {
    check_ajax_referer('cfp_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['msg' => 'Unauthorized']);
    }
    
    global $wpdb;
    
    $recent_events = $wpdb->get_results("
        SELECT * FROM " . $wpdb->prefix . "cfp_fraud_logs 
        ORDER BY created_at DESC LIMIT 20
    ");
    
    $top_suspects = $wpdb->get_results("
        SELECT * FROM " . $wpdb->prefix . "cfp_fraud_suspects 
        ORDER BY violation_count DESC LIMIT 10
    ");
    
    $stats = [
        'total_events' => (int)$wpdb->get_var("SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_fraud_logs"),
        'high_risk' => (int)$wpdb->get_var("SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_fraud_suspects WHERE risk_level IN ('high','critical')"),
        'blocked_today' => (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_fraud_logs WHERE action_taken = 'blocked' AND created_at >= %s",
            date('Y-m-d 00:00:00')
        ))
    ];
    
    wp_send_json_success([
        'stats' => $stats,
        'recent_events' => $recent_events,
        'top_suspects' => $top_suspects
    ]);
}

add_action('wp_ajax_cfp_clear_fraud_suspect', 'cfp_ajax_clear_fraud_suspect');
function cfp_ajax_clear_fraud_suspect() {
    check_ajax_referer('cfp_nonce', 'nonce');
    
    if (!current_user_can('manage_options')) {
        wp_send_json_error(['msg' => 'Unauthorized']);
    }
    
    $ip = sanitize_text_field($_POST['ip']);
    
    global $wpdb;
    $wpdb->query($wpdb->prepare("DELETE FROM " . $wpdb->prefix . "cfp_fraud_suspects WHERE ip_address = %s", $ip));
    
    wp_send_json_success();
}

/* ============================================================
   ADMIN: Anti-Fraud Dashboard
   ============================================================ */
add_action('cfp_security_extra_cards', function() {
    global $wpdb;
    
    $stats = [
        'total_events' => (int)$wpdb->get_var("SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_fraud_logs"),
        'high_risk' => (int)$wpdb->get_var("SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_fraud_suspects WHERE risk_level IN ('high','critical')"),
        'blocked_today' => (int)$wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM " . $wpdb->prefix . "cfp_fraud_logs WHERE action_taken = 'blocked' AND created_at >= %s",
            date('Y-m-d 00:00:00')
        ))
    ];
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🛡️ Anti-Fraud System</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Real-time fraud detection and prevention.</p>
        
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-bottom:20px">
            <div style="background:#111;border-radius:8px;padding:16px;text-align:center">
                <div style="font-size:1.5rem;font-weight:800;color:#ff4444"><?=number_format($stats['total_events'])?></div>
                <div style="font-size:.7rem;color:#555;text-transform:uppercase">Total Events</div>
            </div>
            <div style="background:#111;border-radius:8px;padding:16px;text-align:center">
                <div style="font-size:1.5rem;font-weight:800;color:#ffaa00"><?=number_format($stats['high_risk'])?></div>
                <div style="font-size:.7rem;color:#555;text-transform:uppercase">High Risk IPs</div>
            </div>
            <div style="background:#111;border-radius:8px;padding:16px;text-align:center">
                <div style="font-size:1.5rem;font-weight:800;color:var(--g)"><?=number_format($stats['blocked_today'])?></div>
                <div style="font-size:.7rem;color:#555;text-transform:uppercase">Blocked Today</div>
            </div>
        </div>
        
        <h3 style="color:var(--g);margin-bottom:12px">High Risk Suspects</h3>
        <div id="cfp-fraud-suspects"></div>
        
        <h3 style="color:var(--g);margin:20px 0 12px">Recent Events</h3>
        <div id="cfp-fraud-events"></div>
    </div>
    
    <script>
    function cfpLoadFraudData() {
        const fd = new FormData();
        fd.append('action', 'cfp_get_fraud_stats');
        fd.append('nonce', '<?=wp_create_nonce('cfp_nonce')?>');
        
        fetch('<?=admin_url('admin-ajax.php')?>', {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    const suspects = d.data.top_suspects.map(s => 
                        '<div style="display:flex;align-items:center;justify-content:space-between;background:#111;padding:10px;border-radius:6px;margin-bottom:6px">' +
                            '<div><span style="font-family:monospace">' + s.ip_address + '</span> <span style="font-size:.75rem;color:#555">(' + s.violation_count + ' violations)</span></div>' +
                            '<div style="display:flex;align-items:center;gap:8px">' +
                                '<span style="padding:2px 8px;border-radius:4px;font-size:.7rem;background:' + (s.risk_level === 'critical' ? '#ff4444' : s.risk_level === 'high' ? '#ff8800' : '#4444ff') + '">' + s.risk_level + '</span>' +
                                '<button onclick="cfpClearSuspect(\'' + s.ip_address + '\')" class="button button-small">Clear</button>' +
                            '</div>' +
                        '</div>'
                    ).join('');
                    document.getElementById('cfp-fraud-suspects').innerHTML = suspects || '<p style="color:#555">No suspects</p>';
                    
                    const events = d.data.recent_events.map(e => 
                        '<div style="display:flex;align-items:center;justify-content:space-between;background:#0a0a0a;padding:8px;border-radius:4px;margin-bottom:4px;font-size:.8rem">' +
                            '<div><span style="color:' + (e.risk_score >= 50 ? '#ff4444' : '#888') + '">' + e.event_type + '</span> - ' + (e.details || 'N/A') + '</div>' +
                            '<div style="color:#555">' + e.created_at + '</div>' +
                        '</div>'
                    ).join('');
                    document.getElementById('cfp-fraud-events').innerHTML = events || '<p style="color:#555">No recent events</p>';
                }
            });
    }
    
    function cfpClearSuspect(ip) {
        const fd = new FormData();
        fd.append('action', 'cfp_clear_fraud_suspect');
        fd.append('nonce', '<?=wp_create_nonce('cfp_nonce')?>');
        fd.append('ip', ip);
        
        fetch('<?=admin_url('admin-ajax.php')?>', {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => { if(d.success) cfpLoadFraudData(); });
    }
    
    cfpLoadFraudData();
    </script>
    <?php
});
