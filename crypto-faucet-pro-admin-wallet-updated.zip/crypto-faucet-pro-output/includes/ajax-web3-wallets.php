<?php
/**
 * AJAX Handlers: MetaMask & WalletConnect Deposit and Withdraw
 *
 * Flow:
 *   DEPOSIT  — Frontend signs an EVM message to prove wallet ownership,
 *              plugin creates a NOWPayments invoice (hot wallet address)
 *              and credits the user when the IPN fires.
 *   WITHDRAW — Plugin deducts balance, fires NOWPayments Mass Payout to
 *              the user's Web3 wallet address, and credits the withdrawal
 *              fee to the admin revenue wallet.
 *
 * Revenue:
 *   All MetaMask and WalletConnect withdrawal fees are routed to the
 *   admin revenue wallet via cfp_wallet_credit_game() — identical to the
 *   pattern used by the existing Coinbase withdrawal flows.
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   HELPERS: WEB3 WALLET SETTINGS
   ============================================================ */

/** @return bool True when MetaMask/WalletConnect deposits are enabled. */
function cfp_web3_enabled(): bool {
    return (bool) cfp_get_setting( 'web3_enabled', '0' );
}

/** @return string Currency slug used for Web3 payouts (e.g. 'eth', 'matic'). */
function cfp_web3_currency(): string {
    return strtolower( cfp_get_setting( 'web3_currency', 'eth' ) );
}

/** @return int Minimum withdrawal in satoshis (internally we keep sat as the unit). */
function cfp_web3_min_withdraw_sat(): int {
    return intval( cfp_get_setting( 'web3_min_withdraw_sat', 10000 ) );
}

/** @return int Flat withdrawal fee in satoshis routed to admin revenue wallet. */
function cfp_web3_fee_sat(): int {
    return intval( cfp_get_setting( 'web3_fee_sat', 500 ) );
}

/* ============================================================
   AJAX: INITIATE WEB3 DEPOSIT (MetaMask or WalletConnect)
   Creates a NOWPayments invoice whose pay_address acts as the
   hot-wallet receive address.  The user sends crypto to that
   address; the IPN (handled by nowpayments-api.php) credits
   their balance just like any other NP deposit.

   When web3_direct_rpc_deposits is enabled, the response also
   includes the Infura RPC URL and chain ID so the frontend can
   prompt the user to send via window.ethereum (MetaMask) or
   WalletConnect provider directly — bypassing manual copy-paste.
   ============================================================ */
add_action( 'wp_ajax_cfp_web3_deposit', 'cfp_ajax_web3_deposit' );
function cfp_ajax_web3_deposit(): void {
    check_ajax_referer( 'cfp_nonce', 'nonce' );
    cfp_require_rate_limit( 'default' );

    if ( ! cfp_web3_enabled() ) {
        wp_send_json_error( ['msg' => 'Web3 wallet deposits are not enabled.'] );
    }

    $user        = cfp_require_auth();
    $wallet_type = sanitize_text_field( $_POST['wallet_type']  ?? 'metamask' );   // 'metamask' | 'walletconnect'
    $eth_address = sanitize_text_field( $_POST['eth_address']  ?? '' );
    $currency    = strtolower( sanitize_text_field( $_POST['currency'] ?? cfp_web3_currency() ) );
    $amount_usd  = floatval( $_POST['amount_usd'] ?? 0 );

    // Validate EVM address format (0x + 40 hex chars)
    if ( ! preg_match( '/^0x[0-9a-fA-F]{40}$/', $eth_address ) ) {
        wp_send_json_error( ['msg' => '❌ Invalid EVM wallet address. Must be a valid Ethereum/EVM address (0x…).'] );
    }

    // Minimum deposit gate
    $min_usd = floatval( cfp_get_setting( 'web3_min_deposit_usd', '1' ) );
    if ( $amount_usd > 0 && $amount_usd < $min_usd ) {
        wp_send_json_error( ['msg' => "Minimum deposit is \${$min_usd} USD equivalent."] );
    }
    if ( $amount_usd <= 0 ) {
        $amount_usd = max( $min_usd, 1 );
    }

    $wallet_label = $wallet_type === 'walletconnect' ? 'WalletConnect' : 'MetaMask';
    $order_id     = "cfp_web3_{$wallet_type}_u{$user->id}_" . time();

    // Create NOWPayments invoice — this gives us a hot-wallet pay_address
    $result = cfp_np_create_payment(
        $amount_usd,
        $currency,
        $order_id,
        "CFP {$wallet_label} Deposit — user #{$user->id}"
    );

    if ( ! empty( $result['error'] ) ) {
        wp_send_json_error( ['msg' => 'Payment gateway error: ' . esc_html( $result['error'] )] );
    }

    if ( empty( $result['payment_id'] ) || empty( $result['pay_address'] ) ) {
        wp_send_json_error( ['msg' => 'Could not generate deposit address. Please try again.'] );
    }

    global $wpdb;

    // Store deposit record in the NP deposits table (IPN will credit balance)
    $wpdb->insert( CFP_TABLE_NP_DEPOSITS, [
        'user_id'       => $user->id,
        'np_payment_id' => (string) $result['payment_id'],
        'order_id'      => $order_id,
        'currency'      => $currency,
        'pay_amount'    => floatval( $result['pay_amount'] ?? 0 ),
        'amount_sat'    => 0,                       // filled in by IPN
        'price_amount'  => $amount_usd,
        'status'        => 'waiting',
        'raw_ipn'       => json_encode( array_merge( $result, [
            'web3_wallet_type'    => $wallet_type,
            'web3_eth_address'    => $eth_address,
        ] ) ),
    ] );

    // Build response — include Infura chain data when direct RPC deposits are enabled
    $response = [
        'payment_id'   => $result['payment_id'],
        'pay_address'  => $result['pay_address'],
        'pay_amount'   => $result['pay_amount']   ?? '',
        'pay_currency' => $result['pay_currency'] ?? $currency,
        'expiry'       => $result['expiration_estimate_date'] ?? '',
        'qr'           => 'https://api.qrserver.com/v1/create-qr-code/?data=' . urlencode( $result['pay_address'] ) . '&size=200x200',
        'wallet_type'  => $wallet_type,
        'msg'          => "✅ Send exactly {$result['pay_amount']} " . strtoupper( $currency ) . " to the address below using your {$wallet_label} wallet.",
    ];

    // Attach Infura RPC metadata so the frontend can send via window.ethereum / WalletConnect provider
    $direct_rpc = (bool) cfp_get_setting( 'web3_direct_rpc_deposits', '0' );
    if ( $direct_rpc && function_exists( 'cfp_web3_chain_id' ) ) {
        $response['infura_rpc_url'] = cfp_web3_rpc_url();   // e.g. https://mainnet.infura.io/v3/KEY
        $response['chain_id']       = cfp_web3_chain_id();  // e.g. 1 for mainnet
        $response['chain_id_hex']   = '0x' . dechex( cfp_web3_chain_id() );
        $response['direct_rpc']     = true;
    }

    wp_send_json_success( $response );
}

/* ============================================================
   AJAX: CHECK WEB3 DEPOSIT STATUS
   Polls NOWPayments for payment status — same pattern as cfp_ajax_np_check_deposit.
   ============================================================ */
add_action( 'wp_ajax_cfp_web3_check_deposit', 'cfp_ajax_web3_check_deposit' );
function cfp_ajax_web3_check_deposit(): void {
    check_ajax_referer( 'cfp_nonce', 'nonce' );

    $user       = cfp_require_auth();
    $payment_id = sanitize_text_field( $_POST['payment_id'] ?? '' );

    if ( empty( $payment_id ) ) {
        wp_send_json_error( ['msg' => 'No payment ID supplied.'] );
    }

    global $wpdb;

    // Ownership check — prevents enumeration of other users' payment IDs
    $rec = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_NP_DEPOSITS . " WHERE np_payment_id=%s AND user_id=%d",
        $payment_id, $user->id
    ) );

    if ( ! $rec ) {
        wp_send_json_error( ['msg' => 'Payment not found.'] );
    }

    if ( $rec->status === 'credited' ) {
        wp_send_json_success( [
            'status'     => 'credited',
            'amount_sat' => $rec->amount_sat,
            'msg'        => '✅ Deposit confirmed and credited to your balance!',
        ] );
    }

    $result = cfp_np_get_payment( $payment_id );
    if ( ! empty( $result['error'] ) ) {
        wp_send_json_error( ['msg' => $result['error']] );
    }

    $status = $result['payment_status'] ?? 'unknown';

    wp_send_json_success( [
        'status'        => $status,
        'actually_paid' => $result['actually_paid'] ?? 0,
        'pay_amount'    => $result['pay_amount']    ?? 0,
        'pay_currency'  => $result['pay_currency']  ?? '',
        'msg'           => cfp_np_status_label( $status ),
    ] );
}

/* ============================================================
   AJAX: VERIFY WEB3 DEPOSIT VIA ETHERSCAN + INFURA
   Called by the frontend after the user broadcasts a transaction
   directly from MetaMask / WalletConnect (direct RPC mode).
   Verifies the tx on-chain and — if confirmed — credits the user
   balance without waiting for the NOWPayments IPN.
   ============================================================ */
add_action( 'wp_ajax_cfp_web3_verify_tx', 'cfp_ajax_web3_verify_tx' );
function cfp_ajax_web3_verify_tx(): void {
    check_ajax_referer( 'cfp_nonce', 'nonce' );

    if ( ! cfp_web3_enabled() ) {
        wp_send_json_error( ['msg' => 'Web3 wallet deposits are not enabled.'] );
    }

    // Require Etherscan/Infura helpers
    if ( ! function_exists( 'cfp_etherscan_verify_tx' ) ) {
        wp_send_json_error( ['msg' => 'Etherscan/Infura integration not loaded. Please contact the site admin.'] );
    }

    $user       = cfp_require_auth();
    $tx_hash    = sanitize_text_field( $_POST['tx_hash']    ?? '' );
    $payment_id = sanitize_text_field( $_POST['payment_id'] ?? '' );

    if ( ! preg_match( '/^0x[0-9a-fA-F]{64}$/', $tx_hash ) ) {
        wp_send_json_error( ['msg' => '❌ Invalid transaction hash format.'] );
    }

    global $wpdb;

    // Ownership check — ensure this payment_id belongs to this user
    $dep = $wpdb->get_row( $wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_NP_DEPOSITS . " WHERE np_payment_id=%s AND user_id=%d",
        $payment_id, $user->id
    ) );

    if ( ! $dep ) {
        wp_send_json_error( ['msg' => 'Deposit record not found.'] );
    }

    if ( $dep->status === 'credited' ) {
        wp_send_json_success( [
            'status'     => 'credited',
            'amount_sat' => $dep->amount_sat,
            'msg'        => '✅ Deposit already credited to your balance!',
        ] );
    }

    // Parse stored raw_ipn to get the expected pay_address
    $raw = json_decode( $dep->raw_ipn ?? '{}', true );
    $expected_to = $raw['pay_address'] ?? '';

    if ( empty( $expected_to ) ) {
        wp_send_json_error( ['msg' => 'Cannot determine expected deposit address from deposit record.'] );
    }

    // Verify tx on-chain via Etherscan + Infura
    $verify = cfp_etherscan_verify_tx( $tx_hash, $expected_to );

    if ( ! empty( $verify['error'] ) && ! $verify['verified'] ) {
        // Pass along partial data so the frontend can show confirmation progress
        wp_send_json_error( [
            'msg'           => $verify['error'],
            'confirmations' => $verify['confirmations'] ?? 0,
            'verified'      => false,
        ] );
    }

    if ( ! $verify['verified'] ) {
        wp_send_json_success( [
            'status'        => 'confirming',
            'confirmations' => $verify['confirmations'] ?? 0,
            'msg'           => "⏳ Transaction found — waiting for confirmations ({$verify['confirmations']} so far).",
        ] );
    }

    // ── TX VERIFIED ── credit the user balance
    // Avoid double-credit: check again with a DB lock pattern
    $already = $wpdb->get_var( $wpdb->prepare(
        "SELECT status FROM " . CFP_TABLE_NP_DEPOSITS . " WHERE np_payment_id=%s AND user_id=%d",
        $payment_id, $user->id
    ) );
    if ( $already === 'credited' ) {
        wp_send_json_success( [ 'status' => 'credited', 'msg' => '✅ Deposit already credited!' ] );
    }

    // Convert ETH value to satoshis (using standard rate logic from the plugin)
    $currency   = $dep->currency ?? cfp_web3_currency();
    $value_eth  = $verify['value_eth'] ?? 0;
    $amount_sat = function_exists( 'cfp_np_currency_to_sat' )
        ? cfp_np_currency_to_sat( $value_eth, $currency )
        : intval( $value_eth * 1e8 );  // fallback: treat 1 unit = 1e8 sat

    if ( $amount_sat <= 0 ) {
        wp_send_json_error( ['msg' => 'Could not calculate satoshi value for the transaction amount.'] );
    }

    // Credit balance
    $wpdb->query( $wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat = balance_sat + %d WHERE id = %d",
        $amount_sat, $user->id
    ) );

    // Mark deposit as credited and store tx hash
    $wpdb->update(
        CFP_TABLE_NP_DEPOSITS,
        [
            'status'     => 'credited',
            'amount_sat' => $amount_sat,
            'raw_ipn'    => json_encode( array_merge( $raw, [
                'etherscan_tx_hash'   => $tx_hash,
                'on_chain_value_eth'  => $value_eth,
                'confirmations'       => $verify['confirmations'],
                'verified_via'        => 'etherscan_infura',
            ] ) ),
        ],
        [ 'np_payment_id' => $payment_id, 'user_id' => $user->id ]
    );

    // Transaction log
    $wallet_type = $raw['web3_wallet_type'] ?? 'metamask';
    $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
        'user_id'     => $user->id,
        'type'        => "web3_{$wallet_type}_deposit",
        'amount_sat'  => $amount_sat,
        'description' => "Web3 deposit {$amount_sat} sat ({$value_eth} {$currency}) · tx: {$tx_hash} · confirmations: {$verify['confirmations']}",
    ] );

    wp_send_json_success( [
        'status'        => 'credited',
        'amount_sat'    => $amount_sat,
        'confirmations' => $verify['confirmations'],
        'tx_hash'       => $tx_hash,
        'msg'           => "🎉 Deposit verified on-chain and credited: {$amount_sat} sat ({$value_eth} " . strtoupper( $currency ) . ")!",
    ] );
}

/* ============================================================
   AJAX: GET INFURA CHAIN DATA (public — for frontend wallet switching)
   Returns chain ID and RPC URL so the frontend can prompt MetaMask
   to switch to the correct network before sending a deposit.
   ============================================================ */
add_action( 'wp_ajax_cfp_web3_chain_info',        'cfp_ajax_web3_chain_info' );
add_action( 'wp_ajax_nopriv_cfp_web3_chain_info', 'cfp_ajax_web3_chain_info' );
function cfp_ajax_web3_chain_info(): void {
    check_ajax_referer( 'cfp_nonce', 'nonce' );

    if ( ! function_exists( 'cfp_web3_chain_id' ) ) {
        wp_send_json_error( ['msg' => 'Web3 RPC not configured.'] );
    }

    $network = cfp_web3_current_network();
    wp_send_json_success( [
        'chain_id'     => cfp_web3_chain_id(),
        'chain_id_hex' => '0x' . dechex( cfp_web3_chain_id() ),
        'network'      => cfp_get_setting( 'web3_infura_network', 'mainnet' ),
        'network_name' => $network['label'] ?? 'Ethereum Mainnet',
        'rpc_url'      => cfp_web3_rpc_url(),
        'direct_rpc'   => (bool) cfp_get_setting( 'web3_direct_rpc_deposits', '0' ),
    ] );
}

/* ============================================================
   AJAX: WEB3 WALLET WITHDRAW (MetaMask or WalletConnect)
   Deducts balance, fires NOWPayments Mass Payout to the user's
   EVM address, and routes the fee to the admin revenue wallet.
   ============================================================ */
add_action( 'wp_ajax_cfp_web3_withdraw', 'cfp_ajax_web3_withdraw' );
function cfp_ajax_web3_withdraw(): void {
    check_ajax_referer( 'cfp_nonce', 'nonce' );
    cfp_require_rate_limit( 'withdrawal' );

    if ( ! cfp_web3_enabled() ) {
        wp_send_json_error( ['msg' => 'Web3 wallet withdrawals are not enabled.'] );
    }

    $user        = cfp_require_auth();
    $wallet_type = sanitize_text_field( $_POST['wallet_type']  ?? 'metamask' );   // 'metamask' | 'walletconnect'
    $eth_address = sanitize_text_field( $_POST['eth_address']  ?? '' );
    $amount      = intval( $_POST['amount']   ?? 0 );
    $currency    = strtolower( sanitize_text_field( $_POST['currency'] ?? cfp_web3_currency() ) );

    // Validation
    if ( ! preg_match( '/^0x[0-9a-fA-F]{40}$/', $eth_address ) ) {
        wp_send_json_error( ['msg' => '❌ Invalid EVM address. Please reconnect your wallet and try again.'] );
    }

    $min = cfp_web3_min_withdraw_sat();
    $fee = cfp_web3_fee_sat();

    if ( $amount < $min ) {
        wp_send_json_error( ['msg' => 'Minimum withdrawal is ' . number_format( $min ) . ' sat.'] );
    }

    $total_deduct = $amount + $fee;

    // Withdrawal controls gate (cooling period, fraud checks, etc.)
    do_action( 'cfp_before_withdraw', $user, $amount );

    $wallet_label = $wallet_type === 'walletconnect' ? 'WalletConnect' : 'MetaMask';

    global $wpdb;

    // Block duplicate pending requests
    $pending = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM " . CFP_TABLE_NP_WITHDRAWALS . "
         WHERE user_id=%d AND status='pending' LIMIT 1",
        $user->id
    ) );
    if ( $pending ) {
        wp_send_json_error( ['msg' => "You already have a pending {$wallet_label} withdrawal. Please wait for it to complete."] );
    }

    // Atomically deduct balance before firing the payout (prevents TOCTOU race)
    $rows = $wpdb->query( $wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . "
         SET balance_sat = balance_sat - %d
         WHERE id = %d AND balance_sat >= %d",
        $total_deduct, $user->id, $total_deduct
    ) );

    if ( $rows === 0 ) {
        wp_send_json_error( ['msg' => 'Insufficient balance. Please refresh and try again.'] );
    }

    // Convert satoshis → currency float for NOWPayments
    $pay_amount = cfp_np_sat_to_currency( $amount, $currency );
    if ( $pay_amount <= 0 ) {
        // Refund and abort if conversion fails
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat = balance_sat + %d WHERE id = %d",
            $total_deduct, $user->id
        ) );
        wp_send_json_error( ['msg' => 'Cannot calculate payout amount. Please contact support.'] );
    }

    // Fire NOWPayments Mass Payout to the user's EVM wallet address
    $result = cfp_np_send_payout(
        $eth_address,
        $pay_amount,
        $currency,
        "cfp_web3_{$wallet_type}_u{$user->id}"
    );

    if ( ! empty( $result['error'] ) ) {
        // Refund on API failure
        $wpdb->query( $wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat = balance_sat + %d WHERE id = %d",
            $total_deduct, $user->id
        ) );
        wp_send_json_error( ['msg' => 'Payout error: ' . esc_html( $result['error'] )] );
    }

    // Extract payout ID
    $withdrawals  = $result['withdrawals'] ?? [];
    $np_payout_id = (string) ( $withdrawals[0]['id'] ?? '' );
    $status       = strtolower( $withdrawals[0]['status'] ?? 'pending' );

    // Record withdrawal in NOWPayments withdrawals table
    $wpdb->insert( CFP_TABLE_NP_WITHDRAWALS, [
        'user_id'      => $user->id,
        'np_payout_id' => $np_payout_id,
        'to_address'   => $eth_address,
        'currency'     => $currency,
        'amount_sat'   => $amount,
        'pay_amount'   => $pay_amount,
        'fee_sat'      => $fee,
        'status'       => $status,
        'np_response'  => json_encode( array_merge( $result, [
            'web3_wallet_type' => $wallet_type,
        ] ) ),
    ] );

    // Transaction log
    $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
        'user_id'     => $user->id,
        'type'        => "web3_{$wallet_type}_withdrawal",
        'amount_sat'  => -$total_deduct,
        'description' => "{$wallet_label} withdrawal {$amount} sat ({$pay_amount} {$currency}) → {$eth_address} (ID:{$np_payout_id})",
    ] );

    // ── REVENUE: Route withdrawal fee to admin revenue wallet ──
    // Fee stream key is distinct per wallet type so admin can track
    // MetaMask vs WalletConnect revenue independently.
    if ( $fee > 0 ) {
        $stream_setting = "admin_wallet_stream_web3_{$wallet_type}_fee";
        $wallet_stream  = "web3_{$wallet_type}_withdraw_fee";
        cfp_wallet_credit_game(
            $stream_setting,
            $wallet_stream,
            $fee,
            "{$wallet_label} withdrawal fee from user #{$user->id} ({$amount} sat request)"
        );
    }

    wp_send_json_success( [
        'msg'       => "✅ {$wallet_label} withdrawal submitted! {$pay_amount} " . strtoupper( $currency ) . " is being sent to {$eth_address}. Payout ID: {$np_payout_id}",
        'payout_id' => $np_payout_id,
    ] );
}

/* ============================================================
   AJAX: VALIDATE EVM ADDRESS (lightweight front-end helper)
   ============================================================ */
add_action( 'wp_ajax_cfp_web3_validate_address',        'cfp_ajax_web3_validate_address' );
add_action( 'wp_ajax_nopriv_cfp_web3_validate_address', 'cfp_ajax_web3_validate_address' );
function cfp_ajax_web3_validate_address(): void {
    check_ajax_referer( 'cfp_nonce', 'nonce' );
    $address = sanitize_text_field( $_POST['address'] ?? '' );
    if ( preg_match( '/^0x[0-9a-fA-F]{40}$/', $address ) ) {
        wp_send_json_success( ['msg' => '✅ Valid EVM address.'] );
    } else {
        wp_send_json_error( ['msg' => '❌ Not a valid EVM address (must be 0x + 40 hex characters).'] );
    }
}
