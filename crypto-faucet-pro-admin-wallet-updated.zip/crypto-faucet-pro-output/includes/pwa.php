<?php
/**
 * Progressive Web App (PWA) — makes the faucet installable as a home screen app
 * on iOS and Android, just like FreeBitco.in's "app".
 * Generates: manifest.json, service worker, install banner, offline page.
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   MANIFEST.JSON endpoint
   ============================================================ */
add_action('init', function() {
    if ( isset($_GET['cfp_pwa_manifest']) ) {
        $name      = cfp_get_setting('faucet_name', 'Crypto Faucet Pro');
        $currency  = strtoupper(cfp_get_setting('blockchain_currency', 'BTC'));
        $color     = cfp_get_setting('primary_color', '#f7931a');
        $logo_url  = cfp_get_setting('site_logo_url', '');
        $manifest  = [
            'name'             => $name,
            'short_name'       => $currency . ' Faucet',
            'description'      => "Free {$currency} faucet — claim, play games, earn crypto!",
            'start_url'        => home_url('/'),
            'display'          => 'standalone',
            'background_color' => '#0a0a0a',
            'theme_color'      => $color,
            'orientation'      => 'portrait-primary',
            'scope'            => home_url('/'),
            'icons'            => [
                ['src' => $logo_url ?: home_url('/?cfp_pwa_icon=192'), 'sizes' => '192x192', 'type' => 'image/png', 'purpose' => 'any maskable'],
                ['src' => $logo_url ?: home_url('/?cfp_pwa_icon=512'), 'sizes' => '512x512', 'type' => 'image/png', 'purpose' => 'any maskable'],
            ],
            'categories'       => ['games', 'finance'],
            'shortcuts'        => [
                ['name'=>'Claim Free '.$currency,'short_name'=>'Claim','url'=>home_url('/#cfp-faucet-section'),'description'=>'Claim your free '.$currency],
                ['name'=>'Hi-Lo Game','short_name'=>'Hi-Lo','url'=>home_url('/#cfp-faucet-section'),'description'=>'Play Hi-Lo multiply game'],
            ],
        ];
        header('Content-Type: application/manifest+json');
        header('Cache-Control: public, max-age=3600');
        echo json_encode($manifest);
        exit;
    }
});

/* ============================================================
   SERVICE WORKER endpoint
   ============================================================ */
add_action('init', function() {
    if ( isset($_GET['cfp_pwa_sw']) ) {
        $site = home_url('/');
        header('Content-Type: application/javascript');
        header('Cache-Control: no-cache');
        echo <<<JS
const CFP_CACHE = 'cfp-v1';
const OFFLINE_URL = '{$site}?cfp_offline=1';

// Install: cache offline page
self.addEventListener('install', e => {
    e.waitUntil(
        caches.open(CFP_CACHE).then(c => c.addAll([OFFLINE_URL]))
        .then(() => self.skipWaiting())
    );
});

// Activate: clean old caches
self.addEventListener('activate', e => {
    e.waitUntil(
        caches.keys().then(keys =>
            Promise.all(keys.filter(k => k !== CFP_CACHE).map(k => caches.delete(k)))
        ).then(() => self.clients.claim())
    );
});

// Fetch: network-first with offline fallback
self.addEventListener('fetch', e => {
    if (e.request.method !== 'GET') return;
    if (e.request.url.includes('admin-ajax.php')) return; // never cache AJAX
    e.respondWith(
        fetch(e.request).then(r => {
            // Cache successful HTML/CSS/JS responses
            if (r.ok && ['navigate','style','script'].includes(e.request.mode || e.request.destination)) {
                const clone = r.clone();
                caches.open(CFP_CACHE).then(c => c.put(e.request, clone));
            }
            return r;
        }).catch(() =>
            caches.match(e.request).then(cached => cached || caches.match(OFFLINE_URL))
        )
    );
});
JS;
        exit;
    }
});

/* ============================================================
   OFFLINE PAGE endpoint
   ============================================================ */
add_action('init', function() {
    if ( isset($_GET['cfp_offline']) ) {
        $name  = cfp_get_setting('faucet_name', 'Crypto Faucet Pro');
        $color = cfp_get_setting('primary_color', '#f7931a');
        status_header(200);
        header('Content-Type: text/html; charset=utf-8');
        echo <<<HTML
<!DOCTYPE html><html lang="en">
<head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Offline — {$name}</title>
<style>*{box-sizing:border-box}body{margin:0;background:#0a0a0a;color:#e0e0e0;font-family:'Segoe UI',sans-serif;min-height:100vh;display:flex;align-items:center;justify-content:center;text-align:center;padding:20px}
.icon{font-size:4rem;margin-bottom:16px}.title{font-size:1.8rem;font-weight:800;color:{$color};margin-bottom:8px}
.sub{color:#555;margin-bottom:24px}.btn{background:{$color};color:#000;font-weight:700;padding:14px 32px;border:none;border-radius:8px;font-size:1rem;cursor:pointer;text-decoration:none;display:inline-block}</style>
</head>
<body><div>
<div class="icon">📡</div>
<div class="title">{$name}</div>
<div class="sub">You're offline. Check your connection and try again.</div>
<a href="/" class="btn">Try Again</a>
</div></body></html>
HTML;
        exit;
    }
});

/* ============================================================
   INJECT PWA TAGS INTO <head>
   ============================================================ */
add_action('wp_head', function() {
    if ( cfp_get_setting('pwa_enabled','1') !== '1' ) return;
    $manifest_url = home_url('/?cfp_pwa_manifest=1');
    $sw_url       = home_url('/?cfp_pwa_sw=1');
    $name         = esc_attr(cfp_get_setting('faucet_name','Crypto Faucet Pro'));
    $color        = esc_attr(cfp_get_setting('primary_color','#f7931a'));
    $logo         = esc_url(cfp_get_setting('site_logo_url',''));
    echo <<<HTML
<!-- CFP PWA -->
<link rel="manifest" href="{$manifest_url}">
<meta name="theme-color" content="{$color}">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="{$name}">
<meta name="mobile-web-app-capable" content="yes">
HTML;
    if ($logo) echo '<link rel="apple-touch-icon" href="'.$logo.'">';
});

/* ============================================================
   REGISTER SERVICE WORKER in footer
   ============================================================ */
add_action('wp_footer', function() {
    if ( cfp_get_setting('pwa_enabled','1') !== '1' ) return;
    $sw_url = home_url('/?cfp_pwa_sw=1');
    echo <<<HTML
<script>
// Register service worker
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('{$sw_url}')
            .catch(e => console.log('SW reg failed:', e));
    });
}

// Install banner (deferred prompt)
let cfpDeferredPrompt;
window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    cfpDeferredPrompt = e;
    const banner = document.getElementById('cfp-install-banner');
    if (banner) banner.style.display = 'flex';
});
window.cfpInstallApp = function() {
    if (!cfpDeferredPrompt) return;
    cfpDeferredPrompt.prompt();
    cfpDeferredPrompt.userChoice.then(r => {
        cfpDeferredPrompt = null;
        const banner = document.getElementById('cfp-install-banner');
        if (banner) banner.style.display = 'none';
    });
};
window.addEventListener('appinstalled', () => {
    const banner = document.getElementById('cfp-install-banner');
    if (banner) banner.style.display = 'none';
});
</script>
<!-- Install Banner -->
<div id="cfp-install-banner" style="display:none;position:fixed;bottom:0;left:0;right:0;background:#111;border-top:2px solid var(--cfp-p,#f7931a);padding:12px 16px;z-index:9999;align-items:center;gap:12px;font-family:'Segoe UI',sans-serif">
    <span style="font-size:1.5rem">📱</span>
    <div style="flex:1;color:#fff;font-size:.88rem"><strong>Install as App</strong><br><span style="color:#777;font-size:.78rem">Add to home screen for quick access</span></div>
    <button onclick="cfpInstallApp()" style="background:var(--cfp-p,#f7931a);color:#000;border:none;padding:9px 18px;border-radius:8px;font-weight:700;cursor:pointer;font-size:.85rem">Install</button>
    <button onclick="document.getElementById('cfp-install-banner').style.display='none'" style="background:none;border:none;color:#555;cursor:pointer;font-size:1.2rem;padding:4px">✕</button>
</div>
HTML;
});

/* ============================================================
   SHORTCODE: [cfp_install_app] — iOS install instructions + Android banner
   ============================================================ */
add_shortcode('cfp_install_app', function() {
    $name  = cfp_get_setting('faucet_name', 'Crypto Faucet Pro');
    $color = cfp_get_setting('primary_color', '#f7931a');
    ob_start(); ?>
    <div class="cfp-widget" style="text-align:center">
        <h2>📱 Install the App</h2>
        <p class="sub">Get the full app experience — works on iOS and Android, no App Store needed.</p>
        <!-- Android / Chrome install button -->
        <div id="cfp-android-install" style="display:none;margin-bottom:16px">
            <button onclick="cfpInstallApp()" class="cfp-claim-btn" style="max-width:300px">
                📲 Install on Android / Chrome
            </button>
        </div>
        <script>
        window.addEventListener('beforeinstallprompt', () => {
            document.getElementById('cfp-android-install').style.display = '';
        });
        </script>
        <!-- iOS instructions -->
        <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:12px;padding:20px;text-align:left;max-width:360px;margin:0 auto">
            <div style="font-weight:700;color:#fff;margin-bottom:14px;font-size:.95rem">📱 iOS — Safari</div>
            <?php foreach([
                ['1','Open this site in Safari'],
                ['2','Tap the <strong>Share</strong> button (box with arrow up)'],
                ['3','Scroll down and tap <strong>Add to Home Screen</strong>'],
                ['4','Tap <strong>Add</strong> — done!'],
            ] as [$n,$step]): ?>
            <div style="display:flex;gap:10px;align-items:flex-start;margin-bottom:10px">
                <span style="background:<?=esc_attr($color)?>;color:#000;font-weight:800;width:24px;height:24px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-size:.78rem;flex-shrink:0"><?=$n?></span>
                <span style="font-size:.84rem;color:#aaa;line-height:1.5"><?=$step?></span>
            </div>
            <?php endforeach; ?>
        </div>
        <p style="font-size:.76rem;color:#333;margin-top:14px">
            The app loads instantly, works offline for browsing, and looks just like a native app.
        </p>
    </div>
    <?php return ob_get_clean();
});
