<?php
/**
 * Settings helpers, cron scheduling, admin wallet core functions
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   SETTINGS HELPER
   ============================================================ */
function cfp_get_setting( $key, $default = '' ) {
    global $wpdb, $cfp_settings_cache;
    if ( ! is_array( $cfp_settings_cache ) ) $cfp_settings_cache = [];
    if ( ! array_key_exists( $key, $cfp_settings_cache ) ) {
        $val = $wpdb->get_var($wpdb->prepare("SELECT setting_val FROM " . CFP_TABLE_SETTINGS . " WHERE setting_key=%s", $key));
        $cfp_settings_cache[$key] = ($val !== null) ? $val : $default;
    }
    return $cfp_settings_cache[$key];
}
function cfp_update_setting($key, $val) {
    global $wpdb, $cfp_settings_cache;
    $result = $wpdb->replace(CFP_TABLE_SETTINGS, ['setting_key'=>$key,'setting_val'=>$val]);
    // Bust the in-memory cache so the new value is visible to any subsequent
    // cfp_get_setting() calls within the same request.
    if ( is_array( $cfp_settings_cache ) ) {
        unset( $cfp_settings_cache[$key] );
    }
    return $result;
}

/* ============================================================
   CRON: Daily Interest
   ============================================================ */
add_action('cfp_daily_interest_hook', 'cfp_pay_daily_interest');
add_action( 'init', function() {
    if ( ! wp_next_scheduled( 'cfp_daily_interest_hook' ) ) {
        wp_schedule_event( time(), 'daily', 'cfp_daily_interest_hook' );
    }
} );

/* ============================================================
   ADMIN WALLET: Core helper — record revenue to admin wallet
   ============================================================ */
function cfp_wallet_credit( $stream, $amount_sat, $description = '', $ref_id = null ) {
    if ( $amount_sat <= 0 ) return;
    if ( ! cfp_get_setting('admin_wallet_enabled','1') ) return;
    global $wpdb;
    $wpdb->insert( CFP_TABLE_ADMIN_WALLET, [
        'stream'      => $stream,
        'amount_sat'  => $amount_sat,
        'description' => $description,
        'ref_id'      => $ref_id,
    ]);
    // Fire action so trezor-sweep.php can check threshold and auto-sweep (Tier 1)
    do_action( 'cfp_after_wallet_credit', $stream, $amount_sat );
}

/**
 * Stream-aware wallet credit — respects per-stream on/off toggle from Games admin page.
 * Use this for ALL game/revenue credits so admin can control each stream independently.
 *
 * @param string $stream_setting  The setting key for this stream toggle (e.g. 'admin_wallet_stream_slots')
 * @param string $wallet_stream   The stream label stored in the wallet table (e.g. 'house_edge_slots')
 * @param int    $amount_sat      Amount in satoshis to credit
 * @param string $description     Human-readable log entry
 */
function cfp_wallet_credit_game( $stream_setting, $wallet_stream, $amount_sat, $description = '' ) {
    if ( $amount_sat <= 0 ) return;
    if ( ! cfp_get_setting('admin_wallet_enabled', '1') ) return;
    if ( ! cfp_get_setting($stream_setting, '1') ) return;
    cfp_wallet_credit( $wallet_stream, $amount_sat, $description );
}

function cfp_wallet_total( $stream = null ) {
    global $wpdb;
    if ( $stream ) {
        return (int) $wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE stream=%s", $stream));
    }
    return (int) $wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET);
}

/* ============================================================
   CRON: Daily interest spread collection (admin earns the spread)
   ============================================================ */
add_action('cfp_daily_interest_hook', 'cfp_collect_interest_spread');
function cfp_collect_interest_spread() {
    if(!cfp_get_setting('admin_wallet_enabled','1')) return;
    global $wpdb;
    $apy_paid    = floatval(cfp_get_setting('savings_apy', 4.08));
    $spread_rate = floatval(cfp_get_setting('interest_spread_rate', 2.0)); // admin earns spread above what's paid
    $daily_spread = $spread_rate / 365 / 100;
    $total_savings = $wpdb->get_var("SELECT COALESCE(SUM(savings_sat),0) FROM ".CFP_TABLE_USERS." WHERE savings_sat > 0");
    $spread_earned = floor($total_savings * $daily_spread);
    if($spread_earned > 0) {
        cfp_wallet_credit_game('admin_wallet_stream_interest_spread', 'interest_spread', $spread_earned, "Daily interest spread ({$spread_rate}% above {$apy_paid}% APY paid). Pool: ".number_format($total_savings)." sat");
    }
}

function cfp_pay_daily_interest() {
    if(!cfp_get_setting('savings_enabled',1)) return;
    global $wpdb;
    $apy   = floatval(cfp_get_setting('savings_apy', 4.08));
    $daily = $apy / 365 / 100;
    $users = $wpdb->get_results("SELECT id, savings_sat FROM " . CFP_TABLE_USERS . " WHERE savings_sat > 0");
    foreach($users as $u) {
        $interest = floor($u->savings_sat * $daily);
        if($interest < 1) continue;
        $wpdb->query($wpdb->prepare("UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d", $interest, $u->id));
        $wpdb->insert(CFP_TABLE_INTEREST, ['user_id'=>$u->id,'amount_sat'=>$interest,'balance_snapshot'=>$u->savings_sat]);
        $wpdb->insert(CFP_TABLE_TRANSACTIONS, ['user_id'=>$u->id,'type'=>'savings_interest','amount_sat'=>$interest,'description'=>"Daily interest ({$apy}% APY)"]);
    }
}

/* ============================================================
   ADMIN MENU

*/
