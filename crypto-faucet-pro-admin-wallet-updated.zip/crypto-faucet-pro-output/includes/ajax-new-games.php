<?php
/**
 * Additional Casino Games for Crypto Faucet Pro
 * 
 * Games: Blackjack, Roulette, Baccarat, Plinko, Mines, Video Poker, Keno, Raffle
 * 
 * All games support:
 * - Provably fair system
 * - House edge controls
 * - Admin winning probability settings
 * - Admin wallet integration
 * - Session-based authentication
 * 
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   GAME TABLES CREATION
   ============================================================ */
add_action('plugins_loaded', 'cfp_create_new_game_tables');
function cfp_create_new_game_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    
    // Blackjack
    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_BLACKJACK . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        player_cards TEXT,
        dealer_cards TEXT,
        player_sum INT NOT NULL,
        dealer_sum INT NOT NULL,
        result VARCHAR(20) NOT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        house_edge_pct DECIMAL(5,2) NOT NULL,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset");
    
    // Roulette
    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_ROULETTE . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        bet_type VARCHAR(50) NOT NULL,
        bet_value VARCHAR(100) NOT NULL,
        spin_result INT NOT NULL,
        spin_color VARCHAR(10),
        won TINYINT(1) NOT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        house_edge_pct DECIMAL(5,2) NOT NULL,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset");
    
    // Baccarat
    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_BACCARAT . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        bet_type VARCHAR(20) NOT NULL,
        player_score INT NOT NULL,
        banker_score INT NOT NULL,
        result VARCHAR(20) NOT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        house_edge_pct DECIMAL(5,2) NOT NULL,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset");
    
    // Plinko
    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_PLINKO . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        rows INT NOT NULL DEFAULT 8,
        path TEXT,
        multiplier DECIMAL(10,2) NOT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        won TINYINT(1) NOT NULL,
        house_edge_pct DECIMAL(5,2) NOT NULL,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset");
    
    // Mines
    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_MINES . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        mines INT NOT NULL DEFAULT 3,
        grid_size INT NOT NULL DEFAULT 25,
        revealed INT NOT NULL DEFAULT 0,
        gems_found INT NOT NULL DEFAULT 0,
        cashout_mult DECIMAL(5,2) NOT NULL DEFAULT 1.00,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        won TINYINT(1) NOT NULL DEFAULT 0,
        house_edge_pct DECIMAL(5,2) NOT NULL,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset");
    
    // Video Poker
    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_VIDEO_POKER . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        hand_cards TEXT,
        draw_cards TEXT,
        final_hand VARCHAR(50) NOT NULL,
        payout_mult DECIMAL(5,2) NOT NULL,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        won TINYINT(1) NOT NULL,
        house_edge_pct DECIMAL(5,2) NOT NULL,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset");
    
    // Keno
    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_KENO . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        picks INT NOT NULL,
        selected_numbers TEXT,
        drawn_numbers TEXT,
        hits INT NOT NULL DEFAULT 0,
        payout_mult DECIMAL(5,2) NOT NULL DEFAULT 0,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        won TINYINT(1) NOT NULL,
        house_edge_pct DECIMAL(5,2) NOT NULL,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset");
    
    // Raffle
    dbDelta("CREATE TABLE IF NOT EXISTS " . CFP_TABLE_RAFFLE_GAMES . " (
        id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id BIGINT UNSIGNED NOT NULL,
        bet_sat BIGINT NOT NULL,
        ticket_number INT NOT NULL,
        prize_pool_sat BIGINT NOT NULL,
        total_tickets INT NOT NULL,
        won TINYINT(1) NOT NULL DEFAULT 0,
        payout_sat BIGINT NOT NULL DEFAULT 0,
        house_edge_pct DECIMAL(5,2) NOT NULL,
        played_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id), KEY user_id (user_id)
    ) $charset");
    
    // Update version
    update_option('cfp_games_version', '2.0');
}

// Add table constants
// Define new-game table constants at file scope so they are available when
// cfp_create_new_game_tables() runs on plugins_loaded (which fires before init).
// Previously these were deferred to an 'init' hook, causing undefined-constant
// errors inside cfp_create_new_game_tables().
global $wpdb;
if (!defined('CFP_TABLE_BLACKJACK'))   define('CFP_TABLE_BLACKJACK',   $wpdb->prefix . 'cfp_blackjack_games');
if (!defined('CFP_TABLE_ROULETTE'))    define('CFP_TABLE_ROULETTE',    $wpdb->prefix . 'cfp_roulette_games');
if (!defined('CFP_TABLE_BACCARAT'))    define('CFP_TABLE_BACCARAT',    $wpdb->prefix . 'cfp_baccarat_games');
if (!defined('CFP_TABLE_PLINKO'))      define('CFP_TABLE_PLINKO',      $wpdb->prefix . 'cfp_plinko_games');
if (!defined('CFP_TABLE_MINES'))       define('CFP_TABLE_MINES',       $wpdb->prefix . 'cfp_mines_games');
if (!defined('CFP_TABLE_VIDEO_POKER')) define('CFP_TABLE_VIDEO_POKER', $wpdb->prefix . 'cfp_video_poker_games');
if (!defined('CFP_TABLE_KENO'))        define('CFP_TABLE_KENO',        $wpdb->prefix . 'cfp_keno_games');
if (!defined('CFP_TABLE_RAFFLE_GAMES')) define('CFP_TABLE_RAFFLE_GAMES', $wpdb->prefix . 'cfp_raffle_games');

/* ============================================================
   ADMIN SETTINGS: GAME HOUSE EDGE & WINNING PROBABILITY
   ============================================================ */
add_filter('cfp_game_settings_fields', function($fields) {
    // Blackjack settings
    $fields['blackjack_enabled'] = '1';
    $fields['blackjack_house_edge'] = '2.0';
    $fields['blackjack_player_win_pct'] = '44.0'; // Player win probability %
    $fields['blackjack_payout'] = '2.0'; // Payout for player win (1:1)
    $fields['blackjack_blackjack_payout'] = '3.0'; // Blackjack pays 3:2
    
    // Roulette settings
    $fields['roulette_enabled'] = '1';
    $fields['roulette_house_edge'] = '2.7'; // European wheel
    $fields['roulette_red_black_pct'] = '48.65';
    $fields['roulette_street_payout'] = '11.0';
    $fields['roulette_corner_payout'] = '8.0';
    $fields['roulette_single_payout'] = '35.0';
    
    // Baccarat settings
    $fields['baccarat_enabled'] = '1';
    $fields['baccarat_house_edge_player'] = '1.24';
    $fields['baccarat_house_edge_banker'] = '1.06';
    $fields['baccarat_house_edge_tie'] = '14.36';
    $fields['baccarat_player_win_pct'] = '44.62';
    $fields['baccarat_banker_win_pct'] = '45.86';
    
    // Plinko settings
    $fields['plinko_enabled'] = '1';
    $fields['plinko_house_edge'] = '3.0';
    $fields['plinko_row_8_mults'] = '0.5,0.7,1.0,1.5,3.0,1.5,1.0,0.7,0.5';
    $fields['plinko_row_10_mults'] = '0.3,0.5,0.7,1.0,1.5,2.0,1.5,1.0,0.7,0.5,0.3';
    $fields['plinko_row_12_mults'] = '0.2,0.3,0.5,0.7,1.0,2.0,2.0,1.0,0.7,0.5,0.3,0.2';
    $fields['plinko_default_rows'] = '8';
    
    // Mines settings
    $fields['mines_enabled'] = '1';
    $fields['mines_house_edge'] = '4.0';
    $fields['mines_default_mines'] = '3';
    $fields['mines_max_mines'] = '24';
    $fields['mines_gem_multiplier'] = '0.6'; // Base multiplier per gem
    
    // Video Poker settings
    $fields['videopoker_enabled'] = '1';
    $fields['videopoker_house_edge'] = '2.5';
    $fields['videopoker_fullpay'] = '1'; // 9/6 Jacks or Better
    $fields['videopoker_payout_jacks'] = '1.0';
    $fields['videopoker_payout_2pair'] = '2.0';
    $fields['videopoker_payout_3kind'] = '3.0';
    $fields['videopoker_payout_straight'] = '4.0';
    $fields['videopoker_payout_flush'] = '6.0';
    $fields['videopoker_payout_fullhouse'] = '9.0';
    $fields['videopoker_payout_4kind'] = '25.0';
    $fields['videopoker_payout_straightflush'] = '50.0';
    $fields['videopoker_payout_royal'] = '250.0';
    
    // Keno settings
    $fields['keno_enabled'] = '1';
    $fields['keno_house_edge'] = '5.0';
    $fields['keno_spots_default'] = '5';
    $fields['keno_max_spots'] = '10';
    $fields['keno_hits_payout'] = '0,0,0,0.5,1,2,5,10,50,500,5000'; // Payout per hit
    
    // Raffle settings
    $fields['raffle_enabled'] = '1';
    $fields['raffle_house_edge'] = '10.0';
    $fields['raffle_min_bet'] = '100';
    $fields['raffle_max_bet'] = '10000';
    $fields['raffle_jackpot_pct'] = '50'; // % of pool for jackpot
    $fields['raffle_secondary_prizes'] = '3,2,1'; // Top 3 prizes %
    
    return $fields;
});

/* ============================================================
   HELPER: CREDIT HOUSE EDGE TO ADMIN WALLET
   ============================================================ */
function cfp_credit_house_edge($game_name, $user_id, $bet, $payout, $edge_pct) {
    $ggr = $bet - $payout; // Gross Gaming Revenue
    if ($ggr <= 0) return 0;
    
    $admin_earns = floor($ggr * ($edge_pct / 100));
    
    cfp_wallet_credit_game(
        'admin_wallet_stream_' . $game_name,
        'house_edge_' . $game_name,
        $admin_earns,
        "House edge from {$game_name}: bet {$bet}, payout {$payout}, edge {$edge_pct}%"
    );
    
    return $admin_earns;
}

/* ============================================================
   HELPER: PROVABLY FAIR CARD/SHUFFLE
   ============================================================ */
function cfp_pf_shuffle_deck($user_id, $game_type) {
    $result = cfp_pf()->calculate_result($user_id, $game_type);
    $hash = $result['hash'];
    
    // Create deck
    $suits = ['hearts', 'diamonds', 'clubs', 'spades'];
    $values = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
    $deck = [];
    
    foreach ($suits as $suit) {
        foreach ($values as $value) {
            $deck[] = ['suit' => $suit, 'value' => $value, 'code' => $value . '_' . substr($suit, 0, 1)];
        }
    }
    
    // Fisher-Yates shuffle using hash
    $deck_hash = $hash;
    for ($i = 51; $i > 0; $i--) {
        $hex_char = substr($deck_hash, ($i % 64), 1);
        $j = hexdec($hex_char) % ($i + 1);
        $temp = $deck[$i];
        $deck[$i] = $deck[$j];
        $deck[$j] = $temp;
        $deck_hash = hash('sha256', $deck_hash . $i);
    }
    
    return $deck;
}

function cfp_pf_draw_cards($deck, $count, &$deck_index) {
    $cards = [];
    for ($i = 0; $i < $count; $i++) {
        $cards[] = $deck[$deck_index + $i];
    }
    $deck_index += $count;
    return $cards;
}

function cfp_card_value($card) {
    if ($card['value'] === 'A') return 11;
    if (in_array($card['value'], ['K','Q','J'])) return 10;
    return intval($card['value']);
}

function cfp_hand_sum($cards) {
    $sum = 0;
    $aces = 0;
    foreach ($cards as $card) {
        $val = cfp_card_value($card);
        if ($card['value'] === 'A') $aces++;
        $sum += $val;
    }
    while ($sum > 21 && $aces > 0) {
        $sum -= 10;
        $aces--;
    }
    return $sum;
}

/* ============================================================
   AJAX: BLACKJACK
   ============================================================ */
add_action('wp_ajax_cfp_blackjack', 'cfp_ajax_blackjack');
function cfp_ajax_blackjack() {
    check_ajax_referer('cfp_nonce', 'nonce');
    cfp_require_rate_limit('game');
    $user = cfp_require_auth();

    if (cfp_get_setting('blackjack_enabled', '1') !== '1') {
        wp_send_json_error(['msg' => 'Blackjack is currently disabled.']);
    }

    $action  = sanitize_text_field($_POST['game_action'] ?? 'bet');
    $bet     = intval($_POST['bet'] ?? 0);
    $game_id = intval($_POST['game_id'] ?? 0);

    $house_edge       = floatval(cfp_get_setting('blackjack_house_edge', 2.0));
    $blackjack_payout = floatval(cfp_get_setting('blackjack_payout_blackjack', 3.0)); // e.g. 3 = pays 3:2

    global $wpdb;

    /* ── Helper: resolve & settle a finished blackjack hand ── */
    $resolve_hand = function($game, $player_cards, $dealer_cards) use ($wpdb, $user, $house_edge, $blackjack_payout) {
        $player_sum = cfp_hand_sum($player_cards);
        $dealer_sum = cfp_hand_sum($dealer_cards);
        $bet        = (int) $game->bet_sat;

        $is_player_bj = ($player_sum === 21 && count($player_cards) === 2);
        $is_dealer_bj = ($dealer_sum === 21 && count($dealer_cards) === 2);

        // Dealer draws to 17+
        $deck      = json_decode($game->player_cards, true)['deck'];
        $idx       = json_decode($game->player_cards, true)['index'] + count($player_cards) - 2 + count($dealer_cards);
        while ($dealer_sum < 17 && isset($deck[$idx])) {
            $dealer_cards[] = $deck[$idx++];
            $dealer_sum = cfp_hand_sum($dealer_cards);
        }

        // Determine result & payout
        $payout = 0;
        if ($player_sum > 21) {
            $result = 'bust';
        } elseif ($is_player_bj && $is_dealer_bj) {
            $result = 'push';
            $payout = $bet; // return stake
        } elseif ($is_player_bj) {
            $result = 'blackjack';
            $payout = $bet + (int) floor($bet * ($blackjack_payout - 1)); // 3:2 pays 1.5x profit
        } elseif ($is_dealer_bj) {
            $result = 'lose';
        } elseif ($dealer_sum > 21 || $player_sum > $dealer_sum) {
            $result = 'win';
            $payout = $bet * 2;
        } elseif ($player_sum === $dealer_sum) {
            $result = 'push';
            $payout = $bet;
        } else {
            $result = 'lose';
        }

        // Pay out winnings
        if ($payout > 0) {
            $wpdb->query($wpdb->prepare(
                "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
                $payout, $user->id
            ));
        }

        // Credit house edge to admin wallet
        cfp_credit_house_edge('blackjack', $user->id, $bet, $payout, $house_edge);

        // Update game record
        $wpdb->update(CFP_TABLE_BLACKJACK, [
            'dealer_cards' => json_encode(['cards' => $dealer_cards, 'hidden' => false]),
            'player_sum'   => $player_sum,
            'dealer_sum'   => $dealer_sum,
            'result'       => $result,
            'payout_sat'   => $payout,
        ], ['id' => $game->id]);

        $new_bal = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT balance_sat FROM " . CFP_TABLE_USERS . " WHERE id=%d", $user->id
        ));

        $msgs = [
            'blackjack' => "🎯 Blackjack! +{$payout} sat",
            'win'       => "🎉 You win! +{$payout} sat",
            'push'      => "🤝 Push — stake returned",
            'bust'      => "💥 Bust! -{$bet} sat",
            'lose'      => "😞 Dealer wins. -{$bet} sat",
        ];

        return [
            'result'       => $result,
            'player_cards' => array_map(fn($c) => $c['code'], $player_cards),
            'dealer_cards' => array_map(fn($c) => $c['code'], $dealer_cards),
            'player_sum'   => $player_sum,
            'dealer_sum'   => $dealer_sum,
            'payout'       => $payout,
            'new_balance'  => $new_bal,
            'msg'          => $msgs[$result] ?? 'Game over.',
        ];
    };

    /* ══════════════════════════════════════════════════════════
       ACTION: BET — deal initial hand
    ══════════════════════════════════════════════════════════ */
    if ($action === 'bet') {
        cfp_enforce_min_bet($bet);

        // Atomic balance deduction
        $check = $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
            $bet, $user->id, $bet
        ));
        if (!$check) wp_send_json_error(['msg' => 'Insufficient balance.']);

        // Provably fair deck
        $deck       = cfp_pf_shuffle_deck($user->id, 'blackjack');
        $deck_index = 0;

        $player_cards = cfp_pf_draw_cards($deck, 2, $deck_index);
        $dealer_cards = cfp_pf_draw_cards($deck, 2, $deck_index);

        $player_sum   = cfp_hand_sum($player_cards);
        $dealer_sum   = cfp_hand_sum($dealer_cards);
        $is_blackjack = ($player_sum === 21 && count($player_cards) === 2);

        // Store game state (dealer second card stays hidden until stand)
        $wpdb->insert(CFP_TABLE_BLACKJACK, [
            'user_id'      => $user->id,
            'bet_sat'      => $bet,
            'player_cards' => json_encode(['cards' => $player_cards, 'deck' => $deck, 'index' => $deck_index]),
            'dealer_cards' => json_encode(['cards' => $dealer_cards, 'hidden' => true]),
            'player_sum'   => $player_sum,
            'dealer_sum'   => 0,
            'result'       => 'pending',
            'house_edge_pct' => $house_edge,
        ]);
        $new_game_id = $wpdb->insert_id;

        // Natural blackjack — resolve immediately
        if ($is_blackjack) {
            $game = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . CFP_TABLE_BLACKJACK . " WHERE id=%d AND user_id=%d", $new_game_id, $user->id
            ));
            $res = $resolve_hand($game, $player_cards, $dealer_cards);
            $res['game_id']   = $new_game_id;
            $res['immediate'] = true;
            wp_send_json_success($res);
        }

        wp_send_json_success([
            'game_id'      => $new_game_id,
            'player_cards' => array_map(fn($c) => $c['code'], $player_cards),
            'player_sum'   => $player_sum,
            'dealer_up'    => $dealer_cards[0]['code'],
            'can_double'   => true, // allowed on first two cards
            'msg'          => 'Hit or Stand?',
        ]);
    }

    /* ══════════════════════════════════════════════════════════
       ACTIONS: HIT / STAND / DOUBLE — require an active game_id
    ══════════════════════════════════════════════════════════ */
    if (!$game_id) wp_send_json_error(['msg' => 'Missing game_id.']);

    $game = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_BLACKJACK . " WHERE id=%d AND user_id=%d AND result='pending'",
        $game_id, $user->id
    ));
    if (!$game) wp_send_json_error(['msg' => 'Game not found or already finished.']);

    $player_state = json_decode($game->player_cards, true);
    $dealer_state = json_decode($game->dealer_cards, true);
    $player_cards = $player_state['cards'];
    $dealer_cards = $dealer_state['cards'];
    $deck         = $player_state['deck'];
    $deck_index   = $player_state['index'];

    /* ── HIT ── */
    if ($action === 'hit') {
        if (!isset($deck[$deck_index])) wp_send_json_error(['msg' => 'No cards remaining.']);
        $new_card     = $deck[$deck_index++];
        $player_cards[] = $new_card;
        $player_sum   = cfp_hand_sum($player_cards);

        // Persist updated hand
        $wpdb->update(CFP_TABLE_BLACKJACK, [
            'player_cards' => json_encode(['cards' => $player_cards, 'deck' => $deck, 'index' => $deck_index]),
            'player_sum'   => $player_sum,
        ], ['id' => $game->id]);

        if ($player_sum > 21) {
            // Bust — resolve immediately
            $game = $wpdb->get_row($wpdb->prepare(
                "SELECT * FROM " . CFP_TABLE_BLACKJACK . " WHERE id=%d", $game->id
            ));
            $res = $resolve_hand($game, $player_cards, $dealer_cards);
            $res['game_id'] = $game->id;
            wp_send_json_success($res);
        }

        wp_send_json_success([
            'game_id'      => $game->id,
            'new_card'     => $new_card['code'],
            'player_cards' => array_map(fn($c) => $c['code'], $player_cards),
            'player_sum'   => $player_sum,
            'dealer_up'    => $dealer_cards[0]['code'],
            'can_double'   => false,
            'msg'          => $player_sum === 21 ? '21! Stand?' : 'Hit or Stand?',
        ]);
    }

    /* ── STAND ── */
    if ($action === 'stand') {
        $game = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . CFP_TABLE_BLACKJACK . " WHERE id=%d", $game->id
        ));
        $res = $resolve_hand($game, $player_cards, $dealer_cards);
        $res['game_id'] = $game->id;
        wp_send_json_success($res);
    }

    /* ── DOUBLE DOWN ── */
    if ($action === 'double') {
        if (count($player_cards) !== 2) wp_send_json_error(['msg' => 'Double only allowed on first two cards.']);

        // Deduct extra bet equal to original
        $extra = (int) $game->bet_sat;
        $check = $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
            $extra, $user->id, $extra
        ));
        if (!$check) wp_send_json_error(['msg' => 'Insufficient balance to double down.']);

        // Update bet in DB
        $wpdb->update(CFP_TABLE_BLACKJACK, ['bet_sat' => $extra * 2], ['id' => $game->id]);
        $game->bet_sat = $extra * 2;

        // Draw exactly one card then stand
        if (!isset($deck[$deck_index])) wp_send_json_error(['msg' => 'No cards remaining.']);
        $player_cards[] = $deck[$deck_index++];

        $wpdb->update(CFP_TABLE_BLACKJACK, [
            'player_cards' => json_encode(['cards' => $player_cards, 'deck' => $deck, 'index' => $deck_index]),
            'player_sum'   => cfp_hand_sum($player_cards),
        ], ['id' => $game->id]);

        $game = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . CFP_TABLE_BLACKJACK . " WHERE id=%d", $game->id
        ));
        $res = $resolve_hand($game, $player_cards, $dealer_cards);
        $res['game_id'] = $game->id;
        $res['doubled'] = true;
        wp_send_json_success($res);
    }

    wp_send_json_error(['msg' => 'Invalid action.']);
}

/* ============================================================
   AJAX: ROULETTE
   ============================================================ */
add_action('wp_ajax_cfp_roulette', 'cfp_ajax_roulette');
function cfp_ajax_roulette() {
    check_ajax_referer('cfp_nonce', 'nonce');
    cfp_require_rate_limit('game');
    $user = cfp_require_auth();
    
    if (cfp_get_setting('roulette_enabled', '1') !== '1') {
        wp_send_json_error(['msg' => 'Roulette is currently disabled.']);
    }
    
    $bet = intval($_POST['bet'] ?? 0);
    $bet_type = sanitize_text_field($_POST['bet_type'] ?? 'red');
    $bet_value = sanitize_text_field($_POST['bet_value'] ?? '');
    
    cfp_enforce_min_bet($bet);
    
    $house_edge = floatval(cfp_get_setting('roulette_house_edge', 2.7));
    
    // Payout multipliers (European roulette)
    $payouts = [
        'red' => 2, 'black' => 2,
        'even' => 2, 'odd' => 2,
        'low' => 2, 'high' => 2,
        'dozen1' => 3, 'dozen2' => 3, 'dozen3' => 3,
        'column1' => 3, 'column2' => 3, 'column3' => 3,
        'street' => 12, 'corner' => 9,
        'split' => 18, 'single' => 36
    ];
    
    $payout_mult = $payouts[$bet_type] ?? 2;
    
    global $wpdb;
    
    // Atomic balance check
    $check = $wpdb->query($wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $bet, $user->id, $bet
    ));
    if (!$check) wp_send_json_error(['msg' => 'Insufficient balance.']);
    
    // Spin wheel (provably fair)
    $result = cfp_pf()->calculate_result($user->id, 'roulette');
    $spin = cfp_pf()->hash_to_int($result['hash'], 0, 36);
    
    // Determine color and result
    $reds = [1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36];
    $blacks = [2,4,6,8,10,11,13,15,17,20,22,24,26,28,29,31,33,35];
    
    $color = ($spin === 0) ? 'green' : (in_array($spin, $reds) ? 'red' : 'black');
    $won = false;
    
    switch ($bet_type) {
        case 'red': $won = ($color === 'red'); break;
        case 'black': $won = ($color === 'black'); break;
        case 'even': $won = ($spin % 2 === 0 && $spin !== 0); break;
        case 'odd': $won = ($spin % 2 === 1); break;
        case 'low': $won = ($spin >= 1 && $spin <= 18); break;
        case 'high': $won = ($spin >= 19 && $spin <= 36); break;
        case 'dozen1': $won = ($spin >= 1 && $spin <= 12); break;
        case 'dozen2': $won = ($spin >= 13 && $spin <= 24); break;
        case 'dozen3': $won = ($spin >= 25 && $spin <= 36); break;
        case 'column1': $won = ($spin % 3 === 1); break;
        case 'column2': $won = ($spin % 3 === 2); break;
        case 'column3': $won = ($spin % 3 === 0 && $spin !== 0); break;
        case 'single': $won = ($spin === intval($bet_value)); break;
    }
    
    $payout = $won ? floor($bet * $payout_mult) : 0;
    $net = $payout - $bet;
    
    // Update balance
    if ($won) {
        $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
            $payout, $user->id
        ));
    }
    
    // Credit house edge
    cfp_credit_house_edge('roulette', $user->id, $bet, $payout, $house_edge);
    
    // Log game
    $wpdb->insert(CFP_TABLE_ROULETTE, [
        'user_id' => $user->id,
        'bet_sat' => $bet,
        'bet_type' => $bet_type,
        'bet_value' => $bet_value,
        'spin_result' => $spin,
        'spin_color' => $color,
        'won' => $won ? 1 : 0,
        'payout_sat' => $payout,
        'house_edge_pct' => $house_edge
    ]);
    
    $new_bal = $wpdb->get_var($wpdb->prepare(
        "SELECT balance_sat FROM " . CFP_TABLE_USERS . " WHERE id=%d", $user->id
    ));
    
    wp_send_json_success([
        'spin' => $spin,
        'color' => $color,
        'won' => $won,
        'payout' => $payout,
        'new_balance' => $new_bal,
        'msg' => $won ? "🎉 {$spin} {$color}! +{$payout} sat" : "💥 {$spin} {$color}. -{$bet} sat"
    ]);
}

/* ============================================================
   AJAX: BACCARAT
   ============================================================ */
add_action('wp_ajax_cfp_baccarat', 'cfp_ajax_baccarat');
function cfp_ajax_baccarat() {
    check_ajax_referer('cfp_nonce', 'nonce');
    cfp_require_rate_limit('game');
    $user = cfp_require_auth();
    
    if (cfp_get_setting('baccarat_enabled', '1') !== '1') {
        wp_send_json_error(['msg' => 'Baccarat is currently disabled.']);
    }
    
    $bet = intval($_POST['bet'] ?? 0);
    $bet_type = sanitize_text_field($_POST['bet_type'] ?? 'player'); // player, banker, tie
    
    cfp_enforce_min_bet($bet);
    
    $house_edge_player = floatval(cfp_get_setting('baccarat_house_edge_player', 1.24));
    $house_edge_banker = floatval(cfp_get_setting('baccarat_house_edge_banker', 1.06));
    $house_edge_tie = floatval(cfp_get_setting('baccarat_house_edge_tie', 14.36));
    
    $edge = ($bet_type === 'player') ? $house_edge_player : (($bet_type === 'banker') ? $house_edge_banker : $house_edge_tie);
    
    // Payouts
    $payout_mult = ($bet_type === 'tie') ? 8 : 2;
    
    global $wpdb;
    
    $check = $wpdb->query($wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $bet, $user->id, $bet
    ));
    if (!$check) wp_send_json_error(['msg' => 'Insufficient balance.']);
    
    // Deal cards
    $deck = cfp_pf_shuffle_deck($user->id, 'baccarat');
    $deck_index = 0;
    
    $player_cards = cfp_pf_draw_cards($deck, 2, $deck_index);
    $banker_cards = cfp_pf_draw_cards($deck, 2, $deck_index);
    
    $player_score = cfp_hand_sum($player_cards) % 10;
    $banker_score = cfp_hand_sum($banker_cards) % 10;
    
    // Third card rules (simplified)
    if ($player_score < 6) {
        $player_cards[] = cfp_pf_draw_cards($deck, 1, $deck_index)[0];
        $player_score = cfp_hand_sum($player_cards) % 10;
    }
    
    if ($banker_score < 3) {
        $banker_cards[] = cfp_pf_draw_cards($deck, 1, $deck_index)[0];
        $banker_score = cfp_hand_sum($banker_cards) % 10;
    } elseif ($banker_score === 3 && $player_score !== 8) {
        $banker_cards[] = cfp_pf_draw_cards($deck, 1, $deck_index)[0];
        $banker_score = cfp_hand_sum($banker_cards) % 10;
    } elseif ($banker_score === 4 && $player_score >= 2 && $player_score <= 7) {
        $banker_cards[] = cfp_pf_draw_cards($deck, 1, $deck_index)[0];
        $banker_score = cfp_hand_sum($banker_cards) % 10;
    } elseif ($banker_score === 5 && $player_score >= 4 && $player_score <= 7) {
        $banker_cards[] = cfp_pf_draw_cards($deck, 1, $deck_index)[0];
        $banker_score = cfp_hand_sum($banker_cards) % 10;
    } elseif ($banker_score === 6 && $player_score >= 6 && $player_score <= 7) {
        $banker_cards[] = cfp_pf_draw_cards($deck, 1, $deck_index)[0];
        $banker_score = cfp_hand_sum($banker_cards) % 10;
    }
    
    // Determine winner
    $result = 'tie';
    if ($player_score > $banker_score) $result = 'player';
    elseif ($banker_score > $player_score) $result = 'banker';
    
    $won = ($result === $bet_type);
    $payout = $won ? floor($bet * $payout_mult) : 0;
    
    if ($won) {
        $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
            $payout, $user->id
        ));
    }
    
    cfp_credit_house_edge('baccarat', $user->id, $bet, $payout, $edge);
    
    $wpdb->insert(CFP_TABLE_BACCARAT, [
        'user_id' => $user->id,
        'bet_sat' => $bet,
        'bet_type' => $bet_type,
        'player_score' => $player_score,
        'banker_score' => $banker_score,
        'result' => $result,
        'payout_sat' => $payout,
        'house_edge_pct' => $edge
    ]);
    
    $new_bal = $wpdb->get_var($wpdb->prepare(
        "SELECT balance_sat FROM " . CFP_TABLE_USERS . " WHERE id=%d", $user->id
    ));
    
    wp_send_json_success([
        'player_score' => $player_score,
        'banker_score' => $banker_score,
        'result' => $result,
        'won' => $won,
        'payout' => $payout,
        'new_balance' => $new_bal,
        'msg' => $won ? "🎉 {$result} wins! +{$payout} sat" : "💥 {$result} wins. -{$bet} sat"
    ]);
}

/* ============================================================
   AJAX: PLINKO
   ============================================================ */
add_action('wp_ajax_cfp_plinko', 'cfp_ajax_plinko');
function cfp_ajax_plinko() {
    check_ajax_referer('cfp_nonce', 'nonce');
    cfp_require_rate_limit('game');
    $user = cfp_require_auth();
    
    if (cfp_get_setting('plinko_enabled', '1') !== '1') {
        wp_send_json_error(['msg' => 'Plinko is currently disabled.']);
    }
    
    $bet = intval($_POST['bet'] ?? 0);
    $rows = intval($_POST['rows'] ?? cfp_get_setting('plinko_default_rows', 8));
    
    cfp_enforce_min_bet($bet);
    
    $house_edge = floatval(cfp_get_setting('plinko_house_edge', 3.0));
    
    // Get multipliers for selected rows
    $mults_key = 'plinko_row_' . $rows . '_mults';
    $mults_str = cfp_get_setting($mults_key, '0.5,0.7,1.0,1.5,3.0,1.5,1.0,0.7,0.5');
    $mults = array_map('floatval', explode(',', $mults_str));
    
    global $wpdb;
    
    $check = $wpdb->query($wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $bet, $user->id, $bet
    ));
    if (!$check) wp_send_json_error(['msg' => 'Insufficient balance.']);
    
    // Simulate ball path (provably fair)
    $result = cfp_pf()->calculate_result($user->id, 'plinko_rows_' . $rows);
    $path = [];
    $position = ($rows + 1) / 2;
    
    for ($i = 0; $i < $rows; $i++) {
        $direction = cfp_pf()->hash_to_int(hash('sha256', $result['hash'] . $i), 0, 1);
        $position += ($direction === 0) ? -0.5 : 0.5;
        $path[] = round($position, 1);
    }
    
    // Determine final bucket
    $final_pos = round($path[count($path) - 1]);
    $bucket_idx = max(0, min(count($mults) - 1, $final_pos));
    $multiplier = $mults[$bucket_idx];
    
    $won = ($multiplier > 1);
    $payout = floor($bet * $multiplier);
    
    if ($won) {
        $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
            $payout, $user->id
        ));
    }
    
    cfp_credit_house_edge('plinko', $user->id, $bet, $payout, $house_edge);
    
    $wpdb->insert(CFP_TABLE_PLINKO, [
        'user_id' => $user->id,
        'bet_sat' => $bet,
        'rows' => $rows,
        'path' => json_encode($path),
        'multiplier' => $multiplier,
        'payout_sat' => $payout,
        'won' => $won ? 1 : 0,
        'house_edge_pct' => $house_edge
    ]);
    
    $new_bal = $wpdb->get_var($wpdb->prepare(
        "SELECT balance_sat FROM " . CFP_TABLE_USERS . " WHERE id=%d", $user->id
    ));
    
    wp_send_json_success([
        'path' => $path,
        'multiplier' => $multiplier,
        'won' => $won,
        'payout' => $payout,
        'new_balance' => $new_bal,
        'msg' => $won ? "🎉 {$multiplier}x! +{$payout} sat" : "💥 {$multiplier}x. -{$bet} sat"
    ]);
}

/* ============================================================
   AJAX: MINES
   ============================================================ */
add_action('wp_ajax_cfp_mines', 'cfp_ajax_mines');
function cfp_ajax_mines() {
    check_ajax_referer('cfp_nonce', 'nonce');
    cfp_require_rate_limit('game');
    $user = cfp_require_auth();
    
    if (cfp_get_setting('mines_enabled', '1') !== '1') {
        wp_send_json_error(['msg' => 'Mines is currently disabled.']);
    }
    
    $action = sanitize_text_field($_POST['mine_action'] ?? 'start');
    $bet = intval($_POST['bet'] ?? 0);
    $mines = intval($_POST['mines'] ?? cfp_get_setting('mines_default_mines', 3));
    $tile = intval($_POST['tile'] ?? -1);
    
    $house_edge = floatval(cfp_get_setting('mines_house_edge', 4.0));
    $gem_mult = floatval(cfp_get_setting('mines_gem_multiplier', 0.6));
    
    global $wpdb;
    
    if ($action === 'start') {
        cfp_enforce_min_bet($bet);
        
        $check = $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
            $bet, $user->id, $bet
        ));
        if (!$check) wp_send_json_error(['msg' => 'Insufficient balance.']);
        
        // Generate mine positions (provably fair)
        $result = cfp_pf()->calculate_result($user->id, 'mines_m' . $mines);
        $mine_positions = [];
        $available = range(0, 24);
        
        for ($i = 0; $i < $mines; $i++) {
            $idx = cfp_pf()->hash_to_int(hash('sha256', $result['hash'] . $i), 0, count($available) - 1);
            $mine_positions[] = $available[$idx];
            array_splice($available, $idx, 1);
        }
        
        $game_id = $wpdb->insert(CFP_TABLE_MINES, [
            'user_id' => $user->id,
            'bet_sat' => $bet,
            'mines' => $mines,
            'grid_size' => 25,
            'revealed' => 0,
            'gems_found' => 0,
            'cashout_mult' => 1.0,
            'house_edge_pct' => $house_edge,
            'played_at' => current_time('mysql')
        ]);
        
        wp_send_json_success([
            'game_id' => $game_id,
            'mine_positions' => $mine_positions,
            'mines' => $mines,
            'msg' => 'Click tiles to reveal. Cashout anytime!'
        ]);
        
    } elseif ($action === 'reveal') {
        $game = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . CFP_TABLE_MINES . " WHERE id=%d AND user_id=%d AND played_at = (SELECT MAX(played_at) FROM " . CFP_TABLE_MINES . " WHERE user_id=%d)",
            $tile, $user->id, $user->id
        ));
        
        if (!$game) wp_send_json_error(['msg' => 'Game not found.']);
        
        // This is simplified - full implementation would track revealed tiles
        $won = ($tile !== 5); // Placeholder
        $payout = floor($game->bet_sat * $game->cashout_mult);
        
        if ($won) {
            $wpdb->query($wpdb->prepare(
                "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
                $payout, $user->id
            ));
        }
        
        cfp_credit_house_edge('mines', $user->id, $game->bet_sat, $payout, $house_edge);
        
        $new_bal = $wpdb->get_var($wpdb->prepare(
            "SELECT balance_sat FROM " . CFP_TABLE_USERS . " WHERE id=%d", $user->id
        ));
        
        wp_send_json_success([
            'won' => $won,
            'payout' => $payout,
            'new_balance' => $new_bal,
            'msg' => $won ? "💎 Gem found! +{$payout} sat" : "💥 Hit a mine! -{$game->bet_sat} sat"
        ]);
    }
}

/* ============================================================
   AJAX: VIDEO POKER
   ============================================================ */
add_action('wp_ajax_cfp_videopoker', 'cfp_ajax_videopoker');
function cfp_ajax_videopoker() {
    check_ajax_referer('cfp_nonce', 'nonce');
    $user = cfp_require_auth();
    
    if (cfp_get_setting('videopoker_enabled', '1') !== '1') {
        wp_send_json_error(['msg' => 'Video Poker is currently disabled.']);
    }
    
    $action = sanitize_text_field($_POST['vp_action'] ?? 'deal');
    $bet = intval($_POST['bet'] ?? 0);
    $hold = sanitize_text_field($_POST['hold'] ?? '');
    
    $house_edge = floatval(cfp_get_setting('videopoker_house_edge', 2.5));
    
    global $wpdb;
    
    if ($action === 'deal') {
        cfp_enforce_min_bet($bet);
        
        $check = $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
            $bet, $user->id, $bet
        ));
        if (!$check) wp_send_json_error(['msg' => 'Insufficient balance.']);
        
        // Deal initial hand
        $deck = cfp_pf_shuffle_deck($user->id, 'videopoker_deal');
        $hand = array_slice($deck, 0, 5);
        
        $wpdb->insert(CFP_TABLE_VIDEO_POKER, [
            'user_id' => $user->id,
            'bet_sat' => $bet,
            'hand_cards' => json_encode($hand),
            'draw_cards' => json_encode([]),
            'final_hand' => 'dealt',
            'payout_mult' => 0,
            'payout_sat' => 0,
            'won' => 0,
            'house_edge_pct' => $house_edge
        ]);
        
        wp_send_json_success([
            'hand' => array_map(function($c) { return $c['code']; }, $hand),
            'msg' => 'Hold cards you want to keep, then click Draw'
        ]);
        
    } elseif ($action === 'draw') {
        // Get last game
        $game = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM " . CFP_TABLE_VIDEO_POKER . " WHERE user_id=%d ORDER BY id DESC LIMIT 1",
            $user->id
        ));
        
        if (!$game || $game->final_hand !== 'dealt') {
            wp_send_json_error(['msg' => 'Start a new game first.']);
        }
        
        $hand = json_decode($game->hand_cards, true);
        
        // Replace non-held cards
        $hold_indices = array_map('intval', explode(',', $hold));
        $new_hand = [];
        $draw_index = 5;
        
        for ($i = 0; $i < 5; $i++) {
            if (in_array($i, $hold_indices)) {
                $new_hand[] = $hand[$i];
            } else {
                $deck = cfp_pf_shuffle_deck($user->id, 'videopoker_draw_' . $i);
                $new_hand[] = $deck[5 + $i];
            }
        }
        
        // Evaluate hand
        $hand_result = cfp_evaluate_poker_hand($new_hand);
        
        // Get payout multiplier
        $payout_mult = floatval(cfp_get_setting('videopoker_payout_' . strtolower(str_replace(' ', '', $hand_result)), 0));
        
        $won = ($payout_mult > 0);
        $payout = floor($game->bet_sat * $payout_mult);
        
        if ($won) {
            $wpdb->query($wpdb->prepare(
                "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
                $payout, $user->id
            ));
        }
        
        cfp_credit_house_edge('videopoker', $user->id, $game->bet_sat, $payout, $house_edge);
        
        $wpdb->update(CFP_TABLE_VIDEO_POKER, [
            'draw_cards' => json_encode($new_hand),
            'final_hand' => $hand_result,
            'payout_mult' => $payout_mult,
            'payout_sat' => $payout,
            'won' => $won ? 1 : 0
        ], ['id' => $game->id]);
        
        $new_bal = $wpdb->get_var($wpdb->prepare(
            "SELECT balance_sat FROM " . CFP_TABLE_USERS . " WHERE id=%d", $user->id
        ));
        
        wp_send_json_success([
            'hand' => array_map(function($c) { return $c['code']; }, $new_hand),
            'result' => $hand_result,
            'won' => $won,
            'payout' => $payout,
            'new_balance' => $new_bal,
            'msg' => $won ? "🎉 {$hand_result}! +{$payout} sat" : "💥 No win. -{$game->bet_sat} sat"
        ]);
    }
}

function cfp_evaluate_poker_hand($cards) {
    // Simplified poker hand evaluation
    $values = array_map(function($c) { return $c['value']; }, $cards);
    $suits = array_map(function($c) { return $c['suit']; }, $cards);
    
    $value_counts = array_count_values($values);
    arsort($value_counts);
    
    $flush = count(array_unique($suits)) === 1;
    sort($values);
    $straight = (count(array_unique($values)) === 5 && max($values) - min($values) === 4);
    
    if ($flush && $straight) return 'Straight Flush';
    if (reset($value_counts) === 4) return 'Four of a Kind';
    if (reset($value_counts) === 3 && count($value_counts) === 2) return 'Full House';
    if ($flush) return 'Flush';
    if ($straight) return 'Straight';
    if (reset($value_counts) === 3) return 'Three of a Kind';
    if (count($value_counts) === 3 && max($value_counts) === 2) return 'Two Pair';
    if (reset($value_counts) === 2) return 'Jacks or Better';
    return 'No Win';
}

/* ============================================================
   AJAX: KENO
   ============================================================ */
add_action('wp_ajax_cfp_keno', 'cfp_ajax_keno');
function cfp_ajax_keno() {
    check_ajax_referer('cfp_nonce', 'nonce');
    $user = cfp_require_auth();
    
    if (cfp_get_setting('keno_enabled', '1') !== '1') {
        wp_send_json_error(['msg' => 'Keno is currently disabled.']);
    }
    
    $bet = intval($_POST['bet'] ?? 0);
    $spots = intval($_POST['spots'] ?? cfp_get_setting('keno_spots_default', 5));
    $selected = sanitize_text_field($_POST['selected'] ?? '');
    
    cfp_enforce_min_bet($bet);
    
    $house_edge = floatval(cfp_get_setting('keno_house_edge', 5.0));
    
    $selected_nums = array_map('intval', explode(',', $selected));
    if (count($selected_nums) !== $spots) {
        wp_send_json_error(['msg' => "Select exactly {$spots} numbers."]);
    }
    
    global $wpdb;
    
    $check = $wpdb->query($wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $bet, $user->id, $bet
    ));
    if (!$check) wp_send_json_error(['msg' => 'Insufficient balance.']);
    
    // Draw numbers (provably fair)
    $result = cfp_pf()->calculate_result($user->id, 'keno_s' . $spots);
    $drawn = [];
    $available = range(1, 80);
    
    for ($i = 0; $i < 20; $i++) {
        $idx = cfp_pf()->hash_to_int(hash('sha256', $result['hash'] . $i), 0, count($available) - 1);
        $drawn[] = $available[$idx];
        array_splice($available, $idx, 1);
    }
    
    $hits = count(array_intersect($selected_nums, $drawn));
    
    // Get payout
    $payouts_str = cfp_get_setting('keno_hits_payout', '0,0,0,0.5,1,2,5,10,50,500,5000');
    $payouts = array_map('floatval', explode(',', $payouts_str));
    $payout_mult = $payouts[min($hits, count($payouts) - 1)];
    
    $won = ($payout_mult > 0);
    $payout = floor($bet * $payout_mult);
    
    if ($won) {
        $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
            $payout, $user->id
        ));
    }
    
    cfp_credit_house_edge('keno', $user->id, $bet, $payout, $house_edge);
    
    $wpdb->insert(CFP_TABLE_KENO, [
        'user_id' => $user->id,
        'bet_sat' => $bet,
        'picks' => $spots,
        'selected_numbers' => json_encode($selected_nums),
        'drawn_numbers' => json_encode($drawn),
        'hits' => $hits,
        'payout_mult' => $payout_mult,
        'payout_sat' => $payout,
        'won' => $won ? 1 : 0,
        'house_edge_pct' => $house_edge
    ]);
    
    $new_bal = $wpdb->get_var($wpdb->prepare(
        "SELECT balance_sat FROM " . CFP_TABLE_USERS . " WHERE id=%d", $user->id
    ));
    
    wp_send_json_success([
        'drawn' => $drawn,
        'hits' => $hits,
        'won' => $won,
        'payout' => $payout,
        'new_balance' => $new_bal,
        'msg' => $won ? "🎉 {$hits} hits! +{$payout} sat" : "💥 {$hits} hits. -{$bet} sat"
    ]);
}

/* ============================================================
   AJAX: RAFFLE
   ============================================================ */
add_action('wp_ajax_cfp_raffle', 'cfp_ajax_raffle');
function cfp_ajax_raffle() {
    check_ajax_referer('cfp_nonce', 'nonce');
    $user = cfp_require_auth();
    
    if (cfp_get_setting('raffle_enabled', '1') !== '1') {
        wp_send_json_error(['msg' => 'Raffle is currently disabled.']);
    }
    
    $bet = intval($_POST['bet'] ?? 0);
    $ticket_count = intval($_POST['tickets'] ?? 1);
    $total_bet = $bet * $ticket_count;
    
    cfp_enforce_min_bet($total_bet);
    
    $house_edge = floatval(cfp_get_setting('raffle_house_edge', 10.0));
    $min_bet = intval(cfp_get_setting('raffle_min_bet', 100));
    
    if ($total_bet < $min_bet) {
        wp_send_json_error(['msg' => "Minimum bet is {$min_bet} sat."]);
    }
    
    global $wpdb;
    
    $check = $wpdb->query($wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $total_bet, $user->id, $total_bet
    ));
    if (!$check) wp_send_json_error(['msg' => 'Insufficient balance.']);
    
    // Get current pool info
    $pool_sat = intval(cfp_get_setting('raffle_pool_sat', 0));
    $pool_tickets = intval(cfp_get_setting('raffle_total_tickets', 0));
    $prize_pool = floor($total_bet * (100 - $house_edge) / 100);
    
    // Generate ticket numbers
    $tickets = [];
    $prize_pool_sat = 0;
    
    for ($i = 0; $i < $ticket_count; $i++) {
        $ticket_num = cfp_pf()->hash_to_int(
            hash('sha256', cfp_pf()->calculate_result($user->id, 'raffle_t' . $i)['hash'] . $user->id . time()),
            1, 999999
        );
        $tickets[] = $ticket_num;
        $prize_pool_sat += floor($bet / $ticket_count * (100 - $house_edge) / 100);
    }
    
    // Determine winner (provably fair)
    $result = cfp_pf()->calculate_result($user->id, 'raffle_winner');
    $winning_ticket = cfp_pf()->hash_to_int($result['hash'], 1, 999999);
    
    $won = false;
    $payout = 0;
    
    // Check if user's ticket won
    foreach ($tickets as $t) {
        if ($t === $winning_ticket || abs($t - $winning_ticket) < 100) {
            $won = true;
            break;
        }
    }
    
    if ($won) {
        $payout = $prize_pool_sat;
        $wpdb->query($wpdb->prepare(
            "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
            $payout, $user->id
        ));
    }
    
    // Credit house edge
    $admin_earns = ($total_bet - $payout) - ($won ? floor($prize_pool_sat * $house_edge / 100) : 0);
    cfp_credit_house_edge('raffle', $user->id, $total_bet, $payout, $house_edge);
    
    // Update pool
    cfp_update_setting('raffle_pool_sat', $pool_sat + floor($total_bet * (100 - $house_edge) / 100));
    cfp_update_setting('raffle_total_tickets', $pool_tickets + $ticket_count);
    
    // Log tickets
    foreach ($tickets as $t) {
        $wpdb->insert(CFP_TABLE_RAFFLE_GAMES, [
            'user_id' => $user->id,
            'bet_sat' => $bet,
            'ticket_number' => $t,
            'prize_pool_sat' => $prize_pool_sat,
            'total_tickets' => $pool_tickets + $ticket_count,
            'won' => $won ? 1 : 0,
            'payout_sat' => floor($payout / $ticket_count),
            'house_edge_pct' => $house_edge
        ]);
    }
    
    $new_bal = $wpdb->get_var($wpdb->prepare(
        "SELECT balance_sat FROM " . CFP_TABLE_USERS . " WHERE id=%d", $user->id
    ));
    
    wp_send_json_success([
        'tickets' => $tickets,
        'won' => $won,
        'payout' => $payout,
        'new_balance' => $new_bal,
        'msg' => $won ? "🎉 YOU WON THE RAFFLE! +{$payout} sat" : "Better luck next time! -{$total_bet} sat"
    ]);
}

/* ============================================================
   SHORTCODE: [cfp_games_lobby] (Enhanced with new games)
   ============================================================ */
add_shortcode('cfp_games_lobby', function() {
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax = admin_url('admin-ajax.php');
    
    $games = [
        ['id' => 'slots', 'name' => 'Slots', 'icon' => '🎰', 'color' => '#a855f7', 'enabled' => cfp_get_setting('slots_enabled', 1)],
        ['id' => 'blackjack', 'name' => 'Blackjack', 'icon' => '🃏', 'color' => '#22c55e', 'enabled' => cfp_get_setting('blackjack_enabled', 1)],
        ['id' => 'roulette', 'name' => 'Roulette', 'icon' => '🎡', 'color' => '#ef4444', 'enabled' => cfp_get_setting('roulette_enabled', 1)],
        ['id' => 'baccarat', 'name' => 'Baccarat', 'icon' => '🎴', 'color' => '#3b82f6', 'enabled' => cfp_get_setting('baccarat_enabled', 1)],
        ['id' => 'plinko', 'name' => 'Plinko', 'icon' => '🔽', 'color' => '#f97316', 'enabled' => cfp_get_setting('plinko_enabled', 1)],
        ['id' => 'mines', 'name' => 'Mines', 'icon' => '💎', 'color' => '#06b6d4', 'enabled' => cfp_get_setting('mines_enabled', 1)],
        ['id' => 'videopoker', 'name' => 'Video Poker', 'icon' => '🃏', 'color' => '#84cc16', 'enabled' => cfp_get_setting('videopoker_enabled', 1)],
        ['id' => 'keno', 'name' => 'Keno', 'icon' => '🎱', 'color' => '#ec4899', 'enabled' => cfp_get_setting('keno_enabled', 1)],
        ['id' => 'raffle', 'name' => 'Raffle', 'icon' => '🎟', 'color' => '#eab308', 'enabled' => cfp_get_setting('raffle_enabled', 1)],
        ['id' => 'hilo', 'name' => 'Hi-Lo', 'icon' => '🎲', 'color' => '#f7931a', 'enabled' => cfp_get_setting('multiply_enabled', 1)],
        ['id' => 'coinflip', 'name' => 'Coin Flip', 'icon' => '🪙', 'color' => '#fbbf24', 'enabled' => cfp_get_setting('coinflip_enabled', 1)],
        ['id' => 'dice', 'name' => 'Dice', 'icon' => '🎲', 'color' => '#14b8a6', 'enabled' => cfp_get_setting('dice_enabled', 1)],
        ['id' => 'crash', 'name' => 'Crash', 'icon' => '📈', 'color' => '#f43f5e', 'enabled' => cfp_get_setting('crash_enabled', 1)],
        ['id' => 'wheel', 'name' => 'Wheel', 'icon' => '🎡', 'color' => '#8b5cf6', 'enabled' => cfp_get_setting('wheel_enabled', 1)],
    ];
    
    ob_start(); ?>
    <div class="cfp-games-lobby" style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px;padding:20px 0">
        <?php foreach ($games as $game): 
            if ($game['enabled'] !== '1') continue;
        ?>
        <div class="cfp-game-card" onclick="cfpOpenGame('<?= $game['id'] ?>')" 
             style="background:var(--surface);border:1px solid var(--border);border-radius:12px;padding:20px;text-align:center;cursor:pointer;transition:all .2s"
             onmouseover="this.style.borderColor='<?= $game['color'] ?>';this.style.transform='translateY(-2px)'"
             onmouseout="this.style.borderColor='var(--border)';this.style.transform='translateY(0)'">
            <div style="font-size:2.5rem;margin-bottom:8px"><?= $game['icon'] ?></div>
            <div style="font-weight:700;color:var(--text)"><?= $game['name'] ?></div>
        </div>
        <?php endforeach; ?>
    </div>
    <script>
    const cfpGamesAjax = '<?= $ajax ?>';
    const cfpGamesNonce = '<?= $nonce ?>';
    function cfpOpenGame(id) {
        // Trigger game-specific modal or redirect
        document.dispatchEvent(new CustomEvent('cfp-open-game', { detail: id }));
    }
    </script>
    <?php return ob_get_clean();
});
