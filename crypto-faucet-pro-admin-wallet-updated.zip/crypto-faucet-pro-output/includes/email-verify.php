<?php
/**
 * Email Verification — full implementation.
 *
 * Handles:
 *  - Sending verification emails on registration
 *  - Token validation via ?cfp_verify=<token> URL
 *  - Resend verification link
 *  - Blocking unverified users from claiming/playing (enforced in ip-limiter + game handlers)
 *
 * Token flow:
 *  1. Registration → cfp_send_verification_email() creates a token row + sends email.
 *  2. User clicks link → cfp_maybe_process_verify_token() marks token used + sets is_verified=1.
 *  3. If token expired (>24h), user can request a fresh one via [cfp_resend_verify] shortcode.
 *
 * NOTE: password-auth.php already contains cfp_send_verification_email(), the verify
 * URL handler (cfp_maybe_process_verify_token), and the cfp_ajax_resend_verify AJAX
 * action. This file adds the shortcode UI, the verification status widget, and
 * the admin notification hook so admins can see unverified counts at a glance.
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   SHORTCODE: [cfp_email_verify_status]
   Shows current verification status for the logged-in user.
   Includes a resend button if not yet verified.
   ============================================================ */
add_shortcode('cfp_email_verify_status', function() {
    if ( cfp_get_setting('email_verify_required','0') !== '1' ) return '';

    $nonce = wp_create_nonce('cfp_nonce');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-verify-status-widget" style="max-width:480px;margin:0 auto">
        <h2>📧 Email Verification</h2>
        <div id="cfp-vs-msg"></div>
        <input class="cfp-input" type="email" id="cfp-vs-email" placeholder="Your account email" onblur="cfpVsCheck()">
        <div id="cfp-vs-info" style="display:none">
            <div id="cfp-vs-verified-panel" style="display:none;background:#0a1a0a;border:1px solid #22c55e33;border-radius:10px;padding:14px;margin-bottom:14px;text-align:center">
                <div style="font-size:2rem;margin-bottom:6px">✅</div>
                <div style="font-family:'Oswald',sans-serif;color:#22c55e;font-size:1.1rem">Email Verified</div>
                <div style="color:#555;font-size:.82rem;margin-top:6px">Your account is fully active. You can claim and play games.</div>
            </div>
            <div id="cfp-vs-unverified-panel" style="display:none;background:#1a0a0a;border:1px solid #ef444433;border-radius:10px;padding:14px;margin-bottom:14px;text-align:center">
                <div style="font-size:2rem;margin-bottom:6px">⚠️</div>
                <div style="font-family:'Oswald',sans-serif;color:#ef4444;font-size:1.1rem">Email Not Verified</div>
                <div style="color:#777;font-size:.82rem;margin-top:6px;margin-bottom:14px">
                    Check your inbox for the verification email. It may take a few minutes.<br>
                    Also check your spam/junk folder.
                </div>
                <button class="cfp-claim-btn" onclick="cfpVsResend()" style="font-size:.85rem;padding:10px 24px">
                    📨 Resend Verification Email
                </button>
            </div>
        </div>
    </div>
    <script>
    async function cfpVsCheck() {
        const email = document.getElementById('cfp-vs-email').value;
        if (!email) return;
        const fd = new FormData();
        fd.append('action','cfp_get_user'); fd.append('nonce',cfpNonce); fd.append('email',email);
        const r = await fetch(cfpAjax,{method:'POST',body:fd}); const d = await r.json();
        if (!d.success) { document.getElementById('cfp-vs-msg').innerHTML='<div class="cfp-msg error">Account not found.</div>'; return; }
        document.getElementById('cfp-vs-info').style.display='';
        const verified = d.data.is_verified;
        document.getElementById('cfp-vs-verified-panel').style.display   = verified ? '' : 'none';
        document.getElementById('cfp-vs-unverified-panel').style.display = verified ? 'none' : '';
    }
    async function cfpVsResend() {
        const email = document.getElementById('cfp-vs-email').value;
        if (!email) { document.getElementById('cfp-vs-msg').innerHTML='<div class="cfp-msg error">Enter your email first.</div>'; return; }
        const fd = new FormData();
        fd.append('action','cfp_resend_verify'); fd.append('nonce',cfpNonce); fd.append('email',email);
        const r = await fetch(cfpAjax,{method:'POST',body:fd}); const d = await r.json();
        document.getElementById('cfp-vs-msg').innerHTML=`<div class="cfp-msg ${d.success?'success':'error'}">${d.success?d.data.msg:d.data.msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   ADMIN DASHBOARD WIDGET — unverified user count
   ============================================================ */
add_action('wp_dashboard_setup', function() {
    if ( ! current_user_can('manage_options') ) return;
    if ( cfp_get_setting('email_verify_required','0') !== '1' ) return;
    wp_add_dashboard_widget(
        'cfp_verify_widget',
        '⚡ CFP — Email Verification Status',
        function() {
            global $wpdb;
            $total      = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_USERS);
            $verified   = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_USERS . " WHERE is_verified=1");
            $unverified = $total - $verified;
            echo '<p>Total accounts: <strong>' . number_format($total) . '</strong></p>';
            echo '<p>Verified: <strong style="color:#22c55e">' . number_format($verified) . '</strong></p>';
            echo '<p>Unverified: <strong style="color:#ef4444">' . number_format($unverified) . '</strong></p>';
            echo '<p><a href="' . admin_url('admin.php?page=cfp-users&filter=unverified') . '">View unverified users →</a></p>';
        }
    );
});

/* ============================================================
   CRON: Auto-delete accounts unverified after N days (configurable)
   ============================================================ */
add_action('cfp_daily_interest_hook', 'cfp_cleanup_unverified_accounts');
function cfp_cleanup_unverified_accounts() {
    $days = intval( cfp_get_setting('unverified_purge_days', 0) );
    if ( $days <= 0 ) return; // disabled
    global $wpdb;
    // Only delete zero-balance unverified accounts older than N days
    $deleted = $wpdb->query( $wpdb->prepare(
        "DELETE FROM " . CFP_TABLE_USERS .
        " WHERE is_verified=0 AND balance_sat=0 AND created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
        $days
    ));
    if ( $deleted > 0 ) {
        cfp_wallet_credit( 'admin_log', 0, "Auto-purged {$deleted} unverified zero-balance accounts older than {$days} days." );
    }
}
