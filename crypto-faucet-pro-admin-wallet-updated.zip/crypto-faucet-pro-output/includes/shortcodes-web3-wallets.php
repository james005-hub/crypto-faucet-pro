<?php
/**
 * Shortcodes: MetaMask & WalletConnect Deposit and Withdraw Widgets
 *
 * Provides four shortcodes:
 *   [cfp_metamask_deposit]      — MetaMask deposit widget
 *   [cfp_metamask_withdraw]     — MetaMask withdrawal widget
 *   [cfp_walletconnect_deposit] — WalletConnect deposit widget
 *   [cfp_walletconnect_withdraw]— WalletConnect withdrawal widget
 *
 * Deposits:  Connect wallet → confirm address → plugin creates
 *            a NOWPayments invoice (hot wallet) → user sends crypto
 *            on-chain → IPN credits balance.
 *
 * Withdrawals: Enter amount → plugin deducts balance → NOWPayments
 *              Mass Payout fires → fee goes to admin admin wallet.
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   SHARED: ENQUEUE WEB3 LIBRARIES
   ============================================================ */
add_action( 'wp_enqueue_scripts', 'cfp_enqueue_web3_libs' );
function cfp_enqueue_web3_libs(): void {
    // Only enqueue when at least one Web3 shortcode is likely on the page.
    // We use a global flag set by each shortcode renderer.
    if ( ! isset( $GLOBALS['cfp_web3_shortcode_active'] ) ) return;

    // Ethers.js v6 — used for MetaMask (window.ethereum) signing
    wp_enqueue_script(
        'ethers-js',
        'https://cdnjs.cloudflare.com/ajax/libs/ethers/6.7.1/ethers.umd.min.js',
        [],
        '6.7.1',
        true
    );

    // WalletConnect Web3Modal / EthereumProvider
    // These are loaded inline per-widget below via dynamic <script> tags
    // so they only appear when the WalletConnect shortcode is rendered.
}

/* ============================================================
   HELPER: RENDER SHARED STEP GUIDE
   ============================================================ */
function cfp_web3_how_to_steps( string $wallet_label, string $action ): string {
    $steps = $action === 'deposit' ? [
        "Click \"Connect {$wallet_label}\" and approve the connection in your wallet.",
        'Enter the amount you wish to deposit (in USD equivalent).',
        'Click "Generate Deposit Address" — a unique hot-wallet address is created.',
        "In {$wallet_label}, send the exact crypto amount shown to that address.",
        'Your balance is credited automatically once the transaction confirms.',
    ] : [
        "Click \"Connect {$wallet_label}\" and approve the connection in your wallet.",
        'Enter the withdrawal amount in satoshis.',
        "Your connected {$wallet_label} address is used as the destination — no copy-paste needed.",
        'Click "Withdraw" — your balance is deducted and the payout is sent on-chain via NOWPayments.',
        'A small fee is deducted to cover transaction costs.',
    ];

    $html = '<ol style="padding-left:18px;margin:0 0 14px;font-size:.82rem;color:#555;line-height:1.7">';
    foreach ( $steps as $step ) {
        $html .= '<li>' . esc_html( $step ) . '</li>';
    }
    $html .= '</ol>';
    return $html;
}

/* ============================================================
   SHARED: DEPOSIT WIDGET RENDERER
   Used by both MetaMask and WalletConnect deposit shortcodes.
   ============================================================ */
function cfp_render_web3_deposit_widget( string $wallet_type ): string {
    $GLOBALS['cfp_web3_shortcode_active'] = true;

    if ( ! cfp_web3_enabled() ) {
        return '<div class="cfp-widget"><div style="font-size:.82rem;color:#1a3a7a;padding:14px">Contact the site admin to enable Web3 wallet deposits.</div></div>';
    }

    $wallet_label = $wallet_type === 'walletconnect' ? 'WalletConnect' : 'MetaMask';
    $icon         = $wallet_type === 'walletconnect' ? '📡' : '🦊';
    $currency     = strtoupper( cfp_web3_currency() );
    $min_usd      = cfp_get_setting( 'web3_min_deposit_usd', '1' );
    $nonce        = wp_create_nonce( 'cfp_nonce' );
    $wc_proj_id   = cfp_get_setting( 'web3_walletconnect_project_id', '' );
    $widget_id    = 'cfp-web3-deposit-' . $wallet_type;

    ob_start(); ?>
    <div class="cfp-widget" id="<?= esc_attr( $widget_id ) ?>">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
            <div style="font-size:2rem;line-height:1"><?= $icon ?></div>
            <div>
                <div style="font-weight:700;font-size:1rem"><?= esc_html( $wallet_label ) ?> Deposit</div>
                <div style="font-size:.76rem;color:#1a3a7a">Connect your <?= esc_html( $wallet_label ) ?> wallet and deposit <?= esc_html( $currency ) ?> via the NOWPayments hot wallet · Min: $<?= esc_html( $min_usd ) ?> USD</div>
            </div>
        </div>

        <?= cfp_web3_how_to_steps( $wallet_label, 'deposit' ) ?>

        <div id="<?= esc_attr( $widget_id ) ?>-status" style="margin-bottom:10px"></div>

        <!-- Step 1: Connect -->
        <div id="<?= esc_attr( $widget_id ) ?>-step-connect">
            <button class="cfp-btn cfp-btn-full"
                    id="<?= esc_attr( $widget_id ) ?>-connect-btn"
                    style="background:<?= $wallet_type === 'walletconnect' ? '#3b99fc' : '#f6851b' ?>;color:#fff;font-weight:700;margin-bottom:8px">
                <?= $icon ?> Connect <?= esc_html( $wallet_label ) ?>
            </button>
        </div>

        <!-- Step 2: Deposit form (shown after connect) -->
        <div id="<?= esc_attr( $widget_id ) ?>-step-deposit" style="display:none">
            <div style="background:#f0f8ff;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:.82rem">
                <span style="color:#555">Connected: </span>
                <strong id="<?= esc_attr( $widget_id ) ?>-addr" style="color:#1a3a7a;word-break:break-all"></strong>
            </div>
            <label style="font-size:.82rem;font-weight:600;display:block;margin-bottom:4px">Amount (USD equivalent)</label>
            <input class="cfp-input" type="number" id="<?= esc_attr( $widget_id ) ?>-amount"
                   placeholder="e.g. 10"
                   min="<?= esc_attr( $min_usd ) ?>" step="0.01"
                   style="margin-bottom:10px">
            <label style="font-size:.82rem;font-weight:600;display:block;margin-bottom:4px">Currency</label>
            <select class="cfp-input" id="<?= esc_attr( $widget_id ) ?>-currency" style="margin-bottom:12px">
                <option value="<?= esc_attr( strtolower( $currency ) ) ?>"><?= esc_html( $currency ) ?></option>
                <option value="eth">ETH</option>
                <option value="matic">MATIC</option>
                <option value="btc">BTC</option>
                <option value="usdt">USDT</option>
                <option value="usdc">USDC</option>
            </select>
            <button class="cfp-btn cfp-btn-full" id="<?= esc_attr( $widget_id ) ?>-generate-btn"
                    style="background:#1a3a7a;color:#fff;font-weight:700;margin-bottom:8px">
                ⬇️ Generate Deposit Address
            </button>
            <button class="cfp-btn" id="<?= esc_attr( $widget_id ) ?>-disconnect-btn"
                    style="background:#eee;color:#555;font-size:.78rem">
                Disconnect
            </button>
        </div>

        <!-- Step 3: Payment address (shown after invoice created) -->
        <div id="<?= esc_attr( $widget_id ) ?>-step-payment" style="display:none">
            <div style="background:#fffbe6;border:1px solid #f5c518;border-radius:8px;padding:12px 14px;margin-bottom:12px">
                <div style="font-size:.78rem;font-weight:700;color:#7a5c00;margin-bottom:6px;text-transform:uppercase;letter-spacing:1px">Send Exactly</div>
                <div id="<?= esc_attr( $widget_id ) ?>-pay-amount" style="font-size:1.2rem;font-weight:700;color:#7a3000;margin-bottom:8px"></div>
                <div style="font-size:.76rem;color:#555;margin-bottom:4px">To this address (NOWPayments hot wallet):</div>
                <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                    <code id="<?= esc_attr( $widget_id ) ?>-pay-addr"
                          style="background:#fff;border:1px solid #ddd;border-radius:4px;padding:6px 10px;font-size:.78rem;word-break:break-all;flex:1"></code>
                    <button class="cfp-btn" onclick="cfpWeb3CopyAddr('<?= esc_attr( $widget_id ) ?>')"
                            style="font-size:.75rem;padding:6px 10px">📋 Copy</button>
                </div>
                <div style="text-align:center;margin-top:12px">
                    <img id="<?= esc_attr( $widget_id ) ?>-qr" src="" alt="QR Code" style="width:120px;height:120px;border-radius:8px">
                </div>
            </div>
            <div style="font-size:.76rem;color:#555;margin-bottom:10px">
                ⚠️ Send <strong>only <?= esc_html( $currency ) ?></strong> to this address. Sending the wrong coin may result in permanent loss.
            </div>
            <button class="cfp-btn cfp-btn-full" id="<?= esc_attr( $widget_id ) ?>-poll-btn"
                    style="background:#22c55e;color:#fff;font-weight:700;margin-bottom:6px">
                🔄 Check Payment Status
            </button>
            <button class="cfp-btn" onclick="cfpWeb3DepositReset('<?= esc_attr( $widget_id ) ?>')"
                    style="background:#eee;color:#555;font-size:.78rem">
                Start Over
            </button>
        </div>
    </div>

    <script>
    (function() {
        const wid     = <?= json_encode( $widget_id ) ?>;
        const wtype   = <?= json_encode( $wallet_type ) ?>;
        const nonce   = <?= json_encode( $nonce ) ?>;
        const ajaxUrl = <?= json_encode( admin_url( 'admin-ajax.php' ) ) ?>;
        const wcProjId = <?= json_encode( $wc_proj_id ) ?>;

        let connectedAddress = '';
        let currentPaymentId = '';

        const el = id => document.getElementById(wid + '-' + id);
        const msg = (text, type = 'info') => {
            el('status').innerHTML = `<div class="cfp-msg ${type}">${text}</div>`;
        };

        /* ── Connect ── */
        el('connect-btn').addEventListener('click', async () => {
            if (wtype === 'metamask') {
                await cfpWeb3ConnectMetaMask(wid, addr => {
                    connectedAddress = addr;
                    showDepositForm();
                });
            } else {
                await cfpWeb3ConnectWalletConnect(wid, wcProjId, addr => {
                    connectedAddress = addr;
                    showDepositForm();
                });
            }
        });

        function showDepositForm() {
            el('step-connect').style.display = 'none';
            el('step-deposit').style.display = '';
            el('addr').textContent = connectedAddress;
            msg('✅ Wallet connected. Enter an amount and generate your deposit address.', 'success');
        }

        /* ── Disconnect ── */
        el('disconnect-btn').addEventListener('click', () => {
            connectedAddress = '';
            el('step-deposit').style.display = 'none';
            el('step-payment').style.display = 'none';
            el('step-connect').style.display = '';
            msg('Wallet disconnected.', 'info');
        });

        /* ── Generate deposit address ── */
        el('generate-btn').addEventListener('click', async () => {
            const amount   = parseFloat(el('amount').value) || 0;
            const currency = el('currency').value;
            if (amount <= 0) { msg('❌ Enter a valid USD amount.', 'error'); return; }
            msg('⏳ Creating deposit address via NOWPayments…', 'info');

            const fd = new FormData();
            fd.append('action',      'cfp_web3_deposit');
            fd.append('nonce',       nonce);
            fd.append('wallet_type', wtype);
            fd.append('eth_address', connectedAddress);
            fd.append('currency',    currency);
            fd.append('amount_usd',  amount);

            const res = await fetch(ajaxUrl, { method: 'POST', body: fd });
            const data = await res.json();

            if (!data.success) { msg('❌ ' + (data.data?.msg || 'Error'), 'error'); return; }

            currentPaymentId = data.data.payment_id;
            el('pay-amount').textContent = data.data.pay_amount + ' ' + data.data.pay_currency.toUpperCase();
            el('pay-addr').textContent   = data.data.pay_address;
            el('qr').src                 = data.data.qr;

            el('step-deposit').style.display = 'none';
            el('step-payment').style.display = '';
            msg('✅ Deposit address generated. Send the exact amount shown.', 'success');

            // ── Direct RPC mode: send via wallet provider directly ──
            if (data.data.direct_rpc && connectedAddress) {
                await cfpWeb3SendDirectDeposit({
                    wid,
                    wtype,
                    nonce,
                    ajaxUrl,
                    payAddress:    data.data.pay_address,
                    payAmountEth:  data.data.pay_amount,
                    payCurrency:   data.data.pay_currency,
                    chainId:       data.data.chain_id,
                    chainIdHex:    data.data.chain_id_hex,
                    paymentId:     data.data.payment_id,
                    connectedAddress,
                    wcProvider:    window._cfpWcProvider || null,
                    onTxHash: (txHash) => {
                        msg(`⏳ Transaction broadcast! Waiting for Etherscan confirmation… (${txHash.slice(0,10)}…)`, 'info');
                        startEtherscanPolling(txHash);
                    },
                    onError: (errMsg) => {
                        msg('❌ ' + errMsg, 'error');
                        // Fall back to manual send
                        startPolling();
                    },
                });
            } else {
                // Manual copy-paste mode — auto-poll every 20 s
                startPolling();
            }
        });

        /* ── Poll NOWPayments status ── */
        el('poll-btn').addEventListener('click', pollStatus);

        let pollTimer = null;
        function startPolling() {
            stopPolling();
            pollTimer = setInterval(pollStatus, 20000);
        }
        function stopPolling() {
            if (pollTimer) { clearInterval(pollTimer); pollTimer = null; }
        }

        async function pollStatus() {
            if (!currentPaymentId) return;
            const fd = new FormData();
            fd.append('action',     'cfp_web3_check_deposit');
            fd.append('nonce',      nonce);
            fd.append('payment_id', currentPaymentId);

            const res  = await fetch(ajaxUrl, { method: 'POST', body: fd });
            const data = await res.json();

            if (!data.success) return;
            msg(data.data.msg || '🔄 Checking…', 'info');

            if (data.data.status === 'credited') {
                stopPolling();
                msg('🎉 ' + data.data.msg, 'success');
                setTimeout(() => cfpWeb3DepositReset(wid), 5000);
            }
        }

        /* ── Etherscan confirmation polling (direct RPC mode) ── */
        let etherscanPollTimer = null;
        function startEtherscanPolling(txHash) {
            stopPolling(); // stop NP polling
            if (etherscanPollTimer) clearInterval(etherscanPollTimer);
            let attempts = 0;
            etherscanPollTimer = setInterval(async () => {
                attempts++;
                const fd = new FormData();
                fd.append('action',     'cfp_web3_verify_tx');
                fd.append('nonce',      nonce);
                fd.append('tx_hash',    txHash);
                fd.append('payment_id', currentPaymentId);

                const res  = await fetch(ajaxUrl, { method: 'POST', body: fd });
                const data = await res.json();

                if (data.success && data.data.status === 'credited') {
                    clearInterval(etherscanPollTimer);
                    msg('🎉 ' + data.data.msg, 'success');
                    setTimeout(() => cfpWeb3DepositReset(wid), 5000);
                    return;
                }

                if (data.success && data.data.status === 'confirming') {
                    msg(`⏳ Confirming on-chain… (${data.data.confirmations} confirmations)`, 'info');
                }

                if (attempts > 60) { // ~10 min timeout — fall back to NP polling
                    clearInterval(etherscanPollTimer);
                    msg('⏳ Falling back to payment gateway polling…', 'info');
                    startPolling();
                }
            }, 10000); // poll every 10 s
        }
    })();

    /* Shared helpers (defined once globally) */
    function cfpWeb3CopyAddr(wid) {
        const addr = document.getElementById(wid + '-pay-addr').textContent;
        navigator.clipboard.writeText(addr).then(() => alert('Address copied!'));
    }
    function cfpWeb3DepositReset(wid) {
        ['step-connect','step-deposit','step-payment','status'].forEach(s => {
            const el = document.getElementById(wid + '-' + s);
            if (el) el.style.display = s === 'step-connect' ? '' : 'none';
        });
        const status = document.getElementById(wid + '-status');
        if (status) status.innerHTML = '';
    }
    </script>
    <?php
    return ob_get_clean();
}

/* ============================================================
   SHARED: WITHDRAW WIDGET RENDERER
   Used by both MetaMask and WalletConnect withdraw shortcodes.
   ============================================================ */
function cfp_render_web3_withdraw_widget( string $wallet_type ): string {
    $GLOBALS['cfp_web3_shortcode_active'] = true;

    if ( ! cfp_web3_enabled() ) {
        return '<div class="cfp-widget"><div style="font-size:.82rem;color:#1a3a7a;padding:14px">Contact the site admin to enable Web3 wallet withdrawals.</div></div>';
    }

    $wallet_label = $wallet_type === 'walletconnect' ? 'WalletConnect' : 'MetaMask';
    $icon         = $wallet_type === 'walletconnect' ? '📡' : '🦊';
    $currency     = strtoupper( cfp_web3_currency() );
    $min_sat      = cfp_web3_min_withdraw_sat();
    $fee_sat      = cfp_web3_fee_sat();
    $nonce        = wp_create_nonce( 'cfp_nonce' );
    $wc_proj_id   = cfp_get_setting( 'web3_walletconnect_project_id', '' );
    $widget_id    = 'cfp-web3-withdraw-' . $wallet_type;

    ob_start(); ?>
    <div class="cfp-widget" id="<?= esc_attr( $widget_id ) ?>">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:16px">
            <div style="font-size:2rem;line-height:1"><?= $icon ?></div>
            <div>
                <div style="font-weight:700;font-size:1rem"><?= esc_html( $wallet_label ) ?> Withdraw</div>
                <div style="font-size:.76rem;color:#3a6a3a">
                    Sent on-chain to your <?= esc_html( $wallet_label ) ?> address via NOWPayments ·
                    Min: <?= number_format( $min_sat ) ?> sat
                    <?= $fee_sat > 0 ? ' · Fee: ' . number_format( $fee_sat ) . ' sat' : ' · No fee' ?>
                </div>
            </div>
        </div>

        <?= cfp_web3_how_to_steps( $wallet_label, 'withdraw' ) ?>

        <div id="<?= esc_attr( $widget_id ) ?>-status" style="margin-bottom:10px"></div>

        <!-- Step 1: Connect -->
        <div id="<?= esc_attr( $widget_id ) ?>-step-connect">
            <div style="font-size:.82rem;color:#555;margin-bottom:10px">
                Connect your wallet — your wallet address will be used as the withdrawal destination.
            </div>
            <button class="cfp-btn cfp-btn-full"
                    id="<?= esc_attr( $widget_id ) ?>-connect-btn"
                    style="background:<?= $wallet_type === 'walletconnect' ? '#3b99fc' : '#f6851b' ?>;color:#fff;font-weight:700;margin-bottom:8px">
                <?= $icon ?> Connect <?= esc_html( $wallet_label ) ?>
            </button>
        </div>

        <!-- Step 2: Withdraw form (shown after connect) -->
        <div id="<?= esc_attr( $widget_id ) ?>-step-withdraw" style="display:none">
            <div style="background:#f0fff0;border-radius:8px;padding:10px 14px;margin-bottom:12px;font-size:.82rem">
                <span style="color:#555">Sending to: </span>
                <strong id="<?= esc_attr( $widget_id ) ?>-addr" style="color:#1a7a3a;word-break:break-all"></strong>
            </div>

            <label style="font-size:.82rem;font-weight:600;display:block;margin-bottom:4px">Amount (sat)</label>
            <input class="cfp-input" type="number" id="<?= esc_attr( $widget_id ) ?>-amount"
                   placeholder="Min <?= number_format( $min_sat ) ?> sat"
                   min="<?= esc_attr( $min_sat ) ?>" step="1"
                   style="margin-bottom:6px">
            <div style="font-size:.76rem;color:#888;margin-bottom:12px">
                Fee: <?= number_format( $fee_sat ) ?> sat · Total deducted: <span id="<?= esc_attr( $widget_id ) ?>-total">—</span> sat
            </div>

            <div style="background:#fff8e1;border:1px solid #f5c518;border-radius:6px;padding:8px 12px;font-size:.76rem;color:#7a5c00;margin-bottom:12px">
                ⛓️ Payout is sent on-chain via NOWPayments · Withdrawal fee goes to the platform admin wallet · Ensure your wallet address is correct — transactions cannot be reversed.
            </div>

            <button class="cfp-btn cfp-btn-full" id="<?= esc_attr( $widget_id ) ?>-withdraw-btn"
                    style="background:#22c55e;color:#fff;font-weight:700;margin-bottom:8px">
                ⬆️ Withdraw via <?= esc_html( $wallet_label ) ?>
            </button>
            <button class="cfp-btn" id="<?= esc_attr( $widget_id ) ?>-disconnect-btn"
                    style="background:#eee;color:#555;font-size:.78rem">
                Disconnect
            </button>
        </div>
    </div>

    <script>
    (function() {
        const wid      = <?= json_encode( $widget_id ) ?>;
        const wtype    = <?= json_encode( $wallet_type ) ?>;
        const nonce    = <?= json_encode( $nonce ) ?>;
        const ajaxUrl  = <?= json_encode( admin_url( 'admin-ajax.php' ) ) ?>;
        const wcProjId = <?= json_encode( $wc_proj_id ) ?>;
        const feeSat   = <?= (int) $fee_sat ?>;
        const minSat   = <?= (int) $min_sat ?>;
        const currency = <?= json_encode( strtolower( $currency ) ) ?>;

        let connectedAddress = '';

        const el = id => document.getElementById(wid + '-' + id);
        const msg = (text, type = 'info') => {
            el('status').innerHTML = `<div class="cfp-msg ${type}">${text}</div>`;
        };

        /* ── Live fee calc ── */
        el('amount').addEventListener('input', () => {
            const amt = parseInt(el('amount').value) || 0;
            el('total').textContent = amt > 0 ? (amt + feeSat).toLocaleString() : '—';
        });

        /* ── Connect ── */
        el('connect-btn').addEventListener('click', async () => {
            if (wtype === 'metamask') {
                await cfpWeb3ConnectMetaMask(wid, addr => {
                    connectedAddress = addr;
                    showWithdrawForm();
                });
            } else {
                await cfpWeb3ConnectWalletConnect(wid, wcProjId, addr => {
                    connectedAddress = addr;
                    showWithdrawForm();
                });
            }
        });

        function showWithdrawForm() {
            el('step-connect').style.display  = 'none';
            el('step-withdraw').style.display = '';
            el('addr').textContent = connectedAddress;
            msg('✅ Wallet connected. Enter the amount and click Withdraw.', 'success');
        }

        /* ── Disconnect ── */
        el('disconnect-btn').addEventListener('click', () => {
            connectedAddress = '';
            el('step-withdraw').style.display = 'none';
            el('step-connect').style.display  = '';
            msg('Wallet disconnected.', 'info');
        });

        /* ── Withdraw ── */
        el('withdraw-btn').addEventListener('click', async () => {
            const amount = parseInt(el('amount').value) || 0;
            if (!connectedAddress) { msg('❌ Connect your wallet first.', 'error'); return; }
            if (amount < minSat)   { msg(`❌ Minimum withdrawal is ${minSat.toLocaleString()} sat.`, 'error'); return; }

            el('withdraw-btn').disabled    = true;
            el('withdraw-btn').textContent = '⏳ Processing…';
            msg('⏳ Submitting withdrawal to NOWPayments…', 'info');

            const fd = new FormData();
            fd.append('action',      'cfp_web3_withdraw');
            fd.append('nonce',       nonce);
            fd.append('wallet_type', wtype);
            fd.append('eth_address', connectedAddress);
            fd.append('amount',      amount);
            fd.append('currency',    currency);

            try {
                const res  = await fetch(ajaxUrl, { method: 'POST', body: fd });
                const data = await res.json();

                if (data.success) {
                    msg('🎉 ' + data.data.msg, 'success');
                    el('amount').value = '';
                    el('total').textContent = '—';
                } else {
                    msg('❌ ' + (data.data?.msg || 'Withdrawal failed. Please try again.'), 'error');
                }
            } catch(e) {
                msg('❌ Network error. Please try again.', 'error');
            } finally {
                el('withdraw-btn').disabled    = false;
                el('withdraw-btn').textContent = `⬆️ Withdraw via <?= esc_js( $wallet_label ) ?>`;
            }
        });
    })();
    </script>
    <?php
    return ob_get_clean();
}

/* ============================================================
   SHORTCODES
   ============================================================ */
add_shortcode( 'cfp_metamask_deposit',       fn() => cfp_render_web3_deposit_widget( 'metamask' ) );
add_shortcode( 'cfp_metamask_withdraw',      fn() => cfp_render_web3_withdraw_widget( 'metamask' ) );
add_shortcode( 'cfp_walletconnect_deposit',  fn() => cfp_render_web3_deposit_widget( 'walletconnect' ) );
add_shortcode( 'cfp_walletconnect_withdraw', fn() => cfp_render_web3_withdraw_widget( 'walletconnect' ) );

/* ============================================================
   SHARED WEB3 JS LIBRARY (MetaMask + WalletConnect connectors)
   Output once per page via wp_footer when a Web3 shortcode is active.
   ============================================================ */
add_action( 'wp_footer', 'cfp_output_web3_connector_js', 5 );
function cfp_output_web3_connector_js(): void {
    if ( ! isset( $GLOBALS['cfp_web3_shortcode_active'] ) ) return;
    $wc_proj_id = cfp_get_setting( 'web3_walletconnect_project_id', '' );
    ?>
    <script>
    /* ── CFP Web3 Connector Library ── */

    /**
     * Connect MetaMask (or any window.ethereum injected wallet).
     * @param {string}   wid      Widget element ID prefix
     * @param {Function} onAddr   Callback(address: string)
     */
    async function cfpWeb3ConnectMetaMask(wid, onAddr) {
        const statusEl = document.getElementById(wid + '-status');
        const setMsg = (t, type='info') => { if(statusEl) statusEl.innerHTML = `<div class="cfp-msg ${type}">${t}</div>`; };

        if (!window.ethereum) {
            setMsg('❌ MetaMask not detected. Please <a href="https://metamask.io" target="_blank" rel="noopener">install MetaMask</a> and reload.', 'error');
            return;
        }
        try {
            setMsg('🔗 Requesting MetaMask accounts…', 'info');
            const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
            if (!accounts || !accounts[0]) { setMsg('❌ No accounts returned.', 'error'); return; }
            const addr = accounts[0];
            setMsg('✅ MetaMask connected.', 'success');
            onAddr(addr);

            // Watch for account changes
            window.ethereum.on('accountsChanged', newAccounts => {
                if (newAccounts.length === 0) {
                    setMsg('MetaMask disconnected.', 'info');
                } else {
                    onAddr(newAccounts[0]);
                }
            });
        } catch(err) {
            if (err.code === 4001) {
                setMsg('❌ MetaMask connection rejected by user.', 'error');
            } else {
                setMsg('❌ MetaMask error: ' + (err.message || err), 'error');
            }
        }
    }

    /**
     * Connect via WalletConnect v2 (EthereumProvider).
     * Requires a valid WalletConnect Project ID configured in admin.
     * @param {string}   wid       Widget element ID prefix
     * @param {string}   projectId WalletConnect Cloud project ID
     * @param {Function} onAddr    Callback(address: string)
     */
    async function cfpWeb3ConnectWalletConnect(wid, projectId, onAddr) {
        const statusEl = document.getElementById(wid + '-status');
        const setMsg = (t, type='info') => { if(statusEl) statusEl.innerHTML = `<div class="cfp-msg ${type}">${t}</div>`; };

        if (!projectId) {
            setMsg('❌ WalletConnect Project ID not configured. Ask the site admin to add one in plugin settings.', 'error');
            return;
        }

        // Lazy-load WalletConnect EthereumProvider
        if (!window.EthereumProvider) {
            setMsg('⏳ Loading WalletConnect library…', 'info');
            await new Promise((resolve, reject) => {
                const s = document.createElement('script');
                s.src = 'https://cdn.jsdelivr.net/npm/@walletconnect/ethereum-provider@2/dist/index.umd.js';
                s.onload  = resolve;
                s.onerror = () => reject(new Error('WalletConnect library failed to load.'));
                document.head.appendChild(s);
            }).catch(e => { setMsg('❌ ' + e.message, 'error'); return null; });
            if (!window.EthereumProvider) return;
        }

        try {
            setMsg('📡 Opening WalletConnect — scan QR with your mobile wallet…', 'info');

            const provider = await window.EthereumProvider.init({
                projectId,
                chains:   [1],            // ETH mainnet; add more as needed
                showQrModal: true,
                qrModalOptions: { themeMode: 'light' },
            });

            await provider.connect();

            const accounts = provider.accounts;
            if (!accounts || !accounts[0]) { setMsg('❌ No accounts returned by WalletConnect.', 'error'); return; }

            const addr = accounts[0];
            // Store provider globally so direct deposit flow can reuse it
            window._cfpWcProvider = provider;

            setMsg('✅ WalletConnect connected.', 'success');
            onAddr(addr);

            provider.on('accountsChanged', newAccounts => {
                if (newAccounts.length === 0) {
                    setMsg('WalletConnect session ended.', 'info');
                } else {
                    onAddr(newAccounts[0]);
                }
            });
            provider.on('disconnect', () => setMsg('WalletConnect session disconnected.', 'info'));

        } catch(err) {
            setMsg('❌ WalletConnect error: ' + (err.message || err), 'error');
        }
    }

    /**
     * Direct RPC deposit: switches MetaMask/WalletConnect to the correct
     * Infura-configured chain, then sends eth_sendTransaction to the
     * NOWPayments hot-wallet pay_address.  On success, calls onTxHash(hash)
     * so the caller can poll Etherscan for confirmation.
     *
     * @param {Object} opts
     *   wid             {string}   Widget ID prefix (for status messages)
     *   wtype           {string}   'metamask' | 'walletconnect'
     *   payAddress      {string}   NOWPayments deposit address (0x…)
     *   payAmountEth    {number}   Amount in currency units (ETH/MATIC/…)
     *   payCurrency     {string}   'eth' | 'matic' | etc.
     *   chainId         {number}   Expected chain ID (from Infura config)
     *   chainIdHex      {string}   '0x1' etc.
     *   paymentId       {string}   NP payment_id (passed to onTxHash for later verify)
     *   connectedAddress {string}  Sender address
     *   wcProvider      {object}   WalletConnect EthereumProvider instance (or null)
     *   onTxHash        {Function} Called with tx hash once broadcast
     *   onError         {Function} Called with error message string
     */
    async function cfpWeb3SendDirectDeposit(opts) {
        const { wid, wtype, payAddress, payAmountEth, payCurrency,
                chainId, chainIdHex, connectedAddress,
                wcProvider, onTxHash, onError } = opts;

        const statusEl = document.getElementById(wid + '-status');
        const setMsg = (t, type='info') => { if(statusEl) statusEl.innerHTML = `<div class="cfp-msg ${type}">${t}</div>`; };

        // Only ETH/MATIC native coin transfers are supported via direct send.
        // ERC-20 tokens (USDT, USDC) require contract calls — fall back to manual.
        const directSupportedCurrencies = ['eth', 'matic', 'bnb'];
        if (!directSupportedCurrencies.includes(payCurrency.toLowerCase())) {
            setMsg(`ℹ️ Direct send not supported for ${payCurrency.toUpperCase()} — please send manually from your wallet.`, 'info');
            onError && onError(`Direct send not available for ${payCurrency.toUpperCase()}. Use manual send.`);
            return;
        }

        const provider = wtype === 'walletconnect' && wcProvider ? wcProvider : window.ethereum;
        if (!provider) {
            onError('Wallet provider not found.');
            return;
        }

        try {
            // 1. Switch to the correct chain (Infura-configured network)
            setMsg('🔄 Switching to the correct network…', 'info');
            try {
                await provider.request({
                    method: 'wallet_switchEthereumChain',
                    params: [{ chainId: chainIdHex }],
                });
            } catch (switchErr) {
                // Chain not added to wallet — attempt to add it
                if (switchErr.code === 4902) {
                    setMsg('⚙️ Adding network to wallet…', 'info');
                    // Fetch chain info from server
                    const chainFd = new FormData();
                    chainFd.append('action', 'cfp_web3_chain_info');
                    chainFd.append('nonce', opts.nonce);
                    const chainRes  = await fetch(opts.ajaxUrl, { method: 'POST', body: chainFd });
                    const chainData = await chainRes.json();
                    if (chainData.success && chainData.data.rpc_url) {
                        await provider.request({
                            method: 'wallet_addEthereumChain',
                            params: [{
                                chainId:  chainIdHex,
                                chainName: chainData.data.network_name,
                                rpcUrls:  [ chainData.data.rpc_url ],
                                nativeCurrency: { name: 'ETH', symbol: 'ETH', decimals: 18 },
                            }],
                        });
                    }
                } else if (switchErr.code === 4001) {
                    onError('Network switch rejected by user. Please switch manually and retry.');
                    return;
                }
                // Other switch errors are non-fatal — proceed and let the wallet handle it
            }

            // 2. Convert ETH float to hex wei
            const weiPerEth  = BigInt('1000000000000000000'); // 1e18
            const amountWei  = BigInt(Math.round(payAmountEth * 1e18));
            const valueHex   = '0x' + amountWei.toString(16);

            setMsg('💸 Please confirm the transaction in your wallet…', 'info');

            // 3. Send transaction
            const txHash = await provider.request({
                method: 'eth_sendTransaction',
                params: [{
                    from:  connectedAddress,
                    to:    payAddress,
                    value: valueHex,
                    // gas is intentionally omitted — let the wallet estimate
                }],
            });

            if (!txHash) {
                onError('No transaction hash returned from wallet.');
                return;
            }

            setMsg(`✅ Transaction sent! Hash: ${txHash.slice(0,14)}… Waiting for on-chain confirmation.`, 'success');
            onTxHash(txHash);

        } catch (err) {
            if (err.code === 4001 || err.code === 'ACTION_REJECTED') {
                onError('Transaction rejected by user.');
            } else {
                onError('Wallet error: ' + (err.message || String(err)));
            }
        }
    }
    </script>
    <?php
}
