<?php
/**
 * Auto-play Hi-Lo — server-side batch processing with stop conditions.
 * Player sets: rounds, bet per round, choice (hi/lo), stop on win/loss thresholds.
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action('wp_ajax_cfp_autoplay',        'cfp_ajax_autoplay');
add_action('wp_ajax_nopriv_cfp_autoplay', 'cfp_ajax_autoplay');

function cfp_ajax_autoplay() {
    check_ajax_referer('cfp_nonce','nonce');
    if ( ! cfp_get_setting('multiply_enabled','1') )
        wp_send_json_error(['msg'=>'Hi-Lo game is currently disabled.']);

    $bet        = intval( $_POST['bet'] ?? 0 );
    $choice     = sanitize_text_field( $_POST['choice'] ?? 'hi' );
    $rounds     = min(100, max(1, intval( $_POST['rounds'] ?? 10 )));
    $stop_win   = intval( $_POST['stop_win'] ?? 0 );   // stop if profit >= this (0 = disabled)
    $stop_loss  = intval( $_POST['stop_loss'] ?? 0 );  // stop if loss >= this (0 = disabled)
    $on_win     = sanitize_text_field( $_POST['on_win'] ?? 'continue' );    // continue | reset | increase
    $on_loss    = sanitize_text_field( $_POST['on_loss'] ?? 'continue' );   // continue | reset | increase
    $increase   = max(1.0, floatval( $_POST['increase_mult'] ?? 2.0 ));

    if ( $bet <= 0 ) wp_send_json_error(['msg'=>'Enter a valid bet amount.']);
    if ( ! in_array($choice, ['hi','lo']) ) wp_send_json_error(['msg'=>'Choose Hi or Lo.']);

    global $wpdb;
    $user = cfp_require_auth();
    if ( $user->is_banned ) wp_send_json_error(['msg'=>'Account suspended.']);

    $edge      = floatval(cfp_get_setting('multiply_house_edge', 1));
    $mult      = floatval(cfp_get_setting('multiply_win_mult', 2));
    $results   = [];
    $profit    = 0;
    $cur_bet   = $bet;
    $stopped   = '';

    for ( $i = 0; $i < $rounds; $i++ ) {
        // Re-fetch balance each round to stay accurate
        $bal = (int)$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d", $user->id));
        if ( $bal < $cur_bet ) { $stopped = 'Insufficient balance'; break; }

        // Use provably fair if available, else rand()
        if ( function_exists('cfp_pf_roll') ) {
            $pf   = cfp_pf_roll($user->id, 100);
            $roll = $pf['roll'];
        } else {
            $roll = random_int(1,100);
        }

        $won    = ($choice === 'hi') ? ($roll > 50) : ($roll <= 50);
        $payout = $won ? (int)floor($cur_bet * (1 - $edge/100) * $mult) : 0;
        $net    = $payout - $cur_bet;

        // Update balance
        $wpdb->query($wpdb->prepare(
            "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",
            $net, $user->id
        ));

        // Log transaction
        $wpdb->insert(CFP_TABLE_TRANSACTIONS, [
            'user_id'     => $user->id,
            'type'        => $won ? 'multiply_win' : 'multiply_loss',
            'amount_sat'  => $net,
            'description' => "Auto Hi-Lo " . ($won?'WIN':'LOSS') . ": rolled {$roll}, bet {$cur_bet}",
        ]);

        // Log to multiply table
        $wpdb->insert(CFP_TABLE_MULTIPLY, [
            'user_id'    => $user->id,
            'bet_sat'    => $cur_bet,
            'choice'     => $choice,
            'roll'       => $roll,
            'won'        => $won ? 1 : 0,
            'payout_sat' => $payout,
        ]);

        // Admin wallet
        $ggr = $cur_bet - $payout;
        if ($ggr > 0) cfp_wallet_credit_game('admin_wallet_stream_hilo','house_edge_hilo', $ggr, "Auto Hi-Lo GGR: rolled {$roll}, bet {$cur_bet}");

        $profit += $net;
        $results[] = ['roll'=>$roll,'won'=>$won,'bet'=>$cur_bet,'payout'=>$payout,'net'=>$net,'profit'=>$profit];

        // Stop conditions
        if ( $stop_win > 0 && $profit >= $stop_win ) { $stopped = "Stop on win: profit reached ".number_format($stop_win)." sat"; break; }
        if ( $stop_loss > 0 && $profit <= -$stop_loss ) { $stopped = "Stop on loss: loss reached ".number_format($stop_loss)." sat"; break; }

        // Bet adjustment for next round
        if ( $won ) {
            $cur_bet = ($on_win === 'increase') ? (int)round($cur_bet * $increase) : $bet;
        } else {
            $cur_bet = ($on_loss === 'increase') ? (int)round($cur_bet * $increase) : $bet;
        }
        $cur_bet = max(1, $cur_bet);
    }

    $new_bal = (int)$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d", $user->id));
    wp_send_json_success([
        'results'     => $results,
        'total_rounds'=> count($results),
        'profit'      => $profit,
        'new_balance' => $new_bal,
        'stopped'     => $stopped,
        'msg'         => ($profit >= 0 ? "✅ Auto-play done. Profit: +" : "💥 Auto-play done. Loss: ") . number_format(abs($profit)) . " sat. " . ($stopped ?: ''),
    ]);
}

/* ============================================================
   SHORTCODE: [cfp_autoplay]
   ============================================================ */
add_shortcode('cfp_autoplay', function() {
    if ( ! cfp_get_setting('multiply_enabled','1') ) return '';
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    $min   = intval(cfp_get_setting('min_claim_sat',98));
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-ap-widget">
        <h2>🤖 Auto Hi-Lo</h2>
        <p class="sub">Set your rules and let it run up to 100 rounds automatically.</p>
        <div id="cfp-ap-msg"></div>
        <input class="cfp-input" type="email" id="cfp-ap-email" placeholder="Account email">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Bet per round (sat)</label>
                <input class="cfp-input" type="number" id="cfp-ap-bet" value="<?=$min?>" min="<?=$min?>">
            </div>
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Rounds (max 100)</label>
                <input class="cfp-input" type="number" id="cfp-ap-rounds" value="10" min="1" max="100">
            </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Choice</label>
                <select class="cfp-input" id="cfp-ap-choice" style="margin-bottom:0;background:#0d0d0d">
                    <option value="hi">HI (roll &gt; 50)</option>
                    <option value="lo">LO (roll ≤ 50)</option>
                </select>
            </div>
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Increase bet (×) on win/loss</label>
                <input class="cfp-input" type="number" id="cfp-ap-inc" value="2" min="1" max="10" step="0.1">
            </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">On Win</label>
                <select class="cfp-input" id="cfp-ap-onwin" style="margin-bottom:0;background:#0d0d0d">
                    <option value="continue">Continue same bet</option>
                    <option value="reset">Reset to base bet</option>
                    <option value="increase">Increase bet ×</option>
                </select>
            </div>
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">On Loss</label>
                <select class="cfp-input" id="cfp-ap-onloss" style="margin-bottom:0;background:#0d0d0d">
                    <option value="continue">Continue same bet</option>
                    <option value="reset">Reset to base bet</option>
                    <option value="increase">Increase bet × (Martingale)</option>
                </select>
            </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Stop on profit ≥ (sat, 0=off)</label>
                <input class="cfp-input" type="number" id="cfp-ap-stopwin" value="0" min="0">
            </div>
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Stop on loss ≥ (sat, 0=off)</label>
                <input class="cfp-input" type="number" id="cfp-ap-stoploss" value="0" min="0">
            </div>
        </div>
        <button class="cfp-claim-btn" id="cfp-ap-btn" onclick="cfpStartAutoplay()" style="margin-top:14px">🤖 Start Auto-Play</button>
        <div id="cfp-ap-progress" style="display:none;margin-top:14px">
            <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:10px;padding:14px">
                <div style="display:flex;justify-content:space-between;margin-bottom:10px;font-size:.85rem">
                    <span>Rounds: <strong id="cfp-ap-rounds-done">0</strong></span>
                    <span>Profit: <strong id="cfp-ap-profit" style="color:#22c55e">0</strong> sat</span>
                    <span>Balance: <strong id="cfp-ap-bal">—</strong> sat</span>
                </div>
                <div id="cfp-ap-log" style="max-height:180px;overflow-y:auto;font-size:.75rem;font-family:monospace;color:#555"></div>
            </div>
        </div>
    </div>
    <script>
    async function cfpStartAutoplay(){
        const btn=document.getElementById('cfp-ap-btn');
        btn.disabled=true; btn.textContent='Running…';
        document.getElementById('cfp-ap-progress').style.display='';
        document.getElementById('cfp-ap-log').innerHTML='';
        const fd=new FormData();
        fd.append('action','cfp_autoplay');
        fd.append('nonce','<?=esc_js($nonce)?>');
        fd.append('email',document.getElementById('cfp-ap-email').value);
        fd.append('bet',document.getElementById('cfp-ap-bet').value);
        fd.append('choice',document.getElementById('cfp-ap-choice').value);
        fd.append('rounds',document.getElementById('cfp-ap-rounds').value);
        fd.append('stop_win',document.getElementById('cfp-ap-stopwin').value);
        fd.append('stop_loss',document.getElementById('cfp-ap-stoploss').value);
        fd.append('on_win',document.getElementById('cfp-ap-onwin').value);
        fd.append('on_loss',document.getElementById('cfp-ap-onloss').value);
        fd.append('increase_mult',document.getElementById('cfp-ap-inc').value);
        const r=await fetch('<?=esc_js($ajax)?>',{method:'POST',body:fd});
        const d=await r.json();
        btn.disabled=false; btn.textContent='🤖 Start Auto-Play';
        if(!d.success){ document.getElementById('cfp-ap-msg').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`; return; }
        const res=d.data.results;
        res.forEach((row,i)=>{
            const log=document.getElementById('cfp-ap-log');
            log.innerHTML+=`<div style="color:${row.won?'#22c55e':'#ef4444'}">#${i+1} Roll:${row.roll} Bet:${row.bet} ${row.won?'WIN +'+row.payout:'LOSS'} | Profit:${row.profit>0?'+':''}${row.profit}</div>`;
            log.scrollTop=log.scrollHeight;
        });
        document.getElementById('cfp-ap-rounds-done').textContent=d.data.total_rounds;
        const p=d.data.profit;
        const pEl=document.getElementById('cfp-ap-profit');
        pEl.textContent=(p>=0?'+':'')+p.toLocaleString();
        pEl.style.color=p>=0?'#22c55e':'#ef4444';
        document.getElementById('cfp-ap-bal').textContent=d.data.new_balance.toLocaleString();
        document.getElementById('cfp-ap-msg').innerHTML=`<div class="cfp-msg ${p>=0?'success':'error'}">${d.data.msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   AUTO-PLAY: GENERIC ENGINE FOR ALL CASINO GAMES
   Supports: slots, coinflip, dice, crash, wheel
   ============================================================ */
add_action('wp_ajax_cfp_autoplay_game',        'cfp_ajax_autoplay_game');
add_action('wp_ajax_nopriv_cfp_autoplay_game', 'cfp_ajax_autoplay_game');

function cfp_ajax_autoplay_game() {
    check_ajax_referer('cfp_nonce','nonce');

    $game      = sanitize_key($_POST['game'] ?? '');           // slots|coinflip|dice|crash|wheel
    $bet       = intval($_POST['bet'] ?? 0);
    $rounds    = min(100, max(1, intval($_POST['rounds'] ?? 10)));
    $stop_win  = intval($_POST['stop_win'] ?? 0);
    $stop_loss = intval($_POST['stop_loss'] ?? 0);
    $on_win    = sanitize_text_field($_POST['on_win'] ?? 'continue');
    $on_loss   = sanitize_text_field($_POST['on_loss'] ?? 'continue');
    $increase  = max(1.0, floatval($_POST['increase_mult'] ?? 2.0));
    // Game-specific params
    $choice    = sanitize_text_field($_POST['choice'] ?? 'heads');  // coinflip: heads|tails
    $pred      = intval($_POST['prediction'] ?? 50);                // dice: 1-98
    $direction = sanitize_text_field($_POST['direction'] ?? 'over'); // dice: over|under
    $cashout   = max(1.1, floatval($_POST['cashout'] ?? 2.0));      // crash: cashout multiplier

    $valid_games = ['slots','coinflip','dice','crash','wheel'];
    if (!in_array($game, $valid_games)) wp_send_json_error(['msg'=>'Invalid game.']);
    if ($bet <= 0) wp_send_json_error(['msg'=>'Enter a valid bet.']);

    // Check game is enabled
    $setting_map = ['slots'=>'slots_enabled','coinflip'=>'coinflip_enabled','dice'=>'dice_enabled','crash'=>'crash_enabled','wheel'=>'wheel_enabled'];
    if (cfp_get_setting($setting_map[$game],'1') !== '1') wp_send_json_error(['msg'=>ucfirst($game).' is currently disabled.']);

    global $wpdb;
    $user = cfp_require_auth();
    if ($user->is_banned) wp_send_json_error(['msg'=>'Account suspended.']);

    $results  = [];
    $profit   = 0;
    $cur_bet  = $bet;
    $stopped  = '';

    for ($i = 0; $i < $rounds; $i++) {
        $bal = (int)$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d", $user->id));
        if ($bal < $cur_bet) { $stopped = 'Insufficient balance'; break; }

        [$won, $payout, $label] = cfp_autoplay_single_round($game, $user->id, $cur_bet, $choice, $pred, $direction, $cashout);
        $net = $payout - $cur_bet;

        $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d", $net, $user->id));
        $wpdb->insert(CFP_TABLE_TRANSACTIONS, [
            'user_id'     => $user->id,
            'type'        => $won ? "{$game}_win" : "{$game}_loss",
            'amount_sat'  => $net,
            'description' => "Auto ".ucfirst($game)." ".($won?'WIN':'LOSS').": {$label}, bet {$cur_bet}",
        ]);

        // Admin wallet GGR
        $ggr = $cur_bet - $payout;
        $stream_map = ['slots'=>'admin_wallet_stream_slots','coinflip'=>'admin_wallet_stream_coinflip',
                       'dice'=>'admin_wallet_stream_dice','crash'=>'admin_wallet_stream_crash','wheel'=>'admin_wallet_stream_wheel'];
        $wallet_map = ['slots'=>'house_edge_slots','coinflip'=>'house_edge_coinflip',
                       'dice'=>'house_edge_dice','crash'=>'house_edge_crash','wheel'=>'house_edge_wheel'];
        if ($ggr > 0) cfp_wallet_credit_game($stream_map[$game], $wallet_map[$game], $ggr, "Auto ".ucfirst($game)." GGR: {$label}, bet {$cur_bet}");

        $profit += $net;
        $results[] = ['won'=>$won,'bet'=>$cur_bet,'payout'=>$payout,'net'=>$net,'profit'=>$profit,'label'=>$label];

        if ($stop_win > 0 && $profit >= $stop_win)  { $stopped = "Stop on profit: +".number_format($stop_win)." sat reached"; break; }
        if ($stop_loss > 0 && $profit <= -$stop_loss){ $stopped = "Stop on loss: -".number_format($stop_loss)." sat reached"; break; }

        $cur_bet = $won
            ? ($on_win  === 'increase' ? (int)round($cur_bet * $increase) : $bet)
            : ($on_loss === 'increase' ? (int)round($cur_bet * $increase) : $bet);
        $cur_bet = max(1, $cur_bet);
    }

    $new_bal = (int)$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d", $user->id));
    wp_send_json_success([
        'results'      => $results,
        'total_rounds' => count($results),
        'profit'       => $profit,
        'new_balance'  => $new_bal,
        'stopped'      => $stopped,
        'msg'          => ($profit >= 0 ? "✅ Done. Profit: +" : "💥 Done. Loss: -") . number_format(abs($profit)) . " sat." . ($stopped ? " ($stopped)" : ''),
    ]);
}

/**
 * Run one round of the given game and return [won, payout, label].
 * Mirrors the logic in ajax-games.php exactly.
 */
function cfp_autoplay_single_round($game, $user_id, $bet, $choice='heads', $pred=50, $direction='over', $cashout=2.0) {
    switch ($game) {
        case 'slots': return cfp_autoplay_slots($user_id, $bet);
        case 'coinflip': return cfp_autoplay_coinflip($user_id, $bet, $choice);
        case 'dice': return cfp_autoplay_dice($user_id, $bet, $pred, $direction);
        case 'crash': return cfp_autoplay_crash($user_id, $bet, $cashout);
        case 'wheel': return cfp_autoplay_wheel($user_id, $bet);
    }
    return [false, 0, ''];
}

function cfp_autoplay_slots($user_id, $bet) {
    global $wpdb;
    $edge    = floatval(cfp_get_setting('slots_house_edge',5));
    $symbols = ['seven','bar','bell','cherry','lemon','orange','grape'];
    $weights = [2,4,6,10,15,18,20];
    $payouts = [
        'seven'  => floatval(cfp_get_setting('slots_mult_seven',20)),
        'bar'    => floatval(cfp_get_setting('slots_mult_bar',8)),
        'bell'   => floatval(cfp_get_setting('slots_mult_bell',5)),
        'cherry' => floatval(cfp_get_setting('slots_mult_cherry',3)),
        'lemon'  => floatval(cfp_get_setting('slots_mult_lemon',2)),
        'orange' => floatval(cfp_get_setting('slots_mult_orange',1.5)),
        'grape'  => floatval(cfp_get_setting('slots_mult_grape',1.2)),
    ];
    $spin = function() use ($symbols,$weights) {
        $total=array_sum($weights); $r=random_int(1,$total); $cum=0;
        foreach($symbols as $i=>$s){$cum+=$weights[$i];if($r<=$cum)return $s;}
        return $symbols[count($symbols)-1];
    };
    $r1=$spin(); $r2=$spin(); $r3=$spin();
    $payout=0; $win_type=null;
    if($r1===$r2&&$r2===$r3){ $payout=floor($bet*$payouts[$r1]*(1-$edge/100)); $win_type='jackpot'; }
    elseif($r1===$r2||$r2===$r3||$r1===$r3){ $pm=floatval(cfp_get_setting('slots_mult_pair',1.5)); $payout=floor($bet*$pm*(1-$edge/100)); $win_type='pair'; }
    elseif($r1==='cherry'||$r2==='cherry'||$r3==='cherry'){ $cm=floatval(cfp_get_setting('slots_mult_cherry_any',0.5)); $payout=floor($bet*$cm); $win_type='cherry'; }
    $wpdb->insert(CFP_TABLE_SLOTS,['user_id'=>$user_id,'bet_sat'=>$bet,'reel1'=>$r1,'reel2'=>$r2,'reel3'=>$r3,'win_type'=>$win_type,'payout_sat'=>$payout]);
    return [$payout>0, $payout, "{$r1}|{$r2}|{$r3}"];
}

function cfp_autoplay_coinflip($user_id, $bet, $choice) {
    global $wpdb;
    $edge   = floatval(cfp_get_setting('coinflip_house_edge',2));
    $mult   = floatval(cfp_get_setting('coinflip_win_mult',2));
    $result = random_int(0,1) ? 'heads' : 'tails';
    $won    = ($choice === $result);
    $payout = $won ? floor($bet*$mult*(1-$edge/100)) : 0;
    $wpdb->insert(CFP_TABLE_COINFLIP,['user_id'=>$user_id,'bet_sat'=>$bet,'choice'=>$choice,'result'=>$result,'won'=>$won?1:0,'payout_sat'=>$payout]);
    return [$won, $payout, "{$choice} vs {$result}"];
}

function cfp_autoplay_dice($user_id, $bet, $pred, $direction) {
    global $wpdb;
    $edge     = floatval(cfp_get_setting('dice_house_edge',2));
    $result   = random_int(1,100);
    $won      = ($direction==='over') ? ($result>$pred) : ($result<$pred);
    $win_prob = ($direction==='over') ? (100-$pred) : ($pred-1);
    $win_prob = max(1,$win_prob);
    $multiplier = (100/$win_prob)*(1-$edge/100);
    $payout   = $won ? floor($bet*$multiplier) : 0;
    $wpdb->insert(CFP_TABLE_DICE,['user_id'=>$user_id,'bet_sat'=>$bet,'prediction'=>$pred,'direction'=>$direction,'result'=>$result,'won'=>$won?1:0,'payout_sat'=>$payout]);
    return [$won, $payout, "{$direction} {$pred}, rolled {$result}"];
}

function cfp_autoplay_crash($user_id, $bet, $cashout) {
    global $wpdb;
    $edge      = floatval(cfp_get_setting('crash_house_edge',5));
    $crash_max = floatval(cfp_get_setting('crash_max_mult',10));
    $r         = random_int(1,100)/100;
    $crash_at  = round(min(max(1.0,(100-$edge)/(100*$r)), $crash_max), 2);
    $won       = ($cashout <= $crash_at);
    $payout    = $won ? floor($bet*$cashout) : 0;
    $wpdb->insert(CFP_TABLE_CRASH,['user_id'=>$user_id,'bet_sat'=>$bet,'cashout_at'=>$won?$cashout:null,'crash_at'=>$crash_at,'won'=>$won?1:0,'payout_sat'=>$payout]);
    return [$won, $payout, "cashout {$cashout}x, crashed {$crash_at}x"];
}

function cfp_autoplay_wheel($user_id, $bet) {
    global $wpdb;
    $edge = floatval(cfp_get_setting('wheel_house_edge',3));
    $segs = [
        [floatval(cfp_get_setting('wheel_mult_2x',2)),   intval(cfp_get_setting('wheel_weight_2x',25)),   '2x'],
        [floatval(cfp_get_setting('wheel_mult_1_5x',1.5)),intval(cfp_get_setting('wheel_weight_1_5x',20)),'1.5x'],
        [floatval(cfp_get_setting('wheel_mult_3x',3)),   intval(cfp_get_setting('wheel_weight_3x',10)),   '3x'],
        [floatval(cfp_get_setting('wheel_mult_5x',5)),   intval(cfp_get_setting('wheel_weight_5x',5)),    '5x'],
        [floatval(cfp_get_setting('wheel_mult_10x',10)), intval(cfp_get_setting('wheel_weight_10x',2)),   '10x'],
        [floatval(cfp_get_setting('wheel_mult_half',0.5)),intval(cfp_get_setting('wheel_weight_half',8)), '0.5x'],
    ];
    $pool = []; $lose_w = intval(cfp_get_setting('wheel_lose_weight',30));
    foreach($segs as $s) for($j=0;$j<$s[1];$j++) $pool[]=$s;
    for($j=0;$j<$lose_w;$j++) $pool[]=[0,0,'LOSE'];
    $seg = $pool[random_int(0, count($pool) - 1)];
    $payout = floor($bet*$seg[0]*(1-$edge/100));
    $wpdb->insert(CFP_TABLE_WHEEL,['user_id'=>$user_id,'bet_sat'=>$bet,'segment'=>$seg[2],'multiplier'=>$seg[0],'payout_sat'=>$payout]);
    return [$payout>0, $payout, "landed {$seg[2]}"];
}

/* ============================================================
   SHORTCODE: [cfp_autoplay_casino] — Auto-play for all 5 games
   ============================================================ */
add_shortcode('cfp_autoplay_casino', function() {
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    $min   = intval(cfp_get_setting('min_claim_sat',10));
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-apc-widget">
        <h2>🤖 Casino Auto-Play</h2>
        <p class="sub">Auto-play any casino game up to 100 rounds with stop conditions.</p>
        <div id="cfp-apc-msg"></div>
        <input class="cfp-input" type="email" id="cfp-apc-email" placeholder="Account email">

        <!-- Game selector -->
        <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:6px;margin-bottom:14px">
            <?php foreach(['slots'=>'🎰','coinflip'=>'🪙','dice'=>'🎲','crash'=>'📈','wheel'=>'🎡'] as $g=>$icon): ?>
            <button onclick="cfpApcSetGame('<?=$g?>')" id="cfp-apc-btn-<?=$g?>"
                style="background:#111;border:1px solid #2a2a2a;color:#555;padding:10px 4px;border-radius:8px;cursor:pointer;font-size:.8rem;transition:all .15s"
                onmouseover="this.style.borderColor='var(--cfp-p)'" onmouseout="if(cfpApcGame!=='<?=$g?>')this.style.borderColor='#2a2a2a'">
                <div style="font-size:1.3rem"><?=$icon?></div>
                <div><?=ucfirst($g)?></div>
            </button>
            <?php endforeach; ?>
        </div>

        <!-- Game-specific options -->
        <div id="cfp-apc-opts-coinflip" style="display:none;margin-bottom:10px">
            <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Flip Choice</label>
            <select class="cfp-input" id="cfp-apc-flip" style="background:#0d0d0d;margin-bottom:0">
                <option value="heads">🟡 Heads</option>
                <option value="tails">⚪ Tails</option>
            </select>
        </div>
        <div id="cfp-apc-opts-dice" style="display:none;margin-bottom:10px">
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px">
                <div>
                    <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Target</label>
                    <input class="cfp-input" type="number" id="cfp-apc-pred" value="50" min="2" max="98">
                </div>
                <div>
                    <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Direction</label>
                    <select class="cfp-input" id="cfp-apc-dir" style="background:#0d0d0d;margin-bottom:0">
                        <option value="over">Over</option>
                        <option value="under">Under</option>
                    </select>
                </div>
            </div>
        </div>
        <div id="cfp-apc-opts-crash" style="display:none;margin-bottom:10px">
            <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Cashout At (×)</label>
            <input class="cfp-input" type="number" id="cfp-apc-cashout" value="2.00" min="1.1" max="20" step="0.1">
        </div>

        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Bet (sat)</label>
                <input class="cfp-input" type="number" id="cfp-apc-bet" value="<?=$min?>" min="<?=$min?>">
            </div>
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Rounds (max 100)</label>
                <input class="cfp-input" type="number" id="cfp-apc-rounds" value="10" min="1" max="100">
            </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-top:10px">
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">On Win</label>
                <select class="cfp-input" id="cfp-apc-onwin" style="background:#0d0d0d;margin-bottom:0">
                    <option value="continue">Same bet</option>
                    <option value="reset">Reset to base</option>
                    <option value="increase">Increase ×</option>
                </select>
            </div>
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">On Loss</label>
                <select class="cfp-input" id="cfp-apc-onloss" style="background:#0d0d0d;margin-bottom:0">
                    <option value="continue">Same bet</option>
                    <option value="reset">Reset to base</option>
                    <option value="increase">Increase × (Martingale)</option>
                </select>
            </div>
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:10px;margin-top:10px">
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Increase (×)</label>
                <input class="cfp-input" type="number" id="cfp-apc-inc" value="2" min="1" max="10" step="0.1">
            </div>
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Stop profit ≥ (0=off)</label>
                <input class="cfp-input" type="number" id="cfp-apc-stopwin" value="0" min="0">
            </div>
            <div>
                <label style="font-size:.72rem;text-transform:uppercase;color:#555;letter-spacing:1px">Stop loss ≥ (0=off)</label>
                <input class="cfp-input" type="number" id="cfp-apc-stoploss" value="0" min="0">
            </div>
        </div>
        <button class="cfp-claim-btn" id="cfp-apc-run-btn" onclick="cfpRunAutoplay()" style="margin-top:14px">🤖 Start Auto-Play</button>
        <div id="cfp-apc-progress" style="display:none;margin-top:14px;background:#0d0d0d;border:1px solid #1c1c1c;border-radius:10px;padding:14px">
            <div style="display:flex;justify-content:space-between;font-size:.83rem;margin-bottom:8px">
                <span>Rounds: <strong id="cfp-apc-rdone">0</strong></span>
                <span>Profit: <strong id="cfp-apc-prof" style="color:#22c55e">0</strong> sat</span>
                <span>Bal: <strong id="cfp-apc-bal">—</strong></span>
            </div>
            <div id="cfp-apc-log" style="max-height:160px;overflow-y:auto;font-size:.74rem;font-family:monospace;color:#555"></div>
        </div>
    </div>
    <script>
    let cfpApcGame='slots';
    function cfpApcSetGame(g){
        cfpApcGame=g;
        ['slots','coinflip','dice','crash','wheel'].forEach(x=>{
            const b=document.getElementById('cfp-apc-btn-'+x);
            if(b){b.style.borderColor=x===g?'var(--cfp-p)':'#2a2a2a';b.style.color=x===g?'#fff':'#555';}
            const o=document.getElementById('cfp-apc-opts-'+x);
            if(o) o.style.display=x===g?'':'none';
        });
    }
    cfpApcSetGame('slots');
    async function cfpRunAutoplay(){
        const btn=document.getElementById('cfp-apc-run-btn');
        btn.disabled=true; btn.textContent='Running…';
        document.getElementById('cfp-apc-progress').style.display='';
        document.getElementById('cfp-apc-log').innerHTML='';
        const fd=new FormData();
        fd.append('action','cfp_autoplay_game');
        fd.append('nonce','<?=esc_js($nonce)?>');
        fd.append('email',document.getElementById('cfp-apc-email').value);
        fd.append('game',cfpApcGame);
        fd.append('bet',document.getElementById('cfp-apc-bet').value);
        fd.append('rounds',document.getElementById('cfp-apc-rounds').value);
        fd.append('on_win',document.getElementById('cfp-apc-onwin').value);
        fd.append('on_loss',document.getElementById('cfp-apc-onloss').value);
        fd.append('increase_mult',document.getElementById('cfp-apc-inc').value);
        fd.append('stop_win',document.getElementById('cfp-apc-stopwin').value);
        fd.append('stop_loss',document.getElementById('cfp-apc-stoploss').value);
        fd.append('choice',document.getElementById('cfp-apc-flip')?.value||'heads');
        fd.append('prediction',document.getElementById('cfp-apc-pred')?.value||50);
        fd.append('direction',document.getElementById('cfp-apc-dir')?.value||'over');
        fd.append('cashout',document.getElementById('cfp-apc-cashout')?.value||2.00);
        const r=await fetch('<?=esc_js($ajax)?>',{method:'POST',body:fd});
        const d=await r.json();
        btn.disabled=false; btn.textContent='🤖 Start Auto-Play';
        if(!d.success){document.getElementById('cfp-apc-msg').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;return;}
        const res=d.data.results;
        const log=document.getElementById('cfp-apc-log');
        res.forEach((row,i)=>{
            log.innerHTML+=`<div style="color:${row.won?'#22c55e':'#ef4444'}">#${i+1} ${row.label} | Bet:${row.bet} ${row.won?'WIN +'+row.payout:'LOSS'} | P:${row.profit>0?'+':''}${row.profit}</div>`;
        });
        log.scrollTop=log.scrollHeight;
        document.getElementById('cfp-apc-rdone').textContent=d.data.total_rounds;
        const p=d.data.profit;
        const pEl=document.getElementById('cfp-apc-prof');
        pEl.textContent=(p>=0?'+':'')+p.toLocaleString();
        pEl.style.color=p>=0?'#22c55e':'#ef4444';
        document.getElementById('cfp-apc-bal').textContent=d.data.new_balance.toLocaleString();
        document.getElementById('cfp-apc-msg').innerHTML=`<div class="cfp-msg ${p>=0?'success':'error'}">${d.data.msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});
