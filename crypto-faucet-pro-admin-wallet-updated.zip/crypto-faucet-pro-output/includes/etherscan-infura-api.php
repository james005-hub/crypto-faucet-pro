<?php
/**
 * Etherscan & Infura API Helpers
 *
 * Provides:
 *   cfp_infura_get_balance()       — fetch on-chain ETH/ERC-20 balance via Infura RPC
 *   cfp_infura_send_raw_tx()       — broadcast a signed raw transaction via Infura
 *   cfp_infura_get_tx_receipt()    — fetch a transaction receipt via Infura
 *   cfp_etherscan_verify_tx()      — confirm a deposit tx on Etherscan (amount, confirmations, recipient)
 *   cfp_etherscan_get_tx_list()    — pull recent txns for an address from Etherscan
 *   cfp_etherscan_get_token_tx()   — pull ERC-20 token transfers for an address
 *   cfp_web3_rpc_url()             — returns the configured Infura RPC endpoint URL
 *   cfp_web3_chain_id()            — returns configured chain ID (default: 1 = mainnet)
 *
 * Settings keys (stored via cfp_update_setting / cfp_get_setting):
 *   web3_infura_api_key            — Infura project API key
 *   web3_infura_network            — Network slug: mainnet | sepolia | polygon-mainnet | bnb-mainnet
 *   web3_etherscan_api_key         — Etherscan (or Polygonscan / BscScan) API key
 *   web3_etherscan_base_url        — Base URL for the explorer API (auto-set from network, overridable)
 *   web3_deposit_confirmations     — Min confirmations before a deposit is credited (default: 3)
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   NETWORK CONFIG MAP
   ============================================================ */

/**
 * Returns a map of supported networks with their Infura endpoint suffix,
 * chain ID, and Etherscan-compatible explorer API URL.
 *
 * @return array<string, array{label: string, chain_id: int, infura_slug: string, explorer_api: string}>
 */
function cfp_web3_network_map(): array {
    return [
        'mainnet' => [
            'label'        => 'Ethereum Mainnet',
            'chain_id'     => 1,
            'infura_slug'  => 'mainnet',
            'explorer_api' => 'https://api.etherscan.io/api',
        ],
        'sepolia' => [
            'label'        => 'Ethereum Sepolia (Testnet)',
            'chain_id'     => 11155111,
            'infura_slug'  => 'sepolia',
            'explorer_api' => 'https://api-sepolia.etherscan.io/api',
        ],
        'polygon-mainnet' => [
            'label'        => 'Polygon Mainnet',
            'chain_id'     => 137,
            'infura_slug'  => 'polygon-mainnet',
            'explorer_api' => 'https://api.polygonscan.com/api',
        ],
        'polygon-amoy' => [
            'label'        => 'Polygon Amoy (Testnet)',
            'chain_id'     => 80002,
            'infura_slug'  => 'polygon-amoy',
            'explorer_api' => 'https://api-amoy.polygonscan.com/api',
        ],
        'bnb-mainnet' => [
            'label'        => 'BNB Smart Chain Mainnet',
            'chain_id'     => 56,
            'infura_slug'  => 'bnb-mainnet',
            'explorer_api' => 'https://api.bscscan.com/api',
        ],
    ];
}

/**
 * Returns network config for the currently-configured network slug.
 *
 * @return array|null
 */
function cfp_web3_current_network(): ?array {
    $slug = cfp_get_setting( 'web3_infura_network', 'mainnet' );
    return cfp_web3_network_map()[ $slug ] ?? cfp_web3_network_map()['mainnet'];
}

/**
 * Returns the full Infura RPC URL for the configured network.
 *
 * @return string  e.g. https://mainnet.infura.io/v3/YOUR_KEY
 */
function cfp_web3_rpc_url(): string {
    $api_key = cfp_get_setting( 'web3_infura_api_key', '' );
    $network = cfp_web3_current_network();
    $slug    = $network['infura_slug'] ?? 'mainnet';
    if ( empty( $api_key ) ) {
        return ''; // Not configured
    }
    return "https://{$slug}.infura.io/v3/{$api_key}";
}

/**
 * Returns the chain ID integer for the configured network.
 *
 * @return int
 */
function cfp_web3_chain_id(): int {
    return (int) ( cfp_web3_current_network()['chain_id'] ?? 1 );
}

/**
 * Returns the Etherscan-compatible API base URL for the configured network.
 *
 * @return string
 */
function cfp_web3_explorer_api_url(): string {
    $override = cfp_get_setting( 'web3_etherscan_base_url', '' );
    if ( ! empty( $override ) ) {
        return rtrim( $override, '/' );
    }
    $network = cfp_web3_current_network();
    return $network['explorer_api'] ?? 'https://api.etherscan.io/api';
}

/* ============================================================
   INFURA RPC HELPERS
   ============================================================ */

/**
 * Makes a raw JSON-RPC POST request to Infura.
 *
 * @param string $method   JSON-RPC method name
 * @param array  $params   JSON-RPC params array
 * @return array{result?: mixed, error?: string}
 */
function cfp_infura_rpc( string $method, array $params = [] ): array {
    $rpc_url = cfp_web3_rpc_url();
    if ( empty( $rpc_url ) ) {
        return [ 'error' => 'Infura API key not configured. Please add your Infura key in Web3 Settings.' ];
    }

    $body = wp_json_encode( [
        'jsonrpc' => '2.0',
        'method'  => $method,
        'params'  => $params,
        'id'      => 1,
    ] );

    $response = wp_remote_post( $rpc_url, [
        'headers'     => [ 'Content-Type' => 'application/json' ],
        'body'        => $body,
        'timeout'     => 15,
        'sslverify'   => true,
    ] );

    if ( is_wp_error( $response ) ) {
        return [ 'error' => 'Infura RPC request failed: ' . $response->get_error_message() ];
    }

    $data = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( json_last_error() !== JSON_ERROR_NONE ) {
        return [ 'error' => 'Infura returned invalid JSON.' ];
    }

    if ( ! empty( $data['error'] ) ) {
        $msg = is_array( $data['error'] ) ? ( $data['error']['message'] ?? 'Unknown RPC error' ) : $data['error'];
        return [ 'error' => $msg ];
    }

    return [ 'result' => $data['result'] ?? null ];
}

/**
 * Fetches the native ETH (or native coin) balance of an address via Infura.
 *
 * @param string $address  0x-prefixed EVM address
 * @return array{balance_wei?: string, balance_eth?: float, error?: string}
 */
function cfp_infura_get_balance( string $address ): array {
    $res = cfp_infura_rpc( 'eth_getBalance', [ $address, 'latest' ] );
    if ( ! empty( $res['error'] ) ) {
        return $res;
    }
    $wei = hexdec( ltrim( $res['result'], '0x' ) );
    return [
        'balance_wei' => (string) $wei,
        'balance_eth' => $wei / 1e18,
    ];
}

/**
 * Fetches a transaction receipt from Infura.
 *
 * @param string $tx_hash  0x-prefixed transaction hash
 * @return array{receipt?: array, confirmations?: int, error?: string}
 */
function cfp_infura_get_tx_receipt( string $tx_hash ): array {
    $receipt_res = cfp_infura_rpc( 'eth_getTransactionReceipt', [ $tx_hash ] );
    if ( ! empty( $receipt_res['error'] ) ) {
        return $receipt_res;
    }

    $receipt = $receipt_res['result'];
    if ( empty( $receipt ) ) {
        return [ 'error' => 'Transaction not found or not yet mined.', 'receipt' => null, 'confirmations' => 0 ];
    }

    // Calculate confirmations
    $tx_block_hex = $receipt['blockNumber'] ?? '0x0';
    $tx_block     = hexdec( ltrim( $tx_block_hex, '0x' ) );

    $latest_res = cfp_infura_rpc( 'eth_blockNumber' );
    $latest     = empty( $latest_res['error'] )
        ? hexdec( ltrim( $latest_res['result'], '0x' ) )
        : 0;

    $confirmations = $latest > 0 && $tx_block > 0 ? max( 0, $latest - $tx_block + 1 ) : 0;

    return [
        'receipt'       => $receipt,
        'confirmations' => $confirmations,
        'tx_block'      => $tx_block,
        'latest_block'  => $latest,
        'status'        => $receipt['status'] === '0x1' ? 'success' : 'failed',
    ];
}

/**
 * Broadcasts a signed raw transaction via Infura.
 *
 * @param string $raw_tx  Hex-encoded signed raw transaction (0x-prefixed)
 * @return array{tx_hash?: string, error?: string}
 */
function cfp_infura_send_raw_tx( string $raw_tx ): array {
    $res = cfp_infura_rpc( 'eth_sendRawTransaction', [ $raw_tx ] );
    if ( ! empty( $res['error'] ) ) {
        return $res;
    }
    return [ 'tx_hash' => (string) $res['result'] ];
}

/* ============================================================
   ETHERSCAN API HELPERS
   ============================================================ */

/**
 * Makes a GET request to the Etherscan-compatible API.
 *
 * @param array $params  Query params (module, action, etc.)
 * @return array{result?: mixed, error?: string}
 */
function cfp_etherscan_request( array $params ): array {
    $api_key = cfp_get_setting( 'web3_etherscan_api_key', '' );
    if ( empty( $api_key ) ) {
        return [ 'error' => 'Etherscan API key not configured. Please add your key in Web3 Settings.' ];
    }

    $base_url = cfp_web3_explorer_api_url();
    $params['apikey'] = $api_key;
    $url = add_query_arg( $params, $base_url );

    $response = wp_remote_get( $url, [
        'timeout'   => 15,
        'sslverify' => true,
    ] );

    if ( is_wp_error( $response ) ) {
        return [ 'error' => 'Etherscan request failed: ' . $response->get_error_message() ];
    }

    $data = json_decode( wp_remote_retrieve_body( $response ), true );
    if ( json_last_error() !== JSON_ERROR_NONE ) {
        return [ 'error' => 'Etherscan returned invalid JSON.' ];
    }

    if ( isset( $data['status'] ) && $data['status'] === '0' && ! empty( $data['message'] ) ) {
        // NOTX / no results is not an error; it just means 0 results
        if ( strtoupper( $data['message'] ) === 'NO TRANSACTIONS FOUND'
          || strtoupper( $data['result'] ?? '' ) === 'NO TRANSACTIONS FOUND' ) {
            return [ 'result' => [] ];
        }
        return [ 'error' => $data['result'] ?? $data['message'] ];
    }

    return [ 'result' => $data['result'] ?? null ];
}

/**
 * Verifies a deposit transaction on Etherscan.
 *
 * Checks that:
 *  1. The tx exists and is confirmed on-chain.
 *  2. The tx was sent TO the expected hot-wallet address.
 *  3. The tx has reached the required minimum confirmations.
 *  4. The tx status is successful (not reverted).
 *
 * @param string $tx_hash         0x transaction hash
 * @param string $expected_to     Address that should have received the funds
 * @param int    $min_confirms    Minimum required confirmations
 * @return array{
 *   verified: bool,
 *   confirmations: int,
 *   value_wei: string,
 *   value_eth: float,
 *   from: string,
 *   to: string,
 *   block_number: int,
 *   error?: string
 * }
 */
function cfp_etherscan_verify_tx( string $tx_hash, string $expected_to, int $min_confirms = 0 ): array {
    if ( $min_confirms === 0 ) {
        $min_confirms = intval( cfp_get_setting( 'web3_deposit_confirmations', '3' ) );
    }

    $res = cfp_etherscan_request( [
        'module' => 'proxy',
        'action' => 'eth_getTransactionByHash',
        'txhash' => $tx_hash,
    ] );

    if ( ! empty( $res['error'] ) ) {
        return array_merge( [ 'verified' => false ], $res );
    }

    $tx = $res['result'];
    if ( empty( $tx ) || empty( $tx['hash'] ) ) {
        return [ 'verified' => false, 'error' => 'Transaction not found on Etherscan.' ];
    }

    // Check recipient matches
    $actual_to = strtolower( $tx['to'] ?? '' );
    $expect_to = strtolower( $expected_to );
    if ( $actual_to !== $expect_to ) {
        return [
            'verified' => false,
            'error'    => "Transaction recipient mismatch. Expected {$expect_to}, got {$actual_to}.",
            'to'       => $actual_to,
            'from'     => strtolower( $tx['from'] ?? '' ),
        ];
    }

    // Get receipt for confirmation count & success status
    $receipt_data = cfp_infura_get_tx_receipt( $tx_hash );
    $confirmations = $receipt_data['confirmations'] ?? 0;
    $tx_status     = $receipt_data['status'] ?? 'unknown';

    if ( $tx_status === 'failed' ) {
        return [ 'verified' => false, 'error' => 'Transaction was reverted on-chain.' ];
    }

    if ( $confirmations < $min_confirms ) {
        return [
            'verified'      => false,
            'confirmations' => $confirmations,
            'error'         => "Not enough confirmations yet ({$confirmations}/{$min_confirms}).",
            'value_wei'     => $tx['value'] ?? '0x0',
            'from'          => strtolower( $tx['from'] ?? '' ),
            'to'            => $actual_to,
            'block_number'  => $receipt_data['tx_block'] ?? 0,
        ];
    }

    $value_wei_hex = ltrim( $tx['value'] ?? '0x0', '0x' );
    $value_wei     = $value_wei_hex !== '' ? hexdec( $value_wei_hex ) : 0;

    return [
        'verified'      => true,
        'confirmations' => $confirmations,
        'value_wei'     => (string) $value_wei,
        'value_eth'     => $value_wei / 1e18,
        'from'          => strtolower( $tx['from'] ?? '' ),
        'to'            => $actual_to,
        'block_number'  => $receipt_data['tx_block'] ?? 0,
    ];
}

/**
 * Fetches recent normal (ETH) transactions for an address from Etherscan.
 *
 * @param string $address    0x-prefixed address
 * @param int    $page       Page number (1-based)
 * @param int    $offset     Number of transactions per page (max 100)
 * @param string $sort       'asc' or 'desc'
 * @return array{result?: array, error?: string}
 */
function cfp_etherscan_get_tx_list( string $address, int $page = 1, int $offset = 20, string $sort = 'desc' ): array {
    return cfp_etherscan_request( [
        'module'     => 'account',
        'action'     => 'txlist',
        'address'    => $address,
        'startblock' => '0',
        'endblock'   => '99999999',
        'page'       => $page,
        'offset'     => min( $offset, 100 ),
        'sort'       => $sort,
    ] );
}

/**
 * Fetches ERC-20 token transfer events for an address from Etherscan.
 *
 * @param string      $address           0x-prefixed wallet address
 * @param string|null $contract_address  Optional: filter by specific token contract
 * @param int         $page
 * @param int         $offset
 * @return array{result?: array, error?: string}
 */
function cfp_etherscan_get_token_tx( string $address, ?string $contract_address = null, int $page = 1, int $offset = 20 ): array {
    $params = [
        'module'     => 'account',
        'action'     => 'tokentx',
        'address'    => $address,
        'startblock' => '0',
        'endblock'   => '99999999',
        'page'       => $page,
        'offset'     => min( $offset, 100 ),
        'sort'       => 'desc',
    ];
    if ( ! empty( $contract_address ) ) {
        $params['contractaddress'] = $contract_address;
    }
    return cfp_etherscan_request( $params );
}

/**
 * Checks Etherscan + Infura API connectivity.
 * Used on the admin settings page to show a live status indicator.
 *
 * @return array{infura: bool, etherscan: bool, infura_error?: string, etherscan_error?: string}
 */
function cfp_web3_test_api_connections(): array {
    $result = [
        'infura'    => false,
        'etherscan' => false,
    ];

    // Test Infura: call eth_blockNumber
    $rpc = cfp_infura_rpc( 'eth_blockNumber' );
    if ( empty( $rpc['error'] ) && ! empty( $rpc['result'] ) ) {
        $result['infura']       = true;
        $result['block_number'] = hexdec( ltrim( $rpc['result'], '0x' ) );
    } else {
        $result['infura_error'] = $rpc['error'] ?? 'Unknown error';
    }

    // Test Etherscan: get ETH supply (lightweight call)
    $es = cfp_etherscan_request( [
        'module' => 'stats',
        'action' => 'ethsupply',
    ] );
    if ( empty( $es['error'] ) ) {
        $result['etherscan'] = true;
    } else {
        $result['etherscan_error'] = $es['error'];
    }

    return $result;
}
