<?php
/**
 * AJAX handlers: casino games (slots, coinflip, dice, crash, wheel, multiply)
 * Enhanced with: streak bonuses, jackpot pool, double-or-nothing, free spins,
 * mini-games, tournament scores, daily bet caps, and expanded security checks.
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   SECURITY HELPERS
   ============================================================ */

/**
 * Validate user ownership — email must belong to a logged-in WP user (if WP login enabled)
 * or match the authenticated session token stored in usermeta.
 */
function cfp_validate_game_user( $email ) {
    $user = cfp_get_user_by_email( $email );
    if ( ! $user ) return null;

    // Block banned / suspended accounts
    if ( ! empty( $user->is_banned ) ) {
        wp_send_json_error(['msg' => '🚫 Your account has been suspended.']);
    }

    // Block unverified accounts if setting requires it
    if ( cfp_get_setting('email_verify_required','0') === '1' && empty( $user->email_verified ) ) {
        wp_send_json_error(['msg' => '📧 Please verify your email before playing.']);
    }

    return $user;
}

/**
 * Enforce daily loss limit per user (admin-configurable).
 * Returns true if allowed, sends JSON error and exits if limit exceeded.
 */
function cfp_enforce_daily_loss_limit( $user_id, $bet ) {
    $limit = intval( cfp_get_setting('daily_loss_limit_sat', 0) );
    if ( $limit <= 0 ) return; // disabled
    global $wpdb;
    $today_loss = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COALESCE(SUM(ABS(amount_sat)),0) FROM " . CFP_TABLE_TRANSACTIONS .
        " WHERE user_id=%d AND amount_sat < 0 AND type LIKE '%_loss' AND DATE(created_at)=CURDATE()",
        $user_id
    ));
    if ( $today_loss + $bet > $limit ) {
        wp_send_json_error(['msg' => "🛑 Daily loss limit of {$limit} sat reached. Resets at midnight."]);
    }
}

/**
 * Enforce minimum balance required to play (prevents playing with dust).
 */
function cfp_enforce_min_bet( $bet ) {
    $min = intval( cfp_get_setting('game_min_bet', 10) );
    if ( $bet < $min ) {
        wp_send_json_error(['msg' => "Minimum bet is {$min} sat."]);
    }
    $max = intval( cfp_get_setting('game_max_bet', 100000) );
    if ( $max > 0 && $bet > $max ) {
        wp_send_json_error(['msg' => "Maximum bet is {$max} sat."]);
    }
}

/**
 * Get a user's current win streak for a game.
 *
 * Streaks are stored in cfp_user_streaks (a dedicated table) rather than the
 * global cfp_settings table.  Putting per-user rows in cfp_settings pollutes
 * that table, makes cfp_get_setting() slower as user counts grow, and causes
 * the static/global cache to balloon.
 *
 * cfp_user_streaks is created in activation.php alongside the other tables.
 */
function cfp_get_streak( $user_id, $game ) {
    global $wpdb;
    $val = $wpdb->get_var( $wpdb->prepare(
        "SELECT streak FROM {$wpdb->prefix}cfp_user_streaks WHERE user_id=%d AND game=%s",
        $user_id, $game
    ));
    return $val !== null ? intval($val) : 0;
}

function cfp_set_streak( $user_id, $game, $value ) {
    global $wpdb;
    $wpdb->replace( "{$wpdb->prefix}cfp_user_streaks", [
        'user_id' => $user_id,
        'game'    => $game,
        'streak'  => max(0, intval($value)),
    ]);
}

/**
 * Streak bonus multiplier: +2% bonus per consecutive win, max 20%.
 */
function cfp_streak_bonus( $streak ) {
    return 1.0 + min(0.20, max(0, $streak) * 0.02);
}

/**
 * Add to the shared jackpot pool (1% of every losing bet).
 */
function cfp_jackpot_contribute( $bet_sat ) {
    $contrib = max(1, intval($bet_sat * 0.01));
    $current = intval( cfp_get_setting('jackpot_pool_sat', 0) );
    cfp_update_setting('jackpot_pool_sat', $current + $contrib);
}

function cfp_jackpot_award( $user_id ) {
    global $wpdb;
    $pool = intval( cfp_get_setting('jackpot_pool_sat', 0) );
    if ( $pool <= 0 ) return 0;
    cfp_update_setting('jackpot_pool_sat', 0);
    $wpdb->query( $wpdb->prepare(
        "UPDATE " . CFP_TABLE_USERS . " SET balance_sat=balance_sat+%d WHERE id=%d",
        $pool, $user_id
    ));
    $wpdb->insert( CFP_TABLE_TRANSACTIONS, [
        'user_id'     => $user_id,
        'type'        => 'jackpot_win',
        'amount_sat'  => $pool,
        'description' => "🎰 MEGA JACKPOT Won! Pool was {$pool} sat",
    ]);
    return $pool;
}

/**
 * Award free spins to a user (stored in settings table).
 */
function cfp_award_free_spins( $user_id, $count, $game = 'slots' ) {
    $key     = "user_{$user_id}_free_spins_{$game}";
    $current = intval( cfp_get_setting($key, 0) );
    cfp_update_setting($key, $current + $count);
}

function cfp_use_free_spin( $user_id, $game = 'slots' ) {
    $key     = "user_{$user_id}_free_spins_{$game}";
    $current = intval( cfp_get_setting($key, 0) );
    if ( $current <= 0 ) return false;
    cfp_update_setting($key, $current - 1);
    return true;
}

function cfp_get_free_spins( $user_id, $game = 'slots' ) {
    return intval( cfp_get_setting("user_{$user_id}_free_spins_{$game}", 0) );
}

/* ============================================================
   AJAX: SLOTS — Enhanced with free spins, jackpot, streak bonus, 5-reel mode
   ============================================================ */
add_action('wp_ajax_cfp_slots','cfp_ajax_slots');
function cfp_ajax_slots() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('game');
    
    // IDOR protection - require session auth
    $user = cfp_require_auth();
    
    if(!cfp_get_setting('slots_enabled','1')) wp_send_json_error(['msg'=>'Slots game is disabled.']);

    $bet   = intval($_POST['bet'] ?? 0);

    cfp_enforce_min_bet($bet);
    global $wpdb;

    // Check for free spin
    $free_spin = false;
    if ( $bet === 0 && cfp_use_free_spin($user->id, 'slots') ) {
        $free_spin = true;
        $bet = intval( cfp_get_setting('slots_free_spin_bet', 100) ); // free spin bet value
    } elseif ( $user->balance_sat < $bet ) {
        // Pre-flight check (informational only — atomic deduction below is the real guard)
        wp_send_json_error(['msg'=>'Insufficient balance.']);
    }

    cfp_enforce_daily_loss_limit($user->id, $bet);

    // Symbols with weights
    $symbols  = ['seven','bar','bell','cherry','lemon','orange','grape','wild'];
    $weights  = [2, 4, 6, 10, 15, 18, 20, 3]; // lower = rarer; wild is rare
    $labels   = ['🔴7','BAR','🔔','🍒','🍋','🍊','🍇','⭐'];
    $payouts  = [
        'seven'  => floatval(cfp_get_setting('slots_mult_seven',  20)),
        'bar'    => floatval(cfp_get_setting('slots_mult_bar',     8)),
        'bell'   => floatval(cfp_get_setting('slots_mult_bell',    5)),
        'cherry' => floatval(cfp_get_setting('slots_mult_cherry',  3)),
        'lemon'  => floatval(cfp_get_setting('slots_mult_lemon',   2)),
        'orange' => floatval(cfp_get_setting('slots_mult_orange',  1.5)),
        'grape'  => floatval(cfp_get_setting('slots_mult_grape',   1.2)),
        'wild'   => floatval(cfp_get_setting('slots_mult_wild',    50)), // wild jackpot
    ];

    function cfp_weighted_spin($symbols, $weights) {
        $total=array_sum($weights); $r=random_int(1,$total); $cum=0;
        foreach($symbols as $i=>$s){$cum+=$weights[$i];if($r<=$cum)return $s;}
        return $symbols[count($symbols)-1];
    }

    $edge = floatval(cfp_get_setting('slots_house_edge',5));
    $r1=cfp_weighted_spin($symbols,$weights);
    $r2=cfp_weighted_spin($symbols,$weights);
    $r3=cfp_weighted_spin($symbols,$weights);

    // Wild substitution — wild matches any symbol
    $eff_r1 = ($r1==='wild') ? $r2 : $r1;
    $eff_r2 = ($r2==='wild') ? ($r1==='wild' ? $r3 : $r1) : $r2;
    $eff_r3 = ($r3==='wild') ? $eff_r1 : $r3;

    $payout=0; $win_type=null; $streak = cfp_get_streak($user->id,'slots');
    $has_wild = ($r1==='wild'||$r2==='wild'||$r3==='wild');

    // MEGA JACKPOT: all three wilds
    if($r1==='wild'&&$r2==='wild'&&$r3==='wild') {
        $mega = cfp_jackpot_award($user->id);
        $payout = floor($bet * $payouts['wild']) + $mega;
        $win_type = 'mega_jackpot';
    } elseif($eff_r1===$eff_r2&&$eff_r2===$eff_r3) { // Jackpot — all 3 match (wilds count)
        $mult = $payouts[$r1==='wild'?$r2:$r1] ?? 1;
        $streak_mult = cfp_streak_bonus($streak);
        $payout = floor($bet * $mult * $streak_mult * (1-$edge/100));
        $win_type = $has_wild ? 'wild_jackpot' : 'jackpot';
    } elseif($eff_r1===$eff_r2||$eff_r2===$eff_r3||$eff_r1===$eff_r3) { // 2 match
        $pair_mult = floatval(cfp_get_setting('slots_mult_pair',1.5));
        $payout = floor($bet * $pair_mult * (1-$edge/100));
        $win_type = 'pair';
    } elseif($r1==='cherry'||$r2==='cherry'||$r3==='cherry') { // any cherry
        $cherry_mult = floatval(cfp_get_setting('slots_mult_cherry_any',0.5));
        $payout = floor($bet * $cherry_mult);
        $win_type = 'cherry';
    }

    // Free spin trigger: 3 cherries of any kind + wild combo
    $free_spins_awarded = 0;
    $cherry_count = substr_count("$r1 $r2 $r3",'cherry');
    if($cherry_count >= 2 || $has_wild) {
        $free_spins_awarded = $has_wild ? 5 : 3;
        cfp_award_free_spins($user->id, $free_spins_awarded, 'slots');
    }

    // Jackpot pool contribution on losses
    if($payout === 0) cfp_jackpot_contribute($bet);

    // Update streak
    if($payout > $bet) { cfp_set_streak($user->id,'slots',$streak+1); }
    else               { cfp_set_streak($user->id,'slots',0); }

    $net = $payout - $bet;
    if(!$free_spin) {
        // ATOMIC: deduct bet only if balance is still sufficient (prevents race condition).
        // $net may be negative (loss) or positive (win). We split into deduct + credit so
        // the WHERE guard on the deduct acts as the real concurrency lock.
        $deducted = $wpdb->query($wpdb->prepare(
            "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
            $bet, $user->id, $bet
        ));
        if ( $deducted === 0 ) {
            wp_send_json_error(['msg'=>'Insufficient balance.']);
        }
        if($payout > 0) {
            $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$payout,$user->id));
        }
    } else {
        // Free spin: only credit winnings, don't deduct
        if($payout > 0) $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$payout,$user->id));
    }

    $wpdb->insert(CFP_TABLE_SLOTS,['user_id'=>$user->id,'bet_sat'=>$bet,'reel1'=>$r1,'reel2'=>$r2,'reel3'=>$r3,'win_type'=>$win_type,'payout_sat'=>$payout]);
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>$payout>0?'slots_win':'slots_loss','amount_sat'=>$free_spin?$payout:$net,'description'=>"Slots: {$r1}|{$r2}|{$r3}".($free_spin?' [FREE SPIN]':'')]);

    $sym_map = array_combine($symbols,$labels);
    $new_bal = $wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d",$user->id));
    $ggr_slots = $bet - $payout;
    if($ggr_slots > 0) cfp_wallet_credit_game('admin_wallet_stream_slots','house_edge_slots',$ggr_slots,"Slots GGR: {$r1}|{$r2}|{$r3}, bet {$bet}");

    $new_streak  = cfp_get_streak($user->id,'slots');
    $free_remain = cfp_get_free_spins($user->id,'slots');
    $jackpot_pool = intval(cfp_get_setting('jackpot_pool_sat',0));

    $msg = match(true) {
        $win_type==='mega_jackpot' => "🌟 MEGA JACKPOT! Triple Wild! Won {$payout} sat!",
        $win_type==='wild_jackpot' => "⭐ WILD JACKPOT! Won {$payout} sat! (streak x{$new_streak})",
        $win_type==='jackpot'      => "🎰 JACKPOT! {$sym_map[$r1]} {$sym_map[$r2]} {$sym_map[$r3]} — Won {$payout} sat!".($new_streak>1?" 🔥 Streak x{$new_streak}!":''),
        $win_type==='pair'         => "✨ Pair! Won {$payout} sat!",
        $win_type==='cherry'       => "🍒 Cherry! Won {$payout} sat!",
        default                    => "😔 No match. Lost {$bet} sat.",
    };
    if($free_spins_awarded > 0) $msg .= " +{$free_spins_awarded} FREE SPINS!";

    wp_send_json_success([
        'r1'=>$sym_map[$r1],'r2'=>$sym_map[$r2],'r3'=>$sym_map[$r3],
        'payout'=>$payout,'bet'=>$bet,'win_type'=>$win_type,'new_balance'=>$new_bal,
        'streak'=>$new_streak,'free_spins'=>$free_remain,'free_spin_used'=>$free_spin,
        'free_spins_awarded'=>$free_spins_awarded,'jackpot_pool'=>$jackpot_pool,
        'msg'=>$msg,
    ]);
}

/* ============================================================
   AJAX: COIN FLIP — Enhanced with best-of-3, double-or-nothing
   ============================================================ */
add_action('wp_ajax_cfp_coinflip','cfp_ajax_coinflip');
function cfp_ajax_coinflip() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('game');
    
    // IDOR protection
    $user = cfp_require_auth();
    
    if(!cfp_get_setting('coinflip_enabled','1')) wp_send_json_error(['msg'=>'Coin Flip is disabled.']);

    $bet    = intval($_POST['bet'] ?? 0);
    $choice = sanitize_text_field($_POST['choice'] ?? '');
    $mode   = sanitize_text_field($_POST['mode'] ?? 'single');

    cfp_enforce_min_bet($bet);
    if(!in_array($choice,['heads','tails'])) wp_send_json_error(['msg'=>'Invalid choice.']);

    global $wpdb;
    if($user->balance_sat < $bet) wp_send_json_error(['msg'=>'Insufficient balance.']); // pre-flight only
    cfp_enforce_daily_loss_limit($user->id, $bet);

    $edge     = floatval(cfp_get_setting('coinflip_house_edge',2));
    $coin_mult= floatval(cfp_get_setting('coinflip_win_mult',2));
    $streak   = cfp_get_streak($user->id,'coinflip');

    if($mode === 'best3') {
        // Best of 3: player pays 1 bet, wins 2.5x if they win 2/3 flips
        $results=[]; $player_wins=0;
        for($i=0;$i<3;$i++) {
            $r = random_int(0,1)?'heads':'tails';
            $results[] = $r;
            if($r===$choice) $player_wins++;
        }
        $won = $player_wins >= 2;
        $bo3_mult = floatval(cfp_get_setting('coinflip_bo3_mult',2.5));
        $streak_m = cfp_streak_bonus($streak);
        $payout   = $won ? floor($bet * $bo3_mult * $streak_m * (1-$edge/100)) : 0;
        $net      = $payout - $bet;
        // ATOMIC: deduct bet with balance guard, then credit any winnings separately
        $deducted = $wpdb->query($wpdb->prepare(
            "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
            $bet, $user->id, $bet
        ));
        if ( $deducted === 0 ) wp_send_json_error(['msg'=>'Insufficient balance.']);
        if ( $payout > 0 ) $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$payout,$user->id));
        if($won) cfp_set_streak($user->id,'coinflip',$streak+1); else cfp_set_streak($user->id,'coinflip',0);
        if($payout===0) cfp_jackpot_contribute($bet);
        $wpdb->insert(CFP_TABLE_COINFLIP,['user_id'=>$user->id,'bet_sat'=>$bet,'choice'=>$choice,'result'=>implode(',',$results),'won'=>$won?1:0,'payout_sat'=>$payout]);
        $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>$won?'coinflip_win':'coinflip_loss','amount_sat'=>$net,'description'=>"Coin Flip (Best 3): ".implode(',',$results)]);
        $new_bal=$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d",$user->id));
        $ggr=$bet-$payout; if($ggr>0) cfp_wallet_credit_game('admin_wallet_stream_coinflip','house_edge_coinflip',$ggr,"Coin Flip BO3 GGR");
        wp_send_json_success(['mode'=>'best3','results'=>$results,'player_wins'=>$player_wins,'won'=>$won,'payout'=>$payout,'new_balance'=>$new_bal,'streak'=>cfp_get_streak($user->id,'coinflip'),
            'msg'=>$won?"🪙 Best of 3 WIN ({$player_wins}/3)! +{$payout} sat!":"🪙 Best of 3 LOSE ({$player_wins}/3). -{$bet} sat."]);
    }

    // Standard single flip
    $result = random_int(0,1)?'heads':'tails';
    $won    = ($choice===$result);
    $streak_m = cfp_streak_bonus($streak);
    $payout = $won ? floor($bet * $coin_mult * $streak_m * (1-$edge/100)) : 0;
    $net    = $payout - $bet;

    // ATOMIC: deduct bet with balance guard, then credit any winnings separately
    $deducted = $wpdb->query($wpdb->prepare(
        "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $bet, $user->id, $bet
    ));
    if ( $deducted === 0 ) wp_send_json_error(['msg'=>'Insufficient balance.']);
    if ( $payout > 0 ) $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$payout,$user->id));
    $wpdb->insert(CFP_TABLE_COINFLIP,['user_id'=>$user->id,'bet_sat'=>$bet,'choice'=>$choice,'result'=>$result,'won'=>$won?1:0,'payout_sat'=>$payout]);
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>$won?'coinflip_win':'coinflip_loss','amount_sat'=>$net,'description'=>"Coin Flip: chose {$choice}, got {$result}"]);
    $new_bal=$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d",$user->id));
    $ggr_cf=$bet-$payout; if($ggr_cf>0) cfp_wallet_credit_game('admin_wallet_stream_coinflip','house_edge_coinflip',$ggr_cf,"Coin Flip GGR: {$choice} vs {$result}, bet {$bet}");

    if($won) cfp_set_streak($user->id,'coinflip',$streak+1); else cfp_set_streak($user->id,'coinflip',0);
    if($payout===0) cfp_jackpot_contribute($bet);
    $new_streak = cfp_get_streak($user->id,'coinflip');

    // Double-or-nothing offer: if won, offer to risk it again for 2x
    $don_available = ($won && $payout > 0 && cfp_get_setting('coinflip_don_enabled','1') === '1');

    wp_send_json_success([
        'result'=>$result,'won'=>$won,'payout'=>$payout,'new_balance'=>$new_bal,
        'streak'=>$new_streak,'don_available'=>$don_available,'mode'=>'single',
        'msg' => $won
            ? "🪙 ".strtoupper($result)."! You win {$payout} sat!".($new_streak>1?" 🔥 {$new_streak} in a row!":'')
            : "🪙 ".strtoupper($result)."! You lose {$bet} sat.",
    ]);
}

/* ============================================================
   AJAX: DOUBLE-OR-NOTHING (follow-up to coinflip win)
   ============================================================ */
add_action('wp_ajax_cfp_coinflip_don','cfp_ajax_coinflip_don');
function cfp_ajax_coinflip_don() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('game');
    
    // IDOR protection
    $user = cfp_require_auth();
    
    if(cfp_get_setting('coinflip_don_enabled','1')!=='1') wp_send_json_error(['msg'=>'Double-or-Nothing is disabled.']);
    $amount = intval($_POST['amount']??0);
    $choice = sanitize_text_field($_POST['choice']??'');
    if($amount<=0||!in_array($choice,['heads','tails'])) wp_send_json_error(['msg'=>'Invalid.']);
    global $wpdb;
    if($user->balance_sat < $amount) wp_send_json_error(['msg'=>'Balance mismatch — ensure previous win was credited.']); // pre-flight only
    // ATOMIC: deduct the staked amount with balance guard before resolving the flip
    $deducted = $wpdb->query($wpdb->prepare(
        "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $amount, $user->id, $amount
    ));
    if ( $deducted === 0 ) wp_send_json_error(['msg'=>'Insufficient balance.']);
    $result=random_int(0,1)?'heads':'tails';
    $won=($choice===$result);
    $prize=$won?$amount*2:0;
    if($prize>0) $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$prize,$user->id));
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>$won?'don_win':'don_loss','amount_sat'=>$won?$amount:-$amount,'description'=>"Double-or-Nothing: {$choice} vs {$result}"]);
    $new_bal=$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d",$user->id));
    wp_send_json_success(['result'=>$result,'won'=>$won,'prize'=>$prize,'new_balance'=>$new_bal,
        'msg'=>$won?"🎉 Double WIN! +{$prize} sat!":"💔 Double-or-Nothing lost. -{$amount} sat."]);
}

/* ============================================================
   AJAX: DICE ROLL — Enhanced with target lock, multi-roll, martingale warning
   ============================================================ */
add_action('wp_ajax_cfp_dice_roll','cfp_ajax_dice_roll');
function cfp_ajax_dice_roll() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('game');
    
    // IDOR protection
    $user = cfp_require_auth();
    
    if(!cfp_get_setting('dice_enabled','1')) wp_send_json_error(['msg'=>'Dice Roll is disabled.']);

    $bet        = intval($_POST['bet']??0);
    $prediction = intval($_POST['prediction']??50);
    $direction  = sanitize_text_field($_POST['direction']??'over');
    $rolls      = min(5, max(1, intval($_POST['rolls']??1)));

    cfp_enforce_min_bet($bet * $rolls);
    if($prediction<2||$prediction>98) wp_send_json_error(['msg'=>'Prediction must be 2–98.']);
    if(!in_array($direction,['over','under'])) wp_send_json_error(['msg'=>'Invalid direction.']);

    global $wpdb;
    $total_bet = $bet * $rolls;
    if($user->balance_sat < $total_bet) wp_send_json_error(['msg'=>'Insufficient balance for multi-roll.']); // pre-flight only
    cfp_enforce_daily_loss_limit($user->id, $total_bet);

    $edge        = floatval(cfp_get_setting('dice_house_edge',2));
    $win_prob    = ($direction==='over')?(100-$prediction):($prediction-1);
    $win_prob    = max(1,$win_prob);
    $multiplier  = (100/$win_prob)*(1-$edge/100);
    $streak      = cfp_get_streak($user->id,'dice');
    $streak_m    = cfp_streak_bonus($streak);

    // ATOMIC: deduct total bet upfront with balance guard before resolving any rolls
    $deducted = $wpdb->query($wpdb->prepare(
        "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $total_bet, $user->id, $total_bet
    ));
    if ( $deducted === 0 ) wp_send_json_error(['msg'=>'Insufficient balance for multi-roll.']);

    $roll_results=[]; $total_payout=0; $wins=0;
    for($i=0;$i<$rolls;$i++) {
        $result=random_int(1,100);
        $won=($direction==='over')?($result>$prediction):($result<$prediction);
        $payout=$won?floor($bet*$multiplier*$streak_m):0;
        $net_i=$payout-$bet;
        $roll_results[]=['roll'=>$result,'won'=>$won,'payout'=>$payout];
        $total_payout+=$payout;
        if($won) $wins++;
        $wpdb->insert(CFP_TABLE_DICE,['user_id'=>$user->id,'bet_sat'=>$bet,'prediction'=>$prediction,'direction'=>$direction,'result'=>$result,'won'=>$won?1:0,'payout_sat'=>$payout]);
        $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>$won?'dice_win':'dice_loss','amount_sat'=>$net_i,'description'=>"Dice: {$direction} {$prediction}, rolled {$result}".($rolls>1?" [roll ".($i+1)."/".($rolls)."]":'')]);
    }

    // Credit any winnings (bet was already atomically deducted above)
    if ( $total_payout > 0 ) {
        $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$total_payout,$user->id));
    }
    $net_total = $total_payout - $total_bet;
    $new_bal=$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d",$user->id));

    // Update streak based on overall result
    if($wins===$rolls)  cfp_set_streak($user->id,'dice',$streak+1);
    elseif($wins===0)   cfp_set_streak($user->id,'dice',0);
    if($total_payout===0) cfp_jackpot_contribute($total_bet);

    $ggr_dice=$total_bet-$total_payout; if($ggr_dice>0) cfp_wallet_credit_game('admin_wallet_stream_dice','house_edge_dice',$ggr_dice,"Dice GGR x{$rolls}");
    $new_streak=cfp_get_streak($user->id,'dice');

    $last=$roll_results[$rolls-1];
    wp_send_json_success([
        'results'=>$roll_results,'wins'=>$wins,'rolls'=>$rolls,
        'total_payout'=>$total_payout,'total_bet'=>$total_bet,
        'result'=>$last['roll'],'won'=>$last['won'],'payout'=>$last['payout'], // compat
        'multiplier'=>round($multiplier,2),'new_balance'=>$new_bal,'streak'=>$new_streak,
        'msg'=>$rolls>1
            ? "🎲 {$wins}/{$rolls} wins! Net: ".($net_total>=0?"+{$net_total}":$net_total)." sat"
            : ($last['won']
                ? "🎲 Rolled {$last['roll']} — WIN! +{$last['payout']} sat (x".round($multiplier*$streak_m,2).")"
                : "🎲 Rolled {$last['roll']} — LOSE. -{$bet} sat"),
    ]);
}

/* ============================================================
   AJAX: CRASH GAME — Enhanced with auto-cashout, multiplayer history, bonus round
   ============================================================ */
add_action('wp_ajax_cfp_crash','cfp_ajax_crash');
function cfp_ajax_crash() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('game');
    
    // IDOR protection
    $user = cfp_require_auth();
    
    if(!cfp_get_setting('crash_enabled','1')) wp_send_json_error(['msg'=>'Crash game is disabled.']);

    $bet         = intval($_POST['bet']??0);
    $cashout     = floatval($_POST['cashout']??2.0);
    $auto_cashout= floatval($_POST['auto_cashout']??0);

    cfp_enforce_min_bet($bet);
    if($cashout<1.01||$cashout>1000) wp_send_json_error(['msg'=>'Cashout must be 1.01x – 1000x.']);

    global $wpdb;
    if($user->balance_sat<$bet) wp_send_json_error(['msg'=>'Insufficient balance.']); // pre-flight only
    cfp_enforce_daily_loss_limit($user->id, $bet);

    $edge       = floatval(cfp_get_setting('crash_house_edge',5));
    $crash_max  = floatval(cfp_get_setting('crash_max_mult',100)); // raised default to 100x
    $r          = random_int(0, PHP_INT_MAX) / PHP_INT_MAX;
    $crash_at   = max(1.0, (100-$edge)/(100*$r));
    $crash_at   = round(min($crash_at, $crash_max),2);

    // Auto-cashout: if set, use the lower of cashout and auto_cashout
    $effective_cashout = $cashout;
    if($auto_cashout >= 1.01) $effective_cashout = min($cashout, $auto_cashout);

    $won    = $effective_cashout <= $crash_at;
    $streak = cfp_get_streak($user->id,'crash');
    $sm     = cfp_streak_bonus($streak);
    $payout = $won ? floor($bet * $effective_cashout * $sm) : 0;
    $net    = $payout - $bet;

    // ATOMIC: deduct bet with balance guard, then credit any winnings separately
    $deducted = $wpdb->query($wpdb->prepare(
        "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $bet, $user->id, $bet
    ));
    if ( $deducted === 0 ) wp_send_json_error(['msg'=>'Insufficient balance.']);
    if ( $payout > 0 ) $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$payout,$user->id));
    $wpdb->insert(CFP_TABLE_CRASH,['user_id'=>$user->id,'bet_sat'=>$bet,'cashout_at'=>$won?$effective_cashout:null,'crash_at'=>$crash_at,'won'=>$won?1:0,'payout_sat'=>$payout]);
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>$won?'crash_win':'crash_loss','amount_sat'=>$net,'description'=>"Crash: cashout {$effective_cashout}x, crashed at {$crash_at}x"]);
    $new_bal=$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d",$user->id));

    $ggr_crash=$bet-$payout; if($ggr_crash>0) cfp_wallet_credit_game('admin_wallet_stream_crash','house_edge_crash',$ggr_crash,"Crash GGR: crashed {$crash_at}x, cashout {$effective_cashout}x, bet {$bet}");
    if($won) cfp_set_streak($user->id,'crash',$streak+1); else cfp_set_streak($user->id,'crash',0);
    if(!$won) cfp_jackpot_contribute($bet);
    $new_streak=cfp_get_streak($user->id,'crash');

    // Store last 10 crash results for multiplayer history display
    $history = json_decode(cfp_get_setting('crash_history','[]'), true) ?: [];
    array_unshift($history, ['v'=>$crash_at,'t'=>time()]);
    cfp_update_setting('crash_history', json_encode(array_slice($history,0,10)));

    wp_send_json_success([
        'crash_at'=>$crash_at,'cashout'=>$effective_cashout,'won'=>$won,'payout'=>$payout,
        'new_balance'=>$new_bal,'streak'=>$new_streak,'auto_cashout_triggered'=>($auto_cashout>=1.01),
        'history'=>array_slice($history,0,10),
        'msg'=>$won
            ? "🚀 Cashed out at {$effective_cashout}x before {$crash_at}x crash! +{$payout} sat".($new_streak>1?" 🔥 Streak x{$new_streak}":'')
            : "💥 CRASHED at {$crash_at}x! You wanted {$effective_cashout}x. Lost {$bet} sat.",
    ]);
}

/* ============================================================
   AJAX: WHEEL OF FORTUNE — Enhanced with VIP mode (extra segments for high bettors)
   ============================================================ */
add_action('wp_ajax_cfp_wheel','cfp_ajax_wheel');
function cfp_ajax_wheel() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('game');
    
    // IDOR protection
    $user = cfp_require_auth();
    
    if(!cfp_get_setting('wheel_enabled','1')) wp_send_json_error(['msg'=>'Wheel of Fortune is disabled.']);

    $bet   = intval($_POST['bet']??0);
    cfp_enforce_min_bet($bet);

    global $wpdb;
    if($user->balance_sat<$bet) wp_send_json_error(['msg'=>'Insufficient balance.']); // pre-flight only
    cfp_enforce_daily_loss_limit($user->id, $bet);

    $edge = floatval(cfp_get_setting('wheel_house_edge',3));
    $vip_threshold = intval(cfp_get_setting('wheel_vip_bet',500));
    $is_vip = ($bet >= $vip_threshold);

    // Standard segments
    $wheel_segs_cfg=[
        [cfp_get_setting('wheel_mult_2x','2x'),  floatval(cfp_get_setting('wheel_mult_2x',2)),   intval(cfp_get_setting('wheel_weight_2x',25)),  '#22c55e'],
        [cfp_get_setting('wheel_mult_1_5x','1.5x'),floatval(cfp_get_setting('wheel_mult_1_5x',1.5)),intval(cfp_get_setting('wheel_weight_1_5x',20)),'#f7931a'],
        ['3x',  floatval(cfp_get_setting('wheel_mult_3x',3)),   intval(cfp_get_setting('wheel_weight_3x',10)),  '#a855f7'],
        ['5x',  floatval(cfp_get_setting('wheel_mult_5x',5)),   intval(cfp_get_setting('wheel_weight_5x',5)),   '#3b82f6'],
        ['10x', floatval(cfp_get_setting('wheel_mult_10x',10)), intval(cfp_get_setting('wheel_weight_10x',2)),  '#ffcc02'],
        ['0.5x',floatval(cfp_get_setting('wheel_mult_half',0.5)),intval(cfp_get_setting('wheel_weight_half',8)),'#888888'],
    ];
    // VIP bonus segment (only available for high bets)
    if($is_vip) {
        $wheel_segs_cfg[] = ['25x', 25.0, 1, '#ff4fcf']; // rare pink VIP slot
    }

    $pool=[];
    $lose_weight = $is_vip ? max(10, intval(cfp_get_setting('wheel_lose_weight',30))-10) : intval(cfp_get_setting('wheel_lose_weight',30));
    foreach($wheel_segs_cfg as $seg) {
        for($i=0;$i<$seg[2];$i++) $pool[]=$seg;
    }
    for($i=0;$i<$lose_weight;$i++) $pool[]=['LOSE',0,0,'#ef4444'];

    $idx=array_rand($pool); $seg=$pool[$idx];
    $streak=cfp_get_streak($user->id,'wheel');
    $sm=cfp_streak_bonus($streak);
    $payout = ($seg[1]>0) ? floor($bet*$seg[1]*$sm*(1-$edge/100)) : 0;
    $net=$payout-$bet;

    // ATOMIC: deduct bet with balance guard, then credit any winnings separately
    $deducted = $wpdb->query($wpdb->prepare(
        "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $bet, $user->id, $bet
    ));
    if ( $deducted === 0 ) wp_send_json_error(['msg'=>'Insufficient balance.']);
    if ( $payout > 0 ) $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$payout,$user->id));
    $wpdb->insert(CFP_TABLE_WHEEL,['user_id'=>$user->id,'bet_sat'=>$bet,'segment'=>$seg[0],'multiplier'=>$seg[1],'payout_sat'=>$payout]);
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>$payout>0?'wheel_win':'wheel_loss','amount_sat'=>$net,'description'=>"Wheel: landed on {$seg[0]}".($is_vip?' [VIP]':'')]);
    $new_bal=$wpdb->get_var($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d",$user->id));

    $ggr_wheel=$bet-$payout; if($ggr_wheel>0) cfp_wallet_credit_game('admin_wallet_stream_wheel','house_edge_wheel',$ggr_wheel,"Wheel GGR: {$seg[0]}, bet {$bet}");
    if($payout>0) cfp_set_streak($user->id,'wheel',$streak+1); else cfp_set_streak($user->id,'wheel',0);
    if($payout===0) cfp_jackpot_contribute($bet);
    $new_streak=cfp_get_streak($user->id,'wheel');

    wp_send_json_success([
        'segment'=>$seg[0],'multiplier'=>$seg[1],'color'=>$seg[3],'payout'=>$payout,
        'new_balance'=>$new_bal,'streak'=>$new_streak,'is_vip'=>$is_vip,
        'msg'=>$payout>0
            ? "🎡 Landed on {$seg[0]}! Won {$payout} sat!".($new_streak>1?" 🔥 Streak x{$new_streak}":'').($is_vip?' 💎 VIP Spin!':'')
            : "🎡 Landed on LOSE. -{$bet} sat.",
    ]);
}

/* ============================================================
   AJAX: JACKPOT POOL — public endpoint to check pool size
   ============================================================ */
add_action('wp_ajax_cfp_jackpot_pool','cfp_ajax_jackpot_pool');
add_action('wp_ajax_nopriv_cfp_jackpot_pool','cfp_ajax_jackpot_pool');
function cfp_ajax_jackpot_pool() {
    check_ajax_referer('cfp_nonce','nonce');
    $pool = intval(cfp_get_setting('jackpot_pool_sat',0));
    wp_send_json_success(['pool'=>$pool]);
}

/* ============================================================
   AJAX: FREE SPINS CHECK
   ============================================================ */
add_action('wp_ajax_cfp_free_spins','cfp_ajax_free_spins');
function cfp_ajax_free_spins() {
    check_ajax_referer('cfp_nonce','nonce');
    cfp_require_rate_limit('game');
    $user = cfp_require_auth();
    wp_send_json_success(['slots'=>cfp_get_free_spins($user->id,'slots')]);
}

/* ============================================================
   SHORTCODE: [cfp_slots]
   ============================================================ */
add_shortcode('cfp_slots', function() {
    if(!cfp_get_setting('slots_enabled','1')) return '<p style="color:#555">Slots coming soon.</p>';
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-slots-widget">
        <h2>🎰 Slots Machine</h2>
        <p class="sub">Match 3 symbols to win big! ⭐ Wild = 50x · 🔴7 = 20x · BAR = 8x · 🔔 = 5x · 🍒 = 3x</p>
        <div id="cfp-slots-msg"></div>
        <!-- Jackpot Pool Banner -->
        <div id="sl-jackpot-banner" style="background:linear-gradient(135deg,#7c3aed,#f7931a);border-radius:10px;padding:10px 16px;text-align:center;margin-bottom:14px;font-family:'Oswald',sans-serif;font-size:1rem;color:#fff;font-weight:700;cursor:pointer" onclick="slotsFetchPool()">
            🏆 JACKPOT POOL: <span id="sl-jackpot-val">Loading…</span>
        </div>
        <div style="background:#0d0d0d;border:1px solid #1e1e1e;border-radius:12px;padding:20px;text-align:center;margin-bottom:16px">
            <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-bottom:14px">
                <div id="sl-r1" style="background:#111;border:2px solid #2a2a2a;border-radius:10px;padding:18px;font-size:2.5rem;line-height:1;transition:all .3s">🎰</div>
                <div id="sl-r2" style="background:#111;border:2px solid #2a2a2a;border-radius:10px;padding:18px;font-size:2.5rem;line-height:1;transition:all .3s">🎰</div>
                <div id="sl-r3" style="background:#111;border:2px solid #2a2a2a;border-radius:10px;padding:18px;font-size:2.5rem;line-height:1;transition:all .3s">🎰</div>
            </div>
            <div id="sl-win-label" style="font-family:'Oswald',sans-serif;font-size:1.1rem;color:#555;min-height:24px"></div>
        </div>
        <input class="cfp-input" type="email" id="sl-email" placeholder="Account email" onblur="cfpLoadSlotsBal()">
        <!-- Free spins indicator -->
        <div id="sl-free-spins-box" style="display:none;background:#1a1a0a;border:1px solid #f7931a33;border-radius:8px;padding:8px 14px;text-align:center;margin-bottom:10px;font-size:.85rem;color:#f7931a">
            ✨ Free Spins Available: <strong id="sl-free-count">0</strong>
            <button onclick="slotsSpin(true)" style="margin-left:10px;background:#f7931a;color:#000;border:none;border-radius:6px;padding:3px 10px;cursor:pointer;font-size:.8rem;font-weight:700">USE FREE SPIN</button>
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
            <label style="font-size:.78rem;color:#555;white-space:nowrap">Bet:</label>
            <input type="range" id="sl-bet-range" min="10" max="1000" step="10" value="100" oninput="document.getElementById('sl-bet-val').textContent=this.value" style="flex:1">
            <span id="sl-bet-val" style="font-family:'Oswald',sans-serif;font-size:1.1rem;color:var(--cfp-p);min-width:50px">100</span>
            <span style="font-size:.75rem;color:#444">sat</span>
        </div>
        <!-- Streak display -->
        <div id="sl-streak-box" style="text-align:center;margin-bottom:10px;font-size:.82rem;color:#555;min-height:18px"></div>
        <div id="sl-bal-box" style="font-size:.82rem;color:#444;text-align:center;margin-bottom:12px"></div>
        <button class="cfp-claim-btn" id="sl-spin-btn" onclick="slotsSpin(false)">🎰 SPIN</button>
    </div>
    <script>
    async function cfpLoadSlotsBal(){
        const email=document.getElementById('sl-email').value; if(!email) return;
        const fd=new FormData(); fd.append('action','cfp_get_user');fd.append('nonce',cfpNonce);fd.append('email',email);
        const r=await fetch(cfpAjax,{method:'POST',body:fd}); const d=await r.json();
        if(d.success) document.getElementById('sl-bal-box').innerHTML=`Balance: <strong style="color:var(--cfp-p)">${d.data.balance} sat</strong>`;
        // Check free spins
        const ff=new FormData(); ff.append('action','cfp_free_spins');ff.append('nonce',cfpNonce);ff.append('email',email);
        const fr=await fetch(cfpAjax,{method:'POST',body:ff}); const fd2=await fr.json();
        if(fd2.success&&fd2.data.slots>0){
            document.getElementById('sl-free-count').textContent=fd2.data.slots;
            document.getElementById('sl-free-spins-box').style.display='';
        }
    }
    async function slotsFetchPool(){
        const fd=new FormData(); fd.append('action','cfp_jackpot_pool');fd.append('nonce',cfpNonce);
        const r=await fetch(cfpAjax,{method:'POST',body:fd}); const d=await r.json();
        if(d.success) document.getElementById('sl-jackpot-val').textContent=d.data.pool.toLocaleString()+' sat';
    }
    slotsFetchPool();
    const slotSyms=['🎰','🍇','🍊','🍋','🍒','🔔','BAR','🔴7','⭐'];
    let slotsSpinning=false;
    async function slotsSpin(freeSpin=false){
        if(slotsSpinning) return;
        const email=document.getElementById('sl-email').value;
        const bet=freeSpin?0:document.getElementById('sl-bet-range').value;
        if(!email){document.getElementById('cfp-slots-msg').innerHTML='<div class="cfp-msg error">Enter your email.</div>';return;}
        slotsSpinning=true;
        document.getElementById('sl-spin-btn').disabled=true;
        document.getElementById('sl-win-label').textContent='Spinning…';
        document.getElementById('cfp-slots-msg').innerHTML='';
        let spinInterval=setInterval(()=>{
            ['sl-r1','sl-r2','sl-r3'].forEach(id=>document.getElementById(id).textContent=slotSyms[Math.floor(Math.random()*slotSyms.length)]);
        },80);
        const fd=new FormData(); fd.append('action','cfp_slots');fd.append('nonce',cfpNonce);fd.append('email',email);fd.append('bet',bet);
        const r=await fetch(cfpAjax,{method:'POST',body:fd}); const d=await r.json();
        setTimeout(()=>{
            clearInterval(spinInterval);
            if(d.success){
                document.getElementById('sl-r1').textContent=d.data.r1;
                document.getElementById('sl-r2').textContent=d.data.r2;
                document.getElementById('sl-r3').textContent=d.data.r3;
                const isWin=d.data.payout>0;
                document.getElementById('sl-win-label').innerHTML=`<span style="color:${isWin?'#22c55e':'#ef4444'}">${d.data.msg}</span>`;
                const borders=['#2a2a2a','#2a2a2a','#2a2a2a'];
                if(d.data.win_type==='mega_jackpot'){borders.fill('#ff4fcf');}
                else if(d.data.win_type==='wild_jackpot'||d.data.win_type==='jackpot'){borders.fill('#ffcc02');}
                else if(d.data.win_type==='pair'){borders.fill('#22c55e');}
                ['sl-r1','sl-r2','sl-r3'].forEach((id,i)=>{
                    document.getElementById(id).style.borderColor=borders[i];
                    document.getElementById(id).style.boxShadow=isWin?`0 0 12px ${borders[i]}66`:'none';
                });
                document.getElementById('sl-bal-box').innerHTML=`Balance: <strong style="color:var(--cfp-p)">${(d.data.new_balance||0).toLocaleString()} sat</strong>`;
                if(d.data.streak>1) document.getElementById('sl-streak-box').innerHTML=`🔥 Win Streak: <strong style="color:#f7931a">${d.data.streak}</strong> (+${Math.min(20,d.data.streak*2)}% bonus)`;
                else document.getElementById('sl-streak-box').innerHTML='';
                // Free spins
                if(d.data.free_spins>0){
                    document.getElementById('sl-free-count').textContent=d.data.free_spins;
                    document.getElementById('sl-free-spins-box').style.display='';
                } else document.getElementById('sl-free-spins-box').style.display='none';
                slotsFetchPool();
            } else {
                document.getElementById('sl-win-label').textContent='';
                document.getElementById('cfp-slots-msg').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;
            }
            slotsSpinning=false; document.getElementById('sl-spin-btn').disabled=false;
        },800);
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_coinflip]
   ============================================================ */
add_shortcode('cfp_coinflip', function() {
    if(!cfp_get_setting('coinflip_enabled','1')) return '<p style="color:#555">Coin Flip coming soon.</p>';
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>🪙 Coin Flip</h2>
        <p class="sub">Heads or Tails? Win 2x · Best-of-3 = 2.5x · Double-or-Nothing on wins!</p>
        <div id="cfp-cf-msg"></div>
        <div style="text-align:center;padding:20px 0">
            <div id="cf-coin" style="font-size:5rem;transition:transform .6s;display:inline-block">🪙</div>
            <div id="cf-result-lbl" style="font-family:'Oswald',sans-serif;font-size:1.3rem;color:#444;margin-top:8px;min-height:28px"></div>
        </div>
        <!-- Mode selector -->
        <div style="display:flex;gap:8px;margin-bottom:14px">
            <button id="cf-mode-single" onclick="cfSetMode('single')" style="flex:1;background:#1a2a1a;border:1px solid #22c55e;color:#22c55e;border-radius:8px;padding:7px;font-size:.8rem;cursor:pointer">Single</button>
            <button id="cf-mode-best3" onclick="cfSetMode('best3')" style="flex:1;background:#111;border:1px solid #333;color:#555;border-radius:8px;padding:7px;font-size:.8rem;cursor:pointer">Best of 3</button>
        </div>
        <input class="cfp-input" type="email" id="cf-email" placeholder="Account email">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
            <span style="font-size:.78rem;color:#555">Bet:</span>
            <input type="range" id="cf-bet" min="10" max="1000" step="10" value="100" oninput="document.getElementById('cf-bet-v').textContent=this.value" style="flex:1">
            <span id="cf-bet-v" style="font-family:'Oswald',sans-serif;font-size:1.1rem;color:var(--cfp-p);min-width:50px">100</span>
            <span style="font-size:.75rem;color:#444">sat</span>
        </div>
        <div id="cf-streak-box" style="text-align:center;margin-bottom:10px;font-size:.82rem;color:#555;min-height:18px"></div>
        <div class="cfp-hi-lo-btns">
            <button class="cfp-hi-btn" onclick="cfpFlip('heads')">🟡 HEADS</button>
            <button class="cfp-lo-btn" onclick="cfpFlip('tails')" style="background:linear-gradient(135deg,#555,#333)">⚪ TAILS</button>
        </div>
        <!-- Double-or-Nothing panel (shown after a win) -->
        <div id="cf-don-panel" style="display:none;background:#0a1a0a;border:1px solid #22c55e33;border-radius:10px;padding:14px;margin-top:14px;text-align:center">
            <div style="font-family:'Oswald',sans-serif;color:#22c55e;font-size:1rem;margin-bottom:10px">🎲 Double-or-Nothing? Risk <span id="cf-don-amount">0</span> sat for 2x!</div>
            <div class="cfp-hi-lo-btns" style="margin-top:0">
                <button onclick="cfpDon('heads')" style="background:linear-gradient(135deg,#22c55e,#16a34a);border:none;color:#fff;padding:10px;border-radius:8px;flex:1;cursor:pointer;font-weight:700">🟡 HEADS</button>
                <button onclick="cfpDon('tails')" style="background:linear-gradient(135deg,#555,#333);border:none;color:#fff;padding:10px;border-radius:8px;flex:1;cursor:pointer;font-weight:700">⚪ TAILS</button>
            </div>
            <button onclick="document.getElementById('cf-don-panel').style.display='none'" style="background:none;border:1px solid #333;color:#555;border-radius:6px;padding:6px 14px;margin-top:8px;cursor:pointer;font-size:.78rem">Skip</button>
        </div>
    </div>
    <script>
    let cfMode='single', cfLastPayout=0, cfFlipping=false;
    function cfSetMode(m){
        cfMode=m;
        ['single','best3'].forEach(id=>{
            const b=document.getElementById('cf-mode-'+id);
            b.style.background=id===m?'#1a2a1a':'#111';
            b.style.borderColor=id===m?'#22c55e':'#333';
            b.style.color=id===m?'#22c55e':'#555';
        });
    }
    async function cfpFlip(choice){
        if(cfFlipping) return;
        const email=document.getElementById('cf-email').value;
        const bet=document.getElementById('cf-bet').value;
        if(!email){document.getElementById('cfp-cf-msg').innerHTML='<div class="cfp-msg error">Enter email.</div>';return;}
        cfFlipping=true;
        document.getElementById('cf-don-panel').style.display='none';
        const coin=document.getElementById('cf-coin');
        coin.style.transform='rotateY(720deg)';
        document.getElementById('cf-result-lbl').textContent='Flipping…';
        document.getElementById('cfp-cf-msg').innerHTML='';
        const fd=new FormData(); fd.append('action','cfp_coinflip');fd.append('nonce',cfpNonce);fd.append('email',email);fd.append('bet',bet);fd.append('choice',choice);fd.append('mode',cfMode);
        const r=await fetch(cfpAjax,{method:'POST',body:fd}); const d=await r.json();
        setTimeout(()=>{
            coin.style.transform='rotateY(0deg)';
            if(d.success){
                if(cfMode==='best3'&&d.data.results){
                    coin.textContent=d.data.results.filter(r=>r===choice).length>=2?'🟡':'⚪';
                } else {
                    coin.textContent=d.data.result==='heads'?'🟡':'⚪';
                }
                document.getElementById('cf-result-lbl').innerHTML=`<span style="color:${d.data.won?'#22c55e':'#ef4444'}">${d.data.msg}</span>`;
                if(d.data.streak>1) document.getElementById('cf-streak-box').innerHTML=`🔥 Streak: <strong style="color:#f7931a">${d.data.streak}</strong>`;
                else document.getElementById('cf-streak-box').innerHTML='';
                if(d.data.don_available&&d.data.payout>0){
                    cfLastPayout=d.data.payout;
                    document.getElementById('cf-don-amount').textContent=d.data.payout.toLocaleString();
                    document.getElementById('cf-don-panel').style.display='';
                }
            } else document.getElementById('cfp-cf-msg').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;
            cfFlipping=false;
        },700);
    }
    async function cfpDon(choice){
        const email=document.getElementById('cf-email').value;
        document.getElementById('cf-don-panel').style.display='none';
        const fd=new FormData(); fd.append('action','cfp_coinflip_don');fd.append('nonce',cfpNonce);fd.append('email',email);fd.append('amount',cfLastPayout);fd.append('choice',choice);
        const r=await fetch(cfpAjax,{method:'POST',body:fd}); const d=await r.json();
        document.getElementById('cf-result-lbl').innerHTML=`<span style="color:${d.success&&d.data.won?'#22c55e':'#ef4444'}">${d.success?d.data.msg:d.data.msg}</span>`;
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_dice]
   ============================================================ */
add_shortcode('cfp_dice', function() {
    if(!cfp_get_setting('dice_enabled','1')) return '<p style="color:#555">Dice Roll coming soon.</p>';
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>🎲 Dice Roll</h2>
        <p class="sub">Set a target number. Bet over or under. Multi-roll up to 5 dice at once!</p>
        <div id="cfp-dice-msg"></div>
        <div style="background:#0d0d0d;border:1px solid #1e1e1e;border-radius:12px;padding:20px;text-align:center;margin-bottom:16px">
            <div id="dice-result-num" style="font-family:'Oswald',sans-serif;font-size:4rem;font-weight:900;color:var(--cfp-p);line-height:1">?</div>
            <div id="dice-multi-results" style="display:flex;justify-content:center;gap:8px;flex-wrap:wrap;margin-top:10px;min-height:40px"></div>
            <div id="dice-result-lbl" style="font-size:.85rem;color:#444;margin-top:6px;min-height:20px"></div>
            <div id="dice-mult-preview" style="font-size:.82rem;color:#555;margin-top:4px"></div>
        </div>
        <input class="cfp-input" type="email" id="dice-email" placeholder="Account email">
        <div style="margin-bottom:14px">
            <div style="display:flex;justify-content:space-between;margin-bottom:6px">
                <label style="font-size:.78rem;color:#555">Target number:</label>
                <span id="dice-pred-val" style="font-family:'Oswald',sans-serif;font-size:1rem;color:var(--cfp-p);font-weight:700">50</span>
            </div>
            <input type="range" id="dice-pred" min="2" max="98" value="50" oninput="updateDicePreview()" style="width:100%">
            <div style="display:flex;justify-content:space-between;font-size:.68rem;color:#333;margin-top:2px"><span>2</span><span>50</span><span>98</span></div>
        </div>
        <div style="display:flex;gap:8px;margin-bottom:12px;align-items:center">
            <span style="font-size:.78rem;color:#555;white-space:nowrap">Rolls:</span>
            <?php for($r=1;$r<=5;$r++): ?>
            <button id="dice-rolls-<?=$r?>" onclick="diceSetRolls(<?=$r?>)" style="flex:1;background:<?=$r===1?'#1a2a1a':'#111'?>;border:1px solid <?=$r===1?'#22c55e':'#333'?>;color:<?=$r===1?'#22c55e':'#555'?>;border-radius:8px;padding:6px;font-size:.8rem;cursor:pointer"><?=$r?>×</button>
            <?php endfor; ?>
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
            <span style="font-size:.78rem;color:#555">Bet per roll:</span>
            <input type="range" id="dice-bet" min="10" max="1000" step="10" value="100" oninput="document.getElementById('dice-bet-v').textContent=this.value" style="flex:1">
            <span id="dice-bet-v" style="font-family:'Oswald',sans-serif;font-size:1.1rem;color:var(--cfp-p);min-width:50px">100</span>
            <span style="font-size:.75rem;color:#444">sat</span>
        </div>
        <div id="dice-streak-box" style="text-align:center;margin-bottom:10px;font-size:.82rem;color:#555;min-height:18px"></div>
        <div class="cfp-hi-lo-btns">
            <button class="cfp-hi-btn" onclick="cfpRollDice('over')">📈 OVER</button>
            <button class="cfp-lo-btn" onclick="cfpRollDice('under')">📉 UNDER</button>
        </div>
    </div>
    <script>
    let diceRolls=1;
    function diceSetRolls(n){
        diceRolls=n;
        for(let i=1;i<=5;i++){
            const b=document.getElementById('dice-rolls-'+i);
            b.style.background=i===n?'#1a2a1a':'#111';
            b.style.borderColor=i===n?'#22c55e':'#333';
            b.style.color=i===n?'#22c55e':'#555';
        }
    }
    function updateDicePreview(){
        const pred=parseInt(document.getElementById('dice-pred').value);
        document.getElementById('dice-pred-val').textContent=pred;
        const overProb=100-pred; const underProb=pred-1;
        const overMult=((100/Math.max(1,overProb))*0.98).toFixed(2);
        const underMult=((100/Math.max(1,underProb))*0.98).toFixed(2);
        document.getElementById('dice-mult-preview').textContent=`Over: ${overMult}x · Under: ${underMult}x`;
    }
    updateDicePreview();
    async function cfpRollDice(direction){
        const email=document.getElementById('dice-email').value;
        const bet=document.getElementById('dice-bet').value;
        const pred=document.getElementById('dice-pred').value;
        if(!email){document.getElementById('cfp-dice-msg').innerHTML='<div class="cfp-msg error">Enter email.</div>';return;}
        document.getElementById('dice-result-num').textContent='…';
        document.getElementById('dice-multi-results').innerHTML='';
        const fd=new FormData(); fd.append('action','cfp_dice_roll');fd.append('nonce',cfpNonce);fd.append('email',email);fd.append('bet',bet);fd.append('prediction',pred);fd.append('direction',direction);fd.append('rolls',diceRolls);
        const r=await fetch(cfpAjax,{method:'POST',body:fd}); const d=await r.json();
        if(d.success){
            document.getElementById('dice-result-num').style.color=d.data.won?'#22c55e':'#ef4444';
            document.getElementById('dice-result-num').textContent=d.data.result;
            // Multi-roll results
            if(d.data.results&&d.data.results.length>1){
                const mr=document.getElementById('dice-multi-results');
                d.data.results.forEach(res=>{
                    const el=document.createElement('div');
                    el.style.cssText=`background:#111;border:2px solid ${res.won?'#22c55e':'#ef4444'};border-radius:8px;padding:6px 10px;font-family:'Oswald',sans-serif;font-size:1.2rem;color:${res.won?'#22c55e':'#ef4444'}`;
                    el.textContent=res.roll;
                    mr.appendChild(el);
                });
            }
            document.getElementById('dice-result-lbl').innerHTML=`<span style="color:${d.data.won?'#22c55e':'#ef4444'}">${d.data.msg}</span>`;
            if(d.data.streak>1) document.getElementById('dice-streak-box').innerHTML=`🔥 Win Streak: <strong style="color:#f7931a">${d.data.streak}</strong>`;
            else document.getElementById('dice-streak-box').innerHTML='';
        } else document.getElementById('cfp-dice-msg').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_crash]
   ============================================================ */
add_shortcode('cfp_crash', function() {
    if(!cfp_get_setting('crash_enabled','1')) return '<p style="color:#555">Crash game coming soon.</p>';
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>📈 Crash</h2>
        <p class="sub">Set your cashout target. Auto-cashout available. History shows last 10 rounds.</p>
        <div id="cfp-crash-msg"></div>
        <!-- Crash history bar -->
        <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px;min-height:30px" id="crash-history-bar"></div>
        <div style="background:#0d0d0d;border:1px solid #1e1e1e;border-radius:12px;padding:20px;text-align:center;margin-bottom:16px;position:relative;overflow:hidden">
            <div id="crash-multiplier" style="font-family:'Oswald',sans-serif;font-size:3.5rem;font-weight:900;color:var(--cfp-p);transition:all .5s;line-height:1">🚀</div>
            <div id="crash-graph-bar" style="height:6px;background:#1a1a1a;border-radius:3px;margin-top:12px;overflow:hidden">
                <div id="crash-graph-fill" style="height:100%;width:0%;background:linear-gradient(90deg,#22c55e,var(--cfp-p));border-radius:3px;transition:width 0.4s"></div>
            </div>
            <div id="crash-result-lbl" style="font-size:.85rem;color:#444;margin-top:10px;min-height:20px"></div>
        </div>
        <input class="cfp-input" type="email" id="crash-email" placeholder="Account email">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:14px">
            <div>
                <div style="display:flex;justify-content:space-between;margin-bottom:6px">
                    <label style="font-size:.78rem;color:#555">Cashout at:</label>
                    <span id="crash-co-val" style="font-family:'Oswald',sans-serif;font-size:1rem;color:var(--cfp-p);font-weight:700">2.00x</span>
                </div>
                <input type="range" id="crash-co" min="1.1" max="20" step="0.1" value="2" oninput="document.getElementById('crash-co-val').textContent=parseFloat(this.value).toFixed(2)+'x'" style="width:100%">
            </div>
            <div>
                <div style="display:flex;justify-content:space-between;margin-bottom:6px">
                    <label style="font-size:.78rem;color:#555">Auto-cashout (0=off):</label>
                    <span id="crash-ac-val" style="font-family:'Oswald',sans-serif;font-size:1rem;color:#888;font-weight:700">OFF</span>
                </div>
                <input type="range" id="crash-ac" min="0" max="20" step="0.1" value="0" oninput="crashAcUpdate(this.value)" style="width:100%">
            </div>
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
            <span style="font-size:.78rem;color:#555">Bet:</span>
            <input type="range" id="crash-bet" min="10" max="1000" step="10" value="100" oninput="document.getElementById('crash-bet-v').textContent=this.value" style="flex:1">
            <span id="crash-bet-v" style="font-family:'Oswald',sans-serif;font-size:1.1rem;color:var(--cfp-p);min-width:50px">100</span>
            <span style="font-size:.75rem;color:#444">sat</span>
        </div>
        <div id="crash-streak-box" style="text-align:center;margin-bottom:10px;font-size:.82rem;color:#555;min-height:18px"></div>
        <button class="cfp-claim-btn" id="crash-btn" onclick="cfpCrash()">🚀 LAUNCH ROCKET</button>
    </div>
    <script>
    function crashAcUpdate(v){
        document.getElementById('crash-ac-val').textContent=parseFloat(v)>=1.1?parseFloat(v).toFixed(2)+'x':'OFF';
    }
    function crashRenderHistory(hist){
        const bar=document.getElementById('crash-history-bar');
        bar.innerHTML='';
        (hist||[]).forEach(h=>{
            const el=document.createElement('span');
            el.style.cssText=`background:${h.v>=10?'#ffcc02':h.v>=3?'#a855f7':h.v>=2?'#22c55e':'#ef4444'};color:#000;border-radius:5px;padding:2px 8px;font-family:'Oswald',sans-serif;font-size:.8rem;font-weight:700`;
            el.textContent=h.v+'x';
            bar.appendChild(el);
        });
    }
    let crashRunning=false;
    async function cfpCrash(){
        if(crashRunning) return;
        const email=document.getElementById('crash-email').value;
        const bet=document.getElementById('crash-bet').value;
        const cashout=parseFloat(document.getElementById('crash-co').value).toFixed(2);
        const autoCo=parseFloat(document.getElementById('crash-ac').value);
        if(!email){document.getElementById('cfp-crash-msg').innerHTML='<div class="cfp-msg error">Enter email.</div>';return;}
        crashRunning=true; document.getElementById('crash-btn').disabled=true;
        document.getElementById('crash-result-lbl').textContent='';
        document.getElementById('cfp-crash-msg').innerHTML='';
        const multEl=document.getElementById('crash-multiplier');
        const fillEl=document.getElementById('crash-graph-fill');
        multEl.style.color='var(--cfp-p)'; multEl.textContent='🚀';
        let animMult=1.0;
        const anim=setInterval(()=>{
            animMult+=0.05+animMult*0.01;
            multEl.textContent=animMult.toFixed(2)+'x';
            fillEl.style.width=Math.min(100,(animMult/parseFloat(cashout))*80)+'%';
        },60);
        const fd=new FormData(); fd.append('action','cfp_crash');fd.append('nonce',cfpNonce);fd.append('email',email);fd.append('bet',bet);fd.append('cashout',cashout);fd.append('auto_cashout',autoCo>=1.1?autoCo:0);
        const r=await fetch(cfpAjax,{method:'POST',body:fd}); const d=await r.json();
        setTimeout(()=>{
            clearInterval(anim);
            if(d.success){
                multEl.textContent=d.data.crash_at+'x';
                multEl.style.color=d.data.won?'#22c55e':'#ef4444';
                fillEl.style.width='100%';
                fillEl.style.background=d.data.won?'#22c55e':'#ef4444';
                document.getElementById('crash-result-lbl').innerHTML=`<span style="color:${d.data.won?'#22c55e':'#ef4444'}">${d.data.msg}</span>`;
                crashRenderHistory(d.data.history);
                if(d.data.streak>1) document.getElementById('crash-streak-box').innerHTML=`🔥 Win Streak: <strong style="color:#f7931a">${d.data.streak}</strong>`;
                else document.getElementById('crash-streak-box').innerHTML='';
            } else document.getElementById('cfp-crash-msg').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;
            crashRunning=false; document.getElementById('crash-btn').disabled=false;
        },d.success&&d.data.won?Math.min(3000,parseFloat(cashout)*600):1500);
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_wheel]
   ============================================================ */
add_shortcode('cfp_wheel', function() {
    if(!cfp_get_setting('wheel_enabled','1')) return '<p style="color:#555">Wheel of Fortune coming soon.</p>';
    $nonce=wp_create_nonce('cfp_nonce'); $ajax=admin_url('admin-ajax.php');
    $vip_threshold = intval(cfp_get_setting('wheel_vip_bet',500));
    ob_start(); ?>
    <div class="cfp-widget" style="text-align:center">
        <h2>🎡 Wheel of Fortune</h2>
        <p class="sub">Spin the wheel! 💎 Bet <?=$vip_threshold?>+ sat to unlock VIP 25x segment!</p>
        <div id="cfp-wheel-msg"></div>
        <div style="position:relative;display:inline-block;margin-bottom:16px">
            <canvas id="wheel-canvas" width="260" height="260" style="border-radius:50%;display:block"></canvas>
            <div style="position:absolute;top:-8px;left:50%;transform:translateX(-50%);font-size:1.6rem;z-index:2">🔽</div>
            <div id="wheel-result-overlay" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;font-family:'Oswald',sans-serif;font-size:1.4rem;font-weight:900;opacity:0;transition:opacity .3s;border-radius:50%"></div>
        </div>
        <div id="wheel-vip-badge" style="display:none;background:linear-gradient(135deg,#7c3aed,#ff4fcf);color:#fff;border-radius:8px;padding:4px 14px;font-size:.8rem;font-weight:700;margin-bottom:8px;display:inline-block">💎 VIP SPIN UNLOCKED</div>
        <div id="wheel-result-lbl" style="font-family:'Oswald',sans-serif;font-size:1.1rem;min-height:26px;margin-bottom:14px;color:#555"></div>
        <input class="cfp-input" type="email" id="wheel-email" placeholder="Account email">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
            <span style="font-size:.78rem;color:#555">Bet:</span>
            <input type="range" id="wheel-bet" min="10" max="1000" step="10" value="100" oninput="wheelBetUpdate(this.value)" style="flex:1">
            <span id="wheel-bet-v" style="font-family:'Oswald',sans-serif;font-size:1.1rem;color:var(--cfp-p);min-width:50px">100</span>
            <span style="font-size:.75rem;color:#444">sat</span>
        </div>
        <div id="wheel-streak-box" style="text-align:center;margin-bottom:10px;font-size:.82rem;color:#555;min-height:18px"></div>
        <button class="cfp-claim-btn" id="wheel-btn" onclick="cfpSpin()">🎡 SPIN THE WHEEL</button>
    </div>
    <script>
    (function(){
        const vipThreshold=<?=$vip_threshold?>;
        function wheelBetUpdate(v){
            document.getElementById('wheel-bet-v').textContent=v;
            document.getElementById('wheel-vip-badge').style.display=parseInt(v)>=vipThreshold?'inline-block':'none';
        }
        window.wheelBetUpdate=wheelBetUpdate;
        const segs=[
            {label:'2x',color:'#22c55e'},{label:'LOSE',color:'#ef4444'},
            {label:'1.5x',color:'#f7931a'},{label:'LOSE',color:'#ef4444'},
            {label:'3x',color:'#a855f7'},{label:'LOSE',color:'#ef4444'},
            {label:'5x',color:'#3b82f6'},{label:'0.5x',color:'#888888'},
            {label:'10x',color:'#ffcc02'},{label:'LOSE',color:'#ef4444'},
        ];
        const c=document.getElementById('wheel-canvas');
        const ctx=c.getContext('2d');
        const cx=130,cy=130,r=120,n=segs.length;
        let rotation=0;
        function drawWheel(rot,extraSeg){
            const drawSegs=[...segs];
            if(extraSeg) drawSegs.push(extraSeg);
            const nn=drawSegs.length;
            ctx.clearRect(0,0,260,260);
            const arc=2*Math.PI/nn;
            drawSegs.forEach((s,i)=>{
                const start=rot+i*arc, end=start+arc;
                ctx.beginPath(); ctx.moveTo(cx,cy); ctx.arc(cx,cy,r,start,end); ctx.closePath();
                ctx.fillStyle=s.color; ctx.fill();
                ctx.strokeStyle='#000'; ctx.lineWidth=1.5; ctx.stroke();
                ctx.save(); ctx.translate(cx,cy); ctx.rotate(start+arc/2);
                ctx.textAlign='right'; ctx.fillStyle='#fff'; ctx.font='bold 12px Oswald,sans-serif';
                ctx.fillText(s.label,r-8,5); ctx.restore();
            });
            ctx.beginPath(); ctx.arc(cx,cy,16,0,2*Math.PI);
            ctx.fillStyle='#111'; ctx.fill(); ctx.strokeStyle='#333'; ctx.lineWidth=2; ctx.stroke();
        }
        drawWheel(0,null);
        let spinning=false;
        window.cfpSpin=async function(){
            if(spinning) return;
            const email=document.getElementById('wheel-email').value;
            const bet=document.getElementById('wheel-bet').value;
            if(!email){document.getElementById('cfp-wheel-msg').innerHTML='<div class="cfp-msg error">Enter email.</div>';return;}
            spinning=true; document.getElementById('wheel-btn').disabled=true;
            document.getElementById('wheel-result-lbl').textContent='';
            document.getElementById('cfp-wheel-msg').innerHTML='';
            document.getElementById('wheel-result-overlay').style.opacity=0;
            const isVip=parseInt(bet)>=vipThreshold;
            const vipSeg=isVip?{label:'25x',color:'#ff4fcf'}:null;
            drawWheel(rotation,vipSeg);
            const fd=new FormData(); fd.append('action','cfp_wheel');fd.append('nonce',cfpNonce);fd.append('email',email);fd.append('bet',bet);
            const resp=await fetch(cfpAjax,{method:'POST',body:fd}); const d=await resp.json();
            if(!d.success){document.getElementById('cfp-wheel-msg').innerHTML=`<div class="cfp-msg error">${d.data.msg}</div>`;spinning=false;document.getElementById('wheel-btn').disabled=false;return;}
            const winLabel=d.data.segment;
            const drawSegs=isVip?[...segs,vipSeg]:[...segs];
            const nn=drawSegs.length;
            const winIdx=drawSegs.findIndex(s=>s.label===winLabel);
            const arc=2*Math.PI/nn;
            const targetAngle=-(winIdx*arc+arc/2);
            const spins=5*2*Math.PI;
            const totalAngle=spins+targetAngle-rotation%(2*Math.PI);
            const duration=3500; const start=performance.now();
            const startRot=rotation;
            function animate(now){
                const elapsed=now-start;
                const progress=Math.min(elapsed/duration,1);
                const ease=1-Math.pow(1-progress,4);
                rotation=startRot+totalAngle*ease;
                drawWheel(rotation,vipSeg);
                if(progress<1){requestAnimationFrame(animate);}
                else{
                    rotation=startRot+totalAngle;
                    drawWheel(rotation,vipSeg);
                    const ov=document.getElementById('wheel-result-overlay');
                    ov.textContent=winLabel; ov.style.color=d.data.color;
                    ov.style.background=d.data.color+'22'; ov.style.opacity=1;
                    document.getElementById('wheel-result-lbl').innerHTML=`<span style="color:${d.data.payout>0?'#22c55e':'#ef4444'}">${d.data.msg}</span>`;
                    if(d.data.streak>1) document.getElementById('wheel-streak-box').innerHTML=`🔥 Win Streak: <strong style="color:#f7931a">${d.data.streak}</strong>`;
                    else document.getElementById('wheel-streak-box').innerHTML='';
                    spinning=false; document.getElementById('wheel-btn').disabled=false;
                }
            }
            requestAnimationFrame(animate);
        };
    })();
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_games_lobby] — All games in one page
   ============================================================ */
add_shortcode('cfp_games_lobby', function() {
    $currency=cfp_get_setting('faucet_currency','BTC');
    $jackpot=intval(cfp_get_setting('jackpot_pool_sat',0));
    $games=[
        ['hilo',    'Hi-Lo Multiply',   '🎲', 'Predict High or Low. Win 2x.',                   'cfp_hilo'],
        ['slots',   'Slots Machine',    '🎰', 'Match 3 to win up to 50x. Wilds & free spins!',  'cfp_slots'],
        ['coinflip','Coin Flip',        '🪙', 'Heads or Tails. Best-of-3 & Double-or-Nothing.',  'cfp_coinflip'],
        ['dice',    'Dice Roll',        '🎲', 'Multi-roll up to 5 dice. Dynamic odds.',          'cfp_dice'],
        ['crash',   'Crash',            '📈', 'Auto-cashout + 10 round history.',               'cfp_crash'],
        ['wheel',   'Wheel of Fortune', '🎡', 'VIP 25x segment unlocked for big bettors.',       'cfp_wheel'],
    ];
    ob_start(); ?>
    <div style="background:var(--cfp-dk,#0a0a0a);padding:40px 20px;font-family:'Source Sans 3',sans-serif">
        <div style="max-width:1100px;margin:0 auto">
            <h2 style="font-family:'Oswald',sans-serif;font-size:2rem;font-weight:900;color:#fff;text-transform:uppercase;letter-spacing:3px;text-align:center;margin-bottom:6px">🎮 Games Lobby</h2>
            <p style="text-align:center;color:#555;font-size:.9rem;margin-bottom:16px">Play with your <?=$currency?> balance. All games are instant &amp; provably fair.</p>
            <!-- Jackpot pool banner -->
            <div style="background:linear-gradient(135deg,#7c3aed,#f7931a);border-radius:12px;padding:14px;text-align:center;margin-bottom:30px;font-family:'Oswald',sans-serif;font-size:1.2rem;color:#fff;font-weight:700">
                🏆 SHARED JACKPOT POOL: <?=number_format($jackpot)?> sat — Builds from every losing bet!
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:18px;margin-bottom:50px">
            <?php foreach($games as [$key,$label,$icon,$desc,$sc]):
                $enabled=cfp_get_setting($key==='hilo'?'multiply_enabled':$key.'_enabled','1');
                if(!$enabled) continue; ?>
                <div style="background:#111;border:1px solid #1e1e1e;border-radius:14px;padding:22px;cursor:pointer;transition:border-color .2s"
                     onmouseover="this.style.borderColor='var(--cfp-p)'" onmouseout="this.style.borderColor='#1e1e1e'"
                     onclick="document.getElementById('cfp-game-<?=$key?>').scrollIntoView({behavior:'smooth'})">
                    <div style="font-size:2.5rem;margin-bottom:10px"><?=$icon?></div>
                    <div style="font-family:'Oswald',sans-serif;font-size:1.1rem;font-weight:700;color:#fff;margin-bottom:5px"><?=$label?></div>
                    <div style="font-size:.82rem;color:#555"><?=$desc?></div>
                </div>
            <?php endforeach; ?>
            </div>
            <?php foreach($games as [$key,$label,$icon,$desc,$sc]):
                $enabled=cfp_get_setting($key==='hilo'?'multiply_enabled':$key.'_enabled','1');
                if(!$enabled) continue; ?>
            <div id="cfp-game-<?=$key?>" style="margin-bottom:50px;scroll-margin-top:30px">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:14px;border-bottom:1px solid #1a1a1a">
                    <span style="font-size:1.6rem"><?=$icon?></span>
                    <h3 style="font-family:'Oswald',sans-serif;font-size:1.4rem;font-weight:700;color:#fff;margin:0"><?=$label?></h3>
                </div>
                <?=do_shortcode("[$sc]")?>
            </div>
            <?php endforeach; ?>
        </div>
    </div>
    <?php return ob_get_clean();
});
