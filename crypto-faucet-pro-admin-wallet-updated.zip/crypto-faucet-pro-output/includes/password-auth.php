<?php
/**
 * Email verification on signup, password-based login, and 2FA (TOTP).
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   EMAIL VERIFICATION
   ============================================================ */
function cfp_send_verification_email( $user_id, $email ) {
    global $wpdb;
    $token   = bin2hex( random_bytes(32) );
    $expires = date('Y-m-d H:i:s', strtotime('+24 hours'));
    
    $wpdb->insert(CFP_TABLE_VERIFY_TOKENS, [
        'user_id'    => $user_id,
        'token'      => hash('sha256', $token),
        'type'       => 'email',
        'expires_at' => $expires,
    ]);
    $site  = get_bloginfo('name');
    $url   = add_query_arg(['cfp_verify' => $token], home_url('/'));
    $msg   = "Welcome to {$site}!\n\nClick the link below to verify your email address:\n\n{$url}\n\nThis link expires in 24 hours.\n\nIf you did not register, ignore this email.";
    wp_mail( $email, "Verify your email — {$site}", $msg );
}

// Hook into register to send verification email
add_action('cfp_user_registered', function($user_id, $email) {
    if ( cfp_get_setting('email_verify_required','0') === '1' ) {
        cfp_send_verification_email($user_id, $email);
    }
}, 10, 2);

// Handle verification link click
add_action('init', function() {
    $token = sanitize_text_field($_GET['cfp_verify'] ?? '');
    if ( ! $token ) return;
    if (strlen($token) !== 64) return;
    
    global $wpdb;
    $hashed_token = hash('sha256', $token);
    $row = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM ".CFP_TABLE_VERIFY_TOKENS." WHERE token=%s AND type='email' AND used_at IS NULL AND expires_at > NOW()",
        $hashed_token
    ));
    if ( ! $row ) { wp_die('Verification link is invalid or expired. Please register again.'); }
    $wpdb->update(CFP_TABLE_USERS, ['is_verified'=>1], ['id'=>$row->user_id]);
    $wpdb->update(CFP_TABLE_VERIFY_TOKENS, ['used_at'=>current_time('mysql')], ['id'=>$row->id]);
    wp_redirect( add_query_arg('cfp_verified','1', home_url('/')) );
    exit;
});

// Resend verification email AJAX
add_action('wp_ajax_cfp_resend_verify',        'cfp_ajax_resend_verify');
add_action('wp_ajax_nopriv_cfp_resend_verify', 'cfp_ajax_resend_verify');
function cfp_ajax_resend_verify() {
    check_ajax_referer('cfp_nonce','nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    // Use a neutral response regardless of whether the email exists —
    // distinct errors allow attackers to enumerate registered addresses.
    $neutral = ['msg'=>'✅ If that email is registered and unverified, a new link has been sent. Check your inbox.'];
    if ( ! is_email($email) ) { wp_send_json_success($neutral); }
    $user = cfp_get_user_by_email($email);
    if ( $user && ! $user->is_verified ) {
        cfp_send_verification_email($user->id, $email);
    }
    wp_send_json_success($neutral);
}

/* ============================================================
   PASSWORD-BASED LOGIN & REGISTRATION
   ============================================================ */
// Override register to support password
add_action('wp_ajax_cfp_register_pw',        'cfp_ajax_register_pw');
add_action('wp_ajax_nopriv_cfp_register_pw', 'cfp_ajax_register_pw');
function cfp_ajax_register_pw() {
    check_ajax_referer('cfp_nonce','nonce');
    $email    = sanitize_email($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $ref      = sanitize_text_field($_POST['ref'] ?? '');
    if ( ! is_email($email) ) wp_send_json_error(['msg'=>'Invalid email.']);
    
    // Strong password validation
    if ( strlen($password) < 8 ) wp_send_json_error(['msg'=>'Password must be at least 8 characters.']);
    if ( strlen($password) > 128 ) wp_send_json_error(['msg'=>'Password too long.']);
    if ( ! preg_match('/[A-Z]/', $password) ) wp_send_json_error(['msg'=>'Password must contain at least one uppercase letter.']);
    if ( ! preg_match('/[a-z]/', $password) ) wp_send_json_error(['msg'=>'Password must contain at least one lowercase letter.']);
    if ( ! preg_match('/[0-9]/', $password) ) wp_send_json_error(['msg'=>'Password must contain at least one number.']);
    if ( ! preg_match('/[^A-Za-z0-9]/', $password) ) wp_send_json_error(['msg'=>'Password must contain at least one special character.']);
    
    global $wpdb;
    if ( $wpdb->get_var($wpdb->prepare("SELECT id FROM ".CFP_TABLE_USERS." WHERE email=%s",$email)) )
        wp_send_json_error(['msg'=>'Email already registered.']);
    $hash     = password_hash($password, PASSWORD_BCRYPT, ['cost'=>14]);
    $username = 'user'.strtolower(substr(hash('sha256', $email),0,6));
    $ref_code = strtoupper(substr(bin2hex(random_bytes(4)),0,8));
    $wpdb->insert(CFP_TABLE_USERS,['email'=>$email,'username'=>$username,'ref_code'=>$ref_code,'referred_by'=>$ref,'password_hash'=>$hash]);
    $uid = $wpdb->insert_id;
    if($ref){
        $referrer=$wpdb->get_row($wpdb->prepare("SELECT id FROM ".CFP_TABLE_USERS." WHERE ref_code=%s",$ref));
        if($referrer) $wpdb->insert(CFP_TABLE_REFERRALS,['referrer_id'=>$referrer->id,'referred_id'=>$uid]);
    }
    do_action('cfp_user_registered', $uid, $email);
    wp_send_json_success(['msg'=>'✅ Account created! '.( cfp_get_setting('email_verify_required','0')==='1' ? 'Check your email to verify your account.' : 'You can now log in.'),'email'=>$email]);
}

// Password login
add_action('wp_ajax_cfp_login',        'cfp_ajax_login');
add_action('wp_ajax_nopriv_cfp_login', 'cfp_ajax_login');
function cfp_ajax_login() {
    check_ajax_referer('cfp_nonce','nonce');
    $email    = sanitize_email($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $twofa    = sanitize_text_field($_POST['twofa'] ?? '');
    $user     = cfp_get_user_by_email($email);
    if ( ! $user ) wp_send_json_error(['msg'=>'Invalid email or password.']);
    if ( $user->is_banned ) wp_send_json_error(['msg'=>'Account suspended.']);
    if ( empty($user->password_hash) ) wp_send_json_error(['msg'=>'This account uses email-only login. Leave password blank.']);
    if ( ! password_verify($password, $user->password_hash) ) wp_send_json_error(['msg'=>'Invalid email or password.']);
    // 2FA check
    if ( $user->twofa_enabled && ! empty($user->twofa_secret) ) {
        if ( empty($twofa) ) wp_send_json_error(['msg'=>'Enter your 2FA code.','need_2fa'=>true]);
        if ( ! cfp_totp_verify($user->twofa_secret, $twofa) ) wp_send_json_error(['msg'=>'Invalid 2FA code.']);
    }
    // Email verification check
    if ( cfp_get_setting('email_verify_required','0') === '1' && ! $user->is_verified )
        wp_send_json_error(['msg'=>'Please verify your email first. Check your inbox.','not_verified'=>true]);
    // Issue a login token (session-like)
    global $wpdb;
    $token   = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', strtotime('+7 days'));
    $wpdb->update(CFP_TABLE_USERS,[
        'login_token'=>$token,
        'login_token_expires'=>$expires,
        'last_login'=>current_time('mysql'),
    ],['id'=>$user->id]);
    wp_send_json_success([
        'msg'   => '✅ Logged in!',
        'token' => $token,
        'email' => $email,
    ]);
}

// Set/change password
add_action('wp_ajax_cfp_set_password',        'cfp_ajax_set_password');
add_action('wp_ajax_nopriv_cfp_set_password', 'cfp_ajax_set_password');
function cfp_ajax_set_password() {
    check_ajax_referer('cfp_nonce','nonce');
    $email   = sanitize_email($_POST['email'] ?? '');
    $current = $_POST['current_password'] ?? '';
    $new_pw  = $_POST['new_password'] ?? '';
    $user    = cfp_get_user_by_email($email);
    if ( ! $user ) wp_send_json_error(['msg'=>'Account not found.']);
    if ( ! empty($user->password_hash) && ! password_verify($current, $user->password_hash) )
        wp_send_json_error(['msg'=>'Current password incorrect.']);
    if ( strlen($new_pw) < 8 ) wp_send_json_error(['msg'=>'Password must be at least 8 characters.']);
    global $wpdb;
    $wpdb->update(CFP_TABLE_USERS,['password_hash'=>password_hash($new_pw,PASSWORD_BCRYPT,['cost'=>12])],['id'=>$user->id]);
    wp_send_json_success(['msg'=>'✅ Password updated.']);
}

/* ============================================================
   2FA — TOTP (Google Authenticator compatible)
   Uses Time-based One-Time Password (RFC 6238)
   ============================================================ */
function cfp_totp_generate_secret() {
    $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    $secret = '';
    for ($i=0;$i<32;$i++) $secret .= $chars[random_int(0,31)];
    return $secret;
}

function cfp_totp_verify( $secret, $code, $window = 1 ) {
    $code = preg_replace('/\s+/','',$code);
    $time = floor(time()/30);
    for ($i=-$window; $i<=$window; $i++) {
        if ( cfp_totp_code($secret, $time+$i) === $code ) return true;
    }
    return false;
}

function cfp_totp_code( $secret, $time = null ) {
    $time   = $time ?? floor(time()/30);
    $key    = cfp_base32_decode($secret);
    $msg    = pack('N*',0) . pack('N*',$time);
    $hash   = hash_hmac('sha1', $msg, $key, true);
    $offset = ord($hash[19]) & 0xf;
    $code   = ((ord($hash[$offset])&0x7f)<<24)|((ord($hash[$offset+1])&0xff)<<16)|((ord($hash[$offset+2])&0xff)<<8)|(ord($hash[$offset+3])&0xff);
    return str_pad($code % 1000000, 6, '0', STR_PAD_LEFT);
}

function cfp_base32_decode( $input ) {
    $map = array_flip(str_split('ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'));
    $buf=''; $out='';
    foreach(str_split(strtoupper($input)) as $c){
        if(!isset($map[$c])) continue;
        $buf.=str_pad(decbin($map[$c]),5,'0',STR_PAD_LEFT);
    }
    foreach(str_split($buf,8) as $chunk){
        if(strlen($chunk)===8) $out.=chr(bindec($chunk));
    }
    return $out;
}

// Setup 2FA
add_action('wp_ajax_cfp_2fa_setup',        'cfp_ajax_2fa_setup');
add_action('wp_ajax_nopriv_cfp_2fa_setup', 'cfp_ajax_2fa_setup');
function cfp_ajax_2fa_setup() {
    check_ajax_referer('cfp_nonce','nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    $user  = cfp_get_user_by_email($email);
    if (!$user) wp_send_json_error(['msg'=>'Account not found.']);
    $secret = cfp_totp_generate_secret();
    global $wpdb;
    $wpdb->update(CFP_TABLE_USERS,['twofa_secret'=>$secret],['id'=>$user->id]);
    $site   = rawurlencode(get_bloginfo('name'));
    $email_enc = rawurlencode($email);
    $uri    = "otpauth://totp/{$site}:{$email_enc}?secret={$secret}&issuer={$site}";
    // QR code via Google Charts API
    $qr_url = "https://chart.googleapis.com/chart?chs=200x200&chld=M|0&cht=qr&chl=".urlencode($uri);
    wp_send_json_success(['secret'=>$secret,'qr_url'=>$qr_url,'uri'=>$uri,'msg'=>'Scan the QR code with your authenticator app, then enter a code to confirm.']);
}

// Confirm 2FA enable
add_action('wp_ajax_cfp_2fa_confirm',        'cfp_ajax_2fa_confirm');
add_action('wp_ajax_nopriv_cfp_2fa_confirm', 'cfp_ajax_2fa_confirm');
function cfp_ajax_2fa_confirm() {
    check_ajax_referer('cfp_nonce','nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    $code  = sanitize_text_field($_POST['code'] ?? '');
    $user  = cfp_get_user_by_email($email);
    if (!$user||empty($user->twofa_secret)) wp_send_json_error(['msg'=>'Setup 2FA first.']);
    if (!cfp_totp_verify($user->twofa_secret, $code)) wp_send_json_error(['msg'=>'Invalid code. Try again.']);
    global $wpdb;
    $wpdb->update(CFP_TABLE_USERS,['twofa_enabled'=>1],['id'=>$user->id]);
    wp_send_json_success(['msg'=>'✅ 2FA enabled! Your account is now protected.']);
}

// Disable 2FA
add_action('wp_ajax_cfp_2fa_disable',        'cfp_ajax_2fa_disable');
add_action('wp_ajax_nopriv_cfp_2fa_disable', 'cfp_ajax_2fa_disable');
function cfp_ajax_2fa_disable() {
    check_ajax_referer('cfp_nonce','nonce');
    $email = sanitize_email($_POST['email'] ?? '');
    $code  = sanitize_text_field($_POST['code'] ?? '');
    $user  = cfp_get_user_by_email($email);
    if (!$user) wp_send_json_error(['msg'=>'Account not found.']);
    if ($user->twofa_enabled && !cfp_totp_verify($user->twofa_secret,$code)) wp_send_json_error(['msg'=>'Invalid 2FA code.']);
    global $wpdb;
    $wpdb->update(CFP_TABLE_USERS,['twofa_enabled'=>0,'twofa_secret'=>''],['id'=>$user->id]);
    wp_send_json_success(['msg'=>'✅ 2FA disabled.']);
}

/* ============================================================
   SHORTCODE: [cfp_account_security]
   ============================================================ */
add_shortcode('cfp_account_security', function() {
    $nonce = wp_create_nonce('cfp_nonce');
    $ajax  = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget" id="cfp-sec-widget">
        <h2>🔒 Account Security</h2>
        <input class="cfp-input" type="email" id="cfp-sec-email" placeholder="Your account email">
        <div id="cfp-sec-msg"></div>
        <!-- Password -->
        <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:10px;padding:16px;margin-bottom:14px">
            <h3 style="font-family:'Oswald',sans-serif;color:#fff;font-size:.95rem;margin:0 0 12px;text-transform:uppercase;letter-spacing:1px">🔑 Password</h3>
            <input class="cfp-input" type="password" id="cfp-sec-cur" placeholder="Current password (leave blank if not set)">
            <input class="cfp-input" type="password" id="cfp-sec-new" placeholder="New password (min 8 characters)">
            <button class="cfp-btn-full" onclick="cfpSetPassword()">Set / Update Password</button>
        </div>
        <!-- 2FA -->
        <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:10px;padding:16px;margin-bottom:14px">
            <h3 style="font-family:'Oswald',sans-serif;color:#fff;font-size:.95rem;margin:0 0 12px;text-transform:uppercase;letter-spacing:1px">📱 Two-Factor Auth (2FA)</h3>
            <p style="font-size:.82rem;color:#555;margin-bottom:12px">Use Google Authenticator or Authy to generate time-based codes.</p>
            <button class="cfp-btn-full" onclick="cfpSetup2FA()" style="background:#3b82f6;margin-bottom:8px">Setup 2FA</button>
            <div id="cfp-2fa-setup" style="display:none;text-align:center;margin-bottom:12px">
                <img id="cfp-2fa-qr" src="" alt="QR Code" style="width:180px;height:180px;border:4px solid #fff;border-radius:8px;margin-bottom:8px">
                <div style="font-size:.72rem;color:#555;margin-bottom:8px">Or enter manually: <span id="cfp-2fa-secret" style="font-family:monospace;color:#f7931a"></span></div>
                <input class="cfp-input" type="text" id="cfp-2fa-code" placeholder="Enter 6-digit code to confirm" style="text-align:center;font-size:1.2rem;letter-spacing:4px">
                <button class="cfp-btn-full" onclick="cfpConfirm2FA()" style="background:#22c55e">✓ Confirm & Enable 2FA</button>
            </div>
            <input class="cfp-input" type="text" id="cfp-2fa-dis-code" placeholder="2FA code to disable" style="font-size:1.1rem;letter-spacing:3px;text-align:center">
            <button class="cfp-btn-full" onclick="cfpDisable2FA()" style="background:#ef4444">Disable 2FA</button>
        </div>
        <?php if(cfp_get_setting('email_verify_required','0')==='1'): ?>
        <button class="cfp-btn-full" onclick="cfpResendVerify()" style="background:#555">Resend Verification Email</button>
        <?php endif; ?>
    </div>
    <script>
    const cfpSecAjax='<?=esc_js($ajax)?>'; const cfpSecNonce='<?=esc_js($nonce)?>';
    function cfpSecMsg(msg,type='success'){document.getElementById('cfp-sec-msg').innerHTML=`<div class="cfp-msg ${type}">${msg}</div>`;}
    function cfpSecEmail(){return document.getElementById('cfp-sec-email').value;}
    async function cfpPost(action,extra={}){
        const fd=new FormData(); fd.append('action',action); fd.append('nonce',cfpSecNonce); fd.append('email',cfpSecEmail());
        Object.entries(extra).forEach(([k,v])=>fd.append(k,v));
        const r=await fetch(cfpSecAjax,{method:'POST',body:fd}); return r.json();
    }
    async function cfpSetPassword(){
        const d=await cfpPost('cfp_set_password',{current_password:document.getElementById('cfp-sec-cur').value,new_password:document.getElementById('cfp-sec-new').value});
        cfpSecMsg(d.data.msg,d.success?'success':'error');
    }
    async function cfpSetup2FA(){
        const d=await cfpPost('cfp_2fa_setup');
        if(!d.success){cfpSecMsg(d.data.msg,'error');return;}
        document.getElementById('cfp-2fa-qr').src=d.data.qr_url;
        document.getElementById('cfp-2fa-secret').textContent=d.data.secret;
        document.getElementById('cfp-2fa-setup').style.display='';
    }
    async function cfpConfirm2FA(){
        const d=await cfpPost('cfp_2fa_confirm',{code:document.getElementById('cfp-2fa-code').value});
        cfpSecMsg(d.data.msg,d.success?'success':'error');
        if(d.success) document.getElementById('cfp-2fa-setup').style.display='none';
    }
    async function cfpDisable2FA(){
        const d=await cfpPost('cfp_2fa_disable',{code:document.getElementById('cfp-2fa-dis-code').value});
        cfpSecMsg(d.data.msg,d.success?'success':'error');
    }
    async function cfpResendVerify(){
        const d=await cfpPost('cfp_resend_verify');
        cfpSecMsg(d.data.msg,d.success?'success':'error');
    }
    </script>
    <?php return ob_get_clean();
});
