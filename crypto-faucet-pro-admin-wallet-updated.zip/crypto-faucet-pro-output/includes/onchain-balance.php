<?php
/**
 * CFP On-Chain Balance Reader
 *
 * Queries the live on-chain balance of the configured Trezor / revenue address
 * directly from public block explorers (no API key required for BTC).
 *
 *   - BTC : Blockstream Esplora API     (https://blockstream.info/api)
 *           Fallback: mempool.space     (https://mempool.space/api)
 *   - ETH : reuses cfp_infura_get_balance() from etherscan-infura-api.php
 *
 * Results are cached for 60 seconds (transient) to avoid hammering APIs.
 *
 * Public API:
 *   cfp_onchain_get_balance( $address, $currency = 'BTC', $force_refresh = false )
 *       → [ 'balance_sat' => int, 'balance_coin' => float,
 *           'currency' => str, 'address' => str,
 *           'source' => str, 'cached_at' => int, 'error' => str|null ]
 *
 *   cfp_onchain_trezor_balance( $force_refresh = false )
 *       Convenience wrapper that uses the configured Trezor address + currency.
 *
 *   cfp_onchain_lifetime_earned()
 *       Sum of all positive entries in the admin-wallet ledger (lifetime off-chain earnings).
 *
 *   cfp_onchain_lifetime_swept()
 *       Sum of |negative| entries on the trezor_payout stream (already moved on-chain).
 *
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ============================================================
// LOW-LEVEL FETCHERS
// ============================================================

/**
 * Fetch BTC balance (in satoshis) from Blockstream Esplora, fallback mempool.space.
 *
 * @param string $address  BTC address (legacy / segwit / bech32)
 * @return array{balance_sat?:int, source?:string, error?:string}
 */
function cfp_onchain_btc_balance( string $address ): array {
    if ( $address === '' ) {
        return [ 'error' => 'No BTC address provided.' ];
    }

    $endpoints = [
        'blockstream'  => 'https://blockstream.info/api/address/' . rawurlencode( $address ),
        'mempoolspace' => 'https://mempool.space/api/address/'    . rawurlencode( $address ),
    ];

    $last_error = '';
    foreach ( $endpoints as $source => $url ) {
        $resp = wp_remote_get( $url, [
            'timeout' => 8,
            'headers' => [ 'Accept' => 'application/json' ],
        ] );

        if ( is_wp_error( $resp ) ) {
            $last_error = $resp->get_error_message();
            continue;
        }

        $code = (int) wp_remote_retrieve_response_code( $resp );
        if ( $code !== 200 ) {
            $last_error = "HTTP {$code} from {$source}";
            continue;
        }

        $body = json_decode( wp_remote_retrieve_body( $resp ), true );
        if ( ! is_array( $body ) || ! isset( $body['chain_stats'] ) ) {
            $last_error = "Malformed response from {$source}";
            continue;
        }

        $funded = (int) ( $body['chain_stats']['funded_txo_sum'] ?? 0 );
        $spent  = (int) ( $body['chain_stats']['spent_txo_sum']  ?? 0 );

        // Include unconfirmed (mempool) balance too — useful for "just swept" funds.
        $mp_funded = (int) ( $body['mempool_stats']['funded_txo_sum'] ?? 0 );
        $mp_spent  = (int) ( $body['mempool_stats']['spent_txo_sum']  ?? 0 );

        $confirmed_sat   = max( 0, $funded - $spent );
        $unconfirmed_sat = ( $mp_funded - $mp_spent );

        return [
            'balance_sat'      => $confirmed_sat,
            'unconfirmed_sat'  => $unconfirmed_sat,
            'total_sat'        => $confirmed_sat + max( 0, $unconfirmed_sat ),
            'tx_count'         => (int) ( $body['chain_stats']['tx_count'] ?? 0 ),
            'source'           => $source,
        ];
    }

    return [ 'error' => 'All BTC explorers failed. Last error: ' . $last_error ];
}

/**
 * Fetch native ETH balance for an address. Re-uses the Infura helper if available.
 *
 * @param string $address  0x-prefixed EVM address
 * @return array{balance_sat?:int, balance_eth?:float, source?:string, error?:string}
 */
function cfp_onchain_eth_balance( string $address ): array {
    if ( $address === '' ) {
        return [ 'error' => 'No ETH address provided.' ];
    }
    if ( ! function_exists( 'cfp_infura_get_balance' ) ) {
        return [ 'error' => 'Infura helper not loaded. Configure web3_infura_api_key in Web3 settings.' ];
    }

    $res = cfp_infura_get_balance( $address );
    if ( ! empty( $res['error'] ) ) {
        return [ 'error' => $res['error'] ];
    }

    // Express ETH in "sat-equivalents" using 1 ETH = 1e8 sat-equivalents (so the
    // existing UI which speaks in `sat` keeps working). The real wei value is
    // also returned for accuracy.
    $eth = (float) ( $res['balance_eth'] ?? 0 );
    return [
        'balance_sat'  => (int) round( $eth * 1e8 ),
        'balance_eth'  => $eth,
        'balance_wei'  => $res['balance_wei'] ?? '0',
        'source'       => 'infura',
    ];
}

// ============================================================
// PUBLIC API
// ============================================================

/**
 * Get a normalized on-chain balance for any supported currency, with caching.
 *
 * @param string $address        Destination wallet address.
 * @param string $currency       'BTC' or 'ETH' (case-insensitive). Default 'BTC'.
 * @param bool   $force_refresh  Bypass the 60s cache.
 * @return array
 */
function cfp_onchain_get_balance( string $address, string $currency = 'BTC', bool $force_refresh = false ): array {
    $currency = strtoupper( trim( $currency ) ?: 'BTC' );
    $address  = trim( $address );

    if ( $address === '' ) {
        return [
            'balance_sat'  => 0,
            'balance_coin' => 0.0,
            'currency'     => $currency,
            'address'      => '',
            'source'       => null,
            'cached_at'    => 0,
            'error'        => 'No address configured.',
        ];
    }

    $cache_key = 'cfp_onchain_bal_' . md5( $currency . '|' . $address );
    if ( ! $force_refresh ) {
        $cached = get_transient( $cache_key );
        if ( is_array( $cached ) ) return $cached;
    }

    $raw = ( $currency === 'ETH' )
        ? cfp_onchain_eth_balance( $address )
        : cfp_onchain_btc_balance( $address );

    if ( ! empty( $raw['error'] ) ) {
        $out = [
            'balance_sat'  => 0,
            'balance_coin' => 0.0,
            'currency'     => $currency,
            'address'      => $address,
            'source'       => null,
            'cached_at'    => time(),
            'error'        => $raw['error'],
        ];
        // Cache failures briefly (15s) so a dead explorer doesn't block the UI.
        set_transient( $cache_key, $out, 15 );
        return $out;
    }

    $sat  = (int) ( $raw['balance_sat'] ?? 0 );
    $coin = $sat / 1e8;

    $out = [
        'balance_sat'      => $sat,
        'balance_coin'     => $coin,
        'unconfirmed_sat'  => (int) ( $raw['unconfirmed_sat'] ?? 0 ),
        'total_sat'        => (int) ( $raw['total_sat']       ?? $sat ),
        'tx_count'         => (int) ( $raw['tx_count']        ?? 0 ),
        'currency'         => $currency,
        'address'          => $address,
        'source'           => $raw['source'] ?? null,
        'cached_at'        => time(),
        'error'            => null,
    ];

    set_transient( $cache_key, $out, 60 );
    return $out;
}

/**
 * Convenience: get the on-chain balance of the configured Trezor address.
 */
function cfp_onchain_trezor_balance( bool $force_refresh = false ): array {
    $addr     = function_exists( 'cfp_trezor_address' ) ? cfp_trezor_address() : trim( cfp_get_setting( 'trezor_active_address', '' ) );
    $currency = strtoupper( cfp_get_setting( 'faucet_currency', cfp_get_setting( 'blockchain_currency', 'BTC' ) ) );
    return cfp_onchain_get_balance( $addr, $currency, $force_refresh );
}

/**
 * Lifetime off-chain earnings (positive ledger entries, in sat).
 */
function cfp_onchain_lifetime_earned(): int {
    global $wpdb;
    if ( ! defined( 'CFP_TABLE_ADMIN_WALLET' ) ) return 0;
    return (int) $wpdb->get_var(
        "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE amount_sat > 0"
    );
}

/**
 * Lifetime amount already moved on-chain (|negative entries on trezor_payout|, in sat).
 */
function cfp_onchain_lifetime_swept(): int {
    global $wpdb;
    if ( ! defined( 'CFP_TABLE_ADMIN_WALLET' ) ) return 0;
    return (int) abs( (int) $wpdb->get_var(
        "SELECT COALESCE(SUM(amount_sat),0)
           FROM " . CFP_TABLE_ADMIN_WALLET . "
          WHERE stream = 'trezor_payout'"
    ) );
}

// ============================================================
// AJAX — refresh on-chain balance from the admin UI
// ============================================================

add_action( 'wp_ajax_cfp_onchain_refresh', 'cfp_ajax_onchain_refresh' );
function cfp_ajax_onchain_refresh() {
    if ( ! current_user_can( 'manage_options' ) ) wp_send_json_error( 'Permission denied.', 403 );
    if ( ! check_ajax_referer( 'cfp_trezor_sweep_nonce', 'nonce', false ) ) {
        wp_send_json_error( 'Nonce failed.' );
    }
    $data = cfp_onchain_trezor_balance( true );
    wp_send_json_success( $data );
}

// ============================================================
// AJAX — Convert off-chain ledger balance to on-chain (admin wallet)
// ============================================================

add_action( 'wp_ajax_cfp_convert_offchain_to_onchain', 'cfp_ajax_convert_offchain_to_onchain' );
/**
 * Trigger a real sweep of the specified sat amount from the admin-wallet
 * ledger onto the configured Trezor / revenue address.
 *
 * POST params:
 *   nonce      — cfp_trezor_sweep_nonce
 *   amount_sat — integer, satoshis to convert; 0 = full pending balance
 */
function cfp_ajax_convert_offchain_to_onchain() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Permission denied.', 403 );
    }
    if ( ! check_ajax_referer( 'cfp_trezor_sweep_nonce', 'nonce', false ) ) {
        wp_send_json_error( 'Nonce verification failed.' );
    }

    // Require the sweep engine
    if ( ! function_exists( 'cfp_trezor_do_sweep' ) ) {
        wp_send_json_error( 'Sweep engine not loaded. Make sure trezor-sweep.php is included.' );
    }

    $amount_sat = max( 0, (int) ( $_POST['amount_sat'] ?? 0 ) );

    // Validate against actual pending balance
    $pending = function_exists( 'cfp_trezor_pending_balance' ) ? cfp_trezor_pending_balance() : 0;
    if ( $pending <= 0 ) {
        wp_send_json_error( 'No off-chain balance available to convert.' );
    }
    if ( $amount_sat > $pending ) {
        wp_send_json_error( sprintf(
            'Requested %s sat exceeds pending off-chain balance of %s sat.',
            number_format( $amount_sat ),
            number_format( $pending )
        ) );
    }

    // Perform the sweep — 'manual_sweep' bypasses the threshold check
    $result = cfp_trezor_do_sweep( $amount_sat ?: $pending, 'manual_sweep' );

    if ( ! empty( $result['success'] ) ) {
        wp_send_json_success( [
            'message'    => $result['message'] ?? sprintf(
                'Successfully initiated on-chain conversion of %s sat.',
                number_format( $amount_sat ?: $pending )
            ),
            'queue_id'   => $result['queue_id'] ?? null,
            'amount_sat' => $amount_sat ?: $pending,
        ] );
    } else {
        wp_send_json_error( $result['message'] ?? 'Sweep failed — check the Trezor sweep log.' );
    }
}
