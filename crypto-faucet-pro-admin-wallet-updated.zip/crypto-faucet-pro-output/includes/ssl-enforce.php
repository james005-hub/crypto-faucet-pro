<?php
/**
 * SSL / HTTPS Enforcement
 *
 * - Redirects all frontend HTTP traffic to HTTPS (301)
 * - Sets security headers on every response:
 *     HSTS, X-Frame-Options, X-Content-Type-Options,
 *     Referrer-Policy, Permissions-Policy, Content-Security-Policy (configurable)
 * - Blocks AJAX requests arriving over plain HTTP
 * - Admin toggle in Security settings: ssl_enforce_enabled
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   HTTPS REDIRECT (frontend only — never redirect wp-admin)
   ============================================================ */
add_action('template_redirect', 'cfp_enforce_https', 1);
function cfp_enforce_https() {
    if ( cfp_get_setting('ssl_enforce_enabled','1') !== '1' ) return;
    if ( is_ssl() ) return;
    if ( is_admin() ) return;

    // Build the HTTPS equivalent of the current URL
    $url = 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
    wp_redirect( $url, 301 );
    exit;
}

/* ============================================================
   SECURITY HEADERS (sent on every WP response)
   ============================================================ */
// Security headers sent by security-headers.php (cfp_send_security_headers)

/* ============================================================
   BLOCK AJAX OVER HTTP
   ============================================================ */
add_action('wp_ajax_nopriv_cfp_check_https', 'cfp_ajax_require_https');
add_action('wp_ajax_cfp_check_https',        'cfp_ajax_require_https');
function cfp_ajax_require_https() {
    // This action is just a helper — real enforcement below
}

// Run before all CFP AJAX handlers
add_action('admin_init', 'cfp_block_ajax_over_http', 1);
add_action('init',       'cfp_block_ajax_over_http', 1);
function cfp_block_ajax_over_http() {
    if ( cfp_get_setting('ssl_enforce_enabled','1') !== '1' ) return;
    if ( ! wp_doing_ajax() ) return;
    if ( is_ssl() ) return;

    $action = sanitize_text_field($_POST['action'] ?? $_GET['action'] ?? '');
    // Only block CFP actions
    if ( strpos($action, 'cfp_') === 0 ) {
        wp_send_json_error(['msg' => '🔒 Secure connection required. Please access the site over HTTPS.']);
    }
}
