<?php
/**
 * AJAX handlers: buy lottery tickets, fun tokens, premium; log ad revenue
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action('wp_ajax_cfp_buy_lottery_ticket','cfp_ajax_buy_lottery_ticket');
function cfp_ajax_buy_lottery_ticket() {
    check_ajax_referer('cfp_nonce','nonce');
    
    // IDOR protection
    $user = cfp_require_auth();
    
    if(!cfp_get_setting('lottery_ticket_sale_enabled','1')) wp_send_json_error(['msg'=>'Lottery ticket sales are disabled.']);
    $qty   = max(1, min(100, intval($_POST['qty']??1)));
    global $wpdb;
    $price = intval(cfp_get_setting('lottery_ticket_price_sat',500));
    $total = $price * $qty;
    $lottery = $wpdb->get_row("SELECT id FROM ".CFP_TABLE_LOTTERY." WHERE status='active' ORDER BY id DESC LIMIT 1");
    if(!$lottery) wp_send_json_error(['msg'=>'No active lottery found.']);
    // FIX #8: Atomic conditional UPDATE prevents race conditions. The stale
    // balance check is replaced by a WHERE balance_sat>=%d guard so concurrent
    // requests cannot both succeed on the same balance.
    $rows = $wpdb->query($wpdb->prepare(
        "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d, lottery_tickets=lottery_tickets+%d WHERE id=%d AND balance_sat>=%d",
        $total, $qty, $user->id, $total
    ));
    if($rows === 0) wp_send_json_error(['msg'=>"Insufficient balance. Need {$total} sat for {$qty} ticket(s)."]);
    for($i=0;$i<$qty;$i++) {
        $wpdb->insert(CFP_TABLE_LOTTERY_TICKETS,['lottery_id'=>$lottery->id,'user_id'=>$user->id,'ticket_number'=>random_int(1000000,9999999)]);
    }
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>'lottery_ticket_purchase','amount_sat'=>-$total,'description'=>"Purchased {$qty} lottery ticket(s)"]);
    cfp_wallet_credit_game('admin_wallet_stream_lottery_tickets', 'lottery_ticket_sales', $total, "Lottery ticket sale: {$qty} tickets at {$price} sat each, user #{$user->id}");
    wp_send_json_success(['msg'=>"🎟 Purchased {$qty} lottery ticket(s) for {$total} sat!",'qty'=>$qty,'cost'=>$total]);
}

/* ============================================================
   AJAX: BUY FUN TOKEN
   ============================================================ */
add_action('wp_ajax_cfp_buy_fun_token','cfp_ajax_buy_fun_token');
function cfp_ajax_buy_fun_token() {
    check_ajax_referer('cfp_nonce','nonce');
    
    // IDOR protection
    $user = cfp_require_auth();
    
    $amount = floatval($_POST['amount']??0);
    if($amount <= 0) wp_send_json_error(['msg'=>'Invalid amount.']);
    global $wpdb;
    $price_sat = intval(cfp_get_setting('fun_token_price_sat',100));
    $cost_sat  = (int)ceil($amount * $price_sat);
    if($user->balance_sat < $cost_sat) wp_send_json_error(['msg'=>"Insufficient balance. Need {$cost_sat} sat."]); // pre-flight only
    $token_name = cfp_get_setting('fun_token_name','FUN');
    // ATOMIC: deduct with balance guard to prevent race conditions
    $deducted = $wpdb->query($wpdb->prepare(
        "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $cost_sat, $user->id, $cost_sat
    ));
    if ( $deducted === 0 ) wp_send_json_error(['msg'=>"Insufficient balance. Need {$cost_sat} sat."]);
    $wpdb->insert(CFP_TABLE_FUN_TOKENS,['user_id'=>$user->id,'type'=>'purchase','amount'=>$amount,'price_sat'=>$price_sat,'description'=>"Purchased {$amount} {$token_name} tokens"]);
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>'fun_token_purchase','amount_sat'=>-$cost_sat,'description'=>"Bought {$amount} {$token_name} @ {$price_sat} sat each"]);
    cfp_wallet_credit_game('admin_wallet_stream_fun_tokens', 'fun_token_sales', $cost_sat, "FUN token sale: {$amount} {$token_name} tokens to user #{$user->id}");
    do_action('cfp_after_fun_token_purchase', $user->id, $amount, $price_sat, $cost_sat);
    wp_send_json_success(['msg'=>"✅ Purchased {$amount} {$token_name} tokens for {$cost_sat} sat!"]);
}

/* ============================================================
   AJAX: BUY PREMIUM MEMBERSHIP
   ============================================================ */
add_action('wp_ajax_cfp_buy_premium','cfp_ajax_buy_premium');
function cfp_ajax_buy_premium() {
    check_ajax_referer('cfp_nonce','nonce');
    
    // IDOR protection
    $user = cfp_require_auth();
    
    $tier  = sanitize_text_field($_POST['tier']??'silver');
    if(!in_array($tier,['silver','gold','platinum'])) wp_send_json_error(['msg'=>'Invalid tier.']);
    global $wpdb;
    $price_sat = intval(cfp_get_setting("premium_{$tier}_sat", $tier==='silver'?50000:($tier==='gold'?100000:200000)));
    $days      = intval(cfp_get_setting("premium_{$tier}_days",30));
    if($user->balance_sat < $price_sat) wp_send_json_error(['msg'=>"Insufficient balance. Need ".number_format($price_sat)." sat."]); // pre-flight only
    $expires = date('Y-m-d H:i:s', strtotime("+{$days} days"));
    // ATOMIC: deduct with balance guard to prevent race conditions
    $deducted = $wpdb->query($wpdb->prepare(
        "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat-%d WHERE id=%d AND balance_sat>=%d",
        $price_sat, $user->id, $price_sat
    ));
    if ( $deducted === 0 ) wp_send_json_error(['msg'=>"Insufficient balance. Need ".number_format($price_sat)." sat."]);
    $wpdb->insert(CFP_TABLE_PREMIUM,['user_id'=>$user->id,'tier'=>$tier,'price_sat'=>$price_sat,'expires_at'=>$expires]);
    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$user->id,'type'=>'premium_purchase','amount_sat'=>-$price_sat,'description'=>ucfirst($tier)." Premium membership ({$days} days)"]);
    cfp_wallet_credit_game('admin_wallet_stream_premium', 'premium_membership', $price_sat, "Premium {$tier} purchased by user #{$user->id} for {$days} days");
    wp_send_json_success(['msg'=>"⭐ ".ucfirst($tier)." Premium activated for {$days} days!",'tier'=>$tier,'expires'=>$expires]);
}

/* ============================================================
   AJAX: LOG AD REVENUE (admin-only manual entry)
   ============================================================ */
add_action('wp_ajax_cfp_log_ad_revenue','cfp_ajax_log_ad_revenue');
function cfp_ajax_log_ad_revenue() {
    if(!current_user_can('manage_options')) wp_send_json_error(['msg'=>'Unauthorized.']);
    check_ajax_referer('cfp_admin_nonce','nonce');
    $network = sanitize_text_field($_POST['network']??'');
    $amount  = intval($_POST['amount']??0);
    $period  = sanitize_text_field($_POST['period']??'');
    $notes   = sanitize_textarea_field($_POST['notes']??'');
    if($amount <= 0 || empty($network)) wp_send_json_error(['msg'=>'Network and amount required.']);
    global $wpdb;
    $wpdb->insert(CFP_TABLE_AD_REVENUE,['network'=>$network,'amount_sat'=>$amount,'period_label'=>$period,'notes'=>$notes]);
    cfp_wallet_credit_game('admin_wallet_stream_advertising', 'advertising', $amount, "Ad revenue from {$network}: {$period}");
    wp_send_json_success(['msg'=>"✅ Logged {$amount} sat ad revenue from {$network}."]);
}

/* ============================================================
   ADMIN: FEES & RATES
   ============================================================ */
function cfp_admin_fees() {
    global $wpdb;
    $notice = '';

    if ( isset($_POST['cfp_save_fees']) && check_admin_referer('cfp_fees') ) {
        $fields = [
            // Withdrawal
            'min_withdraw_sat', 'withdraw_fee_sat',
            // Coinbase
            'blockchain_min_withdraw', 'blockchain_fee_sat',
            // Faucet / referral
            'referral_percent', 'min_claim_sat', 'max_claim_sat',
            // Savings
            'savings_apy',
            // Games (house edge)
            'multiply_house_edge', 'slots_house_edge', 'coinflip_house_edge',
            'dice_house_edge', 'crash_house_edge', 'wheel_house_edge',
            // Premium tiers
            'premium_silver_sat', 'premium_silver_days',
            'premium_gold_sat',   'premium_gold_days',
            'premium_platinum_sat','premium_platinum_days',
            // FUN token
            'fun_token_price_sat',
            // Lottery tickets
            'lottery_ticket_price_sat',
            // Trezor sweep threshold
            'trezor_sweep_threshold',
            // Interest spread
            'interest_spread_rate',
        ];
        foreach ( $fields as $f ) {
            if ( isset($_POST[$f]) ) {
                cfp_update_setting($f, sanitize_text_field($_POST[$f]));
            }
        }
        $notice = "<div class='cfp-notice success'>&#9989; Fees &amp; rates saved successfully!</div>";
    }

    // Load all current values
    $s = [];
    $all_fields = [
        'min_withdraw_sat','withdraw_fee_sat',
        'blockchain_min_withdraw','blockchain_fee_sat',
        'referral_percent','min_claim_sat','max_claim_sat',
        'savings_apy','interest_spread_rate',
        'multiply_house_edge','slots_house_edge','coinflip_house_edge',
        'dice_house_edge','crash_house_edge','wheel_house_edge',
        'premium_silver_sat','premium_silver_days',
        'premium_gold_sat','premium_gold_days',
        'premium_platinum_sat','premium_platinum_days',
        'fun_token_price_sat','lottery_ticket_price_sat',
        'trezor_sweep_threshold',
    ];
    $defaults = [
        'min_withdraw_sat'=>30000,'withdraw_fee_sat'=>1000,
        'blockchain_min_withdraw'=>1000,'blockchain_fee_sat'=>0,
        'referral_percent'=>50,'min_claim_sat'=>98,'max_claim_sat'=>200,
        'savings_apy'=>4.08,'interest_spread_rate'=>2.0,
        'multiply_house_edge'=>1,'slots_house_edge'=>5,'coinflip_house_edge'=>2,
        'dice_house_edge'=>2,'crash_house_edge'=>5,'wheel_house_edge'=>3,
        'premium_silver_sat'=>50000,'premium_silver_days'=>30,
        'premium_gold_sat'=>100000,'premium_gold_days'=>30,
        'premium_platinum_sat'=>200000,'premium_platinum_days'=>30,
        'fun_token_price_sat'=>100,'lottery_ticket_price_sat'=>500,
        'trezor_sweep_threshold'=>100000,
    ];
    foreach ($all_fields as $k) $s[$k] = cfp_get_setting($k, $defaults[$k] ?? '');

    $btc_price = intval(cfp_get_setting('btc_usd_price', 67694));
    $currency  = cfp_get_setting('faucet_currency', 'BTC');
    $fp_enabled= cfp_get_setting('blockchain_enabled', '0');

    // Helper: sat to USD string
    $usd = function($sat) use ($btc_price) {
        $v = $sat / 100000000 * $btc_price;
        return $v >= 0.01 ? '$'.number_format($v, 2) : '<$0.01';
    };
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">&#9889; CFP</span>
            <h1>Fees &amp; Rates</h1>
            <span style="margin-left:auto;font-size:.8rem;color:var(--mt)">@ $<?=number_format($btc_price)?>/<?=$currency?></span>
        </div>

        <?=$notice?>

        <form method="post">
            <?php wp_nonce_field('cfp_fees'); ?>

            <!-- ── WITHDRAWAL FEES ──────────────────────────── -->
            <div class="cfp-card" style="margin-bottom:20px">
                <h2 style="display:flex;align-items:center;gap:9px;font-size:1rem;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--br)">
                    <span style="background:#888;color:#fff;padding:3px 9px;border-radius:5px;font-size:.7rem;font-weight:800">WITHDRAW</span>
                    Withdrawal Fees
                </h2>
                <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
                    <div class="cfp-field">
                        <label>Minimum Withdrawal (sat)</label>
                        <input type="number" name="min_withdraw_sat" value="<?=esc_attr($s['min_withdraw_sat'])?>" min="0" step="100"
                            style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 12px;border-radius:8px;width:100%"
                            oninput="cfpFeePreview(this,'prev-min-wd')">
                        <span class="hint" id="prev-min-wd" style="color:#3b82f6">&#8776; <?=$usd($s['min_withdraw_sat'])?> USD</span>
                    </div>
                    <div class="cfp-field">
                        <label>Withdrawal Fee (sat)</label>
                        <input type="number" name="withdraw_fee_sat" value="<?=esc_attr($s['withdraw_fee_sat'])?>" min="0" step="100"
                            style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 12px;border-radius:8px;width:100%"
                            oninput="cfpFeePreview(this,'prev-wd-fee')">
                        <span class="hint" id="prev-wd-fee" style="color:#3b82f6">&#8776; <?=$usd($s['withdraw_fee_sat'])?> USD</span>
                    </div>
                </div>
            </div>

            <!-- ── FAUCETPAY FEES ───────────────────────────── -->
            <div class="cfp-card" style="margin-bottom:20px;border-color:<?=$fp_enabled?'#22c55e33':'var(--br)'?>">
                <h2 style="display:flex;align-items:center;gap:9px;font-size:1rem;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--br)">
                    <span style="background:#22c55e;color:#000;padding:3px 9px;border-radius:5px;font-size:.7rem;font-weight:800">FAUCETPAY</span>
                    Coinbase Fees
                    <?php if(!$fp_enabled): ?><span style="font-size:.75rem;color:#444;font-weight:400">(Coinbase disabled — enable in Coinbase settings)</span><?php endif; ?>
                </h2>
                <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
                    <div class="cfp-field">
                        <label>Coinbase Minimum Withdrawal (sat)</label>
                        <input type="number" name="blockchain_min_withdraw" value="<?=esc_attr($s['blockchain_min_withdraw'])?>" min="1" step="100"
                            style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 12px;border-radius:8px;width:100%"
                            oninput="cfpFeePreview(this,'prev-fp-min')">
                        <span class="hint" id="prev-fp-min" style="color:#22c55e">&#8776; <?=$usd($s['blockchain_min_withdraw'])?> USD</span>
                    </div>
                    <div class="cfp-field">
                        <label>Coinbase Withdrawal Fee (sat)</label>
                        <input type="number" name="blockchain_fee_sat" value="<?=esc_attr($s['blockchain_fee_sat'])?>" min="0" step="100"
                            style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 12px;border-radius:8px;width:100%"
                            oninput="cfpFeePreview(this,'prev-fp-fee')">
                        <span class="hint" id="prev-fp-fee" style="color:#22c55e">0 = no fee charged to users</span>
                    </div>
                </div>
            </div>

            <!-- ── FAUCET & REFERRAL ────────────────────────── -->
            <div class="cfp-card" style="margin-bottom:20px">
                <h2 style="display:flex;align-items:center;gap:9px;font-size:1rem;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--br)">
                    <span style="background:var(--p);color:#000;padding:3px 9px;border-radius:5px;font-size:.7rem;font-weight:800">FAUCET</span>
                    Faucet &amp; Referral Rates
                </h2>
                <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
                    <div class="cfp-field">
                        <label>Min Claim Amount (sat)</label>
                        <input type="number" name="min_claim_sat" value="<?=esc_attr($s['min_claim_sat'])?>" min="1"
                            style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 12px;border-radius:8px;width:100%"
                            oninput="cfpFeePreview(this,'prev-min-claim')">
                        <span class="hint" id="prev-min-claim" style="color:var(--p)">&#8776; <?=$usd($s['min_claim_sat'])?> USD</span>
                    </div>
                    <div class="cfp-field">
                        <label>Max Claim Amount (sat)</label>
                        <input type="number" name="max_claim_sat" value="<?=esc_attr($s['max_claim_sat'])?>" min="1"
                            style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 12px;border-radius:8px;width:100%"
                            oninput="cfpFeePreview(this,'prev-max-claim')">
                        <span class="hint" id="prev-max-claim" style="color:var(--p)">&#8776; <?=$usd($s['max_claim_sat'])?> USD</span>
                    </div>
                    <div class="cfp-field">
                        <label>Referral Commission (%)</label>
                        <div style="position:relative">
                            <input type="number" name="referral_percent" value="<?=esc_attr($s['referral_percent'])?>" min="0" max="100" step="1"
                                style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 40px 10px 12px;border-radius:8px;width:100%">
                            <span style="position:absolute;right:12px;top:50%;transform:translateY(-50%);color:#555;font-size:.9rem;pointer-events:none">%</span>
                        </div>
                        <span class="hint">% of referred user's claims paid to referrer</span>
                    </div>
                </div>
            </div>

            <!-- ── SAVINGS & INTEREST ───────────────────────── -->
            <div class="cfp-card" style="margin-bottom:20px">
                <h2 style="display:flex;align-items:center;gap:9px;font-size:1rem;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--br)">
                    <span style="background:#a855f7;color:#fff;padding:3px 9px;border-radius:5px;font-size:.7rem;font-weight:800">SAVINGS</span>
                    Savings &amp; Interest Rates
                </h2>
                <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
                    <div class="cfp-field">
                        <label>Savings APY (%)</label>
                        <div style="position:relative">
                            <input type="number" name="savings_apy" value="<?=esc_attr($s['savings_apy'])?>" min="0" max="100" step="0.01"
                                style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 40px 10px 12px;border-radius:8px;width:100%">
                            <span style="position:absolute;right:12px;top:50%;transform:translateY(-50%);color:#555;font-size:.9rem;pointer-events:none">%</span>
                        </div>
                        <span class="hint">Annual percentage yield paid to users on savings</span>
                    </div>
                    <div class="cfp-field">
                        <label>Admin Interest Spread (%)</label>
                        <div style="position:relative">
                            <input type="number" name="interest_spread_rate" value="<?=esc_attr($s['interest_spread_rate'])?>" min="0" max="100" step="0.1"
                                style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 40px 10px 12px;border-radius:8px;width:100%">
                            <span style="position:absolute;right:12px;top:50%;transform:translateY(-50%);color:#555;font-size:.9rem;pointer-events:none">%</span>
                        </div>
                        <span class="hint">Admin earns this % above the APY paid to users</span>
                    </div>
                </div>
            </div>

            <!-- ── GAME HOUSE EDGES ─────────────────────────── -->
            <div class="cfp-card" style="margin-bottom:20px">
                <h2 style="display:flex;align-items:center;gap:9px;font-size:1rem;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--br)">
                    <span style="background:#ef4444;color:#fff;padding:3px 9px;border-radius:5px;font-size:.7rem;font-weight:800">GAMES</span>
                    Game House Edges
                    <span style="font-size:.76rem;font-weight:400;color:var(--mt);margin-left:4px">% the house retains per round</span>
                </h2>
                <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr))">
                    <?php
                    $games = [
                        'multiply_house_edge' => ['🎲','Hi-Lo','#f7931a'],
                        'slots_house_edge'    => ['🎰','Slots', '#a855f7'],
                        'coinflip_house_edge' => ['🪙','Coin Flip','#ffcc02'],
                        'dice_house_edge'     => ['🎲','Dice Roll','#22c55e'],
                        'crash_house_edge'    => ['📈','Crash','#ef4444'],
                        'wheel_house_edge'    => ['🎡','Wheel','#3b82f6'],
                    ];
                    foreach($games as $key => [$icon,$name,$color]):
                        $val = floatval($s[$key]);
                        $rtp = round(100 - $val, 2);
                    ?>
                    <div class="cfp-field">
                        <label style="display:flex;align-items:center;gap:6px">
                            <span><?=$icon?></span>
                            <span style="color:<?=$color?>"><?=$name?></span>
                        </label>
                        <div style="position:relative">
                            <input type="number" name="<?=$key?>" value="<?=esc_attr($val)?>" min="0" max="50" step="0.1"
                                style="background:#111;border:1px solid <?=$color?>33;color:<?=$color?>;padding:10px 40px 10px 12px;border-radius:8px;width:100%;font-weight:700"
                                oninput="cfpEdgePreview(this,'rtp-<?=$key?>')">
                            <span style="position:absolute;right:12px;top:50%;transform:translateY(-50%);color:#555;font-size:.9rem;pointer-events:none">%</span>
                        </div>
                        <span class="hint" id="rtp-<?=$key?>" style="color:<?=$color?>">RTP: <?=$rtp?>%</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- ── PREMIUM MEMBERSHIPS ─────────────────────── -->
            <div class="cfp-card" style="margin-bottom:20px">
                <h2 style="display:flex;align-items:center;gap:9px;font-size:1rem;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--br)">
                    <span style="background:#fbbf24;color:#000;padding:3px 9px;border-radius:5px;font-size:.7rem;font-weight:800">PREMIUM</span>
                    Premium Membership Pricing
                </h2>
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px">
                    <?php foreach(['silver'=>['🥈','#888888'],'gold'=>['🥇','#f7931a'],'platinum'=>['💎','#a78bfa']] as $tier=>[$ico,$col]):
                        $price = intval($s["premium_{$tier}_sat"]);
                        $days  = intval($s["premium_{$tier}_days"]);
                    ?>
                    <div style="background:#0d0d0d;border:1px solid <?=$col?>33;border-radius:10px;padding:16px">
                        <div style="display:flex;align-items:center;gap:8px;margin-bottom:14px">
                            <span style="font-size:1.4rem"><?=$ico?></span>
                            <span style="font-weight:700;color:<?=$col?>;text-transform:uppercase;font-size:.9rem"><?=$tier?></span>
                            <span style="margin-left:auto;font-size:.74rem;color:#444">&#8776; <?=$usd($price)?> USD</span>
                        </div>
                        <div class="cfp-field" style="margin-bottom:10px">
                            <label>Price (sat)</label>
                            <input type="number" name="premium_<?=$tier?>_sat" value="<?=esc_attr($price)?>" min="1"
                                style="background:#111;border:1px solid <?=$col?>33;color:<?=$col?>;padding:9px 12px;border-radius:7px;font-size:.9rem;font-weight:700;width:100%"
                                oninput="cfpFeePreview(this,'prev-prem-<?=$tier?>')">
                            <span class="hint" id="prev-prem-<?=$tier?>" style="color:<?=$col?>">&#8776; <?=$usd($price)?> USD</span>
                        </div>
                        <div class="cfp-field" style="margin:0">
                            <label>Duration (days)</label>
                            <input type="number" name="premium_<?=$tier?>_days" value="<?=esc_attr($days)?>" min="1"
                                style="background:#111;border:1px solid <?=$col?>33;color:var(--tx);padding:9px 12px;border-radius:7px;font-size:.9rem;width:100%">
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- ── TOKEN & TICKET PRICES ───────────────────── -->
            <div class="cfp-card" style="margin-bottom:20px">
                <h2 style="display:flex;align-items:center;gap:9px;font-size:1rem;margin-bottom:16px;padding-bottom:10px;border-bottom:1px solid var(--br)">
                    <span style="background:#06b6d4;color:#000;padding:3px 9px;border-radius:5px;font-size:.7rem;font-weight:800">TOKENS</span>
                    Token &amp; Ticket Prices
                </h2>
                <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
                    <div class="cfp-field">
                        <label>🪙 <?=cfp_get_setting('fun_token_name','FUN')?> Token Price (sat)</label>
                        <input type="number" name="fun_token_price_sat" value="<?=esc_attr($s['fun_token_price_sat'])?>" min="1"
                            style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 12px;border-radius:8px;width:100%"
                            oninput="cfpFeePreview(this,'prev-fun')">
                        <span class="hint" id="prev-fun" style="color:#06b6d4">&#8776; <?=$usd($s['fun_token_price_sat'])?> USD per token</span>
                    </div>
                    <div class="cfp-field">
                        <label>🎟 Lottery Ticket Price (sat)</label>
                        <input type="number" name="lottery_ticket_price_sat" value="<?=esc_attr($s['lottery_ticket_price_sat'])?>" min="1"
                            style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 12px;border-radius:8px;width:100%"
                            oninput="cfpFeePreview(this,'prev-ticket')">
                        <span class="hint" id="prev-ticket" style="color:#ffcc02">&#8276; <?=$usd($s['lottery_ticket_price_sat'])?> USD per ticket</span>
                    </div>
                    <div class="cfp-field">
                        <label>🔐 Trezor Sweep Threshold (sat)</label>
                        <input type="number" name="trezor_sweep_threshold" value="<?=esc_attr($s['trezor_sweep_threshold'])?>" min="1000" step="1000"
                            style="background:#111;border:1px solid #1dc92822;color:#1dc928;padding:10px 12px;border-radius:8px;width:100%;font-family:monospace"
                            oninput="cfpFeePreview(this,'prev-trezor')">
                        <span class="hint" id="prev-trezor" style="color:#1dc928">&#8276; <?=$usd($s['trezor_sweep_threshold'])?> USD</span>
                    </div>
                </div>
            </div>

            <!-- SAVE BAR -->
            <div style="position:sticky;bottom:0;background:var(--dk);border-top:1px solid var(--br);padding:16px 0;display:flex;align-items:center;gap:16px;margin-top:4px">
                <button type="submit" name="cfp_save_fees" class="cfp-btn cfp-btn-gold" style="font-size:1rem;padding:13px 32px;font-weight:900">
                    &#128190; Save All Fees &amp; Rates
                </button>
                <span style="font-size:.8rem;color:var(--mt)">Changes take effect immediately for all users</span>
                <a href="<?=admin_url('admin.php?page=cfp-settings')?>" style="margin-left:auto;font-size:.8rem;color:#444;text-decoration:none" onmouseover="this.style.color='var(--p)'" onmouseout="this.style.color='#444'">
                    &#8592; Back to Settings
                </a>
            </div>
        </form>
    </div>

    <script>
    const cfpBtcPrice = <?=$btc_price?>;
    function cfpFeePreview(inp, previewId) {
        var val = parseFloat(inp.value) || 0;
        var el  = document.getElementById(previewId);
        if (!el) return;
        var usd = val / 100000000 * cfpBtcPrice;
        el.textContent = usd >= 0.01
            ? '\u2248 $' + usd.toLocaleString(undefined, {minimumFractionDigits:2,maximumFractionDigits:4}) + ' USD'
            : (val > 0 ? '<$0.01 USD' : '0 USD');
    }
    function cfpEdgePreview(inp, previewId) {
        var val = parseFloat(inp.value) || 0;
        var el  = document.getElementById(previewId);
        if (!el) return;
        el.textContent = 'RTP: ' + (100 - val).toFixed(2) + '%';
    }
    </script>
    <?php
}

/* ============================================================
   ADMIN: REVENUE WALLET PAGE
   ============================================================ */
