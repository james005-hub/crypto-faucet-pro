<?php
/**
 * Admin Audit Log
 *
 * Records every admin setting change, user edit, manual payout,
 * IP ban, and withdrawal approval to a dedicated log table.
 *
 * Table: cfp_audit_log  (created in activation.php via cfp_maybe_create_audit_table())
 * Columns: id, admin_user_id, admin_email, action, details (JSON), ip, created_at
 *
 * Admin page: Settings → Audit Log  (shortcode in admin-menu.php)
 *
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define('CFP_TABLE_AUDIT_LOG', $GLOBALS['wpdb']->prefix . 'cfp_audit_log');

/* ============================================================
   SENSITIVE FIELDS — never written to the audit log in plaintext.
   FIX #7: API keys, secrets, and credentials are redacted before
           any settings save is logged.
   ============================================================ */
define( 'CFP_AUDIT_REDACTED_FIELDS', [
    'blockchain_api_key',
    'blockchain_ipn_secret',
    'nowpayments_api_key',
    'nowpayments_ipn_secret',
    'np_api_key',
    'np_ipn_secret',
    'recaptcha_secret_key',
    'recaptcha_site_key',
    'twofa_secret',
    'smtp_password',
    'smtp_pass',
    'api_key',
    'api_secret',
    'secret_key',
    'private_key',
] );

/* ============================================================
   TABLE CREATION (called on plugin activation / update)
   ============================================================ */
function cfp_maybe_create_audit_table() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    $sql = "CREATE TABLE IF NOT EXISTS " . CFP_TABLE_AUDIT_LOG . " (
        id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
        admin_id     BIGINT UNSIGNED NOT NULL DEFAULT 0,
        admin_email  VARCHAR(255)    NOT NULL DEFAULT '',
        action       VARCHAR(120)    NOT NULL DEFAULT '',
        details      LONGTEXT        NOT NULL DEFAULT '',
        ip           VARCHAR(64)     NOT NULL DEFAULT '',
        created_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id),
        KEY action (action),
        KEY admin_id (admin_id),
        KEY created_at (created_at)
    ) {$charset};";
    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta($sql);
}
add_action('plugins_loaded', 'cfp_maybe_create_audit_table');

/* ============================================================
   CORE LOG FUNCTION
   ============================================================ */
/**
 * Write an audit log entry.
 *
 * @param string $action   Short machine-readable label (e.g. 'setting_changed', 'user_banned')
 * @param array  $details  Key-value context (serialised as JSON)
 */
function cfp_audit_log( $action, array $details = [] ) {
    global $wpdb;
    $admin    = wp_get_current_user();
    $admin_id = $admin->ID ?? 0;
    $email    = $admin->user_email ?? 'system';

    $wpdb->insert( CFP_TABLE_AUDIT_LOG, [
        'admin_id'    => $admin_id,
        'admin_email' => $email,
        'action'      => sanitize_text_field($action),
        'details'     => wp_json_encode($details),
        'ip'          => function_exists('cfp_get_real_ip') ? cfp_get_real_ip() : sanitize_text_field($_SERVER['REMOTE_ADDR'] ?? ''),
        'created_at'  => current_time('mysql'),
    ]);
}

/* ============================================================
   HOOKS — capture admin setting saves automatically
   ============================================================ */

add_action('admin_init', 'cfp_audit_admin_saves');
function cfp_audit_admin_saves() {
    if ( ! current_user_can('manage_options') ) return;
    if ( ! isset($_POST['cfp_save_security'])
      && ! isset($_POST['cfp_save_games'])
      && ! isset($_POST['cfp_save_settings'])
      && ! isset($_POST['cfp_save_faucetpay'])
      && ! isset($_POST['cfp_save_currency'])
      && ! isset($_POST['cfp_save_pwa'])
    ) return;

    // Determine which settings page was saved
    $page = array_keys(array_filter([
        'security'  => isset($_POST['cfp_save_security']),
        'games'     => isset($_POST['cfp_save_games']),
        'general'   => isset($_POST['cfp_save_settings']),
        'faucetpay' => isset($_POST['cfp_save_faucetpay']),
        'currency'  => isset($_POST['cfp_save_currency']),
        'pwa'       => isset($_POST['cfp_save_pwa']),
    ]))[0] ?? 'unknown';

    // Capture only cfp_ prefixed POST fields (sanitised)
    $saved = [];
    foreach ($_POST as $k => $v) {
        if ( in_array($k, ['_wpnonce','_wp_http_referer','cfp_save_security','cfp_save_games','cfp_save_settings','cfp_save_faucetpay','cfp_save_currency','cfp_save_pwa']) ) continue;
        $saved[ sanitize_key($k) ] = is_array($v) ? array_map('sanitize_text_field',$v) : sanitize_text_field($v);
    }

    // FIX #7: Redact sensitive credential fields before writing to the log.
    foreach ( CFP_AUDIT_REDACTED_FIELDS as $sensitive_key ) {
        if ( isset( $saved[ $sensitive_key ] ) ) {
            $saved[ $sensitive_key ] = '[REDACTED]';
        }
    }
    // Also catch any field whose sanitized key contains 'key', 'secret', or 'password'
    // as a safety net for settings added in future without updating the list above.
    foreach ( $saved as $k => $v ) {
        if ( preg_match('/(api_key|secret|password|private_key)/i', $k) ) {
            $saved[ $k ] = '[REDACTED]';
        }
    }

    cfp_audit_log("settings_saved_{$page}", ['fields' => array_keys($saved), 'values' => $saved]);
}

// Log user bans (called manually from admin-users.php ban action)
add_action('cfp_user_banned', function($user_id, $reason='') {
    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare("SELECT email FROM ".CFP_TABLE_USERS." WHERE id=%d",$user_id));
    cfp_audit_log('user_banned', ['user_id'=>$user_id,'email'=>$user->email??'','reason'=>$reason]);
}, 10, 2);

// Log withdrawals approved/rejected (called from admin-wallet-fees.php)
add_action('cfp_withdrawal_approved', function($withdrawal_id, $user_id, $amount) {
    cfp_audit_log('withdrawal_approved', ['withdrawal_id'=>$withdrawal_id,'user_id'=>$user_id,'amount_sat'=>$amount]);
}, 10, 3);

add_action('cfp_withdrawal_rejected', function($withdrawal_id, $user_id, $amount) {
    cfp_audit_log('withdrawal_rejected', ['withdrawal_id'=>$withdrawal_id,'user_id'=>$user_id,'amount_sat'=>$amount]);
}, 10, 3);

// Log IP bans
add_action('cfp_ip_banned', function($ip, $reason='') {
    cfp_audit_log('ip_banned', ['ip'=>$ip,'reason'=>$reason]);
}, 10, 2);

// Log jackpot awards
add_action('cfp_jackpot_awarded', function($user_id, $amount) {
    cfp_audit_log('jackpot_awarded', ['user_id'=>$user_id,'amount_sat'=>$amount]);
}, 10, 2);

/* ============================================================
   ADMIN PAGE: Audit Log viewer
   ============================================================ */
function cfp_admin_audit_log() {
    global $wpdb;

    $per_page = 50;
    $page_num = max(1, intval($_GET['log_page'] ?? 1));
    $offset   = ($page_num - 1) * $per_page;
    $filter   = sanitize_text_field($_GET['log_action'] ?? '');

    $where  = $filter ? $wpdb->prepare(" WHERE action=%s", $filter) : '';
    $total  = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_AUDIT_LOG . $where);
    $rows   = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM " . CFP_TABLE_AUDIT_LOG . $where . " ORDER BY id DESC LIMIT %d OFFSET %d",
        $per_page, $offset
    ));

    $actions = $wpdb->get_col("SELECT DISTINCT action FROM " . CFP_TABLE_AUDIT_LOG . " ORDER BY action ASC");
    $pages   = ceil($total / $per_page);
    ?>
    <div class="cfp-wrap">
    <div class="cfp-header"><span class="cfp-logo-badge">⚡ CFP</span><h1>📋 Audit Log</h1></div>

    <div class="cfp-card" style="margin-bottom:18px">
        <form method="get" style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
            <input type="hidden" name="page" value="cfp-audit-log">
            <select name="log_action" style="background:#111;border:1px solid #222;color:#ccc;padding:7px 12px;border-radius:8px">
                <option value="">All actions</option>
                <?php foreach($actions as $a): ?>
                <option value="<?=esc_attr($a)?>" <?=selected($filter,$a,false)?>><?=esc_html($a)?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="cfp-btn">Filter</button>
            <?php if($filter): ?>
            <a href="<?=admin_url('admin.php?page=cfp-audit-log')?>" class="cfp-btn" style="background:#222">Clear</a>
            <?php endif; ?>
            <span style="color:#555;font-size:.82rem;margin-left:auto"><?=number_format($total)?> entries</span>
        </form>
    </div>

    <div class="cfp-card" style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;font-size:.83rem">
            <thead>
                <tr style="border-bottom:1px solid #222">
                    <th style="padding:8px 10px;text-align:left;color:#555;font-weight:600">Time</th>
                    <th style="padding:8px 10px;text-align:left;color:#555;font-weight:600">Admin</th>
                    <th style="padding:8px 10px;text-align:left;color:#555;font-weight:600">Action</th>
                    <th style="padding:8px 10px;text-align:left;color:#555;font-weight:600">IP</th>
                    <th style="padding:8px 10px;text-align:left;color:#555;font-weight:600">Details</th>
                </tr>
            </thead>
            <tbody>
            <?php if(empty($rows)): ?>
                <tr><td colspan="5" style="padding:20px;text-align:center;color:#444">No log entries found.</td></tr>
            <?php else: foreach($rows as $row):
                $details = json_decode($row->details, true) ?? [];
                $badge_color = match(true) {
                    str_contains($row->action,'ban')      => '#ef4444',
                    str_contains($row->action,'approve')  => '#22c55e',
                    str_contains($row->action,'reject')   => '#f7931a',
                    str_contains($row->action,'jackpot')  => '#ffcc02',
                    default                               => '#3b82f6',
                };
            ?>
                <tr style="border-bottom:1px solid #1a1a1a">
                    <td style="padding:8px 10px;color:#777;white-space:nowrap"><?=esc_html($row->created_at)?></td>
                    <td style="padding:8px 10px;color:#ccc"><?=esc_html($row->admin_email)?></td>
                    <td style="padding:8px 10px">
                        <span style="background:<?=$badge_color?>22;color:<?=$badge_color?>;border:1px solid <?=$badge_color?>44;border-radius:5px;padding:2px 8px;font-size:.75rem;white-space:nowrap"><?=esc_html($row->action)?></span>
                    </td>
                    <td style="padding:8px 10px;color:#555;font-family:monospace;font-size:.75rem"><?=esc_html($row->ip)?></td>
                    <td style="padding:8px 10px;color:#777;font-family:monospace;font-size:.72rem;max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=esc_attr(wp_json_encode($details))?>">
                        <?=esc_html(wp_json_encode($details))?>
                    </td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>

    <?php if($pages > 1): ?>
    <div style="display:flex;gap:8px;justify-content:center;margin-top:20px;flex-wrap:wrap">
        <?php for($p=1;$p<=$pages;$p++):
            // FIX #16: Use add_query_arg + esc_url to safely build pagination URLs.
            $page_url = esc_url( add_query_arg([
                'page'       => 'cfp-audit-log',
                'log_action' => $filter,
                'log_page'   => $p,
            ], admin_url('admin.php')) );
        ?>
        <a href="<?=$page_url?>"
           style="padding:6px 12px;border-radius:7px;border:1px solid <?=$p===$page_num?'#f7931a':'#222'?>;color:<?=$p===$page_num?'#f7931a':'#555'?>;font-size:.82rem;text-decoration:none"><?=$p?></a>
        <?php endfor; ?>
    </div>
    <?php endif; ?>
    </div>
    <?php
}

/* ============================================================
   CRON: Prune old audit entries (keep 90 days by default)
   ============================================================ */
add_action('cfp_daily_interest_hook', 'cfp_prune_audit_log');
function cfp_prune_audit_log() {
    $days = intval( cfp_get_setting('audit_log_retention_days', 90) );
    if ( $days <= 0 ) return;
    global $wpdb;
    $wpdb->query( $wpdb->prepare(
        "DELETE FROM " . CFP_TABLE_AUDIT_LOG . " WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
        $days
    ));
}
