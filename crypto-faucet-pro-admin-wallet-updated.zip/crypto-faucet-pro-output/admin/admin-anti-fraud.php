<?php
/**
 * Admin page: Anti-Fraud Automation
 * Part of Crypto Faucet Pro plugin.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_anti_fraud() {
    global $wpdb;
    $notice = '';

    if ( isset($_POST['cfp_save_anti_fraud']) && check_admin_referer('cfp_anti_fraud') ) {
        $fields = [
            'anti_fraud_enabled',
            'auto_ban_strikes',
            'max_login_attempts',
            'block_disposable_email',
            'require_strong_password',
            'bonus_abuse_detection',
            'multi_account_detection',
            'suspicious_winrate_threshold',
            'rapid_bet_detection',
            'stolen_card_detection',
            'fraud_score_threshold',
            'auto_freeze_high_risk',
            'manual_review_queue',
            'fraud_log_retention_days',
            'ip_fraud_weight',
            'email_fraud_weight',
            'device_fraud_weight',
            'behavior_fraud_weight',
        ];
        foreach ( $fields as $f ) {
            if ( isset($_POST[$f]) ) {
                cfp_update_setting($f, sanitize_text_field($_POST[$f]));
            }
        }
        
        if ( isset($_POST['fraud_blocked_ips']) ) {
            cfp_update_setting('fraud_blocked_ips', sanitize_textarea_field($_POST['fraud_blocked_ips']));
        }
        
        $notice = "<div class='cfp-notice success'>✅ Anti-fraud settings saved!</div>";
    }

    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };
    
    $fraud_events_today = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_IP_LIMITS . " WHERE hit_count >= 20 AND window_start >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
    $auto_banned_today = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_USERS . " WHERE is_banned = 1 AND updated_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
    
    $recent_fraud = $wpdb->get_results("
        SELECT u.username, u.email, u.ip_address, u.created_at, 'multiple_accounts' as reason
        FROM " . CFP_TABLE_USERS . " u
        WHERE u.is_banned = 1
        ORDER BY u.updated_at DESC
        LIMIT 10
    ");
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🛡️</span>
            <h1>🛡️ Anti-Fraud Automation</h1>
        </div>
        <?=$notice?>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px">
            <div class="cfp-stat-card <?=$gs('anti_fraud_enabled','1') === '1' ? 'green' : 'red'?>">
                <div class="label">Anti-Fraud</div>
                <div class="value"><?=$gs('anti_fraud_enabled','1') === '1' ? 'ACTIVE' : 'DISABLED'?></div>
            </div>
            <div class="cfp-stat-card red">
                <div class="label">Flagged Events (24h)</div>
                <div class="value"><?=$fraud_events_today?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Auto-Banned (24h)</div>
                <div class="value"><?=$auto_banned_today?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">Fraud Score Threshold</div>
                <div class="value"><?=$gs('fraud_score_threshold',70)?></div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field('cfp_anti_fraud'); ?>
            
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🛡️ Master Controls</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Anti-Fraud System</label>
                        <select name="anti_fraud_enabled">
                            <option value="1" <?=selected($gs('anti_fraud_enabled','1'),'1',false)?>>✅ Enabled</option>
                            <option value="0" <?=selected($gs('anti_fraud_enabled','1'),'0',false)?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Auto-Ban on Strikes</label>
                        <input type="number" name="auto_ban_strikes" value="<?=esc_attr($gs('auto_ban_strikes',3))?>" min="1" max="10">
                        <span class="hint">Strikes before auto-ban</span>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🔐 Account Security</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Max Login Attempts</label>
                        <input type="number" name="max_login_attempts" value="<?=esc_attr($gs('max_login_attempts',5))?>" min="3">
                        <span class="hint">Failed attempts before lockout</span>
                    </div>
                    <div class="cfp-field">
                        <label>Block Disposable Emails</label>
                        <select name="block_disposable_email">
                            <option value="1" <?=selected($gs('block_disposable_email','1'),'1',false)?>>✅ Yes - block temp emails</option>
                            <option value="0" <?=selected($gs('block_disposable_email','1'),'0',false)?>>⏸ Allow all</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Require Strong Password</label>
                        <select name="require_strong_password">
                            <option value="1" <?=selected($gs('require_strong_password','0'),'1',false)?>>✅ Yes - min 8 chars + number</option>
                            <option value="0" <?=selected($gs('require_strong_password','0'),'0',false)?>>⏸ No minimum</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🎰 Game Protection</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Bonus Abuse Detection</label>
                        <select name="bonus_abuse_detection">
                            <option value="1" <?=selected($gs('bonus_abuse_detection','1'),'1',false)?>>✅ Enabled - detect abuse patterns</option>
                            <option value="0" <?=selected($gs('bonus_abuse_detection','1'),'0',false)?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Multi-Account Detection</label>
                        <select name="multi_account_detection">
                            <option value="1" <?=selected($gs('multi_account_detection','1'),'1',false)?>>✅ Enabled - detect same IP accounts</option>
                            <option value="0" <?=selected($gs('multi_account_detection','1'),'0',false)?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Suspicious Win Rate (%)</label>
                        <input type="number" name="suspicious_winrate_threshold" value="<?=esc_attr($gs('suspicious_winrate_threshold',75))?>" min="50" max="100">
                        <span class="hint">Flag win rates above this</span>
                    </div>
                    <div class="cfp-field">
                        <label>Rapid Bet Detection (seconds)</label>
                        <input type="number" name="rapid_bet_detection" value="<?=esc_attr($gs('rapid_bet_detection',2))?>" min="0">
                        <span class="hint">Flag bets faster than this</span>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>📊 Fraud Scoring</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Fraud Score Threshold (0-100)</label>
                        <input type="number" name="fraud_score_threshold" value="<?=esc_attr($gs('fraud_score_threshold',70))?>" min="0" max="100">
                        <span class="hint">Score above this triggers block</span>
                    </div>
                    <div class="cfp-field">
                        <label>IP Address Weight</label>
                        <input type="number" name="ip_fraud_weight" value="<?=esc_attr($gs('ip_fraud_weight',30))?>" min="0" max="100">
                    </div>
                    <div class="cfp-field">
                        <label>Email Weight</label>
                        <input type="number" name="email_fraud_weight" value="<?=esc_attr($gs('email_fraud_weight',25))?>" min="0" max="100">
                    </div>
                    <div class="cfp-field">
                        <label>Device/Fingerprint Weight</label>
                        <input type="number" name="device_fraud_weight" value="<?=esc_attr($gs('device_fraud_weight',25))?>" min="0" max="100">
                    </div>
                    <div class="cfp-field">
                        <label>Behavior Pattern Weight</label>
                        <input type="number" name="behavior_fraud_weight" value="<?=esc_attr($gs('behavior_fraud_weight',20))?>" min="0" max="100">
                    </div>
                    <div class="cfp-field">
                        <label>Auto-Freeze High Risk</label>
                        <select name="auto_freeze_high_risk">
                            <option value="1" <?=selected($gs('auto_freeze_high_risk','1'),'1',false)?>>✅ Yes - freeze accounts above threshold</option>
                            <option value="0" <?=selected($gs('auto_freeze_high_risk','1'),'0',false)?>>⏸ Manual review only</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🚫 Manual Block List</h2>
                <div class="cfp-field">
                    <label>Blocked IP Addresses (one per line)</label>
                    <textarea name="fraud_blocked_ips" rows="5" style="width:100%;background:#111;border:1px solid #2a2a2a;color:#e8e8e8;padding:10px;border-radius:8px;font-family:monospace"><?=esc_textarea($gs('fraud_blocked_ips',''))?></textarea>
                    <span class="hint">Permanently blocked IPs (manual additions)</span>
                </div>
            </div>

            <button type="submit" name="cfp_save_anti_fraud" class="cfp-btn cfp-btn-gold">💾 Save Anti-Fraud Settings</button>
        </form>

        <div class="cfp-card" style="margin-top:22px">
            <h2>📜 Recent Fraud Events</h2>
            <?php if(!empty($recent_fraud)): ?>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead><tr><th>User</th><th>Email</th><th>IP</th><th>Reason</th><th>Date</th></tr></thead>
                    <tbody>
                    <?php foreach($recent_fraud as $f): ?>
                    <tr>
                        <td><strong><?=esc_html($f->username)?></strong></td>
                        <td style="font-size:.82rem"><?=esc_html($f->email)?></td>
                        <td style="font-family:monospace"><?=esc_html($f->ip_address ?? 'N/A')?></td>
                        <td><span class="cfp-badge rejected"><?=esc_html($f->reason)?></span></td>
                        <td style="color:var(--mt)"><?=date('M j, Y H:i', strtotime($f->created_at))?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p style="color:var(--mt);text-align:center;padding:20px">No recent fraud events detected.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php
}