<?php
/**
 * Admin page: VPN/Tor Blocking & Geo-Blocking
 * Part of Crypto Faucet Pro plugin.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_geo_block() {
    global $wpdb;
    $notice = '';

    if ( isset($_POST['cfp_save_geo_block']) && check_admin_referer('cfp_geo_block') ) {
        $fields = [
            'geo_block_enabled',
            'geo_block_games',
            'geo_block_withdrawals',
            'geo_block_claims',
            'geo_block_deposits',
            'block_datacenters',
            'block_vpns',
            'block_tor',
            'block_proxies',
            'block_vpn_tor',
            'geo_block_strict_mode',
            'geo_block_show_message',
            'geo_block_custom_message',
        ];
        foreach ( $fields as $f ) {
            if ( isset($_POST[$f]) ) {
                cfp_update_setting($f, sanitize_text_field($_POST[$f]));
            }
        }
        
        if ( isset($_POST['blocked_countries']) && is_array($_POST['blocked_countries']) ) {
            $countries = array_map('sanitize_text_field', $_POST['blocked_countries']);
            cfp_update_setting('blocked_countries', json_encode($countries));
        }
        
        if ( isset($_POST['blocked_regions']) && is_array($_POST['blocked_regions']) ) {
            $regions = array_map('sanitize_text_field', $_POST['blocked_regions']);
            cfp_update_setting('blocked_regions', json_encode($regions));
        }
        
        $notice = "<div class='cfp-notice success'>✅ Geo-blocking settings saved!</div>";
    }

    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };
    
    $blocked_countries = json_decode($gs('blocked_countries','[]'), true) ?: [];
    $blocked_regions = json_decode($gs('blocked_regions','[]'), true) ?: [];
    
    $blocked_today = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_IP_LIMITS . " WHERE hit_count >= 10 AND window_start >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
    
    $countries_list = [
        'US' => 'United States', 'GB' => 'United Kingdom', 'DE' => 'Germany', 'FR' => 'France',
        'CA' => 'Canada', 'AU' => 'Australia', 'JP' => 'Japan', 'KR' => 'South Korea',
        'CN' => 'China', 'RU' => 'Russia', 'IN' => 'India', 'BR' => 'Brazil',
        'AF' => 'Afghanistan', 'IR' => 'Iran', 'IQ' => 'Iraq', 'KP' => 'North Korea',
        'SY' => 'Syria', 'YE' => 'Yemen', 'SO' => 'Somalia', 'LY' => 'Libya',
        'VE' => 'Venezuela', 'CU' => 'Cuba', 'BY' => 'Belarus', 'MM' => 'Myanmar',
    ];
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🚫</span>
            <h1>🚫 VPN/Tor & Geo-Blocking</h1>
        </div>
        <?=$notice?>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px">
            <div class="cfp-stat-card <?=$gs('geo_block_enabled','0') === '1' ? 'green' : 'red'?>">
                <div class="label">Geo-Block Status</div>
                <div class="value"><?=$gs('geo_block_enabled','0') === '1' ? 'ACTIVE' : 'DISABLED'?></div>
            </div>
            <div class="cfp-stat-card red">
                <div class="label">Blocked Today</div>
                <div class="value"><?=$blocked_today?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">Countries Blocked</div>
                <div class="value"><?=count($blocked_countries)?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">Regions Blocked</div>
                <div class="value"><?=count($blocked_regions)?></div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field('cfp_geo_block'); ?>
            
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🌍 Master Controls</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Enable Geo-Blocking</label>
                        <select name="geo_block_enabled">
                            <option value="1" <?=selected($gs('geo_block_enabled','0'),'1',false)?>>✅ Enabled</option>
                            <option value="0" <?=selected($gs('geo_block_enabled','0'),'0',false)?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Strict Mode</label>
                        <select name="geo_block_strict_mode">
                            <option value="1" <?=selected($gs('geo_block_strict_mode','0'),'1',false)?>>🔒 Strict - block everything from blocked countries</option>
                            <option value="0" <?=selected($gs('geo_block_strict_mode','0'),'0',false)?>>🔓 Soft - allow with warning</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🌐 Country Blocking</h2>
                <p style="color:#777;font-size:.85rem;margin-bottom:14px">Select countries to block from accessing your faucet.</p>
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:8px;max-height:300px;overflow-y:auto;padding:10px;background:#111;border-radius:8px">
                    <?php foreach($countries_list as $code => $name): ?>
                    <label style="display:flex;align-items:center;gap:8px;padding:6px;background:#1a1a1a;border-radius:6px;cursor:pointer">
                        <input type="checkbox" name="blocked_countries[]" value="<?=$code?>" <?=in_array($code,$blocked_countries)?'checked':''?> style="width:16px;height:16px">
                        <span style="font-size:.82rem"><?=$name?></span>
                    </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🖥️ VPN/Tor/Proxy Blocking</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Block VPNs</label>
                        <select name="block_vpns">
                            <option value="1" <?=selected($gs('block_vpns','0'),'1',false)?>>✅ Block VPN IP ranges</option>
                            <option value="0" <?=selected($gs('block_vpns','0'),'0',false)?>>⏸ Allow</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Block Tor Exit Nodes</label>
                        <select name="block_tor">
                            <option value="1" <?=selected($gs('block_tor','0'),'1',false)?>>✅ Block Tor</option>
                            <option value="0" <?=selected($gs('block_tor','0'),'0',false)?>>⏸ Allow</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Block Proxies</label>
                        <select name="block_proxies">
                            <option value="1" <?=selected($gs('block_proxies','0'),'1',false)?>>✅ Block proxy servers</option>
                            <option value="0" <?=selected($gs('block_proxies','0'),'0',false)?>>⏸ Allow</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Block Data Centers</label>
                        <select name="block_datacenters">
                            <option value="1" <?=selected($gs('block_datacenters','0'),'1',false)?>>✅ Block AWS/DigitalOcean/etc</option>
                            <option value="0" <?=selected($gs('block_datacenters','0'),'0',false)?>>⏸ Allow</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🎯 Block Specific Features</h2>
                <p style="color:#777;font-size:.85rem;margin-bottom:14px">Apply geo/VPN blocking to specific features only.</p>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Block Games</label>
                        <select name="geo_block_games">
                            <option value="1" <?=selected($gs('geo_block_games','1'),'1',false)?>>✅ Yes - block casino games</option>
                            <option value="0" <?=selected($gs('geo_block_games','1'),'0',false)?>>⏸ No - allow games</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Block Withdrawals</label>
                        <select name="geo_block_withdrawals">
                            <option value="1" <?=selected($gs('geo_block_withdrawals','1'),'1',false)?>>✅ Yes - block withdrawals</option>
                            <option value="0" <?=selected($gs('geo_block_withdrawals','1'),'0',false)?>>⏸ No - allow</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Block Claims</label>
                        <select name="geo_block_claims">
                            <option value="1" <?=selected($gs('geo_block_claims','1'),'1',false)?>>✅ Yes - block faucet claims</option>
                            <option value="0" <?=selected($gs('geo_block_claims','1'),'0',false)?>>⏸ No - allow</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Block Deposits</label>
                        <select name="geo_block_deposits">
                            <option value="1" <?=selected($gs('geo_block_deposits','1'),'1',false)?>>✅ Yes - block deposits</option>
                            <option value="0" <?=selected($gs('geo_block_deposits','1'),'0',false)?>>⏸ No - allow</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>💬 Blocked Message</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field" style="grid-column:1/-1">
                        <label>Show Custom Blocked Message</label>
                        <select name="geo_block_show_message" onchange="document.getElementById('custom-msg-wrap').style.display=this.value=='1'?'block':'none'">
                            <option value="1" <?=selected($gs('geo_block_show_message','1'),'1',false)?>>✅ Yes - show message</option>
                            <option value="0" <?=selected($gs('geo_block_show_message','1'),'0',false)?>>⏸ No - show default</option>
                        </select>
                    </div>
                    <div id="custom-msg-wrap" style="grid-column:1/-1;display:<?=$gs('geo_block_show_message','1')==='1'?'block':'none'?>">
                        <label>Custom Block Message</label>
                        <textarea name="geo_block_custom_message" rows="3" style="width:100%;background:#111;border:1px solid #2a2a2a;color:#e8e8e8;padding:10px;border-radius:8px"><?=esc_textarea($gs('geo_block_custom_message','Your location is not allowed to access this feature. Please contact support for assistance.'))?></textarea>
                    </div>
                </div>
            </div>

            <button type="submit" name="cfp_save_geo_block" class="cfp-btn cfp-btn-gold">💾 Save Geo-Blocking Settings</button>
        </form>
    </div>
    <?php
}