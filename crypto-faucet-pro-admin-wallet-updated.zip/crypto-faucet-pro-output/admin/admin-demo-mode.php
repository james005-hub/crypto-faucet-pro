<?php
/**
 * Admin page: Demo Mode Configuration
 * Part of Crypto Faucet Pro plugin.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_demo_mode() {
    $notice = '';

    if ( isset($_POST['cfp_save_demo_mode']) && check_admin_referer('cfp_demo_mode') ) {
        $fields = [
            'demo_mode_enabled',
            'demo_mode_banner',
            'demo_mode_claim_amount',
            'demo_mode_max_claims',
            'demo_mode_game_multiplier',
            'demo_mode_show_notice',
            'demo_mode_notice_text',
            'demo_mode_restrict_withdrawals',
            'demo_mode_restrict_deposits',
            'demo_mode_test_users',
            'demo_mode_custom_label',
        ];
        foreach ( $fields as $f ) {
            if ( isset($_POST[$f]) ) {
                cfp_update_setting($f, sanitize_text_field($_POST[$f]));
            }
        }
        
        $notice = "<div class='cfp-notice success'>✅ Demo mode settings saved!</div>";
    }

    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🎮</span>
            <h1>🎮 Demo Mode Configuration</h1>
        </div>
        <?=$notice?>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px">
            <div class="cfp-stat-card <?=$gs('demo_mode_enabled','0') === '1' ? 'green' : 'red'?>">
                <div class="label">Demo Mode</div>
                <div class="value"><?=$gs('demo_mode_enabled','0') === '1' ? 'ACTIVE' : 'OFF'?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Test Users</div>
                <div class="value"><?=$gs('demo_mode_test_users','0') === '1' ? 'ON' : 'OFF'?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">Demo Claim</div>
                <div class="value"><?=number_format($gs('demo_mode_claim_amount',10))?> sat</div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">Game Multiplier</div>
                <div class="value"><?=$gs('demo_mode_game_multiplier',1)?>x</div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field('cfp_demo_mode'); ?>
            
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🎮 Master Controls</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Enable Demo Mode</label>
                        <select name="demo_mode_enabled">
                            <option value="1" <?=selected($gs('demo_mode_enabled','0'),'1',false)?>>✅ Enabled - Test mode active</option>
                            <option value="0" <?=selected($gs('demo_mode_enabled','0'),'0',false)?>>⏸ Disabled - Production mode</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Demo Mode Custom Label</label>
                        <input type="text" name="demo_mode_custom_label" value="<?=esc_attr($gs('demo_mode_custom_label','DEMO'))?>" placeholder="DEMO">
                        <span class="hint">Label shown on site</span>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>💰 Demo Economy</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Demo Claim Amount (sat)</label>
                        <input type="number" name="demo_mode_claim_amount" value="<?=esc_attr($gs('demo_mode_claim_amount',10))?>" min="1">
                        <span class="hint">Reduced amount for testing</span>
                    </div>
                    <div class="cfp-field">
                        <label>Max Claims Per User</label>
                        <input type="number" name="demo_mode_max_claims" value="<?=esc_attr($gs('demo_mode_max_claims',100))?>" min="1">
                        <span class="hint">Limit demo claims</span>
                    </div>
                    <div class="cfp-field">
                        <label>Game Payout Multiplier</label>
                        <input type="number" name="demo_mode_game_multiplier" value="<?=esc_attr($gs('demo_mode_game_multiplier',1))?>" min="0.1" step="0.1">
                        <span class="hint">Multiply payouts (0.1 = 10%)</span>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🚫 Feature Restrictions</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Restrict Withdrawals</label>
                        <select name="demo_mode_restrict_withdrawals">
                            <option value="1" <?=selected($gs('demo_mode_restrict_withdrawals','1'),'1',false)?>>✅ Yes - block real withdrawals</option>
                            <option value="0" <?=selected($gs('demo_mode_restrict_withdrawals','1'),'0',false)?>>⏸ No - allow</option>
                        </select>
                        <span class="hint">Show "Demo mode" message instead</span>
                    </div>
                    <div class="cfp-field">
                        <label>Restrict Deposits</label>
                        <select name="demo_mode_restrict_deposits">
                            <option value="1" <?=selected($gs('demo_mode_restrict_deposits','1'),'1',false)?>>✅ Yes - block real deposits</option>
                            <option value="0" <?=selected($gs('demo_mode_restrict_deposits','1'),'0',false)?>>⏸ No - allow</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>📢 Demo Notice</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Show Demo Notice</label>
                        <select name="demo_mode_show_notice" onchange="document.getElementById('demo-notice-wrap').style.display=this.value==='1'?'block':'none'">
                            <option value="1" <?=selected($gs('demo_mode_show_notice','1'),'1',false)?>>✅ Yes - show banner</option>
                            <option value="0" <?=selected($gs('demo_mode_show_notice','1'),'0',false)?>>⏸ No - hidden</option>
                        </select>
                    </div>
                    <div id="demo-notice-wrap" style="grid-column:1/-1;display:<?=$gs('demo_mode_show_notice','1')==='1'?'block':'none'?>">
                        <label>Demo Notice Text</label>
                        <textarea name="demo_mode_notice_text" rows="2" style="width:100%;background:#111;border:1px solid #2a2a2a;color:#e8e8e8;padding:10px;border-radius:8px"><?=esc_textarea($gs('demo_mode_notice_text','🎮 DEMO MODE - No real money involved. All claims and wins are simulated.'))?></textarea>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🧪 Test User Accounts</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Allow Test Users</label>
                        <select name="demo_mode_test_users">
                            <option value="1" <?=selected($gs('demo_mode_test_users','0'),'1',false)?>>✅ Yes - create test accounts</option>
                            <option value="0" <?=selected($gs('demo_mode_test_users','0'),'0',false)?>>⏸ No - use real accounts</option>
                        </select>
                        <span class="hint">Create test accounts automatically on registration</span>
                    </div>
                </div>
            </div>

            <button type="submit" name="cfp_save_demo_mode" class="cfp-btn cfp-btn-gold">💾 Save Demo Mode Settings</button>
        </form>

        <div class="cfp-card" style="margin-top:22px">
            <h2>📊 Demo Mode Test Checklist</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px">
                <div style="background:#111;border-radius:8px;padding:14px">
                    <div style="font-weight:700;color:#fff;margin-bottom:6px">✅ Faucet Claim</div>
                    <div style="font-size:.8rem;color:var(--mt)">Test hourly claim flow</div>
                </div>
                <div style="background:#111;border-radius:8px;padding:14px">
                    <div style="font-weight:700;color:#fff;margin-bottom:6px">✅ Casino Games</div>
                    <div style="font-size:.8rem;color:var(--mt)">Test all 22 games</div>
                </div>
                <div style="background:#111;border-radius:8px;padding:14px">
                    <div style="font-weight:700;color:#fff;margin-bottom:6px">✅ Withdrawals</div>
                    <div style="font-size:.8rem;color:var(--mt)">Test blocked message</div>
                </div>
                <div style="background:#111;border-radius:8px;padding:14px">
                    <div style="font-weight:700;color:#fff;margin-bottom:6px">✅ Registration</div>
                    <div style="font-size:.8rem;color:var(--mt)">Test new user flow</div>
                </div>
                <div style="background:#111;border-radius:8px;padding:14px">
                    <div style="font-weight:700;color:#fff;margin-bottom:6px">✅ Shortcodes</div>
                    <div style="font-size:.8rem;color:var(--mt)">Test all widgets</div>
                </div>
                <div style="background:#111;border-radius:8px;padding:14px">
                    <div style="font-weight:700;color:#fff;margin-bottom:6px">✅ Mobile</div>
                    <div style="font-size:.8rem;color:var(--mt)">Test responsive design</div>
                </div>
            </div>
        </div>
    </div>
    <?php
}