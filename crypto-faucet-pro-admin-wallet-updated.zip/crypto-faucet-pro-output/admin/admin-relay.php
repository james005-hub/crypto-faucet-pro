<?php
/**
 * Crypto Faucet Pro — Relay Settings Admin Page
 *
 * Admin panel for configuring and managing the Trezor relay key system.
 * Registered as a submenu under cfp-dashboard.
 *
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Register submenu ────────────────────────────────────────
add_action('admin_menu','cfp_relay_admin_menu',25);
function cfp_relay_admin_menu(): void {
    add_submenu_page(
        'cfp-dashboard',
        'Relay Settings',
        '⚡ Relay / Auto-Sweep',
        'manage_options',
        'cfp-relay',
        'cfp_relay_admin_page'
    );
}

// ── Inline JS/CSS only on this page ────────────────────────
add_action('admin_enqueue_scripts','cfp_relay_admin_assets');
function cfp_relay_admin_assets( string $hook ): void {
    if ( strpos($hook,'cfp-relay') === false ) return;
    // ethers.js for MetaMask signing in browser
    wp_enqueue_script('ethers-js','https://cdnjs.cloudflare.com/ajax/libs/ethers/6.7.0/ethers.umd.min.js',[],null,true);
    wp_enqueue_script('cfp-relay-admin', CFP_PLUGIN_URL.'admin/js/cfp-relay-admin.js',['jquery','ethers-js'],CFP_VERSION,true);
    wp_localize_script('cfp-relay-admin','cfpRelay',[
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce'    => wp_create_nonce('cfp_relay_nonce'),
        'networks' => cfp_evm_networks(),
        'strings'  => [
            'confirm_revoke'    => 'Revoke relay authorization? Auto-sweeps will stop until you re-authorize.',
            'confirm_sweep'     => 'Manually sweep now? This will broadcast an on-chain transaction.',
            'not_connected'     => 'Not connected.',
            'sign_success'      => 'Signed! Saving authorization…',
            'sign_rejected'     => 'Signing rejected or failed.',
        ],
    ]);
}

// ── Page renderer ───────────────────────────────────────────
function cfp_relay_admin_page(): void {
    global $wpdb;
    $saved  = false;
    $notice = '';

    // ── Save settings ──────────────────────────────────────
    if ( isset($_POST['cfp_save_relay_settings']) && check_admin_referer('cfp_relay_settings') ) {
        $fields = [
            'cfp_relay_auto_sweep_enabled',
            'cfp_relay_trezor_address',
            'cfp_relay_sweep_chain_id',
            'cfp_relay_sweep_threshold_sat',
            'cfp_relay_sweep_amount_sat',
            'cfp_relay_sweep_contract',
            'cfp_relay_sweep_decimals',
            'cfp_relay_sat_per_coin',
            'cfp_relay_infura_project_id',
            'cfp_relay_email_on_sweep',
        ];
        foreach ( $fields as $f ) {
            if ( isset($_POST[$f]) )
                cfp_update_setting($f, sanitize_text_field(wp_unslash($_POST[$f])));
        }
        $saved  = true;
        $notice = "<div class='cfp-notice success'>✅ Relay settings saved!</div>";
    }

    $gs = fn($k,$d='') => cfp_get_setting($k,$d);

    // Live stats
    $net_balance_sat = cfp_relay_get_net_balance_sat();
    $net_usd         = round($net_balance_sat / 1e8 * (int)$gs('btc_usd_price',67000),2);
    $threshold_sat   = (int)$gs('cfp_relay_sweep_threshold_sat',500000);
    $relay_logs      = $wpdb->get_results(
        "SELECT * FROM {$wpdb->prefix}cfp_relay_log ORDER BY created_at DESC LIMIT 50"
    );
    $sweep_count     = (int)$wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->prefix}cfp_relay_log WHERE type IN ('auto_sweep','manual_sweep')"
    );
    ?>
    <div class="cfp-wrap">
    <div class="cfp-header">
        <span class="cfp-logo-badge" style="background:linear-gradient(135deg,#7c3aed,#4f46e5)">⚡ RELAY</span>
        <h1>⚡ Relay Key & Auto-Sweep</h1>
        <div style="margin-left:auto;font-size:.8rem;color:var(--mt)">
            Auto-sweep: <strong style="color:<?=$gs('cfp_relay_auto_sweep_enabled','0')?'#22c55e':'#ef4444'?>">
                <?=$gs('cfp_relay_auto_sweep_enabled','0') ? '✅ ON' : '⏸ OFF'?>
            </strong>
        </div>
    </div>

    <?=$notice?>

    <!-- STATUS CARDS -->
    <div class="cfp-stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(170px,1fr));margin-bottom:24px">
        <div class="cfp-stat-card green">
            <div class="label">💰 Admin Wallet Balance</div>
            <div class="value"><?=number_format($net_balance_sat)?></div>
            <div class="sub">sat · $<?=number_format($net_usd,2)?> USD</div>
        </div>
        <div class="cfp-stat-card <?=$net_balance_sat>=$threshold_sat?'green':'red'?>">
            <div class="label">🎯 Sweep Threshold</div>
            <div class="value"><?=number_format($threshold_sat)?></div>
            <div class="sub">sat · <?=$net_balance_sat>=$threshold_sat?'✅ Ready to sweep':'⏳ Accumulating'?></div>
        </div>
        <div class="cfp-stat-card">
            <div class="label">🔐 Total Sweeps</div>
            <div class="value"><?=number_format($sweep_count)?></div>
            <div class="sub">all-time auto + manual</div>
        </div>
        <div class="cfp-stat-card blue">
            <div class="label">📍 Trezor Destination</div>
            <div class="value" style="font-size:.72rem;font-family:monospace;word-break:break-all">
                <?php $ta=esc_html($gs('cfp_relay_trezor_address','')); echo $ta ? substr($ta,0,10).'…'.substr($ta,-6) : '⚠️ Not set'; ?>
            </div>
        </div>
    </div>

    <!-- RELAY STATUS TABLE -->
    <div class="cfp-card" style="margin-bottom:22px">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
            <h2 style="margin:0">📊 Relay Status — All Chains</h2>
            <button onclick="cfpRelayRefreshStatus()" class="cfp-btn cfp-btn-ghost cfp-btn-sm">🔄 Refresh</button>
        </div>
        <table class="widefat" id="cfp-relay-status-table" style="background:#0a0a0a;border:1px solid #1a1a1a">
            <thead>
                <tr>
                    <th>Chain</th><th>Relay Address</th><th>Key</th>
                    <th>Authorized</th><th>Expires</th><th>Max/TX</th><th>Gas Balance</th>
                </tr>
            </thead>
            <tbody id="cfp-relay-status-tbody">
                <tr><td colspan="7" style="text-align:center;padding:20px;color:#555">Loading…</td></tr>
            </tbody>
        </table>
    </div>

    <!-- GENERATE RELAY KEYPAIR -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🔑 Step 1 — Generate Relay Keypair</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">
            Generates a fresh secp256k1 keypair server-side. The private key is stored
            AES-256-GCM encrypted using your WordPress salts + PBKDF2. You never see the
            private key — only the relay address. Fund that address with gas (ETH/BNB/MATIC)
            from your Trezor, then authorize it in Step 2.
        </p>
        <div style="display:flex;gap:12px;align-items:flex-end;flex-wrap:wrap">
            <div class="cfp-field" style="min-width:200px">
                <label>Chain</label>
                <select id="cfp-relay-gen-chain" style="background:#111">
                    <?php foreach(cfp_evm_networks() as $cid=>$net): ?>
                    <option value="<?=esc_attr($cid)?>"><?=esc_html($net['name'].' ('.$net['symbol'].')')?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button onclick="cfpRelayGenerate()" class="cfp-btn cfp-btn-primary" style="padding:10px 24px">
                ⚡ Generate Relay Key
            </button>
        </div>
        <div id="cfp-relay-gen-result" style="display:none;margin-top:14px;padding:14px;background:#050e05;border:1px solid #22c55e44;border-radius:8px;font-size:.85rem">
            <strong style="color:#22c55e">Relay address generated:</strong><br>
            <code id="cfp-relay-gen-addr" style="word-break:break-all;font-size:.8rem;color:#1dc928"></code><br>
            <span style="color:#f59e0b;margin-top:6px;display:block">⚠️ Fund this address with gas before authorizing. Then proceed to Step 2.</span>
        </div>
        <div id="cfp-relay-gen-msg" style="margin-top:8px;font-size:.85rem"></div>
    </div>

    <!-- TREZOR AUTHORIZATION -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>✍️ Step 2 — Authorize Relay with Trezor (EIP-712)</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">
            Connect MetaMask with your Trezor account and sign the authorization.
            This is a <strong style="color:#aaa">gasless off-chain signature</strong> — no ETH spent, no blockchain tx.
            It grants the relay address permission to sign transactions on your behalf within the limits below.
            Revoke anytime from this panel.
        </p>

        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin-bottom:16px">
            <div class="cfp-field">
                <label>Chain to Authorize</label>
                <select id="cfp-relay-auth-chain" style="background:#111">
                    <?php foreach(cfp_evm_networks() as $cid=>$net): ?>
                    <option value="<?=esc_attr($cid)?>"><?=esc_html($net['name'])?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="cfp-field">
                <label>Max Per Transaction (coin units)</label>
                <input type="text" id="cfp-relay-max-per-tx" value="1" placeholder="e.g. 0.5">
                <span class="hint">Relay cannot sign any single tx above this amount.</span>
            </div>
            <div class="cfp-field">
                <label>Authorization Valid For (days)</label>
                <input type="number" id="cfp-relay-expiry-days" value="30" min="1" max="365">
            </div>
        </div>

        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px">
            <button onclick="cfpRelayConnectMetaMask()" class="cfp-btn cfp-btn-primary" style="padding:10px 20px">
                🦊 Connect MetaMask + Trezor
            </button>
            <button id="cfp-relay-sign-btn" onclick="cfpRelaySignAuth()" class="cfp-btn cfp-btn-ghost" style="padding:10px 20px" disabled>
                ✍️ Sign Authorization on Trezor
            </button>
            <button onclick="cfpRelayRevoke(0)" class="cfp-btn" style="background:#1a0000;color:#ef4444;border:1px solid #ef444440;padding:10px 16px">
                🚫 Revoke All
            </button>
        </div>

        <div id="cfp-relay-connect-status" style="font-size:.82rem;padding:8px 12px;background:rgba(0,0,0,.04);border-radius:6px;color:#555;margin-bottom:10px">
            Not connected.
        </div>
        <div id="cfp-relay-auth-msg" style="font-size:.85rem"></div>

        <div style="margin-top:14px;padding:10px 14px;background:rgba(59,130,246,.06);border:1px solid rgba(59,130,246,.25);border-radius:8px;font-size:.78rem;color:#888;line-height:1.7">
            <strong style="color:#93c5fd">ℹ️ How it works:</strong> Your Trezor signs an EIP-712 structured message
            (no gas, off-chain) that authorizes the server relay address to act as your signing delegate
            within the limits you set. The signature is stored encrypted on the server.
            No funds are moved during authorization. Revoke anytime.
        </div>
    </div>

    <!-- SETTINGS FORM -->
    <form method="post">
        <?php wp_nonce_field('cfp_relay_settings'); ?>

        <div class="cfp-card" style="margin-bottom:22px">
            <h2>⚙️ Step 3 — Auto-Sweep Settings</h2>
            <p style="color:#777;font-size:.85rem;margin-bottom:16px">
                Configure when and how the relay automatically sweeps your Admin Wallet earnings
                to your Trezor address on-chain. Fires on every wallet credit and hourly via cron.
            </p>

            <div class="cfp-form-grid">
                <div class="cfp-field">
                    <label>Auto-Sweep Master Switch</label>
                    <select name="cfp_relay_auto_sweep_enabled" style="background:#111">
                        <option value="1" <?=selected($gs('cfp_relay_auto_sweep_enabled','0'),'1',false)?>>✅ Enabled</option>
                        <option value="0" <?=selected($gs('cfp_relay_auto_sweep_enabled','0'),'0',false)?>>⏸ Disabled</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Trezor / Hardware Wallet Address</label>
                    <input type="text" name="cfp_relay_trezor_address"
                        value="<?=esc_attr($gs('cfp_relay_trezor_address',''))?>"
                        placeholder="0x… your Trezor EVM address"
                        style="font-family:monospace;font-size:.82rem">
                    <span class="hint">Destination for all auto-sweeps. Must match address used for Trezor authorization above.</span>
                </div>
                <div class="cfp-field">
                    <label>Sweep Chain</label>
                    <select name="cfp_relay_sweep_chain_id" style="background:#111">
                        <?php foreach(cfp_evm_networks() as $cid=>$net): ?>
                        <option value="<?=esc_attr($cid)?>" <?=selected($gs('cfp_relay_sweep_chain_id','1'),(string)$cid,false)?>>
                            <?=esc_html($net['name'].' ('.$net['symbol'].')')?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Infura Project ID</label>
                    <input type="text" name="cfp_relay_infura_project_id"
                        value="<?=esc_attr($gs('cfp_relay_infura_project_id',''))?>"
                        placeholder="Your Infura v3 Project ID" autocomplete="off">
                    <span class="hint">Required for Ethereum, Polygon, Arbitrum, Base, Optimism, Avalanche. <a href="https://infura.io" target="_blank" style="color:var(--g)">Get one free →</a></span>
                </div>
                <div class="cfp-field">
                    <label>Sweep Threshold (sat)</label>
                    <input type="number" name="cfp_relay_sweep_threshold_sat"
                        value="<?=esc_attr($gs('cfp_relay_sweep_threshold_sat','500000'))?>" min="1">
                    <span class="hint">Min Admin Wallet balance before a sweep fires. Default: 500,000 sat.</span>
                </div>
                <div class="cfp-field">
                    <label>Sweep Amount (sat)</label>
                    <input type="number" name="cfp_relay_sweep_amount_sat"
                        value="<?=esc_attr($gs('cfp_relay_sweep_amount_sat','0'))?>" min="0">
                    <span class="hint">Amount to sweep per trigger. Set 0 to sweep the full balance.</span>
                </div>
                <div class="cfp-field">
                    <label>Sat Per Coin</label>
                    <input type="number" name="cfp_relay_sat_per_coin"
                        value="<?=esc_attr($gs('cfp_relay_sat_per_coin','100000000'))?>" min="1">
                    <span class="hint">How many sat = 1 coin unit. BTC = 100,000,000. ETH = 100,000,000 (treating 1 ETH as 1 BTC-equivalent). Adjust to match your faucet's peg.</span>
                </div>
                <div class="cfp-field">
                    <label>ERC-20 Contract (optional)</label>
                    <input type="text" name="cfp_relay_sweep_contract"
                        value="<?=esc_attr($gs('cfp_relay_sweep_contract',''))?>"
                        placeholder="0x… leave blank for native ETH/BNB/MATIC"
                        style="font-family:monospace;font-size:.82rem">
                </div>
                <div class="cfp-field">
                    <label>Token Decimals</label>
                    <input type="number" name="cfp_relay_sweep_decimals"
                        value="<?=esc_attr($gs('cfp_relay_sweep_decimals','18'))?>" min="0" max="18">
                    <span class="hint">Ignored for native transfers. USDT/USDC on Ethereum = 6.</span>
                </div>
                <div class="cfp-field">
                    <label>Email Alert on Sweep</label>
                    <select name="cfp_relay_email_on_sweep" style="background:#111">
                        <option value="1" <?=selected($gs('cfp_relay_email_on_sweep','0'),'1',false)?>>✅ Yes — email admin</option>
                        <option value="0" <?=selected($gs('cfp_relay_email_on_sweep','0'),'0',false)?>>❌ No</option>
                    </select>
                </div>
            </div>
        </div>

        <div style="text-align:right;margin-bottom:30px">
            <button type="submit" name="cfp_save_relay_settings" class="cfp-btn cfp-btn-primary" style="padding:12px 32px;font-size:1rem">
                💾 Save Relay Settings
            </button>
        </div>
    </form>

    <!-- MANUAL SWEEP -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>💸 Manual On-Demand Sweep</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">
            Trigger a sweep immediately without waiting for the threshold. Relay key must be authorized.
        </p>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr))">
            <div class="cfp-field">
                <label>Chain</label>
                <select id="cfp-manual-chain" style="background:#111">
                    <?php foreach(cfp_evm_networks() as $cid=>$net): ?>
                    <option value="<?=esc_attr($cid)?>"><?=esc_html($net['name'])?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="cfp-field">
                <label>Amount (coin units)</label>
                <input type="text" id="cfp-manual-amount" placeholder="e.g. 0.05000000">
            </div>
            <div class="cfp-field">
                <label>To Address</label>
                <input type="text" id="cfp-manual-to"
                    value="<?=esc_attr(cfp_get_setting('cfp_relay_trezor_address',''))?>"
                    placeholder="0x… destination" style="font-family:monospace;font-size:.82rem">
            </div>
            <div class="cfp-field">
                <label>Note (optional)</label>
                <input type="text" id="cfp-manual-note" placeholder="e.g. Weekly withdrawal">
            </div>
        </div>
        <button onclick="cfpRelayManualSweep()" class="cfp-btn cfp-btn-primary" style="margin-top:10px;padding:10px 24px">
            🔐 Sweep Now
        </button>
        <div id="cfp-manual-sweep-msg" style="margin-top:10px;font-size:.85rem"></div>
    </div>

    <!-- RELAY TRANSACTION LOG -->
    <div class="cfp-card" style="margin-bottom:30px">
        <h2>📋 Relay Transaction Log</h2>
        <?php if ($relay_logs): ?>
        <table class="widefat" style="background:#0a0a0a;border:1px solid #1a1a1a">
            <thead>
                <tr>
                    <th>ID</th><th>Type</th><th>Chain</th><th>Amount</th>
                    <th>To Address</th><th>TX Hash</th><th>Note</th><th>Date</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach($relay_logs as $log):
                $nets = cfp_evm_networks();
                $chain_name = $nets[$log->chain_id]['name'] ?? 'Chain '.$log->chain_id;
            ?>
                <tr>
                    <td><?=esc_html($log->id)?></td>
                    <td><span class="mfcrex-source-badge" style="background:#7c3aed22;color:#a78bfa;padding:2px 8px;border-radius:4px;font-size:.72rem"><?=esc_html(str_replace('_',' ',$log->type))?></span></td>
                    <td><?=esc_html($chain_name)?></td>
                    <td style="color:#22c55e;font-family:monospace"><?=esc_html($log->amount)?></td>
                    <td><code style="font-size:.72rem"><?=esc_html(substr($log->to_addr,0,12))?>…<?=esc_html(substr($log->to_addr,-6))?></code></td>
                    <td>
                        <?php if($log->tx_hash): ?>
                        <code style="font-size:.7rem"><?=esc_html(substr($log->tx_hash,0,10))?>…</code>
                        <?php else: ?>
                        <span style="color:#555">—</span>
                        <?php endif; ?>
                    </td>
                    <td style="font-size:.78rem;color:#666"><?=esc_html(substr($log->note??'',0,60))?></td>
                    <td style="font-size:.78rem;color:#555"><?=esc_html($log->created_at)?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else: ?>
            <div class="mfcrex-empty-state" style="padding:30px;text-align:center;color:#444">
                No relay transactions yet. Configure and authorize the relay to start auto-sweeping.
            </div>
        <?php endif; ?>
    </div>

    </div><!-- .cfp-wrap -->

    <script>
    // ── Inline JS (no external file dependency for status/auth flows) ──

    function cfpRelayRefreshStatus() {
        document.getElementById('cfp-relay-status-tbody').innerHTML =
            '<tr><td colspan="7" style="text-align:center;padding:20px;color:#555">Loading…</td></tr>';
        jQuery.post(cfpRelay.ajax_url, {action:'cfp_relay_status',nonce:cfpRelay.nonce}, function(r){
            if (!r.success) return;
            var rows = '';
            Object.values(r.data).forEach(function(c){
                var gasColor = c.gas_ok ? '#22c55e' : '#ef4444';
                var authColor = c.authorized ? '#22c55e' : '#ef4444';
                rows += '<tr>'
                    + '<td><strong>'+c.chain_name+'</strong><br><small style="color:#555">'+c.symbol+'</small></td>'
                    + '<td><code style="font-size:.7rem">'+(c.relay_address ? c.relay_address.substring(0,12)+'…' : '—')+'</code></td>'
                    + '<td style="color:'+(c.has_key?'#22c55e':'#ef4444')+'">'+(c.has_key?'✅':'❌')+'</td>'
                    + '<td style="color:'+authColor+'">'+(c.authorized?'✅ Until '+(c.expiry_human||'?'):'❌ None')+'</td>'
                    + '<td style="font-size:.78rem">'+(c.expiry_human||'—')+'</td>'
                    + '<td style="font-size:.78rem">'+(c.max_per_tx||'—')+'</td>'
                    + '<td style="color:'+gasColor+';font-family:monospace;font-size:.78rem">'+(c.gas_balance||'—')+'</td>'
                    + '</tr>';
            });
            document.getElementById('cfp-relay-status-tbody').innerHTML = rows || '<tr><td colspan="7" style="color:#555;padding:16px">No data.</td></tr>';
        });
    }

    function cfpRelayGenerate() {
        var chainId = document.getElementById('cfp-relay-gen-chain').value;
        document.getElementById('cfp-relay-gen-msg').textContent = 'Generating…';
        jQuery.post(cfpRelay.ajax_url, {action:'cfp_relay_generate',nonce:cfpRelay.nonce,chain_id:chainId}, function(r){
            document.getElementById('cfp-relay-gen-msg').textContent = '';
            if (r.success) {
                document.getElementById('cfp-relay-gen-result').style.display = 'block';
                document.getElementById('cfp-relay-gen-addr').textContent = r.data.address;
                cfpRelayRefreshStatus();
            } else {
                document.getElementById('cfp-relay-gen-msg').textContent = '❌ ' + r.data;
            }
        });
    }

    var cfpRelayConnectedAddr = null;
    var cfpRelayProvider      = null;

    async function cfpRelayConnectMetaMask() {
        var statusEl = document.getElementById('cfp-relay-connect-status');
        if (typeof window.ethereum === 'undefined') {
            statusEl.textContent = '❌ MetaMask not detected. Install MetaMask and add your Trezor account to it.';
            return;
        }
        try {
            statusEl.textContent = 'Connecting…';
            var accounts = await window.ethereum.request({method:'eth_requestAccounts'});
            cfpRelayConnectedAddr = accounts[0];
            cfpRelayProvider      = new ethers.BrowserProvider(window.ethereum);
            statusEl.innerHTML = '✅ Connected: <code>' + cfpRelayConnectedAddr + '</code>';
            document.getElementById('cfp-relay-sign-btn').disabled = false;
        } catch(e) {
            statusEl.textContent = '❌ ' + (e.message || 'Connection failed');
        }
    }

    async function cfpRelaySignAuth() {
        var authEl   = document.getElementById('cfp-relay-auth-msg');
        var chainId  = parseInt(document.getElementById('cfp-relay-auth-chain').value);
        var maxPerTx = document.getElementById('cfp-relay-max-per-tx').value;
        var days     = parseInt(document.getElementById('cfp-relay-expiry-days').value);

        if (!cfpRelayConnectedAddr || !cfpRelayProvider) {
            authEl.textContent = '❌ Connect MetaMask first.'; return;
        }
        authEl.textContent = 'Fetching typed data…';

        // Fetch typed data from server
        jQuery.post(cfpRelay.ajax_url, {
            action:'cfp_relay_get_auth_data', nonce:cfpRelay.nonce,
            chain_id:chainId, max_per_tx:maxPerTx, expiry_days:days
        }, async function(r) {
            if (!r.success) { authEl.textContent = '❌ ' + r.data; return; }
            var td      = r.data.typed_data;
            var expiry  = r.data.expiry;
            var relayAddr = r.data.relay_address;

            try {
                authEl.textContent = 'Please confirm the signing request on your Trezor device…';
                var signer = await cfpRelayProvider.getSigner();
                var sig    = await signer.signTypedData(td.domain, {RelayAuthorization:td.types.RelayAuthorization}, td.message);
                authEl.textContent = '✅ Signed! Saving…';

                jQuery.post(cfpRelay.ajax_url, {
                    action:'cfp_relay_save_auth', nonce:cfpRelay.nonce,
                    chain_id:chainId, signature:sig,
                    relay_address:relayAddr, max_per_tx:maxPerTx,
                    expiry:expiry, trezor_address:cfpRelayConnectedAddr,
                }, function(sr){
                    if (sr.success) {
                        authEl.innerHTML = '<span style="color:#22c55e">✅ ' + sr.data.message + ' Expires: ' + sr.data.expires + '</span>';
                        cfpRelayRefreshStatus();
                    } else {
                        authEl.textContent = '❌ ' + sr.data;
                    }
                });
            } catch(e) {
                authEl.textContent = '❌ Signing failed: ' + (e.message || e);
            }
        });
    }

    function cfpRelayRevoke(chainId) {
        if (!confirm(cfpRelay.strings.confirm_revoke)) return;
        jQuery.post(cfpRelay.ajax_url, {action:'cfp_relay_revoke',nonce:cfpRelay.nonce,chain_id:chainId}, function(r){
            alert(r.success ? '✅ ' + r.data : '❌ ' + r.data);
            cfpRelayRefreshStatus();
        });
    }

    function cfpRelayManualSweep() {
        var msgEl   = document.getElementById('cfp-manual-sweep-msg');
        var chainId = document.getElementById('cfp-manual-chain').value;
        var amount  = document.getElementById('cfp-manual-amount').value;
        var to      = document.getElementById('cfp-manual-to').value;
        var note    = document.getElementById('cfp-manual-note').value;

        if (!amount || !to) { msgEl.textContent = '❌ Amount and destination address are required.'; return; }
        if (!confirm(cfpRelay.strings.confirm_sweep)) return;

        msgEl.textContent = 'Signing and broadcasting…';
        jQuery.post(cfpRelay.ajax_url, {
            action:'cfp_relay_manual_sweep', nonce:cfpRelay.nonce,
            chain_id:chainId, amount:amount, to_address:to, note:note
        }, function(r){
            msgEl.innerHTML = r.success
                ? '<span style="color:#22c55e">✅ ' + r.data.message + '</span>'
                : '<span style="color:#ef4444">❌ ' + r.data + '</span>';
        });
    }

    // Auto-refresh status on page load
    jQuery(function(){ cfpRelayRefreshStatus(); });
    </script>
    <?php
}
