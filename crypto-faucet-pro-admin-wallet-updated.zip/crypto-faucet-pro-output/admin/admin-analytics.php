<?php
/**
 * Admin page: Analytics Dashboard with charts, trends, and data export
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Get chart data
   ============================================================ */
add_action('wp_ajax_cfp_analytics_chart_data', 'cfp_ajax_analytics_chart_data');
function cfp_ajax_analytics_chart_data() {
    check_ajax_referer('cfp_analytics_nonce', 'nonce');
    
    global $wpdb;
    $period = sanitize_text_field($_POST['period'] ?? '7days');
    $game = sanitize_text_field($_POST['game'] ?? 'all');
    
    switch($period) {
        case '24hours':
            $date_format = '%Y-%m-%d %H:00';
            $date_range = "played_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)";
            break;
        case '30days':
            $date_format = '%Y-%m-%d';
            $date_range = "played_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            break;
        case '90days':
            $date_format = '%Y-%m-%d';
            $date_range = "played_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)";
            break;
        default: // 7days
            $date_format = '%Y-%m-%d';
            $date_range = "played_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
    }
    
    $tables = [
        'hilo' => CFP_TABLE_MULTIPLY,
        'slots' => CFP_TABLE_SLOTS,
        'coinflip' => CFP_TABLE_COINFLIP,
        'dice' => CFP_TABLE_DICE,
        'crash' => CFP_TABLE_CRASH,
        'wheel' => CFP_TABLE_WHEEL,
    ];
    
    $chart_data = [];
    
    foreach($tables as $key => $tbl) {
        if($game !== 'all' && $key !== $game) continue;
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT DATE_FORMAT(played_at, '{$date_format}') as date,
                    COUNT(*) as plays,
                    COALESCE(SUM(bet_sat), 0) as wagered,
                    COALESCE(SUM(payout_sat), 0) as paid
             FROM {$tbl}
             WHERE {$date_range}
             GROUP BY DATE_FORMAT(played_at, '{$date_format}')
             ORDER BY date ASC"
        ));
        
        foreach($results as $r) {
            $chart_data[$key][] = [
                'date' => $r->date,
                'plays' => intval($r->plays),
                'wagered' => intval($r->wagered),
                'paid' => intval($r->paid),
                'ggr' => intval($r->wagered) - intval($r->paid)
            ];
        }
    }
    
    wp_send_json_success(['chart_data' => $chart_data, 'period' => $period]);
}

/* ============================================================
   ADMIN: ANALYTICS DASHBOARD
   ============================================================ */
function cfp_admin_analytics() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_analytics_nonce');
    
    // Get date ranges
    $today = $wpdb->get_results("
        SELECT 'claims' as type, COUNT(*) as count, COALESCE(SUM(amount_sat), 0) as amount FROM " . CFP_TABLE_CLAIMS . " WHERE DATE(claimed_at) = CURDATE()
        UNION ALL
        SELECT 'users' as type, COUNT(*) as count, 0 FROM " . CFP_TABLE_USERS . " WHERE DATE(created_at) = CURDATE()
        UNION ALL
        SELECT 'games' as type, COUNT(*) as count, COALESCE(SUM(bet_sat), 0) FROM " . CFP_TABLE_MULTIPLY . " WHERE DATE(played_at) = CURDATE()
    ");
    
    $yesterday = $wpdb->get_results("
        SELECT 'claims' as type, COUNT(*) as count, COALESCE(SUM(amount_sat), 0) as amount FROM " . CFP_TABLE_CLAIMS . " WHERE DATE(claimed_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)
        UNION ALL
        SELECT 'users' as type, COUNT(*) as count, 0 FROM " . CFP_TABLE_USERS . " WHERE DATE(created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)
        UNION ALL
        SELECT 'games' as type, COUNT(*) as count, COALESCE(SUM(bet_sat), 0) FROM " . CFP_TABLE_MULTIPLY . " WHERE DATE(played_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)
    ");
    
    // Top players
    $top_players = $wpdb->get_results("
        SELECT username, balance_sat, total_earned, total_claims
        FROM " . CFP_TABLE_USERS . "
        ORDER BY total_earned DESC LIMIT 10
    ");
    
    // Recent activity
    $recent_activity = $wpdb->get_results("
        SELECT 'claim' as type, id, user_id, amount_sat, claimed_at as timestamp, username
        FROM " . CFP_TABLE_CLAIMS . " c
        LEFT JOIN " . CFP_TABLE_USERS . " u ON c.user_id = u.id
        ORDER BY c.claimed_at DESC LIMIT 20
    ");
    
    // Game stats summary
    $game_stats = [];
    $tables = [
        'hilo' => ['Hi-Lo Multiply', '🎲', CFP_TABLE_MULTIPLY],
        'slots' => ['Slots', '🎰', CFP_TABLE_SLOTS],
        'coinflip' => ['Coin Flip', '🪙', CFP_TABLE_COINFLIP],
        'dice' => ['Dice Roll', '🎲', CFP_TABLE_DICE],
        'crash' => ['Crash', '📈', CFP_TABLE_CRASH],
        'wheel' => ['Wheel', '🎡', CFP_TABLE_WHEEL],
    ];
    
    foreach($tables as $key => [$label, $icon, $tbl]) {
        $game_stats[$key] = [
            'label' => $label,
            'icon' => $icon,
            'today_plays' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$tbl} WHERE DATE(played_at) = CURDATE()"),
            'today_wagered' => (int)$wpdb->get_var("SELECT COALESCE(SUM(bet_sat), 0) FROM {$tbl} WHERE DATE(played_at) = CURDATE()"),
            'today_paid' => (int)$wpdb->get_var("SELECT COALESCE(SUM(payout_sat), 0) FROM {$tbl} WHERE DATE(played_at) = CURDATE()"),
            'total_plays' => (int)$wpdb->get_var("SELECT COUNT(*) FROM {$tbl}"),
            'total_wagered' => (int)$wpdb->get_var("SELECT COALESCE(SUM(bet_sat), 0) FROM {$tbl}"),
        ];
        $game_stats[$key]['today_ggr'] = $game_stats[$key]['today_wagered'] - $game_stats[$key]['today_paid'];
    }
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">📊</span>
            <h1>📊 Analytics Dashboard</h1>
            <div style="margin-left:auto;display:flex;gap:10px">
                <button onclick="cfpExportAnalytics('csv')" class="cfp-btn cfp-btn-ghost">📥 Export CSV</button>
                <button onclick="cfpExportAnalytics('pdf')" class="cfp-btn cfp-btn-ghost">📄 Export PDF</button>
            </div>
        </div>

        <!-- PERIOD SELECTOR -->
        <div class="cfp-tabs" style="margin-bottom:20px">
            <button class="cfp-tab active" onclick="cfpChangePeriod('7days', this)">7 Days</button>
            <button class="cfp-tab" onclick="cfpChangePeriod('24hours', this)">24 Hours</button>
            <button class="cfp-tab" onclick="cfpChangePeriod('30days', this)">30 Days</button>
            <button class="cfp-tab" onclick="cfpChangePeriod('90days', this)">90 Days</button>
        </div>

        <!-- TODAY VS YESTERDAY -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card green">
                <div class="label">📥 Claims Today</div>
                <div class="value"><?=number_format(array_sum(array_column($today, 'count')))?></div>
                <div class="sub">
                    <?php 
                    $today_claims = array_sum(array_column(array_filter($today, function($t) { return $t->type === 'claims'; }), 'count'));
                    $yest_claims = array_sum(array_column(array_filter($yesterday, function($t) { return $t->type === 'claims'; }), 'count'));
                    $change = $yest_claims > 0 ? round(($today_claims - $yest_claims) / $yest_claims * 100, 1) : 0;
                    echo ($change >= 0 ? '+' : '') . $change . '% vs yesterday';
                    ?>
                </div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">👥 New Users Today</div>
                <div class="value"><?=number_format(array_sum(array_column(array_filter($today, function($t) { return $t->type === 'users'; }), 'count')))?></div>
                <div class="sub">
                    <?php 
                    $today_users = array_sum(array_column(array_filter($today, function($t) { return $t->type === 'users'; }), 'count'));
                    $yest_users = array_sum(array_column(array_filter($yesterday, function($t) { return $t->type === 'users'; }), 'count'));
                    $change = $yest_users > 0 ? round(($today_users - $yest_users) / $yest_users * 100, 1) : 0;
                    echo ($change >= 0 ? '+' : '') . $change . '% vs yesterday';
                    ?>
                </div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">🎮 Games Played Today</div>
                <div class="value"><?=number_format(array_sum(array_column(array_filter($today, function($t) { return $t->type === 'games'; }), 'count')))?></div>
                <div class="sub">
                    <?php 
                    $today_games = array_sum(array_column(array_filter($today, function($t) { return $t->type === 'games'; }), 'count'));
                    $yest_games = array_sum(array_column(array_filter($yesterday, function($t) { return $t->type === 'games'; }), 'count'));
                    $change = $yest_games > 0 ? round(($today_games - $yest_games) / $yest_games * 100, 1) : 0;
                    echo ($change >= 0 ? '+' : '') . $change . '% vs yesterday';
                    ?>
                </div>
            </div>
            <div class="cfp-stat-card" style="border-top:3px solid #22c55e">
                <div class="label">💰 Today's Revenue</div>
                <div class="value" style="color:#22c55e">
                    <?php 
                    $total_ggr = 0;
                    foreach($game_stats as $gs) {
                        $total_ggr += $gs['today_ggr'];
                    }
                    echo number_format($total_ggr) . ' sat';
                    ?>
                </div>
                <div class="sub">From all games</div>
            </div>
        </div>

        <!-- CHARTS SECTION -->
        <div class="cfp-2col" style="margin-bottom:30px">
            <div class="cfp-card">
                <h2>📈 Revenue Trend</h2>
                <div style="height:300px;position:relative">
                    <canvas id="cfpRevenueChart"></canvas>
                </div>
            </div>
            <div class="cfp-card">
                <h2>🎮 Games Activity</h2>
                <div style="height:300px;position:relative">
                    <canvas id="cfpGamesChart"></canvas>
                </div>
            </div>
        </div>

        <!-- GAME STATS BREAKDOWN -->
        <div class="cfp-card" style="margin-bottom:30px">
            <h2>🎰 Game Performance Breakdown</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px">
                <?php foreach($game_stats as $key => $gs): ?>
                <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:12px;padding:18px">
                    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
                        <span style="font-size:1.4rem"><?=$gs['icon']?></span>
                        <span style="font-weight:700;color:#fff"><?=$gs['label']?></span>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                        <div>
                            <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:4px">Today's Plays</div>
                            <div style="font-size:1.2rem;font-weight:700;color:#fff"><?=number_format($gs['today_plays'])?></div>
                        </div>
                        <div>
                            <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:4px">Total Plays</div>
                            <div style="font-size:1.2rem;font-weight:700;color:#fff"><?=number_format($gs['total_plays'])?></div>
                        </div>
                        <div>
                            <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:4px">Wagered Today</div>
                            <div style="font-size:1rem;font-weight:600;color:#f7931a"><?=number_format($gs['today_wagered'])?> sat</div>
                        </div>
                        <div>
                            <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:4px">Today's GGR</div>
                            <div style="font-size:1rem;font-weight:700;color:<?=$gs['today_ggr'] >= 0 ? '#22c55e' : '#ef4444'?>">
                                <?=number_format($gs['today_ggr'])?> sat
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- TOP PLAYERS & RECENT ACTIVITY -->
        <div class="cfp-2col">
            <div class="cfp-card">
                <h2>🏆 Top Players by Earnings</h2>
                <table class="cfp-table">
                    <thead><tr><th>#</th><th>User</th><th>Total Earned</th><th>Balance</th><th>Claims</th></tr></thead>
                    <tbody>
                    <?php foreach($top_players as $i => $p): ?>
                    <tr>
                        <td><?=($i + 1)?></td>
                        <td><strong><?=esc_html($p->username)?></strong></td>
                        <td style="color:#22c55e;font-weight:700"><?=number_format($p->total_earned)?> sat</td>
                        <td><?=number_format($p->balance_sat)?> sat</td>
                        <td><?=number_format($p->total_claims)?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="cfp-card">
                <h2>📜 Recent Activity</h2>
                <table class="cfp-table">
                    <thead><tr><th>Type</th><th>User</th><th>Amount</th><th>Time</th></tr></thead>
                    <tbody>
                    <?php foreach($recent_activity as $a): ?>
                    <tr>
                        <td><span class="cfp-badge <?=$a->type === 'claim' ? 'active' : 'pending'?>"><?=esc_html($a->type)?></span></td>
                        <td><strong><?=esc_html($a->username ?? 'Unknown')?></strong></td>
                        <td style="color:#22c55e"><?=number_format($a->amount_sat)?> sat</td>
                        <td style="color:#555;font-size:.78rem"><?=human_time_diff(strtotime($a->timestamp), current_time('timestamp'))?> ago</td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
    let cfpRevenueChart = null;
    let cfpGamesChart = null;
    let currentPeriod = '7days';
    
    document.addEventListener('DOMContentLoaded', function() {
        cfpLoadChartData();
    });
    
    function cfpChangePeriod(period, btn) {
        document.querySelectorAll('.cfp-tabs .cfp-tab').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentPeriod = period;
        cfpLoadChartData();
    }
    
    function cfpLoadChartData() {
        const fd = new FormData();
        fd.append('action', 'cfp_analytics_chart_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('period', currentPeriod);
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(data => {
                if(data.success) {
                    cfpRenderCharts(data.data.chart_data);
                }
            });
    }
    
    function cfpRenderCharts(chartData) {
        const ctx1 = document.getElementById('cfpRevenueChart');
        const ctx2 = document.getElementById('cfpGamesChart');
        
        if(!ctx1 || !ctx2) return;
        
        // Prepare data
        const labels = [];
        const ggrData = [];
        const playsData = [];
        
        // Get all unique dates
        const allDates = new Set();
        Object.values(chartData).forEach(gameData => {
            gameData.forEach(d => allDates.add(d.date));
        });
        labels = Array.from(allDates).sort();
        
        labels.forEach(date => {
            let totalGGR = 0;
            let totalPlays = 0;
            Object.values(chartData).forEach(gameData => {
                const dayData = gameData.find(d => d.date === date);
                if(dayData) {
                    totalGGR += dayData.ggr;
                    totalPlays += dayData.plays;
                }
            });
            ggrData.push(totalGGR);
            playsData.push(totalPlays);
        });
        
        // Destroy existing charts
        if(cfpRevenueChart) cfpRevenueChart.destroy();
        if(cfpGamesChart) cfpGamesChart.destroy();
        
        // Revenue Chart
        cfpRevenueChart = new Chart(ctx1, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Revenue (GGR) - sat',
                    data: ggrData,
                    borderColor: '#22c55e',
                    backgroundColor: 'rgba(34, 197, 94, 0.1)',
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#888' } }
                },
                scales: {
                    x: { ticks: { color: '#666' }, grid: { color: '#222' } },
                    y: { ticks: { color: '#666' }, grid: { color: '#222' } }
                }
            }
        });
        
        // Games Chart
        cfpGamesChart = new Chart(ctx2, {
            type: 'bar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Games Played',
                    data: playsData,
                    backgroundColor: '#f7931a',
                    borderRadius: 4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { labels: { color: '#888' } }
                },
                scales: {
                    x: { ticks: { color: '#666' }, grid: { color: '#222' } },
                    y: { ticks: { color: '#666' }, grid: { color: '#222' } }
                }
            }
        });
    }
    
    function cfpExportAnalytics(format) {
        const fd = new FormData();
        fd.append('action', 'cfp_export_analytics');
        fd.append('format', format);
        fd.append('nonce', '<?=$nonce?>');
        
        // Open export in new tab or download
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.blob())
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'analytics_' + new Date().toISOString().split('T')[0] + '.' + format;
                a.click();
                window.URL.revokeObjectURL(url);
            });
    }
    </script>
    <?php
}

/* ============================================================
   AJAX: Export Analytics
   ============================================================ */
add_action('wp_ajax_cfp_export_analytics', 'cfp_ajax_export_analytics');
function cfp_ajax_export_analytics() {
    check_ajax_referer('cfp_analytics_nonce', 'nonce');
    
    global $wpdb;
    $format = sanitize_text_field($_POST['format'] ?? 'csv');
    
    $tables = [
        'hilo' => CFP_TABLE_MULTIPLY,
        'slots' => CFP_TABLE_SLOTS,
        'coinflip' => CFP_TABLE_COINFLIP,
        'dice' => CFP_TABLE_DICE,
        'crash' => CFP_TABLE_CRASH,
        'wheel' => CFP_TABLE_WHEEL,
    ];
    
    $data = [];
    $data[] = ['Game', 'Date', 'Plays', 'Wagered (sat)', 'Paid Out (sat)', 'GGR (sat)'];
    
    foreach($tables as $key => $tbl) {
        $results = $wpdb->get_results("
            SELECT DATE_FORMAT(played_at, '%Y-%m-%d') as date,
                   COUNT(*) as plays,
                   COALESCE(SUM(bet_sat), 0) as wagered,
                   COALESCE(SUM(payout_sat), 0) as paid
            FROM {$tbl}
            WHERE played_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY DATE_FORMAT(played_at, '%Y-%m-%d')
            ORDER BY date DESC
        ");
        
        foreach($results as $r) {
            $data[] = [
                ucfirst($key),
                $r->date,
                $r->plays,
                $r->wagered,
                $r->paid,
                intval($r->wagered) - intval($r->paid)
            ];
        }
    }
    
    if($format === 'csv') {
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="analytics_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        foreach($data as $row) {
            fputcsv($output, $row);
        }
        fclose($output);
    }
    
    exit;
}
