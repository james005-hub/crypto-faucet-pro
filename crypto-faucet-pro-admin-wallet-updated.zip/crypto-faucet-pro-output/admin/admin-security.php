<?php
/**
 * Admin Security page — IP rate limits, email verify, 2FA settings, XP, chat, KYC thresholds.
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_security() {
    $saved = false;
    if ( isset($_POST['cfp_save_security']) && check_admin_referer('cfp_security') ) {
        $fields = [
            'ip_limiter_enabled', 'ip_limit_game', 'ip_limit_claim',
            'ip_limit_register', 'ip_limit_withdraw', 'ip_limit_chat',
            'ip_limit_api', 'ip_limit_login', 'ip_limit_password_reset',
            'max_concurrent_sessions', 'ip_limit_window_seconds', 'ip_fingerprinting_enabled',
            'email_verify_required',
            'xp_enabled',
            'chat_enabled', 'chat_min_tip', 'chat_min_rain',
            'kyc_required_above_sat',
            'live_price_enabled','tos_enabled','tos_minimum_age','tos_page_url','privacy_page_url','tos_content','withdraw_new_account_hold_days','withdraw_cooling_hours','withdraw_cooling_win_sat','withdraw_daily_cap_sat','withdraw_flag_winrate','ssl_enforce_enabled','csp_policy','unverified_purge_days','audit_log_retention_days','block_vpn_tor','block_bot_ua','honeypot_enabled','multi_ip_check','multi_ip_max','auto_ban_strikes','request_ts_check','banned_ips','blocked_cidrs','daily_loss_limit_sat','game_min_bet','game_max_bet','coinflip_don_enabled','wheel_vip_bet',
            'secure_cookies','session_ip_strict','block_disposable_email','require_strong_password','max_login_attempts',
            'country_blocking_enabled', 'country_block_action', 'blocked_countries_custom',
            'geo_block_games', 'geo_block_withdrawals', 'geo_block_claims', 'geo_block_deposits',
            'block_datacenters', 'block_vpns', 'block_tor', 'block_proxies',
            // Revenue Controller
            'revenue_withdraw_pct_fee', 'revenue_withdraw_fixed_fee',
            'revenue_fun_token_pct_fee', 'revenue_fun_token_fixed_fee',
            'revenue_auto_sweep_enabled', 'revenue_sweep_pct', 'revenue_sweep_threshold',
            'revenue_deposit_pct', 'revenue_claim_pct', 'revenue_game_win_pct',
            'revenue_game_loss_pct', 'revenue_referral_pct', 'revenue_game_pct',
            // Auto Onchain Sweep
            'revenue_auto_sweep_onchain', 'revenue_onchain_address', 'revenue_onchain_threshold', 'revenue_onchain_currency',
        ];
        foreach ($fields as $f) {
            if (isset($_POST[$f])) cfp_update_setting($f, sanitize_text_field($_POST[$f]));
        }
        
        if (isset($_POST['blocked_countries'])) {
            $countries = is_array($_POST['blocked_countries']) ? array_map('sanitize_text_field', $_POST['blocked_countries']) : [];
            cfp_update_setting('blocked_countries', json_encode($countries));
        }
        
        $saved = true;
    }
    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };

    global $wpdb;
    $blocked_today = (int)$wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_IP_LIMITS." WHERE hit_count >= 5 AND window_start >= DATE_SUB(NOW(),INTERVAL 1 DAY)");
    $chat_count    = (int)$wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_CHAT);
    $kyc_pending   = (int)$wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_KYC." WHERE status='pending'");
    $xp_given      = (int)$wpdb->get_var("SELECT COALESCE(SUM(xp_amount),0) FROM ".CFP_TABLE_XP_LOG);
    ?>
    <div class="cfp-wrap">
    <div class="cfp-header"><span class="cfp-logo-badge">⚡ CFP</span><h1>🛡️ Security & Features</h1></div>
    <?php if($saved): ?><div class="cfp-notice success">✅ Settings saved!</div><?php endif; ?>

    <div class="cfp-stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px">
        <div class="cfp-stat-card red"><div class="label">🚫 IPs Rate-Limited (24h)</div><div class="value"><?=$blocked_today?></div></div>
        <div class="cfp-stat-card blue"><div class="label">💬 Chat Messages</div><div class="value"><?=number_format($chat_count)?></div></div>
        <div class="cfp-stat-card"><div class="label">🪪 KYC Pending</div><div class="value"><?=$kyc_pending?></div><div class="sub"><a href="<?=admin_url('admin.php?page=cfp-kyc')?>" style="color:var(--g)">Review →</a></div></div>
        <div class="cfp-stat-card green"><div class="label">⭐ Total XP Given</div><div class="value"><?=number_format($xp_given)?></div></div>
    </div>

    <form method="post">
    <?php wp_nonce_field('cfp_security'); ?>

    <!-- IP RATE LIMITER -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🚫 IP Rate Limiter</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Automatically blocks IPs that send too many requests within a time window. Protects games, claims, and registrations from bots.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Master Switch</label>
                <select name="ip_limiter_enabled" style="background:#111">
                    <option value="1" <?=selected($gs('ip_limiter_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('ip_limiter_enabled','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Game rolls per minute per IP</label>
                <input type="number" name="ip_limit_game" value="<?=esc_attr($gs('ip_limit_game',120))?>" min="1">
                <span class="hint">Default 120 (2/sec). Lower = stricter.</span>
            </div>
            <div class="cfp-field">
                <label>Claim attempts per 5 min per IP</label>
                <input type="number" name="ip_limit_claim" value="<?=esc_attr($gs('ip_limit_claim',5))?>" min="1">
            </div>
            <div class="cfp-field">
                <label>Registrations per hour per IP</label>
                <input type="number" name="ip_limit_register" value="<?=esc_attr($gs('ip_limit_register',3))?>" min="1">
            </div>
            <div class="cfp-field">
                <label>Withdrawals per hour per IP</label>
                <input type="number" name="ip_limit_withdraw" value="<?=esc_attr($gs('ip_limit_withdraw',5))?>" min="1">
            </div>
            <div class="cfp-field">
                <label>Chat messages per minute per IP</label>
                <input type="number" name="ip_limit_chat" value="<?=esc_attr($gs('ip_limit_chat',30))?>" min="1">
            </div>
        </div>
    </div>

    <!-- ADVANCED RATE LIMITING -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>⚡ Advanced Rate Limiting Rules</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Configure granular rate limits for specific actions and endpoints.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>API requests per minute per IP</label>
                <input type="number" name="ip_limit_api" value="<?=esc_attr($gs('ip_limit_api',60))?>" min="1">
                <span class="hint">AJAX API calls, shortcode loads</span>
            </div>
            <div class="cfp-field">
                <label>Login attempts per 15 min per IP</label>
                <input type="number" name="ip_limit_login" value="<?=esc_attr($gs('ip_limit_login',10))?>" min="1">
                <span class="hint">Protect against brute force</span>
            </div>
            <div class="cfp-field">
                <label>Password reset requests per hour</label>
                <input type="number" name="ip_limit_password_reset" value="<?=esc_attr($gs('ip_limit_password_reset',3))?>" min="1">
            </div>
            <div class="cfp-field">
                <label>Max concurrent sessions per user</label>
                <input type="number" name="max_concurrent_sessions" value="<?=esc_attr($gs('max_concurrent_sessions',3))?>" min="1">
            </div>
            <div class="cfp-field">
                <label>Rate limit window (seconds)</label>
                <input type="number" name="ip_limit_window_seconds" value="<?=esc_attr($gs('ip_limit_window_seconds',60))?>" min="10">
                <span class="hint">Base time window for rate counting</span>
            </div>
            <div class="cfp-field">
                <label>Enable IP fingerprinting</label>
                <select name="ip_fingerprinting_enabled" style="background:#111">
                    <option value="1" <?=selected($gs('ip_fingerprinting_enabled','0'),'1',false)?>>✅ Enabled — combine IP + User-Agent</option>
                    <option value="0" <?=selected($gs('ip_fingerprinting_enabled','0'),'0',false)?>>⏸ Disabled — IP only</option>
                </select>
            </div>
        </div>
    </div>

    <!-- COUNTRY BLOCKING -->
    <?php
    // Country blocking options (common countries)
    $countries = [
        'US' => 'United States', 'GB' => 'United Kingdom', 'DE' => 'Germany', 'FR' => 'France',
        'CA' => 'Canada', 'AU' => 'Australia', 'JP' => 'Japan', 'KR' => 'South Korea',
        'CN' => 'China', 'RU' => 'Russia', 'BR' => 'Brazil', 'IN' => 'India',
        'NG' => 'Nigeria', 'PK' => 'Pakistan', 'ID' => 'Indonesia', 'VN' => 'Vietnam',
    ];
    $blocked_countries = json_decode(cfp_get_setting('blocked_countries', '[]'), true) ?: [];
    ?>
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🌍 Country Blocking</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Block access from specific countries. Uses IP geolocation to determine user location.</p>
        
        <div style="display:flex;gap:20px;margin-bottom:16px">
            <div class="cfp-field">
                <label>Enable Country Blocking</label>
                <select name="country_blocking_enabled" style="background:#111">
                    <option value="1" <?=selected($gs('country_blocking_enabled','0'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('country_blocking_enabled','0'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Block Action</label>
                <select name="country_block_action" style="background:#111">
                    <option value="block" <?=selected($gs('country_block_action','block'),'block',false)?>>🚫 Block completely</option>
                    <option value="flag" <?=selected($gs('country_block_action','block'),'flag',false)?>>⚠️ Allow but flag for review</option>
                </select>
            </div>
        </div>
        
        <div style="margin-bottom:16px">
            <label style="display:block;font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:var(--mt);margin-bottom:8px">Select Countries to Block</label>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:8px;max-height:250px;overflow-y:auto;background:#0d0d0d;border:1px solid #1a1a1a;border-radius:8px;padding:12px">
                <?php foreach($countries as $code => $name): ?>
                <label style="display:flex;align-items:center;gap:8px;padding:8px;background:#111;border-radius:6px;cursor:pointer;font-size:.82rem;transition:background .15s" onmouseover="this.style.background='#1a1a1a'" onmouseout="this.style.background='#111'">
                    <input type="checkbox" name="blocked_countries[]" value="<?=$code?>" <?=in_array($code, $blocked_countries)?'checked':''?> style="width:16px;height:16px">
                    <span><?=$code?> - <?=$name?></span>
                </label>
                <?php endforeach; ?>
            </div>
        </div>
        
        <div class="cfp-field">
            <label>Custom Blocked Countries (comma-separated country codes)</label>
            <input type="text" name="blocked_countries_custom" value="<?=esc_attr($gs('blocked_countries_custom',''))?>" placeholder="XX, YY, ZZ">
            <span class="hint">Add additional 2-letter country codes not in the list above</span>
        </div>
    </div>

    <!-- GEO-RESTRICTIONS BY FEATURE -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🎯 Feature-Specific Geo-Rules</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Restrict certain features by country while allowing others.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Block Games for Blocked Countries</label>
                <select name="geo_block_games" style="background:#111">
                    <option value="1" <?=selected($gs('geo_block_games','1'),'1',false)?>>✅ Block games</option>
                    <option value="0" <?=selected($gs('geo_block_games','1'),'0',false)?>>⏸ Allow games</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Block Withdrawals for Blocked Countries</label>
                <select name="geo_block_withdrawals" style="background:#111">
                    <option value="1" <?=selected($gs('geo_block_withdrawals','1'),'1',false)?>>✅ Block withdrawals</option>
                    <option value="0" <?=selected($gs('geo_block_withdrawals','1'),'0',false)?>>⏸ Allow withdrawals</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Block Faucet Claims for Blocked Countries</label>
                <select name="geo_block_claims" style="background:#111">
                    <option value="1" <?=selected($gs('geo_block_claims','1'),'1',false)?>>✅ Block claims</option>
                    <option value="0" <?=selected($gs('geo_block_claims','1'),'0',false)?>>⏸ Allow claims</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Block Deposits for Blocked Countries</label>
                <select name="geo_block_deposits" style="background:#111">
                    <option value="1" <?=selected($gs('geo_block_deposits','1'),'1',false)?>>✅ Block deposits</option>
                    <option value="0" <?=selected($gs('geo_block_deposits','1'),'0',false)?>>⏸ Allow deposits</option>
                </select>
            </div>
        </div>
    </div>

    <!-- ISP BLOCKING -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>📡 ISP / Data Center Blocking</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Block known data centers, hosting providers, and VPN services.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Block Data Centers</label>
                <select name="block_datacenters" style="background:#111">
                    <option value="1" <?=selected($gs('block_datacenters','0'),'1',false)?>>✅ Enabled — block AWS, GCP, Azure, DigitalOcean, etc.</option>
                    <option value="0" <?=selected($gs('block_datacenters','0'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Block Known VPNs</label>
                <select name="block_vpns" style="background:#111">
                    <option value="1" <?=selected($gs('block_vpns','0'),'1',false)?>>✅ Enabled — block common VPN providers</option>
                    <option value="0" <?=selected($gs('block_vpns','0'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Block Tor Exit Nodes</label>
                <select name="block_tor" style="background:#111">
                    <option value="1" <?=selected($gs('block_tor','0'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('block_tor','0'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Block Proxy Services</label>
                <select name="block_proxies" style="background:#111">
                    <option value="1" <?=selected($gs('block_proxies','0'),'1',false)?>>✅ Enabled — block HideMyAss, ProxyHub, etc.</option>
                    <option value="0" <?=selected($gs('block_proxies','0'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
        </div>
    </div>

    <!-- EMAIL VERIFICATION -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>📧 Email Verification</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Require users to verify their email before they can claim. Reduces fake account abuse.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Require email verification on signup</label>
                <select name="email_verify_required" style="background:#111">
                    <option value="1" <?=selected($gs('email_verify_required','0'),'1',false)?>>✅ Required — must verify before claiming</option>
                    <option value="0" <?=selected($gs('email_verify_required','0'),'0',false)?>>⏸ Optional — can claim without verifying</option>
                </select>
                <span class="hint">Requires WordPress email (SMTP) to be configured.</span>
            </div>
        </div>
    </div>

    <!-- XP SYSTEM -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>⭐ XP & Level System</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Players earn XP for claims, game plays, tips, and rain. Higher levels get claim bonuses and lower house edge.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>XP System</label>
                <select name="xp_enabled" style="background:#111">
                    <option value="1" <?=selected($gs('xp_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('xp_enabled','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
        </div>
        <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:8px;padding:12px;margin-top:12px;font-size:.82rem;color:#777">
            XP earned per action: Claim = 10 XP · Game played = 1 XP · Game win = 5 XP · Tip = 5 XP · Rain = 20 XP
        </div>
    </div>

    <!-- CHAT -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>💬 Chat Settings</h2>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Chat</label>
                <select name="chat_enabled" style="background:#111">
                    <option value="1" <?=selected($gs('chat_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('chat_enabled','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Minimum tip amount (sat)</label>
                <input type="number" name="chat_min_tip" value="<?=esc_attr($gs('chat_min_tip',100))?>" min="1">
            </div>
            <div class="cfp-field">
                <label>Minimum rain amount (sat)</label>
                <input type="number" name="chat_min_rain" value="<?=esc_attr($gs('chat_min_rain',1000))?>" min="1">
            </div>
        </div>
    </div>

    <!-- KYC -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🪪 KYC Settings</h2>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Require KYC for withdrawals above (sat, 0 = disabled)</label>
                <input type="number" name="kyc_required_above_sat" value="<?=esc_attr($gs('kyc_required_above_sat',0))?>" min="0">
                <span class="hint">e.g. 1000000 = require KYC for withdrawals over 1M sat. 0 = KYC never required.</span>
            </div>
        </div>
        <p style="color:#777;font-size:.82rem;margin-top:10px">
            <a href="<?=admin_url('admin.php?page=cfp-kyc')?>" style="color:var(--g)">→ Review KYC submissions</a>
        </p>
    </div>

    <!-- LIVE PRICE -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>💱 Live Price Feed</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Fetches live price from CoinGecko API every 2 minutes. Auto-updates the static fallback price in General Settings.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Live Price Feed</label>
                <select name="live_price_enabled" style="background:#111">
                    <option value="1" <?=selected($gs('live_price_enabled','1'),'1',false)?>>✅ Enabled (CoinGecko API)</option>
                    <option value="0" <?=selected($gs('live_price_enabled','1'),'0',false)?>>⏸ Use static price only</option>
                </select>
                <span class="hint">Uses the free CoinGecko API — no key required. Add [cfp_price_ticker] shortcode anywhere.</span>
            </div>
            <div class="cfp-field">
                <label>Current Cached Price</label>
                <input type="text" value="$<?=number_format(cfp_get_live_price(),2)?>" readonly style="opacity:.6;cursor:not-allowed">
                <span class="hint">Auto-refreshed. Edit static fallback in General Settings.</span>
            </div>
        </div>
    </div>

    
    <!-- ADVANCED SECURITY -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🛡️ Advanced Security</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Enhanced bot detection, auto-banning, IP blocking, and request integrity checks.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Block Bot User-Agents</label>
                <select name="block_bot_ua" style="background:#111">
                    <option value="1" <?=selected($gs('block_bot_ua','1'),'1',false)?>>✅ Enabled (curl, scrapy, headless browsers…)</option>
                    <option value="0" <?=selected($gs('block_bot_ua','1'),'0',false)?>>⏸ Disabled</option>
                </select>
                <span class="hint">Blocks common automation tools by User-Agent signature.</span>
            </div>
            <div class="cfp-field">
                <label>Honeypot on Registration</label>
                <select name="honeypot_enabled" style="background:#111">
                    <option value="1" <?=selected($gs('honeypot_enabled','1'),'1',false)?>>✅ Enabled — auto-ban IPs that fill hidden field</option>
                    <option value="0" <?=selected($gs('honeypot_enabled','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Multi-IP Fraud Detection</label>
                <select name="multi_ip_check" style="background:#111">
                    <option value="1" <?=selected($gs('multi_ip_check','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('multi_ip_check','1'),'0',false)?>>⏸ Disabled</option>
                </select>
                <span class="hint">Flags accounts used from too many IPs in 1 hour.</span>
            </div>
            <div class="cfp-field">
                <label>Max IPs per email per hour</label>
                <input type="number" name="multi_ip_max" value="<?=esc_attr($gs('multi_ip_max',5))?>" min="1" max="20">
                <span class="hint">Default 5. Lower = stricter fraud detection.</span>
            </div>
            <div class="cfp-field">
                <label>Auto-ban after N rate-limit violations</label>
                <input type="number" name="auto_ban_strikes" value="<?=esc_attr($gs('auto_ban_strikes',5))?>" min="1">
                <span class="hint">IP is auto-banned after this many strikes in 10 minutes. 0 = disabled.</span>
            </div>
            <div class="cfp-field">
                <label>Request Timestamp Check (replay protection)</label>
                <select name="request_ts_check" style="background:#111">
                    <option value="1" <?=selected($gs('request_ts_check','1'),'1',false)?>>✅ Enabled — reject requests older than 5 min</option>
                    <option value="0" <?=selected($gs('request_ts_check','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Block VPN / Tor</label>
                <select name="block_vpn_tor" style="background:#111">
                    <option value="0" <?=selected($gs('block_vpn_tor','0'),'0',false)?>>⏸ Disabled</option>
                    <option value="1" <?=selected($gs('block_vpn_tor','0'),'1',false)?>>✅ Enabled (uses CIDR list below)</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Block Disposable Emails (tempmail, guerrillamail, etc.)</label>
                <select name="block_disposable_email" style="background:#111">
                    <option value="1" <?=selected($gs('block_disposable_email','0'),'1',false)?>>✅ Enabled — block known disposable email domains</option>
                    <option value="0" <?=selected($gs('block_disposable_email','0'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Require Strong Passwords (uppercase, lowercase, number, special)</label>
                <select name="require_strong_password" style="background:#111">
                    <option value="1" <?=selected($gs('require_strong_password','1'),'1',false)?>>✅ Enabled — enforce complex passwords</option>
                    <option value="0" <?=selected($gs('require_strong_password','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Session IP Strict Mode (validate IP on each request)</label>
                <select name="session_ip_strict" style="background:#111">
                    <option value="1" <?=selected($gs('session_ip_strict','1'),'1',false)?>>✅ Enabled — stricter session security</option>
                    <option value="0" <?=selected($gs('session_ip_strict','1'),'0',false)?>>⏸ Disabled — allow IP changes within session</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Secure Cookies (HTTPOnly, Secure, SameSite)</label>
                <select name="secure_cookies" style="background:#111">
                    <option value="1" <?=selected($gs('secure_cookies','1'),'1',false)?>>✅ Enabled — enhanced cookie security</option>
                    <option value="0" <?=selected($gs('secure_cookies','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
        </div>
        <div class="cfp-field" style="margin-top:14px">
            <label>Blocked CIDR Ranges / IPs (one per line)</label>
            <textarea name="blocked_cidrs" rows="4" style="background:#111;border:1px solid #222;border-radius:8px;padding:8px 12px;color:#ccc;font-family:monospace;font-size:.8rem;width:100%;box-sizing:border-box"><?=esc_textarea($gs('blocked_cidrs',''))?></textarea>
            <span class="hint">e.g. 185.220.101.0/24 — Tor exit nodes, known VPN ranges.</span>
        </div>
        <div class="cfp-field" style="margin-top:14px">
            <label>Manually Banned IPs (JSON array — edit with care)</label>
            <textarea name="banned_ips" rows="3" style="background:#111;border:1px solid #222;border-radius:8px;padding:8px 12px;color:#ccc;font-family:monospace;font-size:.8rem;width:100%;box-sizing:border-box"><?=esc_textarea($gs('banned_ips','[]'))?></textarea>
            <span class="hint">Format: ["1.2.3.4","5.6.7.0/24"]. Managed automatically by auto-ban.</span>
        </div>
    </div>

    <!-- RESPONSIBLE GAMBLING LIMITS -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>⚖️ Responsible Gambling Limits</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Protect players with daily loss caps and bet size limits. Applied across all games.</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Daily Loss Limit per user (sat, 0 = disabled)</label>
                <input type="number" name="daily_loss_limit_sat" value="<?=esc_attr($gs('daily_loss_limit_sat',0))?>" min="0">
                <span class="hint">e.g. 500000 = user cannot lose more than 500k sat per day.</span>
            </div>
            <div class="cfp-field">
                <label>Minimum bet (sat)</label>
                <input type="number" name="game_min_bet" value="<?=esc_attr($gs('game_min_bet',10))?>" min="1">
            </div>
            <div class="cfp-field">
                <label>Maximum bet (sat, 0 = unlimited)</label>
                <input type="number" name="game_max_bet" value="<?=esc_attr($gs('game_max_bet',100000))?>" min="0">
            </div>
        </div>
    </div>

    <!-- GAME FEATURE TOGGLES -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🎮 Game Feature Toggles</h2>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Coin Flip: Double-or-Nothing</label>
                <select name="coinflip_don_enabled" style="background:#111">
                    <option value="1" <?=selected($gs('coinflip_don_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('coinflip_don_enabled','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
            <div class="cfp-field">
                <label>Wheel: VIP bet threshold for 25x segment (sat)</label>
                <input type="number" name="wheel_vip_bet" value="<?=esc_attr($gs('wheel_vip_bet',500))?>" min="1">
                <span class="hint">Players betting at least this amount unlock the rare 25x VIP wheel segment.</span>
            </div>
        </div>
    </div>

    
    <!-- SSL / HTTPS -->
    <div class="cfp-card" style="margin-bottom:22px">
        <h2>🔒 HTTPS / SSL Enforcement</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">Force all traffic over HTTPS and apply security headers (HSTS, CSP, X-Frame-Options, etc.).</p>
        <div class="cfp-form-grid">
            <div class="cfp-field">
                <label>Enforce HTTPS</label>
                <select name="ssl_enforce_enabled" style="background:#111">
                    <option value="1" <?=selected($gs('ssl_enforce_enabled','1'),'1',false)?>>✅ Enabled — 301 redirect HTTP → HTTPS + security headers</option>
                    <option value="0" <?=selected($gs('ssl_enforce_enabled','1'),'0',false)?>>⏸ Disabled</option>
                </select>
                <span class="hint">Only disable if your server/Cloudflare already handles HTTPS.</span>
            </div>
            <div class="cfp-field">
                <label>Auto-purge unverified accounts after (days, 0 = never)</label>
                <input type="number" name="unverified_purge_days" value="<?=esc_attr($gs('unverified_purge_days',0))?>" min="0">
                <span class="hint">Deletes zero-balance unverified accounts older than N days. 0 = keep forever.</span>
            </div>
            <div class="cfp-field">
                <label>Audit log retention (days)</label>
                <input type="number" name="audit_log_retention_days" value="<?=esc_attr($gs('audit_log_retention_days',90))?>" min="7">
            </div>
        </div>
        <div class="cfp-field" style="margin-top:14px">
            <label>Custom Content Security Policy (leave blank for default)</label>
            <textarea name="csp_policy" rows="3" style="background:#111;border:1px solid #222;border-radius:8px;padding:8px 12px;color:#ccc;font-family:monospace;font-size:.78rem;width:100%;box-sizing:border-box"><?=esc_textarea($gs('csp_policy',''))?></textarea>
            <span class="hint">Advanced: override the CSP header. Leave blank for the built-in safe default.</span>
        </div>
    </div>

    <?php do_action('cfp_security_extra_cards'); ?>

    <button type="submit" name="cfp_save_security" class="cfp-btn cfp-btn-gold" style="font-size:1rem;padding:13px 36px">
        💾 Save Security Settings
    </button>
    </form>
    </div>
    <?php
}

/* ============================================================
   ADMIN: PWA SETTINGS PAGE
   ============================================================ */
function cfp_admin_pwa_settings() {
    $saved = false;
    if (isset($_POST['cfp_save_pwa']) && check_admin_referer('cfp_pwa')) {
        cfp_update_setting('pwa_enabled', sanitize_text_field($_POST['pwa_enabled'] ?? '1'));
        $saved = true;
    }
    $manifest_url = home_url('/?cfp_pwa_manifest=1');
    $sw_url       = home_url('/?cfp_pwa_sw=1');
    ?>
    <div class="cfp-wrap">
    <div class="cfp-header"><span class="cfp-logo-badge">⚡ CFP</span><h1>📱 PWA / Mobile App</h1></div>
    <?php if($saved): ?><div class="cfp-notice success">✅ Saved!</div><?php endif; ?>

    <div class="cfp-card" style="margin-bottom:22px">
        <h2>Progressive Web App</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:16px">
            Makes your faucet installable as a home screen app on iOS and Android — no App Store needed.
            Users tap "Install" on Chrome/Android or "Add to Home Screen" on iOS Safari.
        </p>
        <form method="post">
        <?php wp_nonce_field('cfp_pwa'); ?>
        <div class="cfp-form-grid" style="margin-bottom:16px">
            <div class="cfp-field">
                <label>PWA / Install-as-App</label>
                <select name="pwa_enabled" style="background:#111">
                    <option value="1" <?=selected(cfp_get_setting('pwa_enabled','1'),'1',false)?>>✅ Enabled — install banner + manifest</option>
                    <option value="0" <?=selected(cfp_get_setting('pwa_enabled','1'),'0',false)?>>⏸ Disabled</option>
                </select>
            </div>
        </div>
        <button type="submit" name="cfp_save_pwa" class="cfp-btn cfp-btn-gold">💾 Save</button>
        </form>
    </div>

    <div class="cfp-card" style="margin-bottom:22px">
        <h2>📋 PWA Endpoints</h2>
        <div style="margin-bottom:12px">
            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1px;color:#555;margin-bottom:4px">App Manifest</div>
            <div style="display:flex;align-items:center;gap:8px">
                <code style="background:#0d0d0d;border:1px solid #1e1e1e;padding:8px 12px;border-radius:7px;font-size:.78rem;color:#22c55e;flex:1;word-break:break-all"><?=esc_html($manifest_url)?></code>
                <button onclick="navigator.clipboard.writeText('<?=esc_js($manifest_url)?>')" style="background:#1a2a1a;border:1px solid #22c55e33;color:#22c55e;padding:7px 12px;border-radius:7px;font-size:.75rem;cursor:pointer">📋 Copy</button>
            </div>
        </div>
        <div style="margin-bottom:12px">
            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1px;color:#555;margin-bottom:4px">Service Worker</div>
            <div style="display:flex;align-items:center;gap:8px">
                <code style="background:#0d0d0d;border:1px solid #1e1e1e;padding:8px 12px;border-radius:7px;font-size:.78rem;color:#3b82f6;flex:1;word-break:break-all"><?=esc_html($sw_url)?></code>
            </div>
        </div>
        <p style="color:#555;font-size:.82rem;margin-top:10px">
            Shortcode for install instructions: <code>[cfp_install_app]</code>
        </p>
    </div>
    </div>
    <?php
}

/* ============================================================
   ADMIN: Multi-crypto wrapper page
   ============================================================ */
function cfp_admin_multicurrency() {
    echo '<div class="cfp-wrap"><div class="cfp-header"><span class="cfp-logo-badge">⚡ CFP</span><h1>🪙 Multi-Crypto</h1></div>';
    if (function_exists('cfp_admin_multicurrency_settings')) cfp_admin_multicurrency_settings();
    echo '</div>';
}
