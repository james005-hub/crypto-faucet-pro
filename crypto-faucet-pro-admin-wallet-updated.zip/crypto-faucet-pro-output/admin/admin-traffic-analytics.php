<?php
/**
 * Admin page: Traffic Analytics - Source tracking, user agents, referrer URLs
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Detailed Traffic Data
   ============================================================ */
add_action('wp_ajax_cfp_traffic_analytics_data', 'cfp_ajax_traffic_analytics_data');
function cfp_ajax_traffic_analytics_data() {
    check_ajax_referer('cfp_traffic_nonce', 'nonce');
    
    global $wpdb;
    $period = sanitize_text_field($_POST['period'] ?? '7days');
    $page = max(1, intval($_POST['page'] ?? 1));
    $limit = 50;
    $offset = ($page - 1) * $limit;
    
    switch($period) {
        case '24hours':
            $date_cond = "created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)";
            break;
        case '30days':
            $date_cond = "created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)";
            break;
        case '90days':
            $date_cond = "created_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)";
            break;
        default:
            $date_cond = "created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
    }
    
    $sessions = $wpdb->get_results($wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}cfp_traffic_sessions 
        WHERE {$date_cond} AND is_bot = 0
        ORDER BY last_activity DESC LIMIT %d OFFSET %d",
        $limit, $offset
    ));
    
    $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}cfp_traffic_sessions WHERE {$date_cond} AND is_bot = 0");
    
    $top_referrers = $wpdb->get_results($wpdb->prepare(
        "SELECT referrer, COUNT(*) as cnt FROM {$wpdb->prefix}cfp_traffic_sessions 
        WHERE {$date_cond} AND referrer IS NOT NULL AND referrer != ''
        GROUP BY referrer ORDER BY cnt DESC LIMIT 10"
    ));
    
    $top_browsers = $wpdb->get_results($wpdb->prepare(
        "SELECT browser, COUNT(*) as cnt FROM {$wpdb->prefix}cfp_traffic_sessions 
        WHERE {$date_cond} AND browser IS NOT NULL
        GROUP BY browser ORDER BY cnt DESC LIMIT 5"
    ));
    
    $top_os = $wpdb->get_results($wpdb->prepare(
        "SELECT os, COUNT(*) as cnt FROM {$wpdb->prefix}cfp_traffic_sessions 
        WHERE {$date_cond} AND os IS NOT NULL
        GROUP BY os ORDER BY cnt DESC LIMIT 5"
    ));
    
    $device_breakdown = $wpdb->get_results($wpdb->prepare(
        "SELECT device_type, COUNT(*) as cnt FROM {$wpdb->prefix}cfp_traffic_sessions 
        WHERE {$date_cond}
        GROUP BY device_type"
    ));
    
    wp_send_json_success([
        'sessions' => $sessions,
        'total' => $total,
        'pages' => ceil($total / $limit),
        'current_page' => $page,
        'top_referrers' => $top_referrers,
        'top_browsers' => $top_browsers,
        'top_os' => $top_os,
        'device_breakdown' => $device_breakdown
    ]);
}

/* ============================================================
   ADMIN: TRAFFIC ANALYTICS PAGE
   ============================================================ */
function cfp_admin_traffic_analytics() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_traffic_nonce');
    
    $today = date('Y-m-d');
    $this_month = date('Y-m-01');
    
    $today_visitors = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT session_id) FROM {$wpdb->prefix}cfp_traffic_sessions WHERE DATE(created_at) = %s AND is_bot = 0",
        $today
    ));
    
    $today_pageviews = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}cfp_traffic_pageviews WHERE DATE(created_at) = %s",
        $today
    ));
    
    $month_visitors = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(DISTINCT session_id) FROM {$wpdb->prefix}cfp_traffic_sessions WHERE created_at >= %s AND is_bot = 0",
        $this_month
    ));
    
    $month_pageviews = (int)$wpdb->get_var($wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->prefix}cfp_traffic_pageviews WHERE created_at >= %s",
        $this_month
    ));
    
    $total_visitors = (int)$wpdb->get_var("SELECT COUNT(DISTINCT session_id) FROM {$wpdb->prefix}cfp_traffic_sessions WHERE is_bot = 0");
    $total_pageviews = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}cfp_traffic_pageviews");
    $bot_visitors = (int)$wpdb->get_var("SELECT COUNT(DISTINCT session_id) FROM {$wpdb->prefix}cfp_traffic_sessions WHERE is_bot = 1");
    
    $top_pages = $wpdb->get_results("
        SELECT path, COUNT(*) as views FROM {$wpdb->prefix}cfp_traffic_pageviews 
        GROUP BY path ORDER BY views DESC LIMIT 10
    ");
    
    $top_countries = $wpdb->get_results("
        SELECT country, COUNT(*) as visitors FROM {$wpdb->prefix}cfp_traffic_sessions 
        WHERE country != 'XX' AND is_bot = 0
        GROUP BY country ORDER BY visitors DESC LIMIT 10
    ");
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">📈</span>
            <h1>📈 Traffic Analytics</h1>
            <button onclick="cfpExportTraffic('csv')" class="cfp-btn cfp-btn-ghost" style="margin-left:auto">📥 Export CSV</button>
        </div>

        <!-- PERIOD TABS -->
        <div class="cfp-tabs" style="margin-bottom:20px">
            <button class="cfp-tab active" onclick="cfpChangeTrafficPeriod('7days', this)">7 Days</button>
            <button class="cfp-tab" onclick="cfpChangeTrafficPeriod('24hours', this)">24 Hours</button>
            <button class="cfp-tab" onclick="cfpChangeTrafficPeriod('30days', this)">30 Days</button>
            <button class="cfp-tab" onclick="cfpChangeTrafficPeriod('90days', this)">90 Days</button>
        </div>

        <!-- OVERVIEW STATS -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(6, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card green">
                <div class="label">👥 Today's Visitors</div>
                <div class="value"><?=number_format($today_visitors)?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">📄 Today's Page Views</div>
                <div class="value"><?=number_format($today_pageviews)?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">👥 Month Visitors</div>
                <div class="value"><?=number_format($month_visitors)?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">📄 Month Page Views</div>
                <div class="value"><?=number_format($month_pageviews)?></div>
            </div>
            <div class="cfp-stat-card green">
                <div class="label">👥 Total Visitors</div>
                <div class="value"><?=number_format($total_visitors)?></div>
            </div>
            <div class="cfp-stat-card red">
                <div class="label">🤖 Bots Blocked</div>
                <div class="value"><?=number_format($bot_visitors)?></div>
            </div>
        </div>

        <!-- CHARTS ROW -->
        <div class="cfp-2col" style="margin-bottom:30px">
            <div class="cfp-card">
                <h2>🌍 Top Countries</h2>
                <div id="cfp-country-list" style="max-height:300px;overflow-y:auto">
                    <?php foreach($top_countries as $c): ?>
                    <div style="display:flex;justify-content:space-between;padding:10px;border-bottom:1px solid #1a1a1a">
                        <span><span style="font-size:1.2rem"><?=cfp_get_country_flag($c->country)?></span> <?=esc_html($c->country)?></span>
                        <span style="color:#f7931a;font-weight:700"><?=number_format($c->visitors)?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <div class="cfp-card">
                <h2>📄 Top Pages</h2>
                <div id="cfp-pages-list" style="max-height:300px;overflow-y:auto">
                    <?php foreach($top_pages as $p): ?>
                    <div style="display:flex;justify-content:space-between;padding:10px;border-bottom:1px solid #1a1a1a">
                        <span style="color:#888;max-width:250px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=esc_html($p->path)?></span>
                        <span style="color:#22c55e;font-weight:700"><?=number_format($p->views)?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- DEVICE & BROWSER BREAKDOWN -->
        <div class="cfp-3col" style="margin-bottom:30px">
            <div class="cfp-card">
                <h2>📱 Device Types</h2>
                <div id="cfp-devices" style="height:250px;position:relative">
                    <canvas id="cfpDeviceChart"></canvas>
                </div>
            </div>
            <div class="cfp-card">
                <h2>🌐 Browsers</h2>
                <div id="cfp-browsers"></div>
            </div>
            <div class="cfp-card">
                <h2>💻 Operating Systems</h2>
                <div id="cfp-os"></div>
            </div>
        </div>

        <!-- SESSION LIST -->
        <div class="cfp-card">
            <h2>📋 Recent Sessions</h2>
            <div class="cfp-tabs" style="margin-bottom:15px">
                <button class="cfp-tab active" onclick="cfpLoadSessions(1)">All Sessions</button>
            </div>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>IP</th>
                            <th>Country</th>
                            <th>Device</th>
                            <th>Browser</th>
                            <th>OS</th>
                            <th>Pages</th>
                            <th>Referrer</th>
                            <th>Last Activity</th>
                        </tr>
                    </thead>
                    <tbody id="cfp-sessions-tbody">
                        <tr><td colspan="8" style="text-align:center;color:#555">Loading...</td></tr>
                    </tbody>
                </table>
            </div>
            <div class="cfp-pagination" id="cfp-sessions-pagination"></div>
        </div>

        <!-- TOP REFERRERS -->
        <div class="cfp-card" style="margin-top:24px">
            <h2>🔗 Top Referrers</h2>
            <div id="cfp-referrers-list">
                <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:12px">
                    <?php 
                    $top_refs = $wpdb->get_results("
                        SELECT referrer, COUNT(*) as cnt FROM {$wpdb->prefix}cfp_traffic_sessions 
                        WHERE referrer IS NOT NULL AND referrer != '' AND is_bot = 0
                        GROUP BY referrer ORDER BY cnt DESC LIMIT 15
                    ");
                    foreach($top_refs as $r): 
                    ?>
                    <div style="background:#0d0d0d;padding:14px;border-radius:8px;display:flex;justify-content:space-between;align-items:center">
                        <span style="color:#888;font-size:.8rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:250px" title="<?=esc_attr($r->referrer)?>">
                            <?=esc_html($r->referrer)?>
                        </span>
                        <span style="color:#f7931a;font-weight:700"><?=number_format($r->cnt)?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
    let currentTrafficPeriod = '7days';
    let deviceChart = null;

    document.addEventListener('DOMContentLoaded', function() {
        cfpLoadTrafficData();
    });

    function cfpChangeTrafficPeriod(period, btn) {
        document.querySelectorAll('.cfp-tabs .cfp-tab').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentTrafficPeriod = period;
        cfpLoadTrafficData();
    }

    function cfpLoadTrafficData() {
        const fd = new FormData();
        fd.append('action', 'cfp_traffic_analytics_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('period', currentTrafficPeriod);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(data => {
                if(data.success) {
                    cfpUpdateTrafficUI(data.data);
                }
            });
    }

    function cfpUpdateTrafficUI(d) {
        // Update sessions table
        const tbody = document.getElementById('cfp-sessions-tbody');
        if(d.sessions.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#555">No sessions found</td></tr>';
        } else {
            tbody.innerHTML = d.sessions.map(s => `
                <tr>
                    <td style="font-family:monospace">${s.ip_address || 'N/A'}</td>
                    <td>${s.country ? cfpGetFlag(s.country) : 'N/A'} ${s.country || ''}</td>
                    <td><span class="cfp-badge ${s.device_type === 'mobile' ? 'pending' : s.device_type === 'tablet' ? 'drawn' : 'active'}">${s.device_type || 'unknown'}</span></td>
                    <td>${s.browser || 'Unknown'}</td>
                    <td>${s.os || 'Unknown'}</td>
                    <td>${s.page_views}</td>
                    <td style="max-width:150px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#666">${s.referrer || 'Direct'}</td>
                    <td style="color:#555;font-size:.75rem">${cfpTimeAgo(s.last_activity)}</td>
                </tr>
            `).join('');
        }

        // Pagination
        const pag = document.getElementById('cfp-sessions-pagination');
        if(d.pages > 1) {
            let html = '';
            for(let i=1; i<=Math.min(d.pages, 5); i++) {
                html += `<a href="#" onclick="cfpLoadSessions(${i});return false" class="${i === d.current_page ? 'current' : ''}">${i}</a>`;
            }
            pag.innerHTML = html;
        } else {
            pag.innerHTML = '';
        }

        // Browsers
        document.getElementById('cfp-browsers').innerHTML = d.top_browsers.map(b => `
            <div style="display:flex;justify-content:space-between;padding:8px;border-bottom:1px solid #1a1a1a">
                <span>${b.browser}</span>
                <span style="color:#3b82f6;font-weight:700">${b.cnt}</span>
            </div>
        `).join('');

        // OS
        document.getElementById('cfp-os').innerHTML = d.top_os.map(o => `
            <div style="display:flex;justify-content:space-between;padding:8px;border-bottom:1px solid #1a1a1a">
                <span>${o.os}</span>
                <span style="color:#a855f7;font-weight:700">${o.cnt}</span>
            </div>
        `).join('');

        // Device Chart
        const ctx = document.getElementById('cfpDeviceChart');
        if(ctx) {
            if(deviceChart) deviceChart.destroy();
            deviceChart = new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: d.device_breakdown.map(d => d.device_type),
                    datasets: [{
                        data: d.device_breakdown.map(d => d.cnt),
                        backgroundColor: ['#f7931a', '#22c55e', '#3b82f6', '#a855f7']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom', labels: { color: '#888' } } }
                }
            });
        }
    }

    function cfpLoadSessions(page) {
        const fd = new FormData();
        fd.append('action', 'cfp_traffic_analytics_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('period', currentTrafficPeriod);
        fd.append('page', page);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(data => {
                if(data.success) cfpUpdateTrafficUI(data.data);
            });
    }

    function cfpGetFlag(code) {
        const flags = { 'US': '🇺🇸', 'GB': '🇬🇧', 'DE': '🇩🇪', 'FR': '🇫🇷', 'IN': '🇮🇳', 'BR': '🇧🇷', 'RU': '🇷🇺', 'CN': '🇨🇳', 'JP': '🇯🇵', 'KR': '🇰🇷', 'CA': '🇨🇦', 'AU': '🇦🇺', 'ES': '🇪🇸', 'IT': '🇮🇹', 'NL': '🇳🇱' };
        return flags[code] || '🌍';
    }

    function cfpTimeAgo(dateStr) {
        const date = new Date(dateStr);
        const now = new Date();
        const secs = Math.floor((now - date) / 1000);
        if(secs < 60) return secs + 's ago';
        if(secs < 3600) return Math.floor(secs/60) + 'm ago';
        if(secs < 86400) return Math.floor(secs/3600) + 'h ago';
        return Math.floor(secs/86400) + 'd ago';
    }

    function cfpExportTraffic(format) {
        const fd = new FormData();
        fd.append('action', 'cfp_export_traffic');
        fd.append('format', format);
        fd.append('nonce', '<?=$nonce?>');
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.blob())
            .then(blob => {
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'traffic_' + new Date().toISOString().split('T')[0] + '.' + format;
                a.click();
            });
    }
    </script>
    <?php
}

function cfp_get_country_flag($code) {
    $flags = [
        'US' => '🇺🇸', 'GB' => '🇬🇧', 'DE' => '🇩🇪', 'FR' => '🇫🇷', 'IN' => '🇮🇳',
        'BR' => '🇧🇷', 'RU' => '🇷🇺', 'CN' => '🇨🇳', 'JP' => '🇯🇵', 'KR' => '🇰🇷',
        'CA' => '🇨🇦', 'AU' => '🇦🇺', 'ES' => '🇪🇸', 'IT' => '🇮🇹', 'NL' => '🇳🇱',
        'PL' => '🇵🇱', 'TR' => '🇹🇷', 'ID' => '🇮🇩', 'TH' => '🇹🇭', 'VN' => '🇻🇳'
    ];
    return $flags[$code] ?? '🌍';
}