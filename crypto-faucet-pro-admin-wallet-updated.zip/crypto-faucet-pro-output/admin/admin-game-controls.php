<?php
/**
 * Admin Panel: Game House Edge & Winning Probability Controls
 * 
 * Allows admin to adjust:
 * - House edge percentage for each game
 * - Player winning probability
 * - Payout multipliers
 * - Admin earnings from user losses
 * 
 * @package CryptoFaucetPro
 */
if ( ! defined( 'ABSPATH' ) ) exit;

add_action('admin_menu', function() {
    add_submenu_page(
        'cfp-settings',
        '🎰 Game Controls',
        '🎰 Game Controls',
        'manage_options',
        'cfp-game-controls',
        'cfp_render_game_controls_page'
    );
});

function cfp_render_game_controls_page() {
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized');
    }
    
    global $wpdb;
    $saved = false;
    
    if (isset($_POST['cfp_save_game_controls']) && wp_verify_nonce($_POST['game_controls_nonce'], 'cfp_game_controls')) {
        // Save all game settings
        $settings = [
            // Blackjack
            'blackjack_enabled', 'blackjack_house_edge', 'blackjack_player_win_pct', 
            'blackjack_payout', 'blackjack_blackjack_payout',
            // Roulette
            'roulette_enabled', 'roulette_house_edge', 'roulette_red_black_pct',
            'roulette_street_payout', 'roulette_corner_payout', 'roulette_single_payout',
            // Baccarat
            'baccarat_enabled', 'baccarat_house_edge_player', 'baccarat_house_edge_banker',
            'baccarat_house_edge_tie', 'baccarat_player_win_pct', 'baccarat_banker_win_pct',
            // Plinko
            'plinko_enabled', 'plinko_house_edge', 'plinko_row_8_mults', 
            'plinko_row_10_mults', 'plinko_row_12_mults', 'plinko_default_rows',
            // Mines
            'mines_enabled', 'mines_house_edge', 'mines_default_mines', 
            'mines_max_mines', 'mines_gem_multiplier',
            // Video Poker
            'videopoker_enabled', 'videopoker_house_edge', 'videopoker_fullpay',
            'videopoker_payout_jacks', 'videopoker_payout_2pair', 'videopoker_payout_3kind',
            'videopoker_payout_straight', 'videopoker_payout_flush', 'videopoker_payout_fullhouse',
            'videopoker_payout_4kind', 'videopoker_payout_straightflush', 'videopoker_payout_royal',
            // Keno
            'keno_enabled', 'keno_house_edge', 'keno_spots_default', 
            'keno_max_spots', 'keno_hits_payout',
            // Raffle
            'raffle_enabled', 'raffle_house_edge', 'raffle_min_bet', 
            'raffle_max_bet', 'raffle_jackpot_pct', 'raffle_secondary_prizes',
        ];
        
        foreach ($settings as $key) {
            if (isset($_POST[$key])) {
                cfp_update_setting($key, sanitize_text_field($_POST[$key]));
            }
        }
        
        // Reset jackpot pool if requested
        if (isset($_POST['reset_raffle_pool'])) {
            cfp_update_setting('raffle_pool_sat', 0);
            cfp_update_setting('raffle_total_tickets', 0);
        }
        
        $saved = true;
    }
    
    // Get current settings
    $s = [];
    $settings_keys = [
        'blackjack_enabled', 'blackjack_house_edge', 'blackjack_player_win_pct', 
        'blackjack_payout', 'blackjack_blackjack_payout',
        'roulette_enabled', 'roulette_house_edge', 'roulette_red_black_pct',
        'roulette_street_payout', 'roulette_corner_payout', 'roulette_single_payout',
        'baccarat_enabled', 'baccarat_house_edge_player', 'baccarat_house_edge_banker',
        'baccarat_house_edge_tie', 'baccarat_player_win_pct', 'baccarat_banker_win_pct',
        'plinko_enabled', 'plinko_house_edge', 'plinko_row_8_mults', 
        'plinko_row_10_mults', 'plinko_row_12_mults', 'plinko_default_rows',
        'mines_enabled', 'mines_house_edge', 'mines_default_mines', 
        'mines_max_mines', 'mines_gem_multiplier',
        'videopoker_enabled', 'videopoker_house_edge',
        'videopoker_payout_jacks', 'videopoker_payout_2pair', 'videopoker_payout_3kind',
        'videopoker_payout_straight', 'videopoker_payout_flush', 'videopoker_payout_fullhouse',
        'videopoker_payout_4kind', 'videopoker_payout_straightflush', 'videopoker_payout_royal',
        'keno_enabled', 'keno_house_edge', 'keno_spots_default', 
        'keno_max_spots', 'keno_hits_payout',
        'raffle_enabled', 'raffle_house_edge', 'raffle_min_bet', 
        'raffle_max_bet', 'raffle_jackpot_pct', 'raffle_secondary_prizes',
    ];
    
    foreach ($settings_keys as $key) {
        $s[$key] = cfp_get_setting($key, '');
    }
    
    $nonce = wp_create_nonce('cfp_game_controls');
    ?>
    <div class="wrap cfp-admin-wrap">
        <h1>🎰 Game Controls</h1>
        <p style="color:#666;margin-bottom:20px">Control house edge, winning probability, and payouts for all casino games.</p>
        
        <?php if ($saved): ?>
        <div class="notice notice-success"><p>✅ Game settings saved successfully!</p></div>
        <?php endif; ?>
        
        <form method="post" style="max-width:900px">
            <?php wp_nonce_field('cfp_game_controls', 'game_controls_nonce'); ?>
            
            <!-- QUICK INFO BOX -->
            <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:12px;padding:20px;margin-bottom:30px">
                <h3 style="margin:0 0 12px;color:#f7931a">💰 How House Edge Works</h3>
                <p style="color:#888;font-size:.85rem;line-height:1.6;margin:0">
                    <strong style="color:#ccc">House Edge %</strong> = How much you earn from each bet placed.<br>
                    <strong style="color:#ccc">Example:</strong> 5% house edge on a 1000 sat bet = <span style="color:#22c55e">50 sat goes to admin wallet</span><br>
                    <strong style="color:#ccc">Recommended:</strong> 1-10% for fair games. Higher = more earnings but fewer players.
                </p>
            </div>
            
            <!-- BLACKJACK -->
            <div style="background:#111;border:1px solid #1c1c1c;border-radius:12px;padding:24px;margin-bottom:20px">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid #1c1c1c">
                    <span style="font-size:1.5rem">🃏</span>
                    <h2 style="margin:0;font-size:1.2rem">Blackjack</h2>
                    <select name="blackjack_enabled" style="margin-left:auto;background:#1a1a1a;color:#fff;border:1px solid #333;padding:6px 12px;border-radius:6px">
                        <option value="1" <?=selected($s['blackjack_enabled'],'1',false)?>>Enabled</option>
                        <option value="0" <?=selected($s['blackjack_enabled'],'0',false)?>>Disabled</option>
                    </select>
                </div>
                
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px">
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">HOUSE EDGE (%)</label>
                        <input type="number" name="blackjack_house_edge" value="<?=esc_attr($s['blackjack_house_edge'] ?: '2.0')?>" step="0.1" min="0" max="50" 
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">Default: 2.0% (player-friendly)</small>
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">PLAYER WIN PROBABILITY (%)</label>
                        <input type="number" name="blackjack_player_win_pct" value="<?=esc_attr($s['blackjack_player_win_pct'] ?: '44.0')?>" step="0.1" min="30" max="50"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">Default: 44% (incl. pushes)</small>
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">STANDARD WIN PAYOUT</label>
                        <input type="number" name="blackjack_payout" value="<?=esc_attr($s['blackjack_payout'] ?: '2.0')?>" step="0.1" min="1" max="3"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">1 = even money, 2 = double</small>
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">BLACKJACK PAYOUT</label>
                        <input type="number" name="blackjack_blackjack_payout" value="<?=esc_attr($s['blackjack_blackjack_payout'] ?: '3.0')?>" step="0.1" min="1.5" max="3"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">3.0 = 3:2, 2.5 = 5:2</small>
                    </div>
                </div>
            </div>
            
            <!-- ROULETTE -->
            <div style="background:#111;border:1px solid #1c1c1c;border-radius:12px;padding:24px;margin-bottom:20px">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid #1c1c1c">
                    <span style="font-size:1.5rem">🎡</span>
                    <h2 style="margin:0;font-size:1.2rem">Roulette</h2>
                    <select name="roulette_enabled" style="margin-left:auto;background:#1a1a1a;color:#fff;border:1px solid #333;padding:6px 12px;border-radius:6px">
                        <option value="1" <?=selected($s['roulette_enabled'],'1',false)?>>Enabled</option>
                        <option value="0" <?=selected($s['roulette_enabled'],'0',false)?>>Disabled</option>
                    </select>
                </div>
                
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px">
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">HOUSE EDGE (%)</label>
                        <input type="number" name="roulette_house_edge" value="<?=esc_attr($s['roulette_house_edge'] ?: '2.7')?>" step="0.1" min="0" max="50"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">European: 2.7%, American: 5.26%</small>
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">RED/BLACK WIN %</label>
                        <input type="number" name="roulette_red_black_pct" value="<?=esc_attr($s['roulette_red_black_pct'] ?: '48.65')?>" step="0.1" min="40" max="50"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">European: 48.65%</small>
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">STREET BET PAYOUT</label>
                        <input type="number" name="roulette_street_payout" value="<?=esc_attr($s['roulette_street_payout'] ?: '12')?>" step="1" min="1" max="20"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">Standard: 11:1</small>
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">SINGLE NUMBER PAYOUT</label>
                        <input type="number" name="roulette_single_payout" value="<?=esc_attr($s['roulette_single_payout'] ?: '35')?>" step="1" min="1" max="50"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">Standard: 35:1</small>
                    </div>
                </div>
            </div>
            
            <!-- BACCARAT -->
            <div style="background:#111;border:1px solid #1c1c1c;border-radius:12px;padding:24px;margin-bottom:20px">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid #1c1c1c">
                    <span style="font-size:1.5rem">🎴</span>
                    <h2 style="margin:0;font-size:1.2rem">Baccarat</h2>
                    <select name="baccarat_enabled" style="margin-left:auto;background:#1a1a1a;color:#fff;border:1px solid #333;padding:6px 12px;border-radius:6px">
                        <option value="1" <?=selected($s['baccarat_enabled'],'1',false)?>>Enabled</option>
                        <option value="0" <?=selected($s['baccarat_enabled'],'0',false)?>>Disabled</option>
                    </select>
                </div>
                
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px">
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">PLAYER BET HOUSE EDGE (%)</label>
                        <input type="number" name="baccarat_house_edge_player" value="<?=esc_attr($s['baccarat_house_edge_player'] ?: '1.24')?>" step="0.01" min="0" max="20"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">Standard: 1.24%</small>
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">BANKER BET HOUSE EDGE (%)</label>
                        <input type="number" name="baccarat_house_edge_banker" value="<?=esc_attr($s['baccarat_house_edge_banker'] ?: '1.06')?>" step="0.01" min="0" max="20"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">Standard: 1.06% (best bet)</small>
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">TIE BET HOUSE EDGE (%)</label>
                        <input type="number" name="baccarat_house_edge_tie" value="<?=esc_attr($s['baccarat_house_edge_tie'] ?: '14.36')?>" step="0.01" min="0" max="50"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">Standard: 14.36% (avoid!)</small>
                    </div>
                </div>
            </div>
            
            <!-- PLINKO -->
            <div style="background:#111;border:1px solid #1c1c1c;border-radius:12px;padding:24px;margin-bottom:20px">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid #1c1c1c">
                    <span style="font-size:1.5rem">🔽</span>
                    <h2 style="margin:0;font-size:1.2rem">Plinko</h2>
                    <select name="plinko_enabled" style="margin-left:auto;background:#1a1a1a;color:#fff;border:1px solid #333;padding:6px 12px;border-radius:6px">
                        <option value="1" <?=selected($s['plinko_enabled'],'1',false)?>>Enabled</option>
                        <option value="0" <?=selected($s['plinko_enabled'],'0',false)?>>Disabled</option>
                    </select>
                </div>
                
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px">
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">HOUSE EDGE (%)</label>
                        <input type="number" name="plinko_house_edge" value="<?=esc_attr($s['plinko_house_edge'] ?: '3.0')?>" step="0.1" min="0" max="50"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">DEFAULT ROWS</label>
                        <select name="plinko_default_rows" style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                            <option value="8" <?=selected($s['plinko_default_rows'],'8',false)?>>8 Rows</option>
                            <option value="10" <?=selected($s['plinko_default_rows'],'10',false)?>>10 Rows</option>
                            <option value="12" <?=selected($s['plinko_default_rows'],'12',false)?>>12 Rows</option>
                        </select>
                    </div>
                    <div style="grid-column:1/-1">
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">8-ROW MULTIPLIERS (comma-separated, low to high)</label>
                        <input type="text" name="plinko_row_8_mults" value="<?=esc_attr($s['plinko_row_8_mults'] ?: '0.5,0.7,1.0,1.5,3.0,1.5,1.0,0.7,0.5')?>" 
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px;font-family:monospace">
                        <small style="color:#555;font-size:.7rem">Center has highest multiplier. Sum should be less than rows to create house edge.</small>
                    </div>
                </div>
            </div>
            
            <!-- MINES -->
            <div style="background:#111;border:1px solid #1c1c1c;border-radius:12px;padding:24px;margin-bottom:20px">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid #1c1c1c">
                    <span style="font-size:1.5rem">💎</span>
                    <h2 style="margin:0;font-size:1.2rem">Mines</h2>
                    <select name="mines_enabled" style="margin-left:auto;background:#1a1a1a;color:#fff;border:1px solid #333;padding:6px 12px;border-radius:6px">
                        <option value="1" <?=selected($s['mines_enabled'],'1',false)?>>Enabled</option>
                        <option value="0" <?=selected($s['mines_enabled'],'0',false)?>>Disabled</option>
                    </select>
                </div>
                
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px">
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">HOUSE EDGE (%)</label>
                        <input type="number" name="mines_house_edge" value="<?=esc_attr($s['mines_house_edge'] ?: '4.0')?>" step="0.1" min="0" max="50"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">DEFAULT MINES</label>
                        <input type="number" name="mines_default_mines" value="<?=esc_attr($s['mines_default_mines'] ?: '3')?>" min="1" max="24"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">GEM MULTIPLIER PER GEM</label>
                        <input type="number" name="mines_gem_multiplier" value="<?=esc_attr($s['mines_gem_multiplier'] ?: '0.6')?>" step="0.1" min="0.1" max="2"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                        <small style="color:#555;font-size:.7rem">Multiplier increase per gem found</small>
                    </div>
                </div>
            </div>
            
            <!-- VIDEO POKER -->
            <div style="background:#111;border:1px solid #1c1c1c;border-radius:12px;padding:24px;margin-bottom:20px">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid #1c1c1c">
                    <span style="font-size:1.5rem">🃏</span>
                    <h2 style="margin:0;font-size:1.2rem">Video Poker (Jacks or Better)</h2>
                    <select name="videopoker_enabled" style="margin-left:auto;background:#1a1a1a;color:#fff;border:1px solid #333;padding:6px 12px;border-radius:6px">
                        <option value="1" <?=selected($s['videopoker_enabled'],'1',false)?>>Enabled</option>
                        <option value="0" <?=selected($s['videopoker_enabled'],'0',false)?>>Disabled</option>
                    </select>
                </div>
                
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px">
                    <div>
                        <label style="display:block;font-size:.7rem;color:#888;margin-bottom:4px">JACKS OR BETTER</label>
                        <input type="number" name="videopoker_payout_jacks" value="<?=esc_attr($s['videopoker_payout_jacks'] ?: '1')?>" step="0.1" min="0" max="10"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:8px;border-radius:4px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.7rem;color:#888;margin-bottom:4px">TWO PAIR</label>
                        <input type="number" name="videopoker_payout_2pair" value="<?=esc_attr($s['videopoker_payout_2pair'] ?: '2')?>" step="0.1" min="0" max="10"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:8px;border-radius:4px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.7rem;color:#888;margin-bottom:4px">THREE KIND</label>
                        <input type="number" name="videopoker_payout_3kind" value="<?=esc_attr($s['videopoker_payout_3kind'] ?: '3')?>" step="0.1" min="0" max="10"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:8px;border-radius:4px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.7rem;color:#888;margin-bottom:4px">STRAIGHT</label>
                        <input type="number" name="videopoker_payout_straight" value="<?=esc_attr($s['videopoker_payout_straight'] ?: '4')?>" step="0.1" min="0" max="20"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:8px;border-radius:4px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.7rem;color:#888;margin-bottom:4px">FLUSH</label>
                        <input type="number" name="videopoker_payout_flush" value="<?=esc_attr($s['videopoker_payout_flush'] ?: '6')?>" step="0.1" min="0" max="20"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:8px;border-radius:4px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.7rem;color:#888;margin-bottom:4px">FULL HOUSE</label>
                        <input type="number" name="videopoker_payout_fullhouse" value="<?=esc_attr($s['videopoker_payout_fullhouse'] ?: '9')?>" step="0.1" min="0" max="20"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:8px;border-radius:4px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.7rem;color:#888;margin-bottom:4px">FOUR KIND</label>
                        <input type="number" name="videopoker_payout_4kind" value="<?=esc_attr($s['videopoker_payout_4kind'] ?: '25')?>" step="1" min="0" max="100"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:8px;border-radius:4px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.7rem;color:#888;margin-bottom:4px">STRAIGHT FLUSH</label>
                        <input type="number" name="videopoker_payout_straightflush" value="<?=esc_attr($s['videopoker_payout_straightflush'] ?: '50')?>" step="1" min="0" max="200"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:8px;border-radius:4px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.7rem;color:#888;margin-bottom:4px">ROYAL FLUSH</label>
                        <input type="number" name="videopoker_payout_royal" value="<?=esc_attr($s['videopoker_payout_royal'] ?: '250')?>" step="1" min="0" max="1000"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:8px;border-radius:4px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.7rem;color:#888;margin-bottom:4px">HOUSE EDGE (%)</label>
                        <input type="number" name="videopoker_house_edge" value="<?=esc_attr($s['videopoker_house_edge'] ?: '2.5')?>" step="0.1" min="0" max="50"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:8px;border-radius:4px">
                    </div>
                </div>
                <p style="color:#555;font-size:.75rem;margin-top:12px">💡 Standard 9/6 Jacks or Better has 99.54% RTP (0.46% house edge). Change payouts to adjust.</p>
            </div>
            
            <!-- KENO -->
            <div style="background:#111;border:1px solid #1c1c1c;border-radius:12px;padding:24px;margin-bottom:20px">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid #1c1c1c">
                    <span style="font-size:1.5rem">🎱</span>
                    <h2 style="margin:0;font-size:1.2rem">Keno</h2>
                    <select name="keno_enabled" style="margin-left:auto;background:#1a1a1a;color:#fff;border:1px solid #333;padding:6px 12px;border-radius:6px">
                        <option value="1" <?=selected($s['keno_enabled'],'1',false)?>>Enabled</option>
                        <option value="0" <?=selected($s['keno_enabled'],'0',false)?>>Disabled</option>
                    </select>
                </div>
                
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px">
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">HOUSE EDGE (%)</label>
                        <input type="number" name="keno_house_edge" value="<?=esc_attr($s['keno_house_edge'] ?: '5.0')?>" step="0.1" min="0" max="50"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">DEFAULT SPOTS</label>
                        <input type="number" name="keno_spots_default" value="<?=esc_attr($s['keno_spots_default'] ?: '5')?>" min="1" max="10"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">MAX SPOTS</label>
                        <input type="number" name="keno_max_spots" value="<?=esc_attr($s['keno_max_spots'] ?: '10')?>" min="1" max="15"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                    </div>
                    <div style="grid-column:1/-1">
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">PAYOUTS BY HITS (0-10 hits, comma-separated)</label>
                        <input type="text" name="keno_hits_payout" value="<?=esc_attr($s['keno_hits_payout'] ?: '0,0,0,0.5,1,2,5,10,50,500,5000')?>" 
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px;font-family:monospace">
                        <small style="color:#555;font-size:.7rem">Payout multipliers for 0-10 hits. Adjust to change house edge.</small>
                    </div>
                </div>
            </div>
            
            <!-- RAFFLE -->
            <div style="background:#111;border:1px solid #1c1c1c;border-radius:12px;padding:24px;margin-bottom:20px">
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:20px;padding-bottom:16px;border-bottom:1px solid #1c1c1c">
                    <span style="font-size:1.5rem">🎟</span>
                    <h2 style="margin:0;font-size:1.2rem">Raffle</h2>
                    <select name="raffle_enabled" style="margin-left:auto;background:#1a1a1a;color:#fff;border:1px solid #333;padding:6px 12px;border-radius:6px">
                        <option value="1" <?=selected($s['raffle_enabled'],'1',false)?>>Enabled</option>
                        <option value="0" <?=selected($s['raffle_enabled'],'0',false)?>>Disabled</option>
                    </select>
                </div>
                
                <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px">
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">HOUSE EDGE (%)</label>
                        <input type="number" name="raffle_house_edge" value="<?=esc_attr($s['raffle_house_edge'] ?: '10.0')?>" step="0.1" min="0" max="50"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">MINIMUM BET (sat)</label>
                        <input type="number" name="raffle_min_bet" value="<?=esc_attr($s['raffle_min_bet'] ?: '100')?>" min="1"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">MAXIMUM BET (sat)</label>
                        <input type="number" name="raffle_max_bet" value="<?=esc_attr($s['raffle_max_bet'] ?: '10000')?>" min="1"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                    </div>
                    <div>
                        <label style="display:block;font-size:.75rem;color:#888;margin-bottom:6px">JACKPOT % OF POOL</label>
                        <input type="number" name="raffle_jackpot_pct" value="<?=esc_attr($s['raffle_jackpot_pct'] ?: '50')?>" min="1" max="100"
                               style="width:100%;background:#1a1a1a;border:1px solid #333;color:#fff;padding:10px;border-radius:6px">
                    </div>
                </div>
                
                <div style="margin-top:16px;padding:16px;background:#0a0a0a;border:1px solid #222;border-radius:8px">
                    <h4 style="margin:0 0 8px;color:#888;font-size:.85rem">Current Raffle Pool</h4>
                    <p style="margin:0;color:#22c55e;font-size:1.2rem;font-weight:bold">
                        <?=number_format(intval(cfp_get_setting('raffle_pool_sat', 0)))?> sat 
                        <span style="color:#555;font-size:.8rem">(<?=number_format(intval(cfp_get_setting('raffle_total_tickets', 0)))?> tickets)</span>
                    </p>
                    <button type="submit" name="reset_raffle_pool" class="button" style="margin-top:8px;background:#ef4444;color:#fff;border:none;padding:6px 12px;border-radius:4px;cursor:pointer"
                            onclick="return confirm('Reset raffle pool to zero? This cannot be undone.')">Reset Pool</button>
                </div>
            </div>
            
            <button type="submit" name="cfp_save_game_controls" class="button button-primary button-large" 
                    style="background:#f7931a;border:none;color:#000;font-weight:bold;padding:12px 32px;font-size:1rem">
                💾 Save All Game Controls
            </button>
        </form>
    </div>
    <?php
}
