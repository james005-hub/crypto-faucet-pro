<?php
/**
 * Admin page: Backup & Restore
 * Part of Crypto Faucet Pro plugin.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_backup() {
    global $wpdb;
    $notice = '';
    $error = '';

    if ( isset($_POST['cfp_create_backup']) && check_admin_referer('cfp_backup') ) {
        $backup_type = sanitize_text_field($_POST['backup_type'] ?? 'full');
        
        $backup_data = [
            'version' => CFP_VERSION,
            'created_at' => current_time('mysql'),
            'type' => $backup_type,
        ];
        
        if ( in_array($backup_type, ['full', 'settings']) ) {
            $settings = $wpdb->get_results("SELECT * FROM " . CFP_TABLE_SETTINGS);
            $backup_data['settings'] = $settings;
        }
        
        if ( in_array($backup_type, ['full', 'users']) ) {
            $users = $wpdb->get_results("SELECT id, username, email, balance_sat, savings_sat, total_earned, total_claims, is_banned, created_at FROM " . CFP_TABLE_USERS);
            $backup_data['users'] = $users;
        }
        
        if ( in_array($backup_type, ['full', 'wallet']) ) {
            $wallet = $wpdb->get_results("SELECT * FROM " . CFP_TABLE_ADMIN_WALLET . " ORDER BY created_at DESC LIMIT 1000");
            $backup_data['wallet'] = $wallet;
        }
        
        $json = json_encode($backup_data, JSON_PRETTY_PRINT);
        $filename = 'cfp-backup-' . date('Y-m-d-H-i-s') . '.json';
        
        header('Content-Type: application/json');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Content-Length: ' . strlen($json));
        // Raw echo is intentional: this is a JSON file download, not HTML output.
        // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        echo $json;
        exit;
    }

    if ( isset($_POST['cfp_restore_backup']) && check_admin_referer('cfp_backup') ) {
        if ( ! empty($_FILES['backup_file']['tmp_name']) ) {
            $json = file_get_contents($_FILES['backup_file']['tmp_name']);
            $data = json_decode($json, true);
            
            if ( ! $data || ! isset($data['version']) ) {
                $error = "❌ Invalid backup file format.";
            } else {
                if ( isset($data['settings']) ) {
                    foreach ( $data['settings'] as $s ) {
                        cfp_update_setting($s->setting_key, $s->setting_val);
                    }
                    $notice .= "✅ Settings restored. ";
                }
                
                if ( isset($data['users']) && ! empty($_POST['restore_users']) ) {
                    $restored = 0;
                    foreach ( $data['users'] as $u ) {
                        $existing = $wpdb->get_row($wpdb->prepare("SELECT id FROM " . CFP_TABLE_USERS . " WHERE id = %d", $u['id']));
                        if ( $existing ) {
                            $wpdb->update(CFP_TABLE_USERS, [
                                'balance_sat' => $u['balance_sat'],
                                'savings_sat' => $u['savings_sat'],
                                'total_earned' => $u['total_earned'],
                            ], ['id' => $u['id']]);
                        }
                        $restored++;
                    }
                    $notice .= "✅ {$restored} user balances restored. ";
                }
                
                $notice .= "✅ Backup restored successfully!";
            }
        } else {
            $error = "❌ Please select a backup file to restore.";
        }
    }

    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };
    
    $total_settings = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_SETTINGS);
    $total_users = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_USERS);
    $total_wallet_entries = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_ADMIN_WALLET);
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">💾</span>
            <h1>💾 Backup & Restore</h1>
        </div>
        <?php if($notice): ?><div class="cfp-notice success"><?= esc_html($notice) ?></div><?php endif; ?>
        <?php if($error): ?><div class="cfp-notice error"><?= esc_html($error) ?></div><?php endif; ?>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px">
            <div class="cfp-stat-card blue">
                <div class="label">Total Settings</div>
                <div class="value"><?=number_format($total_settings)?></div>
            </div>
            <div class="cfp-stat-card green">
                <div class="label">Total Users</div>
                <div class="value"><?=number_format($total_users)?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Wallet Entries</div>
                <div class="value"><?=number_format($total_wallet_entries)?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">Plugin Version</div>
                <div class="value"><?=CFP_VERSION?></div>
            </div>
        </div>

        <div class="cfp-2col">
            <div class="cfp-card">
                <h2>📥 Create Backup</h2>
                <form method="post">
                    <?php wp_nonce_field('cfp_backup'); ?>
                    <div class="cfp-field" style="margin-bottom:16px">
                        <label>Backup Type</label>
                        <select name="backup_type">
                            <option value="full">📦 Full Backup (Settings + Users + Wallet)</option>
                            <option value="settings">⚙️ Settings Only</option>
                            <option value="users">👥 Users Only (balances)</option>
                            <option value="wallet">💰 Wallet Only</option>
                        </select>
                    </div>
                    <button type="submit" name="cfp_create_backup" class="cfp-btn cfp-btn-gold" style="width:100%">📥 Download Backup</button>
                </form>
                
                <div style="margin-top:16px;padding:12px;background:#111;border-radius:8px;font-size:.8rem;color:var(--mt)">
                    <strong>📋 What's included:</strong><br>
                    • Settings: All plugin configuration<br>
                    • Users: Balance, savings, totals<br>
                    • Wallet: Revenue stream history
                </div>
            </div>

            <div class="cfp-card">
                <h2>📤 Restore Backup</h2>
                <form method="post" enctype="multipart/form-data">
                    <?php wp_nonce_field('cfp_backup'); ?>
                    <div class="cfp-field" style="margin-bottom:16px">
                        <label>Select Backup File</label>
                        <input type="file" name="backup_file" accept=".json" style="background:#111;border:1px solid #2a2a2a;color:#e8e8e8;padding:10px;border-radius:8px;width:100%">
                    </div>
                    <div style="margin-bottom:16px">
                        <label style="display:flex;align-items:center;gap:8px;cursor:pointer">
                            <input type="checkbox" name="restore_users" value="1" checked>
                            <span style="font-size:.85rem">Restore user balances</span>
                        </label>
                    </div>
                    <button type="submit" name="cfp_restore_backup" class="cfp-btn cfp-btn-green" style="width:100%">📤 Restore Backup</button>
                </form>
                
                <div style="margin-top:16px;padding:12px;background:#2d0a0a;border-radius:8px;font-size:.8rem;color:#ef4444">
                    <strong>⚠️ Warning:</strong><br>
                    Restoring will overwrite current settings and optionally update user balances. Backup first!
                </div>
            </div>
        </div>

        <div class="cfp-card" style="margin-top:22px">
            <h2>🔄 Auto-Backup Settings</h2>
            <?php
            $auto_backup_enabled = $gs('auto_backup_enabled', '0');
            $auto_backup_frequency = $gs('auto_backup_frequency', 'daily');
            $auto_backup_retention = $gs('auto_backup_retention', 7);
            
            if ( isset($_POST['cfp_save_auto_backup']) && check_admin_referer('cfp_backup') ) {
                cfp_update_setting('auto_backup_enabled', sanitize_text_field($_POST['auto_backup_enabled'] ?? '0'));
                cfp_update_setting('auto_backup_frequency', sanitize_text_field($_POST['auto_backup_frequency'] ?? 'daily'));
                cfp_update_setting('auto_backup_retention', sanitize_text_field($_POST['auto_backup_retention'] ?? 7));
                echo "<div class='cfp-notice success'>✅ Auto-backup settings saved!</div>";
            }
            ?>
            <form method="post">
                <?php wp_nonce_field('cfp_backup'); ?>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Enable Auto-Backup</label>
                        <select name="auto_backup_enabled">
                            <option value="1" <?=selected($auto_backup_enabled,'1',false)?>>✅ Enabled</option>
                            <option value="0" <?=selected($auto_backup_enabled,'0',false)?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Frequency</label>
                        <select name="auto_backup_frequency">
                            <option value="daily" <?=selected($auto_backup_frequency,'daily',false)?>>Daily</option>
                            <option value="weekly" <?=selected($auto_backup_frequency,'weekly',false)?>>Weekly</option>
                            <option value="monthly" <?=selected($auto_backup_frequency,'monthly',false)?>>Monthly</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Keep Backups (days)</label>
                        <input type="number" name="auto_backup_retention" value="<?=esc_attr($auto_backup_retention)?>" min="1" max="90">
                    </div>
                </div>
                <button type="submit" name="cfp_save_auto_backup" class="cfp-btn cfp-btn-gold" style="margin-top:12px">💾 Save Auto-Backup Settings</button>
            </form>
        </div>
    </div>
    <?php
}