<?php
/**
 * Admin page: Promotions & Events Scheduler
 * Part of Crypto Faucet Pro plugin.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_promotions() {
    global $wpdb;
    $notice = '';

    if ( isset($_POST['cfp_save_promotion']) && check_admin_referer('cfp_promotions') ) {
        $promo_name = sanitize_text_field($_POST['promo_name']);
        $promo_type = sanitize_text_field($_POST['promo_type']);
        $promo_value = floatval($_POST['promo_value']);
        $start_date = sanitize_text_field($_POST['start_date']);
        $end_date = sanitize_text_field($_POST['end_date']);
        $promo_active = isset($_POST['promo_active']) ? '1' : '0';
        
        if ( ! empty($promo_name) ) {
            $promo_id = intval($_POST['promo_id'] ?? 0);
            
            $data = [
                'promo_name' => $promo_name,
                'promo_type' => $promo_type,
                'promo_value' => $promo_value,
                'start_date' => $start_date,
                'end_date' => $end_date,
                'is_active' => $promo_active,
                'created_at' => current_time('mysql'),
            ];
            
            if ( $promo_id > 0 ) {
                $wpdb->update($wpdb->prefix . 'cfp_promotions', $data, ['id' => $promo_id]);
                $notice = "<div class='cfp-notice success'>✅ Promotion updated!</div>";
            } else {
                $wpdb->insert($wpdb->prefix . 'cfp_promotions', $data);
                $notice = "<div class='cfp-notice success'>✅ Promotion created!</div>";
            }
        }
    }

    if ( isset($_GET['delete_promo']) && check_admin_referer('cfp_del_promo') ) {
        $promo_id = intval($_GET['delete_promo']);
        $wpdb->delete($wpdb->prefix . 'cfp_promotions', ['id' => $promo_id]);
        $notice = "<div class='cfp-notice success'>✅ Promotion deleted.</div>";
    }

    if ( isset($_GET['toggle_promo']) && check_admin_referer('cfp_toggle_promo') ) {
        $promo_id = intval($_GET['toggle_promo']);
        $promo = $wpdb->get_row($wpdb->prepare("SELECT is_active FROM " . $wpdb->prefix . "cfp_promotions WHERE id = %d", $promo_id));
        if ($promo) {
            $wpdb->update($wpdb->prefix . 'cfp_promotions', ['is_active' => $promo->is_active ? 0 : 1], ['id' => $promo_id]);
            $notice = "<div class='cfp-notice success'>✅ Promotion " . ($promo->is_active ? 'paused' : 'activated') . ".</div>";
        }
    }

    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };
    $promotions = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "cfp_promotions ORDER BY created_at DESC");
    
    $active_promos = count(array_filter($promotions, function($p){ 
        return $p->is_active && strtotime($p->start_date) <= time() && strtotime($p->end_date) >= time(); 
    }));
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🏆</span>
            <h1>🏆 Promotions & Events</h1>
        </div>
        <?=$notice?>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px">
            <div class="cfp-stat-card green">
                <div class="label">Active Promotions</div>
                <div class="value"><?=$active_promos?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">Total Promotions</div>
                <div class="value"><?=count($promotions)?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">Boosted Claims</div>
                <div class="value"><?=cfp_get_setting('promo_claim_boost_active','0') === '1' ? 'ON' : 'OFF'?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Event Mode</div>
                <div class="value"><?=cfp_get_setting('promo_event_mode','0') === '1' ? 'ACTIVE' : 'NORMAL'?></div>
            </div>
        </div>

        <div class="cfp-card" style="margin-bottom:22px">
            <h2>➕ Create/Edit Promotion</h2>
            <form method="post">
                <?php wp_nonce_field('cfp_promotions'); ?>
                <input type="hidden" name="promo_id" value="">
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Promotion Name</label>
                        <input type="text" name="promo_name" placeholder="e.g. Holiday Bonus" required>
                    </div>
                    <div class="cfp-field">
                        <label>Type</label>
                        <select name="promo_type" onchange="cfpUpdatePromoFields(this.value)">
                            <option value="claim_boost">💰 Claim Amount Boost (%)</option>
                            <option value="game_multiplier">🎰 Game Payout Multiplier</option>
                            <option value="lottery_bonus">🎟 Extra Lottery Tickets</option>
                            <option value="xp_boost">⭐ XP Boost (%)</option>
                            <option value="interest_boost">📈 Interest Boost (%)</option>
                            <option value="referral_boost">🔗 Referral Commission Boost (%)</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Value (percentage or multiplier)</label>
                        <input type="number" name="promo_value" value="100" min="0" step="0.1">
                        <span class="hint">e.g. 50 = +50%, 2 = 2x</span>
                    </div>
                    <div class="cfp-field">
                        <label>Start Date</label>
                        <input type="datetime-local" name="start_date" value="<?=date('Y-m-d\TH:i')?>">
                    </div>
                    <div class="cfp-field">
                        <label>End Date</label>
                        <input type="datetime-local" name="end_date" value="<?=date('Y-m-d\TH:i', strtotime('+7 days'))?>">
                    </div>
                    <div class="cfp-field">
                        <label>Active</label>
                        <select name="promo_active">
                            <option value="1">✅ Active</option>
                            <option value="0">⏸ Inactive</option>
                        </select>
                    </div>
                </div>
                <button type="submit" name="cfp_save_promotion" class="cfp-btn cfp-btn-gold" style="margin-top:12px">💾 Save Promotion</button>
            </form>
        </div>

        <div class="cfp-card">
            <h2>📋 All Promotions</h2>
            <?php if(!empty($promotions)): ?>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead><tr><th>Name</th><th>Type</th><th>Value</th><th>Period</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                    <?php foreach($promotions as $p): 
                        $now = time();
                        $start = strtotime($p->start_date);
                        $end = strtotime($p->end_date);
                        $is_live = $p->is_active && $now >= $start && $now <= $end;
                        
                        $type_labels = [
                            'claim_boost' => '💰 Claim Boost',
                            'game_multiplier' => '🎰 Game Multiplier',
                            'lottery_bonus' => '🎟 Lottery Bonus',
                            'xp_boost' => '⭐ XP Boost',
                            'interest_boost' => '📈 Interest Boost',
                            'referral_boost' => '🔗 Referral Boost',
                        ];
                    ?>
                    <tr>
                        <td><strong><?=esc_html($p->promo_name)?></strong></td>
                        <td><span class="cfp-badge"><?=$type_labels[$p->promo_type] ?? $p->promo_type?></span></td>
                        <td style="color:var(--g);font-weight:700"><?=$p->promo_value?><?=in_array($p->promo_type, ['game_multiplier']) ? 'x' : '%'?></td>
                        <td style="font-size:.8rem">
                            <?=date('M j, H:i', $start)?> - <?=date('M j, H:i', $end)?>
                        </td>
                        <td>
                            <?php if($is_live): ?>
                                <span class="cfp-badge active">🔴 LIVE</span>
                            <?php elseif($now < $start): ?>
                                <span class="cfp-badge pending">⏳ Scheduled</span>
                            <?php elseif($now > $end): ?>
                                <span class="cfp-badge">⏰ Ended</span>
                            <?php else: ?>
                                <span class="cfp-badge banned">⏸ Paused</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php $toggle_nonce = wp_create_nonce('cfp_toggle_promo'); ?>
                            <a href="?page=cfp-promotions&toggle_promo=<?=$p->id?>&_wpnonce=<?=$toggle_nonce?>" class="cfp-btn cfp-btn-ghost cfp-btn-sm">
                                <?=$p->is_active ? '⏸ Pause' : '▶️ Activate'?>
                            </a>
                            <?php $del_nonce = wp_create_nonce('cfp_del_promo'); ?>
                            <a href="?page=cfp-promotions&delete_promo=<?=$p->id?>&_wpnonce=<?=$del_nonce?>" class="cfp-btn cfp-btn-red cfp-btn-sm" onclick="return confirm('Delete this promotion?')">🗑️</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p style="color:var(--mt);text-align:center;padding:20px">No promotions created yet.</p>
            <?php endif; ?>
        </div>

        <div class="cfp-card" style="margin-top:22px">
            <h2>⚡ Quick Promotions</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px">
                <form method="post" style="background:#111;border-radius:8px;padding:14px">
                    <?php wp_nonce_field('cfp_promotions'); ?>
                    <input type="hidden" name="promo_name" value="Weekend Bonus">
                    <input type="hidden" name="promo_type" value="claim_boost">
                    <input type="hidden" name="promo_value" value="50">
                    <input type="hidden" name="start_date" value="<?=date('Y-m-d\TH:i', strtotime('Saturday'))?>">
                    <input type="hidden" name="end_date" value="<?=date('Y-m-d\TH:i', strtotime('Sunday 23:59'))?>">
                    <input type="hidden" name="promo_active" value="1">
                    <button type="submit" name="cfp_save_promotion" class="cfp-btn cfp-btn-gold" style="width:100%">🎉 Weekend +50% Claims</button>
                </form>
                <form method="post" style="background:#111;border-radius:8px;padding:14px">
                    <?php wp_nonce_field('cfp_promotions'); ?>
                    <input type="hidden" name="promo_name" value="Double Jackpot">
                    <input type="hidden" name="promo_type" value="game_multiplier">
                    <input type="hidden" name="promo_value" value="2">
                    <input type="hidden" name="start_date" value="<?=date('Y-m-d\TH:i')?>">
                    <input type="hidden" name="end_date" value="<?=date('Y-m-d\TH:i', strtotime('+24 hours'))?>">
                    <input type="hidden" name="promo_active" value="1">
                    <button type="submit" name="cfp_save_promotion" class="cfp-btn cfp-btn-green" style="width:100%">💎 2x Game Payouts 24h</button>
                </form>
                <form method="post" style="background:#111;border-radius:8px;padding:14px">
                    <?php wp_nonce_field('cfp_promotions'); ?>
                    <input type="hidden" name="promo_name" value="Loyalty Week">
                    <input type="hidden" name="promo_type" value="xp_boost">
                    <input type="hidden" name="promo_value" value="200">
                    <input type="hidden" name="start_date" value="<?=date('Y-m-d\TH:i')?>">
                    <input type="hidden" name="end_date" value="<?=date('Y-m-d\TH:i', strtotime('+7 days'))?>">
                    <input type="hidden" name="promo_active" value="1">
                    <button type="submit" name="cfp_save_promotion" class="cfp-btn cfp-btn-blue" style="width:100%;background:#3b82f6">⭐ 2x XP All Week</button>
                </form>
            </div>
        </div>
    </div>

    <script>
    function cfpUpdatePromoFields(type) {
        const valInput = document.querySelector('input[name="promo_value"]');
        if (type === 'game_multiplier') {
            valInput.value = 2;
            valInput.min = 0.1;
            valInput.step = 0.1;
        } else {
            valInput.value = 50;
            valInput.min = 0;
            valInput.step = 1;
        }
    }
    </script>
    <?php
}