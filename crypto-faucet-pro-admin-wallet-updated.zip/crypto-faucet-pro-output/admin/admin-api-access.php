<?php
/**
 * Admin page: API Access Management
 * Part of Crypto Faucet Pro plugin.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_api_access() {
    global $wpdb;
    $notice = '';

    if ( isset($_POST['cfp_save_api_settings']) && check_admin_referer('cfp_api_access') ) {
        $fields = [
            'api_enabled',
            'api_require_auth',
            'api_rate_limit',
            'api_rate_window',
            'api_allow_cors',
            'api_log_requests',
        ];
        foreach ( $fields as $f ) {
            if ( isset($_POST[$f]) ) {
                cfp_update_setting($f, sanitize_text_field($_POST[$f]));
            }
        }
        
        if ( isset($_POST['api_allowed_ips']) ) {
            cfp_update_setting('api_allowed_ips', sanitize_textarea_field($_POST['api_allowed_ips']));
        }
        
        $notice = "<div class='cfp-notice success'>✅ API settings saved!</div>";
    }

    if ( isset($_POST['cfp_generate_api_key']) && check_admin_referer('cfp_api_access') ) {
        $key_name = sanitize_text_field($_POST['new_api_key_name'] ?? 'API Key');
        $api_key = 'cfp_' . bin2hex(random_bytes(24));
        $api_secret = bin2hex(random_bytes(16));
        
        $wpdb->insert($wpdb->prefix . 'cfp_api_keys', [
            'key_name' => $key_name,
            'api_key' => $api_key,
            'api_secret_hash' => wp_hash($api_secret),
            'created_at' => current_time('mysql'),
            'last_used' => null,
            'is_active' => 1,
        ]);
        
        $notice = "<div class='cfp-notice success'>
            ✅ API Key Created!<br>
            <strong>Key:</strong> <code style='background:#111;padding:4px 8px;border-radius:4px'>{$api_key}</code><br>
            <strong>Secret:</strong> <code style='background:#111;padding:4px 8px;border-radius:4px'>{$api_secret}</code><br>
            <span style='color:#f7931a'>⚠️ Save the secret now - it cannot be shown again!</span>
        </div>";
    }

    if ( isset($_GET['delete_api_key']) && check_admin_referer('cfp_delete_key') ) {
        $key_id = intval($_GET['delete_api_key']);
        $wpdb->delete($wpdb->prefix . 'cfp_api_keys', ['id' => $key_id]);
        $notice = "<div class='cfp-notice success'>✅ API key deleted.</div>";
    }

    if ( isset($_GET['toggle_api_key']) && check_admin_referer('cfp_toggle_key') ) {
        $key_id = intval($_GET['toggle_api_key']);
        $key = $wpdb->get_row($wpdb->prepare("SELECT is_active FROM " . $wpdb->prefix . "cfp_api_keys WHERE id = %d", $key_id));
        if ($key) {
            $wpdb->update($wpdb->prefix . 'cfp_api_keys', ['is_active' => $key->is_active ? 0 : 1], ['id' => $key_id]);
            $notice = "<div class='cfp-notice success'>✅ API key " . ($key->is_active ? 'disabled' : 'enabled') . ".</div>";
        }
    }

    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };
    $api_keys = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . "cfp_api_keys ORDER BY created_at DESC");
    
    $api_calls_today = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_IP_LIMITS . " WHERE window_start >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🔑</span>
            <h1>🔑 API Access Management</h1>
        </div>
        <?=$notice?>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px">
            <div class="cfp-stat-card <?=$gs('api_enabled','0') === '1' ? 'green' : 'red'?>">
                <div class="label">API Status</div>
                <div class="value"><?=$gs('api_enabled','0') === '1' ? 'ACTIVE' : 'DISABLED'?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Total Keys</div>
                <div class="value"><?=count($api_keys)?></div>
            </div>
            <div class="cfp-stat-card green">
                <div class="label">Active Keys</div>
                <div class="value"><?=count(array_filter($api_keys, function($k){ return $k->is_active; }))?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">Rate Limit</div>
                <div class="value"><?=$gs('api_rate_limit',100)?>/<?=$gs('api_rate_window',60)?>sec</div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field('cfp_api_access'); ?>
            
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>⚙️ API Settings</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Enable API</label>
                        <select name="api_enabled">
                            <option value="1" <?=selected($gs('api_enabled','0'),'1',false)?>>✅ Enabled</option>
                            <option value="0" <?=selected($gs('api_enabled','0'),'0',false)?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Require Authentication</label>
                        <select name="api_require_auth">
                            <option value="1" <?=selected($gs('api_require_auth','1'),'1',false)?>>✅ Yes - key required</option>
                            <option value="0" <?=selected($gs('api_require_auth','1'),'0',false)?>>⏸ No - public</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Rate Limit (per window)</label>
                        <input type="number" name="api_rate_limit" value="<?=esc_attr($gs('api_rate_limit',100))?>" min="10">
                    </div>
                    <div class="cfp-field">
                        <label>Rate Window (seconds)</label>
                        <input type="number" name="api_rate_window" value="<?=esc_attr($gs('api_rate_window',60))?>" min="10">
                    </div>
                    <div class="cfp-field">
                        <label>Allow CORS</label>
                        <select name="api_allow_cors">
                            <option value="1" <?=selected($gs('api_allow_cors','1'),'1',false)?>>✅ Yes - cross-origin requests</option>
                            <option value="0" <?=selected($gs('api_allow_cors','1'),'0',false)?>>⏸ No</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Log API Requests</label>
                        <select name="api_log_requests">
                            <option value="1" <?=selected($gs('api_log_requests','1'),'1',false)?>>✅ Yes - log all calls</option>
                            <option value="0" <?=selected($gs('api_log_requests','1'),'0',false)?>>⏸ No - no logging</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🌐 IP Whitelist</h2>
                <div class="cfp-field">
                    <label>Allowed IP Addresses (one per line, leave empty for all)</label>
                    <textarea name="api_allowed_ips" rows="4" style="width:100%;background:#111;border:1px solid #2a2a2a;color:#e8e8e8;padding:10px;border-radius:8px;font-family:monospace"><?=esc_textarea($gs('api_allowed_ips',''))?></textarea>
                    <span class="hint">Restrict API access to specific IPs (optional)</span>
                </div>
            </div>

            <button type="submit" name="cfp_save_api_settings" class="cfp-btn cfp-btn-gold">💾 Save API Settings</button>
        </form>

        <div class="cfp-card" style="margin-top:22px">
            <h2>🔐 API Keys</h2>
            <form method="post" style="margin-bottom:20px">
                <?php wp_nonce_field('cfp_api_access'); ?>
                <div style="display:flex;gap:10px;align-items:end">
                    <div class="cfp-field" style="flex:1">
                        <label>Key Name</label>
                        <input type="text" name="new_api_key_name" placeholder="My Bot API Key" style="width:100%">
                    </div>
                    <button type="submit" name="cfp_generate_api_key" class="cfp-btn cfp-btn-green">➕ Generate New Key</button>
                </div>
            </form>

            <?php if(!empty($api_keys)): ?>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead><tr><th>Name</th><th>API Key</th><th>Created</th><th>Last Used</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                    <?php foreach($api_keys as $k): ?>
                    <tr>
                        <td><strong><?=esc_html($k->key_name)?></strong></td>
                        <td style="font-family:monospace;font-size:.8rem"><?=esc_html(substr($k->api_key,0,12))?>...</td>
                        <td style="color:var(--mt)"><?=date('M j, Y', strtotime($k->created_at))?></td>
                        <td style="color:var(--mt)"><?=$k->last_used ? date('M j, H:i', strtotime($k->last_used)) : 'Never'?></td>
                        <td>
                            <span class="cfp-badge <?=$k->is_active ? 'active' : 'banned'?>">
                                <?=$k->is_active ? 'Active' : 'Disabled'?>
                            </span>
                        </td>
                        <td>
                            <?php $toggle_nonce = wp_create_nonce('cfp_toggle_key'); ?>
                            <a href="?page=cfp-api-access&toggle_api_key=<?=$k->id?>&_wpnonce=<?=$toggle_nonce?>" class="cfp-btn cfp-btn-ghost cfp-btn-sm">
                                <?=$k->is_active ? 'Disable' : 'Enable'?>
                            </a>
                            <?php $delete_nonce = wp_create_nonce('cfp_delete_key'); ?>
                            <a href="?page=cfp-api-access&delete_api_key=<?=$k->id?>&_wpnonce=<?=$delete_nonce?>" class="cfp-btn cfp-btn-red cfp-btn-sm" onclick="return confirm('Delete this API key?')">
                                🗑️
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p style="color:var(--mt);text-align:center;padding:20px">No API keys generated yet.</p>
            <?php endif; ?>
        </div>

        <div class="cfp-card" style="margin-top:22px">
            <h2>📚 API Documentation</h2>
            <div style="background:#111;border-radius:8px;padding:16px">
                <h3 style="color:var(--g);margin-bottom:10px">Base URL</h3>
                <code style="display:block;background:#0a0a0a;padding:10px;border-radius:6px;margin-bottom:16px"><?=get_site_url()?>/wp-json/cfp/v1/</code>
                
                <h3 style="color:var(--g);margin-bottom:10px">Available Endpoints</h3>
                <div style="display:grid;gap:8px;font-size:.85rem">
                    <div style="display:flex;gap:10px;padding:8px;background:#1a1a1a;border-radius:6px">
                        <span style="color:#22c55e;font-weight:700">GET</span>
                        <code>/balance?key=YOUR_KEY</code>
                        <span style="color:var(--mt)">- Get user balance</span>
                    </div>
                    <div style="display:flex;gap:10px;padding:8px;background:#1a1a1a;border-radius:6px">
                        <span style="color:#22c55e;font-weight:700">GET</span>
                        <code>/stats</code>
                        <span style="color:var(--mt)">- Site statistics</span>
                    </div>
                    <div style="display:flex;gap:10px;padding:8px;background:#1a1a1a;border-radius:6px">
                        <span style="color:#f7931a;font-weight:700">POST</span>
                        <code>/claim?key=YOUR_KEY</code>
                        <span style="color:var(--mt)">- Make a claim</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
}