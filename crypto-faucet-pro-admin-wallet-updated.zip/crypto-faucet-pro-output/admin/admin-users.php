<?php
/**
 * Admin pages: Dashboard, Users list, Balance Adjustor, bulk adjust handler
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   ADMIN DASHBOARD
   ============================================================ */
function cfp_admin_dashboard() {
    global $wpdb;
    $total_users   = $wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_USERS);
    $total_claims  = $wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_CLAIMS);
    $total_paid    = $wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_WITHDRAWALS." WHERE status='approved'");
    $pending_wds   = $wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_WITHDRAWALS." WHERE status='pending'");
    $claims_today  = $wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_CLAIMS." WHERE DATE(claimed_at)=CURDATE()");
    $total_balance = $wpdb->get_var("SELECT COALESCE(SUM(balance_sat),0) FROM ".CFP_TABLE_USERS);
    $total_savings = $wpdb->get_var("SELECT COALESCE(SUM(savings_sat),0) FROM ".CFP_TABLE_USERS);
    $total_games   = $wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_MULTIPLY);
    $lottery_tickets = $wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_LOTTERY_TICKETS);
    $p2p_events    = $wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_P2P." WHERE status='open'");

    $recent_claims = $wpdb->get_results("SELECT c.*,u.username,u.email FROM ".CFP_TABLE_CLAIMS." c LEFT JOIN ".CFP_TABLE_USERS." u ON c.user_id=u.id ORDER BY c.claimed_at DESC LIMIT 7");
    $recent_wds    = $wpdb->get_results("SELECT w.*,u.username FROM ".CFP_TABLE_WITHDRAWALS." w LEFT JOIN ".CFP_TABLE_USERS." u ON w.user_id=u.id WHERE w.status='pending' ORDER BY w.requested_at DESC LIMIT 5");
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">⚡ CFP</span>
            <h1>Crypto Faucet Pro — Dashboard</h1>
            <span style="margin-left:auto">
                <?php if(cfp_get_setting('faucet_enabled',1)): ?>
                    <span class="cfp-badge active">● Faucet LIVE</span>
                <?php else: ?>
                    <span class="cfp-badge banned">● Faucet PAUSED</span>
                <?php endif; ?>
            </span>
        </div>

        <div style="display:flex;flex-wrap:wrap;gap:9px;margin-bottom:22px">
            <a href="<?=admin_url('admin.php?page=cfp-settings')?>" class="cfp-btn cfp-btn-gold">⚙️ Settings</a>
            <a href="<?=admin_url('admin.php?page=cfp-withdrawals')?>" class="cfp-btn cfp-btn-ghost">💸 Withdrawals <?php if($pending_wds>0): ?><span style="background:var(--rd);color:#fff;border-radius:20px;padding:1px 7px;font-size:.72rem"><?=$pending_wds?></span><?php endif; ?></a>
            <a href="<?=admin_url('admin.php?page=cfp-lottery')?>" class="cfp-btn cfp-btn-ghost">🎟 Lottery</a>
            <a href="<?=admin_url('admin.php?page=cfp-p2p')?>" class="cfp-btn cfp-btn-ghost">🤝 P2P Events</a>
            <a href="<?=admin_url('admin.php?page=cfp-users')?>" class="cfp-btn cfp-btn-ghost">👥 Users</a>
        </div>

        <div class="cfp-stats-grid">
            <div class="cfp-stat-card"><div class="label">Total Users</div><div class="value"><?=number_format($total_users)?></div></div>
            <div class="cfp-stat-card green"><div class="label">Claims Today</div><div class="value"><?=number_format($claims_today)?></div><div class="sub"><?=number_format($total_claims)?> total</div></div>
            <div class="cfp-stat-card blue"><div class="label">Hi-Lo Games</div><div class="value"><?=number_format($total_games)?></div></div>
            <div class="cfp-stat-card"><div class="label">Lottery Tickets</div><div class="value"><?=number_format($lottery_tickets)?></div></div>
            <div class="cfp-stat-card purple"><div class="label">P2P Open Events</div><div class="value"><?=number_format($p2p_events)?></div></div>
            <div class="cfp-stat-card"><div class="label">Total Savings</div><div class="value"><?=number_format($total_savings)?></div><div class="sub">sat in savings</div></div>
            <div class="cfp-stat-card red"><div class="label">Pending Withdrawals</div><div class="value" style="color:<?=($pending_wds>0?'var(--rd)':'var(--gr)')?>"><?=$pending_wds?></div></div>
            <div class="cfp-stat-card"><div class="label">Total Paid Out</div><div class="value"><?=number_format($total_paid)?></div><div class="sub">satoshis</div></div>
        </div>

        <div class="cfp-2col">
            <div class="cfp-card">
                <h2>📥 Recent Claims</h2>
                <table class="cfp-table"><thead><tr><th>User</th><th>Amount</th><th>Time</th></tr></thead><tbody>
                <?php foreach($recent_claims as $c): ?>
                <tr><td><strong><?=esc_html($c->username)?></strong></td><td style="color:var(--g);font-weight:700"><?=number_format($c->amount_sat)?> sat</td><td style="font-size:.76rem;color:var(--mt)"><?=human_time_diff(strtotime($c->claimed_at),current_time('timestamp'))?> ago</td></tr>
                <?php endforeach; ?>
                </tbody></table>
            </div>
            <div class="cfp-card">
                <h2>💸 Pending Withdrawals</h2>
                <table class="cfp-table"><thead><tr><th>User</th><th>Amount</th><th>Action</th></tr></thead><tbody>
                <?php foreach($recent_wds as $w): $n=wp_create_nonce('cfp_wd'); ?>
                <tr>
                    <td><strong><?=esc_html($w->username)?></strong></td>
                    <td style="color:var(--g);font-weight:700"><?=number_format($w->amount_sat)?> sat</td>
                    <td>
                        <a href="<?=admin_url("admin.php?page=cfp-withdrawals&action=approve&id={$w->id}&_wpnonce=$n")?>" class="cfp-btn cfp-btn-green cfp-btn-sm">✓</a>
                        <a href="<?=admin_url("admin.php?page=cfp-withdrawals&action=reject&id={$w->id}&_wpnonce=$n")?>" class="cfp-btn cfp-btn-red cfp-btn-sm">✕</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php if(empty($recent_wds)): ?><tr><td colspan="3" style="text-align:center;color:var(--mt);padding:20px">None pending 🎉</td></tr><?php endif; ?>
                </tbody></table>
            </div>
        </div>

        <div class="cfp-card">
            <h2>🔧 All Shortcodes</h2>
            <div style="display:flex;flex-wrap:wrap;gap:10px">
            <?php $codes=['[cfp_landing]'=>'Full landing page','[cfp_faucet]'=>'Hourly claim widget','[cfp_hilo]'=>'Hi-Lo multiply game','[cfp_slots]'=>'Slots machine','[cfp_coinflip]'=>'Coin flip','[cfp_dice]'=>'Dice roll','[cfp_crash]'=>'Crash game','[cfp_wheel]'=>'Wheel of fortune','[cfp_games_lobby]'=>'All games lobby','[cfp_lottery]'=>'Weekly lottery','[cfp_savings]'=>'BTC savings account','[cfp_golden]'=>'Golden ticket contest','[cfp_p2p]'=>'P2P event predictions','[cfp_referral]'=>'Referral program','[cfp_deposit]'=>'Coinbase deposit','[cfp_withdraw]'=>'Coinbase / manual withdrawal','[cfp_history]'=>'Transaction history','[cfp_leaderboard]'=>'Top earners','[cfp_balance]'=>'Balance checker'];
            foreach($codes as $sc=>$d): ?>
            <div style="background:#111;border:1px solid var(--br);border-radius:8px;padding:11px 14px;min-width:190px">
                <code style="color:var(--g);font-size:.86rem"><?=esc_html($sc)?></code>
                <div style="font-size:.75rem;color:var(--mt);margin-top:3px"><?=esc_html($d)?></div>
            </div>
            <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php
}


/* ============================================================
   ADMIN: USERS  — Block / Ban / Delete + Bulk Actions
   ============================================================ */
function cfp_admin_users() {
    global $wpdb;
    $notice = '';

    // ── Single-user actions (GET) ────────────────────────────
    if ( isset($_GET['action'], $_GET['id']) && check_admin_referer('cfp_user') ) {
        $uid = intval($_GET['id']);
        $act = sanitize_text_field($_GET['action']);

        if ( $act === 'ban' ) {
            $wpdb->update(CFP_TABLE_USERS, ['is_banned'=>1], ['id'=>$uid]);
            $u = $wpdb->get_row($wpdb->prepare("SELECT username FROM ".CFP_TABLE_USERS." WHERE id=%d",$uid));
            $notice = "<div class='cfp-notice error'>&#128683; <strong>".esc_html($u->username??'User')."</strong> has been banned.</div>";
        }
        if ( $act === 'unban' ) {
            $wpdb->update(CFP_TABLE_USERS, ['is_banned'=>0], ['id'=>$uid]);
            $u = $wpdb->get_row($wpdb->prepare("SELECT username FROM ".CFP_TABLE_USERS." WHERE id=%d",$uid));
            $notice = "<div class='cfp-notice success'>&#9989; <strong>".esc_html($u->username??'User')."</strong> access restored.</div>";
        }
        if ( $act === 'block' ) {
            $u = $wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_USERS." WHERE id=%d",$uid));
            if ($u) {
                $wpdb->update(CFP_TABLE_USERS, ['is_banned'=>1,'balance_sat'=>0,'savings_sat'=>0], ['id'=>$uid]);
                $wpdb->update(CFP_TABLE_WITHDRAWALS, ['status'=>'rejected'], ['user_id'=>$uid,'status'=>'pending']);
                $wpdb->insert(CFP_TABLE_TRANSACTIONS, ['user_id'=>$uid,'type'=>'admin_block','amount_sat'=>-$u->balance_sat,'description'=>'Account blocked — balance forfeited']);
                $notice = "<div class='cfp-notice error'>&#128683; <strong>".esc_html($u->username)."</strong> blocked. Balance forfeited &amp; pending withdrawals cancelled.</div>";
            }
        }
        if ( $act === 'delete' ) {
            $u = $wpdb->get_row($wpdb->prepare("SELECT username,email FROM ".CFP_TABLE_USERS." WHERE id=%d",$uid));
            if ($u) {
                foreach([CFP_TABLE_CLAIMS,CFP_TABLE_TRANSACTIONS,CFP_TABLE_INTEREST,CFP_TABLE_LOTTERY_TICKETS,CFP_TABLE_FP_DEPOSITS,CFP_TABLE_FP_WITHDRAWALS] as $tbl)
                    $wpdb->delete($tbl, ['user_id'=>$uid]);
                $wpdb->delete(CFP_TABLE_REFERRALS,   ['referrer_id'=>$uid]);
                $wpdb->delete(CFP_TABLE_REFERRALS,   ['referred_id'=>$uid]);
                $wpdb->delete(CFP_TABLE_WITHDRAWALS, ['user_id'=>$uid]);
                $wpdb->delete(CFP_TABLE_USERS,       ['id'=>$uid]);
                $notice = "<div class='cfp-notice success'>&#128465;&#65039; User <strong>".esc_html($u->username)."</strong> and all data permanently deleted.</div>";
            }
        }
        if (!$notice) echo '<script>window.location="'.admin_url('admin.php?page=cfp-users').'"</script>';
        if ($act !== 'delete') { echo '<script>window.location="'.admin_url('admin.php?page=cfp-users').'"</script>'; exit; }
    }

    // ── Bulk actions (POST) ──────────────────────────────────
    if ( isset($_POST['cfp_bulk_action'], $_POST['bulk_users']) && check_admin_referer('cfp_bulk') ) {
        $bulk_act = sanitize_text_field($_POST['cfp_bulk_action']);
        $bulk_ids = array_filter(array_map('intval',(array)$_POST['bulk_users']));
        $count    = count($bulk_ids);
        if ($count > 0 && in_array($bulk_act,['ban','unban','block','delete'])) {
            foreach($bulk_ids as $bid) {
                if ($bulk_act === 'ban')   $wpdb->update(CFP_TABLE_USERS,['is_banned'=>1],['id'=>$bid]);
                if ($bulk_act === 'unban') $wpdb->update(CFP_TABLE_USERS,['is_banned'=>0],['id'=>$bid]);
                if ($bulk_act === 'block') {
                    $bu = $wpdb->get_row($wpdb->prepare("SELECT balance_sat FROM ".CFP_TABLE_USERS." WHERE id=%d",$bid));
                    $wpdb->update(CFP_TABLE_USERS,['is_banned'=>1,'balance_sat'=>0,'savings_sat'=>0],['id'=>$bid]);
                    $wpdb->update(CFP_TABLE_WITHDRAWALS,['status'=>'rejected'],['user_id'=>$bid,'status'=>'pending']);
                    if($bu) $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$bid,'type'=>'admin_block','amount_sat'=>-$bu->balance_sat,'description'=>'Bulk block by admin']);
                }
                if ($bulk_act === 'delete') {
                    foreach([CFP_TABLE_CLAIMS,CFP_TABLE_TRANSACTIONS,CFP_TABLE_INTEREST,CFP_TABLE_LOTTERY_TICKETS,CFP_TABLE_FP_DEPOSITS,CFP_TABLE_FP_WITHDRAWALS] as $tbl)
                        $wpdb->delete($tbl,['user_id'=>$bid]);
                    $wpdb->delete(CFP_TABLE_REFERRALS,  ['referrer_id'=>$bid]);
                    $wpdb->delete(CFP_TABLE_REFERRALS,  ['referred_id'=>$bid]);
                    $wpdb->delete(CFP_TABLE_WITHDRAWALS,['user_id'=>$bid]);
                    $wpdb->delete(CFP_TABLE_USERS,      ['id'=>$bid]);
                }
            }
            $lbl = ['ban'=>'Banned','unban'=>'Unbanned','block'=>'Blocked','delete'=>'Deleted'];
            $notice = "<div class='cfp-notice success'>&#9989; {$lbl[$bulk_act]} {$count} user(s).</div>";
        }
    }

    // ── Balance Adjustment (POST) ────────────────────────────
    if ( isset($_POST['cfp_adjust_submit']) && check_admin_referer('cfp_adjust_balance') ) {
        $uid    = intval($_POST['adj_user_id']);
        $type   = sanitize_text_field($_POST['adj_type']);
        $amount = intval($_POST['adj_amount']);
        $reason = sanitize_text_field($_POST['adj_reason']);
        $target = sanitize_text_field($_POST['adj_target']);
        if ($uid > 0 && $amount > 0) {
            $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_USERS." WHERE id=%d",$uid));
            if ($user) {
                $col     = $target === 'savings' ? 'savings_sat' : 'balance_sat';
                $delta   = $type === 'credit' ? $amount : -$amount;
                $current = $target === 'savings' ? $user->savings_sat : $user->balance_sat;
                if ($type === 'debit' && $amount > $current) {
                    $notice = "<div class='cfp-notice error'>&#10060; Cannot debit more than {$target} balance (".number_format($current)." sat).</div>";
                } else {
                    $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET {$col}={$col}+%d WHERE id=%d",$delta,$uid));
                    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$uid,'type'=>'admin_'.$type,'amount_sat'=>$delta,'description'=>'Admin '.ucfirst($type)." ({$target}): ".($reason?:'No reason given')]);
                    $verb   = $type === 'credit' ? 'Credited' : 'Debited';
                    $notice = "<div class='cfp-notice success'>&#9989; {$verb} ".number_format($amount)." sat ".($type==='credit'?'to':'from')." {$user->username}'s {$target}.</div>";
                }
            } else { $notice = "<div class='cfp-notice error'>&#10060; User not found.</div>"; }
        } else { $notice = "<div class='cfp-notice error'>&#10060; Invalid amount or user.</div>"; }
    }

    // Load data
    $search  = sanitize_text_field($_GET['s']      ?? '');
    $filter  = sanitize_text_field($_GET['filter'] ?? 'all');
    $page    = max(1, intval($_GET['paged'] ?? 1));
    $per     = 20; $offset = ($page-1)*$per;

    $where_parts = [];
    if ($search)         $where_parts[] = $wpdb->prepare("(email LIKE %s OR username LIKE %s)","%$search%","%$search%");
    if ($filter==='active') $where_parts[] = "is_banned=0";
    if ($filter==='banned') $where_parts[] = "is_banned=1";
    $where = $where_parts ? 'WHERE '.implode(' AND ',$where_parts) : '';

    $total_all    = (int)$wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_USERS);
    $total_active = (int)$wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_USERS." WHERE is_banned=0");
    $total_banned = (int)$wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_USERS." WHERE is_banned=1");
    $total_shown  = (int)$wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_USERS." $where");
    $users        = $wpdb->get_results($wpdb->prepare("SELECT * FROM ".CFP_TABLE_USERS." $where ORDER BY created_at DESC LIMIT %d OFFSET %d",$per,$offset));
    $pages        = max(1, ceil($total_shown/$per));
    $all_for_sel  = $wpdb->get_results("SELECT id,username,email,balance_sat,savings_sat FROM ".CFP_TABLE_USERS." ORDER BY username ASC LIMIT 500");
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">&#9889; CFP</span>
            <h1>User Management</h1>
            <span style="margin-left:auto;font-size:.83rem;color:var(--mt)">
                <?=$total_all?> total &nbsp;&middot;&nbsp;
                <span style="color:var(--gr)"><?=$total_active?> active</span> &nbsp;&middot;&nbsp;
                <span style="color:var(--rd)"><?=$total_banned?> banned</span>
            </span>
        </div>

        <?=$notice?>

        <div style="display:flex;gap:10px;margin-bottom:18px;flex-wrap:wrap">
            <button class="cfp-btn cfp-btn-gold" onclick="document.getElementById('cfp-adj-modal').style.display='flex'">&#9878;&#65039; Balance Adjustor</button>
            <a href="<?=admin_url('admin.php?page=cfp-currencies')?>" class="cfp-btn cfp-btn-ghost">&#129689; Currency Editor</a>
        </div>

        <!-- ══ USER ACTION CONFIRMATION MODAL ══════════════════════ -->
        <div id="cfp-action-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.85);z-index:99999;align-items:center;justify-content:center">
            <div style="background:#161616;border:1px solid #333;border-radius:16px;padding:28px;width:480px;max-width:94vw;position:relative;box-shadow:0 24px 80px rgba(0,0,0,.8)">
                <button onclick="document.getElementById('cfp-action-modal').style.display='none'" style="position:absolute;top:12px;right:14px;background:transparent;border:none;color:#555;font-size:1.4rem;cursor:pointer;line-height:1">&times;</button>

                <!-- Dynamic header per action -->
                <div id="act-header-ban"    style="display:none;margin-bottom:14px"><span style="background:#ef4444;color:#fff;font-weight:800;padding:4px 10px;border-radius:6px;font-size:.76rem">&#128683; BAN</span> <span style="font-size:1.05rem;font-weight:700;color:#fff;margin-left:6px">Ban User</span><p style="font-size:.8rem;color:#888;margin:8px 0 0">Blocks access. Balance preserved. Reversible via Unban.</p></div>
                <div id="act-header-unban"  style="display:none;margin-bottom:14px"><span style="background:#22c55e;color:#000;font-weight:800;padding:4px 10px;border-radius:6px;font-size:.76rem">&#9989; UNBAN</span> <span style="font-size:1.05rem;font-weight:700;color:#fff;margin-left:6px">Restore Access</span><p style="font-size:.8rem;color:#888;margin:8px 0 0">User regains full access to faucet, games, and withdrawals.</p></div>
                <div id="act-header-block"  style="display:none;margin-bottom:14px"><span style="background:#7f1d1d;color:#fca5a5;font-weight:800;padding:4px 10px;border-radius:6px;font-size:.76rem">&#9940; BLOCK</span> <span style="font-size:1.05rem;font-weight:700;color:#fff;margin-left:6px">Block &amp; Forfeit</span><p style="font-size:.8rem;color:#f87171;margin:8px 0 0">Bans user AND forfeits their entire balance. Pending withdrawals cancelled. For fraudulent accounts.</p></div>
                <div id="act-header-delete" style="display:none;margin-bottom:14px"><span style="background:#450a0a;color:#fca5a5;font-weight:800;padding:4px 10px;border-radius:6px;font-size:.76rem">&#128465; DELETE</span> <span style="font-size:1.05rem;font-weight:700;color:#fff;margin-left:6px">Permanent Delete</span><p style="font-size:.8rem;color:#f87171;margin:8px 0 0"><strong>Irreversible.</strong> Erases account, all claims, transactions, game records, and referral links forever.</p></div>

                <!-- User preview card -->
                <div style="background:#111;border:1px solid #1e1e1e;border-radius:10px;padding:14px;margin-bottom:16px;display:flex;align-items:center;gap:12px">
                    <div id="act-avatar" style="width:40px;height:40px;border-radius:50%;background:#1a1a1a;border:1px solid #2a2a2a;display:flex;align-items:center;justify-content:center;font-weight:800;color:var(--g);font-size:1.1rem;flex-shrink:0">U</div>
                    <div style="flex:1">
                        <div id="act-username" style="font-weight:700;color:#fff">—</div>
                        <div id="act-email"    style="font-size:.74rem;color:var(--mt)">—</div>
                    </div>
                    <div style="text-align:right">
                        <div id="act-balance" style="font-size:.85rem;font-weight:700;color:var(--g)">— sat</div>
                        <div id="act-status"  style="font-size:.7rem;color:#444">—</div>
                    </div>
                </div>

                <!-- Optional reason field -->
                <div id="act-reason-wrap" style="margin-bottom:16px">
                    <label style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--mt);display:block;margin-bottom:5px">Reason / Note <span style="color:#333;font-weight:400">(optional, shown in log)</span></label>
                    <input type="text" id="act-reason" placeholder="e.g. Multiple accounts, spam, abuse…" style="width:100%;background:#111;border:1px solid #2a2a2a;color:var(--tx);padding:9px 12px;border-radius:7px;font-size:.86rem;outline:none">
                </div>

                <!-- Delete-only: mandatory checkbox -->
                <div id="act-delete-confirm" style="display:none;margin-bottom:16px">
                    <div style="background:#2d0a0a;border:1px solid #ef444433;border-radius:8px;padding:12px;margin-bottom:10px">
                        <div style="font-size:.8rem;color:#ef4444;font-weight:700;margin-bottom:4px">&#9888;&#65039; Cannot be undone</div>
                        <div style="font-size:.76rem;color:#a33">Erases: account, all claims, transactions, game history, referrals, withdrawals, deposits.</div>
                    </div>
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:.84rem;color:#aaa">
                        <input type="checkbox" id="act-delete-cb" onchange="document.getElementById('act-confirm-btn').disabled=!this.checked">
                        I understand this is permanent and irreversible
                    </label>
                </div>

                <div style="display:grid;grid-template-columns:1fr 1fr;gap:11px">
                    <button onclick="document.getElementById('cfp-action-modal').style.display='none'" class="cfp-btn cfp-btn-ghost" style="justify-content:center;padding:11px">Cancel</button>
                    <button id="act-confirm-btn" class="cfp-btn" style="justify-content:center;padding:11px;font-size:.88rem" onclick="cfpDoAction()">Confirm</button>
                </div>
            </div>
        </div>

        <!-- ══ BALANCE ADJUSTOR MODAL ══════════════════════════════ -->
        <div id="cfp-adj-modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,.8);z-index:99999;align-items:center;justify-content:center">
            <div style="background:#161616;border:1px solid #333;border-radius:16px;padding:30px;width:540px;max-width:94vw;max-height:90vh;overflow-y:auto;position:relative;box-shadow:0 20px 60px rgba(0,0,0,.7)">
                <button onclick="document.getElementById('cfp-adj-modal').style.display='none'" style="position:absolute;top:12px;right:14px;background:transparent;border:none;color:#555;font-size:1.4rem;cursor:pointer;line-height:1">&times;</button>
                <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
                    <span style="background:var(--g);color:#000;font-weight:900;padding:4px 10px;border-radius:6px;font-size:.78rem">ADJUSTOR</span>
                    <h2 style="font-size:1.1rem;font-weight:700;color:#fff;margin:0">Balance Adjustor</h2>
                </div>
                <p style="font-size:.8rem;color:var(--mt);margin:0 0 20px">Credit or debit any user's main balance or savings. All adjustments are logged.</p>
                <form method="post">
                    <?php wp_nonce_field('cfp_adjust_balance'); ?>
                    <input type="hidden" name="cfp_adjust_submit" value="1">
                    <div class="cfp-field" style="margin-bottom:14px">
                        <label>Select User</label>
                        <select name="adj_user_id" id="adj-user-select" onchange="cfpUpdateUserInfo(this)" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 12px;border-radius:8px;font-size:.87rem;width:100%">
                            <option value="">&#8212; Choose a user &#8212;</option>
                            <?php foreach($all_for_sel as $u): ?>
                            <option value="<?=$u->id?>" data-balance="<?=$u->balance_sat?>" data-savings="<?=$u->savings_sat?>" data-name="<?=esc_attr($u->username)?>">
                                #<?=$u->id?> &middot; <?=esc_html($u->username)?> (<?=esc_html($u->email)?>)
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div id="adj-user-info" style="display:none;background:#0d0d0d;border:1px solid #1e1e1e;border-radius:9px;padding:14px;margin-bottom:14px">
                        <div style="font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt);margin-bottom:10px">Current Balances</div>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
                            <div style="background:#111;border:1px solid #1e1e1e;border-radius:8px;padding:12px;text-align:center">
                                <div style="font-size:.63rem;text-transform:uppercase;letter-spacing:1px;color:#444;margin-bottom:4px">Main</div>
                                <div id="adj-bal-display" style="font-size:1.4rem;font-weight:800;color:var(--g);font-family:monospace">0</div>
                                <div style="font-size:.66rem;color:#333">sat</div>
                            </div>
                            <div style="background:#111;border:1px solid #1e1e1e;border-radius:8px;padding:12px;text-align:center">
                                <div style="font-size:.63rem;text-transform:uppercase;letter-spacing:1px;color:#444;margin-bottom:4px">Savings</div>
                                <div id="adj-sav-display" style="font-size:1.4rem;font-weight:800;color:#a855f7;font-family:monospace">0</div>
                                <div style="font-size:.66rem;color:#333">sat</div>
                            </div>
                        </div>
                        <div id="adj-preview" style="display:none;margin-top:10px;padding:9px 12px;border-radius:7px;font-size:.8rem;font-weight:600;text-align:center"></div>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
                        <div class="cfp-field">
                            <label>Operation</label>
                            <select name="adj_type" id="adj-type" onchange="cfpAdjPreview()" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.87rem">
                                <option value="credit">&#10133; Credit (Add)</option>
                                <option value="debit">&#10134; Debit (Remove)</option>
                            </select>
                        </div>
                        <div class="cfp-field">
                            <label>Target</label>
                            <select name="adj_target" id="adj-target" onchange="cfpAdjPreview()" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.87rem">
                                <option value="balance">Main Balance</option>
                                <option value="savings">Savings</option>
                            </select>
                        </div>
                    </div>
                    <div class="cfp-field" style="margin-bottom:12px">
                        <label>Amount (satoshis)</label>
                        <input type="number" name="adj_amount" id="adj-amount" min="1" placeholder="e.g. 10000" oninput="cfpAdjPreview()" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.87rem;width:100%">
                    </div>
                    <div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:12px">
                        <?php foreach([100,500,1000,5000,10000,50000,100000] as $qa): ?>
                        <button type="button" onclick="document.getElementById('adj-amount').value=<?=$qa?>;cfpAdjPreview()" style="background:#1a1a1a;border:1px solid var(--br);color:var(--mt);padding:4px 10px;border-radius:5px;font-size:.73rem;cursor:pointer" onmouseover="this.style.borderColor='var(--g)';this.style.color='var(--g)'" onmouseout="this.style.borderColor='var(--br)';this.style.color='var(--mt)'"><?=number_format($qa)?></button>
                        <?php endforeach; ?>
                    </div>
                    <div class="cfp-field" style="margin-bottom:18px">
                        <label>Reason <span style="font-weight:400;color:#333">(logged)</span></label>
                        <input type="text" name="adj_reason" placeholder="e.g. Contest prize, Error correction…" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.87rem;width:100%">
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:11px">
                        <button type="button" onclick="document.getElementById('cfp-adj-modal').style.display='none'" class="cfp-btn cfp-btn-ghost" style="justify-content:center;padding:12px">Cancel</button>
                        <button type="submit" class="cfp-btn cfp-btn-gold" style="justify-content:center;padding:12px" onclick="return cfpConfirmAdj()">&#9989; Apply</button>
                    </div>
                </form>
            </div>
        </div>

        <!-- ══ FILTER TABS ══════════════════════════════════════════ -->
        <div class="cfp-tabs">
            <?php foreach(['all'=>"All ({$total_all})",'active'=>"Active ({$total_active})",'banned'=>"Banned ({$total_banned})"] as $k=>$lbl): ?>
            <a href="<?=admin_url("admin.php?page=cfp-users&filter=$k".($search?'&s='.urlencode($search):''))?>" class="cfp-tab <?=$filter===$k?'active':''?>"><?=$lbl?></a>
            <?php endforeach; ?>
        </div>

        <!-- ══ SEARCH + BULK FORM ═══════════════════════════════════ -->
        <form method="post" id="cfp-users-form">
            <?php wp_nonce_field('cfp_bulk'); ?>
            <div style="display:flex;gap:9px;margin-bottom:16px;flex-wrap:wrap;align-items:center">
                <input type="text" id="cfp-search-inp" placeholder="Search email or username…" value="<?=esc_attr($search)?>"
                    onkeydown="if(event.key==='Enter'){var v=this.value;window.location='<?=admin_url('admin.php?page=cfp-users&filter='.$filter)?>'+(v?'&s='+encodeURIComponent(v):'');return false;}"
                    style="flex:1;min-width:180px;background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.86rem">
                <button type="button" onclick="var v=document.getElementById('cfp-search-inp').value;window.location='<?=admin_url('admin.php?page=cfp-users&filter='.$filter)?>'+(v?'&s='+encodeURIComponent(v):'')" class="cfp-btn cfp-btn-gold">Search</button>
                <?php if($search): ?><a href="<?=admin_url('admin.php?page=cfp-users&filter='.$filter)?>" class="cfp-btn cfp-btn-ghost">&#10005; Clear</a><?php endif; ?>
                <div style="height:28px;width:1px;background:#2a2a2a;flex-shrink:0"></div>
                <select name="cfp_bulk_action" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.84rem">
                    <option value="">Bulk Action…</option>
                    <option value="ban">&#128683; Ban selected</option>
                    <option value="unban">&#9989; Unban selected</option>
                    <option value="block">&#9940; Block &amp; Forfeit selected</option>
                    <option value="delete">&#128465; Delete selected (permanent)</option>
                </select>
                <button type="submit" class="cfp-btn cfp-btn-ghost" onclick="return cfpConfirmBulk()">Apply</button>
            </div>

            <div class="cfp-card">
                <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th style="width:34px"><input type="checkbox" id="cfp-sel-all" title="Select all" onchange="document.querySelectorAll('.u-cb').forEach(c=>c.checked=this.checked)" style="cursor:pointer;width:16px;height:16px"></th>
                            <th>#</th><th>User</th><th>Balance</th><th>Savings</th><th>Claims</th><th>Refs</th><th>Joined</th><th>Status</th><th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach($users as $u):
                        $refs  = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM ".CFP_TABLE_REFERRALS." WHERE referrer_id=%d",$u->id));
                        $nonce = wp_create_nonce('cfp_user');
                        $udata = esc_attr(json_encode(['id'=>$u->id,'username'=>$u->username,'email'=>$u->email,'balance'=>$u->balance_sat,'banned'=>(bool)$u->is_banned]));
                        $row_style = $u->is_banned ? 'background:#130505;' : '';
                    ?>
                    <tr style="<?=$row_style?>">
                        <td><input type="checkbox" name="bulk_users[]" value="<?=$u->id?>" class="u-cb" style="cursor:pointer;width:15px;height:15px"></td>
                        <td style="color:var(--mt)"><?=$u->id?></td>
                        <td>
                            <div style="display:flex;align-items:center;gap:9px">
                                <div style="width:32px;height:32px;border-radius:50%;background:#1a1a1a;border:1px solid #2a2a2a;display:flex;align-items:center;justify-content:center;font-weight:800;color:var(--g);font-size:.82rem;flex-shrink:0">
                                    <?=esc_html(strtoupper(substr($u->username,0,1)))?>
                                </div>
                                <div>
                                    <div style="font-weight:700;color:#fff;font-size:.9rem"><?=esc_html($u->username)?></div>
                                    <div style="font-size:.72rem;color:var(--mt)"><?=esc_html($u->email)?></div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span style="color:var(--g);font-weight:700"><?=number_format($u->balance_sat)?></span>
                            <button title="Adjust" onclick="cfpOpenAdj(<?=$u->id?>,<?=$u->balance_sat?>,<?=$u->savings_sat?>,'<?=esc_js($u->username)?>')" style="background:transparent;border:1px solid #2a2a2a;color:#555;border-radius:4px;padding:1px 5px;font-size:.63rem;cursor:pointer;margin-left:3px" onmouseover="this.style.color='var(--g)';this.style.borderColor='var(--g)'" onmouseout="this.style.color='#555';this.style.borderColor='#2a2a2a'">&#9878;</button>
                        </td>
                        <td style="color:#a855f7"><?=number_format($u->savings_sat)?></td>
                        <td><?=$u->total_claims?></td>
                        <td><?=$refs?></td>
                        <td style="font-size:.74rem;color:var(--mt)"><?=date('M j, Y',strtotime($u->created_at))?></td>
                        <td>
                            <?php if($u->is_banned): ?>
                                <span class="cfp-badge banned">&#128683; Banned</span>
                            <?php else: ?>
                                <span class="cfp-badge active">&#9679; Active</span>
                            <?php endif; ?>
                        </td>
                        <td style="white-space:nowrap">
                            <?php if($u->is_banned): ?>
                            <button class="cfp-btn cfp-btn-green cfp-btn-sm" onclick="cfpShowAction('unban','<?=$udata?>','<?=$nonce?>')" title="Restore full access">&#9989; Unban</button>
                            <?php else: ?>
                            <button class="cfp-btn cfp-btn-sm" style="background:#ef4444;color:#fff" onclick="cfpShowAction('ban','<?=$udata?>','<?=$nonce?>')" title="Suspend account">&#128683; Ban</button>
                            <?php endif; ?>
                            <button class="cfp-btn cfp-btn-sm" style="background:#7f1d1d;color:#fca5a5;border:1px solid #991b1b44" onclick="cfpShowAction('block','<?=$udata?>','<?=$nonce?>')" title="Ban + forfeit balance">&#9940; Block</button>
                            <button class="cfp-btn cfp-btn-gold cfp-btn-sm" onclick="cfpOpenAdj(<?=$u->id?>,<?=$u->balance_sat?>,<?=$u->savings_sat?>,'<?=esc_js($u->username)?>')" title="Adjust balance">&#9878;</button>
                            <button class="cfp-btn cfp-btn-sm" style="background:#111;color:#ef4444;border:1px solid #ef444433" onclick="cfpShowAction('delete','<?=$udata?>','<?=$nonce?>')" title="Permanently delete">&#128465;</button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($users)): ?>
                    <tr><td colspan="10" style="text-align:center;color:var(--mt);padding:28px;font-size:.9rem">No users found<?=$search?' matching "'.esc_html($search).'"':''?>.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
                </div>
                <?php if($pages > 1): ?>
                <div class="cfp-pagination">
                    <?php for($i=1;$i<=$pages;$i++): ?>
                    <a href="<?=admin_url("admin.php?page=cfp-users&paged=$i&filter=$filter".($search?'&s='.urlencode($search):''))?>" class="<?=$i===$page?'current':''?>"><?=$i?></a>
                    <?php endfor; ?>
                </div>
                <?php endif; ?>
            </div>
        </form>

        <!-- CSV EXPORT -->
        <div class="cfp-card" style="margin-top:20px">
            <h2>📥 Export Users</h2>
            <p style="color:#777;font-size:.85rem;margin-bottom:14px">Export user data to CSV for external analysis or backup.</p>
            <form method="post" action="<?=admin_url('admin-post.php')?>" target="_blank">
                <input type="hidden" name="action" value="cfp_export_users_csv">
                <?php wp_nonce_field('cfp_export_users'); ?>
                <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:end">
                    <div class="cfp-field">
                        <label>Filter</label>
                        <select name="export_filter" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                            <option value="all">All Users</option>
                            <option value="active">Active Only</option>
                            <option value="banned">Banned Only</option>
                            <option value="with_balance">With Balance > 0</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Include</label>
                        <select name="export_include" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                            <option value="basic">Basic (ID, username, email, balance)</option>
                            <option value="full">Full (all fields)</option>
                        </select>
                    </div>
                    <button type="submit" class="cfp-btn cfp-btn-gold">📥 Download CSV</button>
                </div>
            </form>
        </div>

        <!-- USER ACTIVITY TIMELINE -->
        <div class="cfp-card" style="margin-top:20px">
            <h2>📜 User Activity Timeline</h2>
            <p style="color:#777;font-size:.85rem;margin-bottom:14px">View recent activity across all users - claims, games, withdrawals, and more.</p>
            <?php
            // Get recent activity from various tables
            $activity_timeline = $wpdb->get_results("
                SELECT 'claim' as type, id, user_id, amount_sat, claimed_at as timestamp, 'claim' as action
                FROM " . CFP_TABLE_CLAIMS . "
                UNION ALL
                SELECT 'withdrawal' as type, id, user_id, amount_sat, requested_at as timestamp, status as action
                FROM " . CFP_TABLE_WITHDRAWALS . "
                UNION ALL
                SELECT 'game' as type, id, user_id, bet_sat as amount_sat, played_at as timestamp, 'play' as action
                FROM " . CFP_TABLE_MULTIPLY . "
                ORDER BY timestamp DESC LIMIT 50
            ");
            
            $activity_types = [
                'claim' => ['icon' => '💰', 'label' => 'Claim', 'color' => '#22c55e'],
                'withdrawal' => ['icon' => '💸', 'label' => 'Withdrawal', 'color' => '#f7931a'],
                'game' => ['icon' => '🎮', 'label' => 'Game', 'color' => '#3b82f6'],
            ];
            ?>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>Type</th>
                            <th>User</th>
                            <th>Amount</th>
                            <th>Details</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($activity_timeline as $act):
                            $user = $wpdb->get_row($wpdb->prepare("SELECT username FROM " . CFP_TABLE_USERS . " WHERE id = %d", $act->user_id));
                            $type_info = $activity_types[$act->type] ?? ['icon' => '📌', 'label' => 'Unknown', 'color' => '#888'];
                        ?>
                        <tr>
                            <td>
                                <span style="display:inline-flex;align-items:center;gap:6px;padding:4px 10px;background:<?=$type_info['color']?>22;border:1px solid <?=$type_info['color']?>44;border-radius:6px;font-size:.78rem">
                                    <?=$type_info['icon']?> <?=$type_info['label']?>
                                </span>
                            </td>
                            <td><strong><?=esc_html($user->username ?? 'Unknown')?></strong></td>
                            <td style="color:var(--g);font-weight:600"><?=number_format($act->amount_sat)?> sat</td>
                            <td style="color:#777;font-size:.78rem"><?=esc_html($act->action ?? '-')?></td>
                            <td style="color:#555;font-size:.78rem"><?=human_time_diff(strtotime($act->timestamp), current_time('timestamp'))?> ago</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- LOGIN HISTORY -->
        <?php
        // Check if login history table exists, if not create it
        $login_table_exists = $wpdb->get_var("SHOW TABLES LIKE '" . CFP_TABLE_LOGIN_HISTORY . "'");
        if(!$login_table_exists && defined('CFP_TABLE_LOGIN_HISTORY')) {
            $wpdb->query("
                CREATE TABLE IF NOT EXISTS " . CFP_TABLE_LOGIN_HISTORY . " (
                    id bigint(20) NOT NULL AUTO_INCREMENT,
                    user_id bigint(20) NOT NULL,
                    ip_address varchar(45) DEFAULT NULL,
                    user_agent text,
                    logged_in_at datetime DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY  (id),
                    KEY user_id (user_id),
                    KEY logged_in_at (logged_in_at)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
            ");
        }
        
        $recent_logins = $wpdb->get_results("
            SELECT l.*, u.username 
            FROM " . CFP_TABLE_LOGIN_HISTORY . " l
            LEFT JOIN " . CFP_TABLE_USERS . " u ON l.user_id = u.id
            ORDER BY l.logged_in_at DESC LIMIT 20
        ");
        ?>
        <div class="cfp-card" style="margin-top:20px">
            <h2>🔐 Recent Login History</h2>
            <p style="color:#777;font-size:.85rem;margin-bottom:14px">Track user logins for security and audit purposes.</p>
            <?php if(!empty($recent_logins)): ?>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>IP Address</th>
                            <th>Location</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($recent_logins as $login): ?>
                        <tr>
                            <td><strong><?=esc_html($login->username ?? 'Unknown')?></strong></td>
                            <td style="font-family:monospace;font-size:.82rem"><?=esc_html($login->ip_address ?? 'N/A')?></td>
                            <td style="font-size:.82rem;color:#777">
                                <?php 
                                // Simple country detection based on IP (would need MaxMind DB for accurate results)
                                $country = !empty($login->ip_address) ? '🌍 Unknown' : 'N/A';
                                echo esc_html($country);
                                ?>
                            </td>
                            <td style="color:#555;font-size:.78rem"><?=human_time_diff(strtotime($login->logged_in_at), current_time('timestamp'))?> ago</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <div style="text-align:center;padding:30px;color:#555">
                <p>No login history recorded yet.</p>
                <p style="font-size:.82rem">Login tracking can be enabled in Security settings.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
    var cfpActNonce = '', cfpActUser = null, cfpActType = '';

    function cfpShowAction(type, udataStr, nonce) {
        cfpActType  = type;
        cfpActNonce = nonce;
        try { cfpActUser = JSON.parse(udataStr); } catch(e) { return; }

        // Toggle headers
        ['ban','unban','block','delete'].forEach(function(t){
            document.getElementById('act-header-'+t).style.display = t===type ? '' : 'none';
        });

        // Fill preview
        document.getElementById('act-avatar').textContent   = cfpActUser.username.charAt(0).toUpperCase();
        document.getElementById('act-username').textContent = cfpActUser.username;
        document.getElementById('act-email').textContent    = cfpActUser.email;
        document.getElementById('act-balance').textContent  = parseInt(cfpActUser.balance).toLocaleString() + ' sat';
        document.getElementById('act-status').innerHTML     = cfpActUser.banned
            ? '<span style="color:var(--rd)">Banned</span>'
            : '<span style="color:var(--gr)">Active</span>';

        // Reason field (hidden for unban)
        document.getElementById('act-reason-wrap').style.display = type === 'unban' ? 'none' : '';
        document.getElementById('act-reason').value = '';

        // Delete confirm
        var dc = document.getElementById('act-delete-confirm');
        dc.style.display = type === 'delete' ? '' : 'none';
        document.getElementById('act-delete-cb').checked = false;

        // Confirm button
        var btn = document.getElementById('act-confirm-btn');
        var colors = { ban:'background:#ef4444;color:#fff', unban:'background:#22c55e;color:#000', block:'background:#7f1d1d;color:#fca5a5', delete:'background:#450a0a;color:#fca5a5' };
        var labels = { ban:'&#128683; Confirm Ban', unban:'&#9989; Restore Access', block:'&#9940; Block & Forfeit', delete:'&#128465; Delete Forever' };
        btn.setAttribute('style', 'justify-content:center;padding:11px;font-size:.88rem;border:none;border-radius:8px;cursor:pointer;'+colors[type]);
        btn.innerHTML = labels[type];
        btn.disabled  = (type === 'delete');

        document.getElementById('cfp-action-modal').style.display = 'flex';
    }

    function cfpDoAction() {
        if(!cfpActType || !cfpActUser) return;
        var url = '<?=admin_url('admin.php')?>?page=cfp-users&action='+cfpActType+'&id='+cfpActUser.id+'&_wpnonce='+cfpActNonce;
        var reason = document.getElementById('act-reason').value;
        if(reason) url += '&reason='+encodeURIComponent(reason);
        window.location = url;
    }

    function cfpConfirmBulk() {
        var act     = document.querySelector('[name="cfp_bulk_action"]').value;
        var checked = document.querySelectorAll('.u-cb:checked');
        if(!act)         { alert('Select a bulk action first.'); return false; }
        if(!checked.length) { alert('Select at least one user.'); return false; }
        var lbl = {ban:'Ban',unban:'Unban',block:'Block & forfeit balance of',delete:'PERMANENTLY DELETE'};
        var msg = (lbl[act]||act) + ' ' + checked.length + ' user(s)?';
        if(act === 'delete') msg += '\n\n\u26A0\uFE0F This CANNOT be undone. All user data will be erased permanently.';
        if(act === 'block')  msg += '\n\nBalances will be forfeited and pending withdrawals cancelled.';
        return confirm(msg + '\n\nProceed?');
    }

    /* Close modals on backdrop click */
    ['cfp-action-modal','cfp-adj-modal'].forEach(function(id){
        var el = document.getElementById(id);
        if(el) el.addEventListener('click',function(e){if(e.target===this)this.style.display='none';});
    });

    /* Balance Adjustor */
    function cfpOpenAdj(uid,bal,sav,name){
        var sel=document.getElementById('adj-user-select');
        for(var i=0;i<sel.options.length;i++){if(sel.options[i].value==uid){sel.selectedIndex=i;break;}}
        document.getElementById('adj-user-info').style.display='';
        document.getElementById('adj-bal-display').textContent=parseInt(bal).toLocaleString();
        document.getElementById('adj-sav-display').textContent=parseInt(sav).toLocaleString();
        document.getElementById('cfp-adj-modal').style.display='flex';
        cfpAdjPreview();
    }
    function cfpUpdateUserInfo(sel){
        var opt=sel.options[sel.selectedIndex];
        if(!opt.value){document.getElementById('adj-user-info').style.display='none';return;}
        document.getElementById('adj-user-info').style.display='';
        document.getElementById('adj-bal-display').textContent=parseInt(opt.dataset.balance||0).toLocaleString();
        document.getElementById('adj-sav-display').textContent=parseInt(opt.dataset.savings||0).toLocaleString();
        cfpAdjPreview();
    }
    function cfpAdjPreview(){
        var sel=document.getElementById('adj-user-select');
        var opt=sel.options[sel.selectedIndex];
        var type=document.getElementById('adj-type').value;
        var target=document.getElementById('adj-target').value;
        var amount=parseInt(document.getElementById('adj-amount').value)||0;
        var prev=document.getElementById('adj-preview');
        if(!opt||!opt.value||!amount){prev.style.display='none';return;}
        var cur=target==='savings'?parseInt(opt.dataset.savings||0):parseInt(opt.dataset.balance||0);
        var after=(type==='credit')?cur+amount:cur-amount;
        var isC=type==='credit';
        prev.style.cssText='display:block;padding:9px 12px;border-radius:7px;font-size:.8rem;font-weight:600;text-align:center;background:'+(isC?'#052e16':'#2d0a0a')+';border:1px solid '+(isC?'#22c55e44':'#ef444433')+';color:'+(isC?'#22c55e':'#ef4444');
        prev.textContent=(isC?'+ ':'- ')+amount.toLocaleString()+' sat \u2192 new '+target+': '+after.toLocaleString()+' sat';
    }
    function cfpConfirmAdj(){
        var sel=document.getElementById('adj-user-select');
        var opt=sel.options[sel.selectedIndex];
        var amount=parseInt(document.getElementById('adj-amount').value)||0;
        if(!opt||!opt.value){alert('Select a user.');return false;}
        if(!amount){alert('Enter an amount.');return false;}
        var type=document.getElementById('adj-type').value;
        var target=document.getElementById('adj-target').value;
        return confirm((type==='credit'?'CREDIT':'DEBIT')+' '+amount.toLocaleString()+' sat '+(type==='credit'?'to':'from')+' '+opt.dataset.name+"'s "+target+'?\n\nThis will be logged.');
    }
    </script>
    <?php
}


/* ============================================================
   ADMIN: BALANCE ADJUSTOR
   ============================================================ */
function cfp_admin_balance_adjust() {
    global $wpdb;
    $saved = false; $error = ''; $adjusted_user = null;

    // Handle form submission
    if ( isset($_POST['cfp_adjust_submit']) && check_admin_referer('cfp_balance_adjust') ) {
        $uid    = intval($_POST['user_id']);
        $amount = intval($_POST['amount']);
        $type   = sanitize_text_field($_POST['adjust_type']); // credit or debit
        $reason = sanitize_text_field($_POST['reason']);
        $target = sanitize_text_field($_POST['target_wallet']); // balance or savings

        if ( $uid <= 0 || $amount <= 0 ) {
            $error = 'Please select a valid user and enter an amount greater than 0.';
        } else {
            $user = $wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_USERS." WHERE id=%d", $uid));
            if ( ! $user ) {
                $error = 'User not found.';
            } else {
                $signed_amount = ($type === 'credit') ? abs($amount) : -abs($amount);
                $col = ($target === 'savings') ? 'savings_sat' : 'balance_sat';

                if ($type === 'debit') {
                    $current = ($target === 'savings') ? $user->savings_sat : $user->balance_sat;
                    if ($current < $amount) {
                        $error = "Insufficient {$target} balance. User only has ".number_format($current)." sat.";
                    }
                }

                if (!$error) {
                    if ($type === 'credit') {
                        $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET {$col}={$col}+%d WHERE id=%d", $amount, $uid));
                    } else {
                        $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET {$col}={$col}-%d WHERE id=%d", $amount, $uid));
                    }
                    $desc = "Admin {$type} ({$target}): " . ($reason ?: 'Manual adjustment');
                    $wpdb->insert(CFP_TABLE_TRANSACTIONS, [
                        'user_id'     => $uid,
                        'type'        => 'admin_' . $type,
                        'amount_sat'  => $signed_amount,
                        'description' => $desc . ' [by ' . wp_get_current_user()->user_login . ']',
                    ]);
                    $saved = true;
                    $adjusted_user = $wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_USERS." WHERE id=%d", $uid));
                }
            }
        }
    }

    // Pre-fill user if coming from Users page
    $prefill_uid = intval($_GET['uid'] ?? 0);
    $prefill_user = $prefill_uid ? $wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_USERS." WHERE id=%d", $prefill_uid)) : null;

    // Recent adjustments audit log
    $audit = $wpdb->get_results("
        SELECT t.*, u.username, u.email
        FROM ".CFP_TABLE_TRANSACTIONS." t
        LEFT JOIN ".CFP_TABLE_USERS." u ON t.user_id=u.id
        WHERE t.type IN ('admin_credit','admin_debit')
        ORDER BY t.created_at DESC LIMIT 50
    ");

    // User search AJAX
    $ajax_url = admin_url('admin-ajax.php');
    $search_nonce = wp_create_nonce('cfp_user_search');
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">⚡ CFP</span>
            <h1>💰 Balance Adjustor</h1>
            <a href="<?=admin_url('admin.php?page=cfp-users')?>" class="cfp-btn cfp-btn-ghost" style="margin-left:auto">← Back to Users</a>
        </div>

        <?php if($saved): ?>
        <div class="cfp-notice success">
            ✅ Balance adjusted successfully for <strong><?=esc_html($adjusted_user->username)?></strong>. New balance: <strong><?=number_format($adjusted_user->balance_sat)?> sat</strong> · Savings: <strong><?=number_format($adjusted_user->savings_sat)?> sat</strong>
        </div>
        <?php endif; ?>
        <?php if($error): ?>
        <div class="cfp-notice error">❌ <?=esc_html($error)?></div>
        <?php endif; ?>

        <div class="cfp-2col">

            <!-- ADJUSTMENT FORM -->
            <div class="cfp-card">
                <h2>⚖️ Adjust User Balance</h2>
                <form method="post" id="cfp-adj-form">
                    <?php wp_nonce_field('cfp_balance_adjust'); ?>
                    <input type="hidden" name="user_id" id="adj-user-id" value="<?=$prefill_uid?>">

                    <!-- User search -->
                    <div class="cfp-field" style="margin-bottom:14px">
                        <label>Search User</label>
                        <div style="display:flex;gap:8px">
                            <input type="text" id="adj-search-input" placeholder="Email or username…"
                                value="<?=$prefill_user?esc_attr($prefill_user->email):''?>"
                                style="flex:1;background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 13px;border-radius:8px;font-size:.88rem;outline:none">
                            <button type="button" class="cfp-btn cfp-btn-ghost" onclick="cfpSearchUser()">🔍 Find</button>
                        </div>
                    </div>

                    <!-- User preview card -->
                    <div id="cfp-user-found" class="cfp-user-found" style="display:<?=$prefill_user?'block':'none'?>">
                        <?php if($prefill_user): ?>
                        <div style="display:flex;align-items:center;gap:12px">
                            <div style="width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,var(--g),var(--a));display:flex;align-items:center;justify-content:center;font-weight:900;font-size:1rem;color:#000;flex-shrink:0">
                                <?=esc_html(strtoupper(substr($prefill_user->username,0,1)))?>
                            </div>
                            <div style="flex:1">
                                <div style="font-weight:700;color:#fff;font-size:.95rem" id="adj-uname"><?=esc_html($prefill_user->username)?></div>
                                <div style="font-size:.75rem;color:var(--mt)" id="adj-uemail"><?=esc_html($prefill_user->email)?></div>
                            </div>
                            <div style="text-align:right">
                                <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt)">Balance</div>
                                <div style="font-size:1.2rem;font-weight:800;color:var(--g);font-family:monospace" id="adj-ubal"><?=number_format($prefill_user->balance_sat)?> sat</div>
                                <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt);margin-top:3px">Savings</div>
                                <div style="font-size:.92rem;font-weight:700;color:#a855f7;font-family:monospace" id="adj-usav"><?=number_format($prefill_user->savings_sat)?> sat</div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Credit / Debit toggle -->
                    <div class="cfp-field" style="margin-bottom:14px">
                        <label>Operation Type</label>
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:0;border-radius:8px;overflow:hidden;border:1px solid var(--br)">
                            <label style="display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;cursor:pointer;font-size:.88rem;font-weight:700;transition:background .15s" id="lbl-credit" onclick="cfpToggleType('credit')">
                                <input type="radio" name="adjust_type" value="credit" id="adj-credit" checked style="display:none"> ➕ CREDIT
                            </label>
                            <label style="display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;cursor:pointer;font-size:.88rem;font-weight:700;transition:background .15s" id="lbl-debit" onclick="cfpToggleType('debit')">
                                <input type="radio" name="adjust_type" value="debit" id="adj-debit" style="display:none"> ➖ DEBIT
                            </label>
                        </div>
                    </div>

                    <!-- Target wallet -->
                    <div class="cfp-field" style="margin-bottom:14px">
                        <label>Target Wallet</label>
                        <select name="target_wallet" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 13px;border-radius:8px;font-size:.88rem">
                            <option value="balance">💰 Main Balance</option>
                            <option value="savings">🏦 Savings Account</option>
                        </select>
                    </div>

                    <!-- Amount -->
                    <div class="cfp-field" style="margin-bottom:14px">
                        <label>Amount (Satoshis)</label>
                        <div style="position:relative">
                            <input type="number" name="amount" id="adj-amount" min="1" placeholder="Enter amount in satoshis" required
                                style="width:100%;background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 13px;border-radius:8px;font-size:.88rem;outline:none;padding-right:60px">
                            <span style="position:absolute;right:13px;top:50%;transform:translateY(-50%);font-size:.75rem;color:var(--mt);pointer-events:none">sat</span>
                        </div>
                        <!-- Quick amounts -->
                        <div style="display:flex;flex-wrap:wrap;gap:6px;margin-top:8px">
                            <?php foreach([100,500,1000,5000,10000,50000,100000,1000000] as $q): ?>
                            <button type="button" onclick="document.getElementById('adj-amount').value=<?=$q?>" class="cfp-btn cfp-btn-ghost cfp-btn-sm"><?=number_format($q)?></button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Reason -->
                    <div class="cfp-field" style="margin-bottom:20px">
                        <label>Reason / Note</label>
                        <input type="text" name="reason" placeholder="e.g. Bonus reward, Compensation, Contest prize…"
                            style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 13px;border-radius:8px;font-size:.88rem;outline:none">
                        <span style="font-size:.72rem;color:var(--mt)">Saved in transaction log with admin username</span>
                        <!-- Reason presets -->
                        <div style="display:flex;flex-wrap:wrap;gap:5px;margin-top:7px">
                            <?php foreach(['Bonus reward','Contest prize','Compensation','Referral fix','Support credit','Chargeback','Penalty','Test account'] as $r): ?>
                            <button type="button" onclick="document.querySelector('[name=reason]').value='<?=$r?>'" class="cfp-btn cfp-btn-ghost cfp-btn-sm" style="font-size:.72rem"><?=$r?></button>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <button type="submit" name="cfp_adjust_submit" id="adj-submit-btn" class="cfp-btn cfp-btn-gold" style="width:100%;padding:14px;font-size:1rem;justify-content:center" disabled>
                        💰 Apply Balance Adjustment
                    </button>
                </form>
            </div>

            <!-- STATS PANEL -->
            <div>
                <div class="cfp-card" style="margin-bottom:22px">
                    <h2>📊 Quick Stats</h2>
                    <?php
                    $total_credits = $wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_TRANSACTIONS." WHERE type='admin_credit'");
                    $total_debits  = abs($wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_TRANSACTIONS." WHERE type='admin_debit'"));
                    $adj_count     = $wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_TRANSACTIONS." WHERE type IN ('admin_credit','admin_debit')");
                    $adj_today     = $wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_TRANSACTIONS." WHERE type IN ('admin_credit','admin_debit') AND DATE(created_at)=CURDATE()");
                    ?>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                        <div style="background:#052e16;border:1px solid #22c55e22;border-radius:8px;padding:14px;text-align:center">
                            <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#22c55e99;margin-bottom:5px">Total Credited</div>
                            <div style="font-size:1.4rem;font-weight:800;color:var(--gr);font-family:monospace">+<?=number_format($total_credits)?></div>
                            <div style="font-size:.72rem;color:#22c55e66">satoshis</div>
                        </div>
                        <div style="background:#2d0a0a;border:1px solid #ef444422;border-radius:8px;padding:14px;text-align:center">
                            <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#ef444499;margin-bottom:5px">Total Debited</div>
                            <div style="font-size:1.4rem;font-weight:800;color:var(--rd);font-family:monospace">-<?=number_format($total_debits)?></div>
                            <div style="font-size:.72rem;color:#ef444466">satoshis</div>
                        </div>
                        <div style="background:#111;border:1px solid var(--br);border-radius:8px;padding:14px;text-align:center">
                            <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt);margin-bottom:5px">Total Adjustments</div>
                            <div style="font-size:1.6rem;font-weight:800;color:#fff"><?=number_format($adj_count)?></div>
                        </div>
                        <div style="background:#111;border:1px solid var(--br);border-radius:8px;padding:14px;text-align:center">
                            <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt);margin-bottom:5px">Adjustments Today</div>
                            <div style="font-size:1.6rem;font-weight:800;color:#fff"><?=number_format($adj_today)?></div>
                        </div>
                    </div>
                </div>

                <div class="cfp-card">
                    <h2>⚡ Bulk Adjust</h2>
                    <p style="font-size:.83rem;color:var(--mt);margin-bottom:14px">Credit or debit all users, or users matching a filter.</p>
                    <form method="post"><?php wp_nonce_field('cfp_balance_adjust'); ?>
                    <input type="hidden" name="user_id" value="0">
                    <div style="display:flex;flex-direction:column;gap:10px">
                        <select name="bulk_target" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 13px;border-radius:8px;font-size:.85rem">
                            <option value="">— Select Bulk Target —</option>
                            <option value="all_active">All Active Users</option>
                            <option value="all_users">All Users (incl. banned)</option>
                            <option value="top10">Top 10 Earners</option>
                            <option value="zero_balance">Users with 0 Balance</option>
                        </select>
                        <input type="number" name="bulk_amount" placeholder="Amount per user (sat)" min="1" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 13px;border-radius:8px;font-size:.85rem">
                        <select name="bulk_type" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 13px;border-radius:8px;font-size:.85rem">
                            <option value="credit">➕ Credit All</option>
                            <option value="debit">➖ Debit All</option>
                        </select>
                        <input type="text" name="reason" value="Bulk admin adjustment" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 13px;border-radius:8px;font-size:.85rem">
                        <button type="submit" name="cfp_bulk_adjust" class="cfp-btn cfp-btn-ghost" style="justify-content:center" onclick="return confirm('Apply bulk adjustment to all matching users?')">
                            ⚡ Run Bulk Adjustment
                        </button>
                    </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- AUDIT LOG -->
        <div class="cfp-card">
            <h2>📋 Adjustment Audit Log <span style="font-size:.78rem;font-weight:400;color:var(--mt)">(last 50 entries)</span></h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead><tr><th>Date</th><th>Admin</th><th>User</th><th>Type</th><th>Wallet</th><th>Amount</th><th>Reason</th></tr></thead>
                    <tbody>
                    <?php foreach($audit as $a):
                        $is_credit = $a->type === 'admin_credit';
                        $desc = $a->description;
                        // Parse wallet from description
                        $wallet = strpos($desc,'savings') !== false ? 'Savings' : 'Balance';
                        // Parse admin from description
                        preg_match('/\[by (.+?)\]/', $desc, $admin_match);
                        $admin_name = $admin_match[1] ?? 'Admin';
                        $reason_clean = preg_replace('/Admin (credit|debit) \((balance|savings)\):\s*/', '', $desc);
                        $reason_clean = preg_replace('/\s*\[by .+?\]/', '', $reason_clean);
                    ?>
                    <tr>
                        <td style="font-size:.78rem;color:var(--mt)"><?=date('M j, Y H:i', strtotime($a->created_at))?></td>
                        <td style="font-size:.8rem;color:#a855f7"><?=esc_html($admin_name)?></td>
                        <td><strong><?=esc_html($a->username)?></strong><br><span style="font-size:.72rem;color:var(--mt)"><?=esc_html($a->email)?></span></td>
                        <td>
                            <?php if($is_credit): ?>
                                <span class="cfp-badge approved">+ Credit</span>
                            <?php else: ?>
                                <span class="cfp-badge rejected">- Debit</span>
                            <?php endif; ?>
                        </td>
                        <td style="font-size:.8rem;color:var(--mt)"><?=$wallet?></td>
                        <td style="font-weight:700;font-family:monospace;color:<?=$is_credit?'var(--gr)':'var(--rd)'?>">
                            <?=$is_credit?'+':'-'?><?=number_format(abs($a->amount_sat))?> sat
                        </td>
                        <td style="font-size:.8rem;color:var(--mt);max-width:220px"><?=esc_html($reason_clean)?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($audit)): ?>
                    <tr><td colspan="7" style="text-align:center;color:var(--mt);padding:28px">No adjustments made yet</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
    // Type toggle colours
    function cfpToggleType(t) {
        const lc=document.getElementById('lbl-credit');
        const ld=document.getElementById('lbl-debit');
        const btn=document.getElementById('adj-submit-btn');
        if(t==='credit'){
            lc.style.cssText='display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;cursor:pointer;font-size:.88rem;font-weight:700;background:#052e16;color:#22c55e;';
            ld.style.cssText='display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;cursor:pointer;font-size:.88rem;font-weight:700;background:#111;color:#555;';
            btn.style.background='#22c55e';
            document.getElementById('adj-credit').checked=true;
        } else {
            ld.style.cssText='display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;cursor:pointer;font-size:.88rem;font-weight:700;background:#2d0a0a;color:#ef4444;';
            lc.style.cssText='display:flex;align-items:center;justify-content:center;gap:7px;padding:12px;cursor:pointer;font-size:.88rem;font-weight:700;background:#111;color:#555;';
            btn.style.background='#ef4444';
            document.getElementById('adj-debit').checked=true;
        }
    }
    // Init credit style
    cfpToggleType('credit');

    // User search
    async function cfpSearchUser() {
        const q = document.getElementById('adj-search-input').value.trim();
        if(!q) return;
        const fd = new FormData();
        fd.append('action','cfp_admin_user_search');
        fd.append('nonce','<?=wp_create_nonce('cfp_user_search')?>');
        fd.append('q', q);
        const r = await fetch('<?=$ajax_url?>',{method:'POST',body:fd});
        const d = await r.json();
        if(d.success && d.data.user) {
            const u=d.data.user;
            document.getElementById('adj-user-id').value=u.id;
            document.getElementById('cfp-user-found').style.display='block';
            document.getElementById('cfp-user-found').innerHTML=`
                <div style="display:flex;align-items:center;gap:12px">
                    <div style="width:42px;height:42px;border-radius:50%;background:linear-gradient(135deg,var(--g),var(--a));display:flex;align-items:center;justify-content:center;font-weight:900;font-size:1rem;color:#000;flex-shrink:0">${u.username.charAt(0).toUpperCase()}</div>
                    <div style="flex:1">
                        <div style="font-weight:700;color:#fff;font-size:.95rem">${u.username}</div>
                        <div style="font-size:.75rem;color:var(--mt)">${u.email} · ID #${u.id}</div>
                        <div style="font-size:.72rem;color:var(--mt);margin-top:2px">${u.total_claims} claims · ${u.is_banned?'<span style="color:var(--rd)">Banned</span>':'<span style="color:var(--gr)">Active</span>'}</div>
                    </div>
                    <div style="text-align:right">
                        <div style="font-size:.62rem;text-transform:uppercase;letter-spacing:1px;color:var(--mt)">Balance</div>
                        <div style="font-size:1.2rem;font-weight:800;color:var(--g);font-family:monospace">${parseInt(u.balance_sat).toLocaleString()} sat</div>
                        <div style="font-size:.62rem;text-transform:uppercase;letter-spacing:1px;color:var(--mt);margin-top:3px">Savings</div>
                        <div style="font-size:.9rem;font-weight:700;color:#a855f7;font-family:monospace">${parseInt(u.savings_sat).toLocaleString()} sat</div>
                    </div>
                </div>`;
            document.getElementById('adj-submit-btn').disabled=false;
        } else {
            document.getElementById('cfp-user-found').style.display='block';
            document.getElementById('cfp-user-found').innerHTML='<div style="color:var(--rd);font-size:.85rem">❌ No user found matching "'+q+'"</div>';
            document.getElementById('adj-user-id').value='';
            document.getElementById('adj-submit-btn').disabled=true;
        }
    }
    document.getElementById('adj-search-input').addEventListener('keypress',function(e){if(e.key==='Enter'){e.preventDefault();cfpSearchUser();}});
    // If prefill user exists, enable button
    <?php if($prefill_uid): ?>document.getElementById('adj-submit-btn').disabled=false;<?php endif; ?>
    </script>
    <?php
}

// AJAX: admin user search
add_action('wp_ajax_cfp_admin_user_search', 'cfp_ajax_admin_user_search');
function cfp_ajax_admin_user_search() {
    if(!current_user_can('manage_options')) wp_send_json_error();
    check_ajax_referer('cfp_user_search','nonce');
    $q = sanitize_text_field($_POST['q'] ?? '');
    global $wpdb;
    $user = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM ".CFP_TABLE_USERS." WHERE email=%s OR username=%s OR id=%d LIMIT 1",
        $q, $q, intval($q)
    ));
    if($user) wp_send_json_success(['user'=>$user]);
    else wp_send_json_error(['msg'=>'Not found']);
}

/* ============================================================
   ADMIN: BULK ADJUST HANDLER
   ============================================================ */
add_action('admin_init', 'cfp_handle_bulk_adjust');
function cfp_handle_bulk_adjust() {
    if(!isset($_POST['cfp_bulk_adjust']) || !current_user_can('manage_options')) return;
    check_admin_referer('cfp_balance_adjust');
    global $wpdb;
    $target  = sanitize_text_field($_POST['bulk_target']??'');
    $amount  = intval($_POST['bulk_amount']??0);
    $type    = sanitize_text_field($_POST['bulk_type']??'credit');
    $reason  = sanitize_text_field($_POST['reason']??'Bulk admin adjustment');
    if(!$target || $amount <= 0) return;

    $where = '1=1';
    if($target==='all_active')    $where='is_banned=0';
    if($target==='top10')         $where='is_banned=0 ORDER BY total_earned DESC LIMIT 10';
    if($target==='zero_balance')  $where='balance_sat=0';

    $users = $wpdb->get_results("SELECT id FROM ".CFP_TABLE_USERS." WHERE $where");
    $admin = wp_get_current_user()->user_login;
    foreach($users as $u) {
        if($type==='credit') {
            $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$amount,$u->id));
            $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$u->id,'type'=>'admin_credit','amount_sat'=>$amount,'description'=>"Admin credit (balance): $reason [by $admin]"]);
        } else {
            $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=GREATEST(0,balance_sat-%d) WHERE id=%d",$amount,$u->id));
            $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$u->id,'type'=>'admin_debit','amount_sat'=>-$amount,'description'=>"Admin debit (balance): $reason [by $admin]"]);
        }
    }
    wp_redirect(admin_url('admin.php?page=cfp-balance-adjust&bulk_done='.count($users)));
    exit;
}

/* ============================================================
   ADMIN: EXPORT USERS CSV
   ============================================================ */
add_action('admin_post_cfp_export_users_csv', 'cfp_export_users_csv');
function cfp_export_users_csv() {
    if(!current_user_can('manage_options') || !check_admin_referer('cfp_export_users')) {
        wp_die('Unauthorized');
    }
    
    global $wpdb;
    $filter = sanitize_text_field($_POST['export_filter'] ?? 'all');
    $include = sanitize_text_field($_POST['export_include'] ?? 'basic');
    
    $where = '1=1';
    if($filter === 'active') $where = 'is_banned=0';
    if($filter === 'banned') $where = 'is_banned=1';
    if($filter === 'with_balance') $where = 'balance_sat > 0';
    
    if($include === 'basic') {
        $users = $wpdb->get_results("
            SELECT id, username, email, balance_sat, savings_sat, total_claims, total_earned, created_at, is_banned
            FROM " . CFP_TABLE_USERS . "
            WHERE $where
            ORDER BY id DESC
        ");
    } else {
        $users = $wpdb->get_results("
            SELECT * FROM " . CFP_TABLE_USERS . "
            WHERE $where
            ORDER BY id DESC
        ");
    }
    
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="users_export_' . date('Y-m-d') . '.csv"');
    header('Cache-Control: no-cache, no-store, must-revalidate');
    
    $output = fopen('php://output', 'w');
    
    // Header row
    if($include === 'basic') {
        fputcsv($output, ['ID', 'Username', 'Email', 'Balance (sat)', 'Savings (sat)', 'Total Claims', 'Total Earned', 'Joined', 'Status']);
    } else {
        fputcsv($output, ['ID', 'Username', 'Email', 'Password Hash', 'Balance (sat)', 'Savings (sat)', 'Total Claims', 'Total Earned', 'Referrer ID', 'Ref Code', 'Lottery Tickets', 'Golden Tickets', 'Last Claim', 'Created', 'Is Banned', 'Email Verified']);
    }
    
    // Data rows
    foreach($users as $u) {
        if($include === 'basic') {
            fputcsv($output, [
                $u->id,
                $u->username,
                $u->email,
                $u->balance_sat,
                $u->savings_sat,
                $u->total_claims,
                $u->total_earned,
                $u->created_at,
                $u->is_banned ? 'Banned' : 'Active'
            ]);
        } else {
            fputcsv($output, [
                $u->id,
                $u->username,
                $u->email,
                '[HIDDEN]',
                $u->balance_sat,
                $u->savings_sat,
                $u->total_claims,
                $u->total_earned,
                $u->referrer_id,
                $u->ref_code,
                $u->lottery_tickets,
                $u->golden_tickets,
                $u->last_claim,
                $u->created_at,
                $u->is_banned,
                $u->email_verified
            ]);
        }
    }
    
    fclose($output);
    exit;
}

/* ============================================================
   ADMIN: CRYPTOCURRENCY CODE EDITOR

*/
