<?php
/**
 * Admin page: Jackpot Manager - Manage game jackpot pools
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Jackpot Management
   ============================================================ */
add_action('wp_ajax_cfp_jackpot_data', 'cfp_ajax_jackpot_data');
function cfp_ajax_jackpot_data() {
    check_ajax_referer('cfp_jackpot_nonce', 'nonce');
    
    global $wpdb;
    $action = sanitize_text_field($_POST['sub_action'] ?? 'list');
    
    if($action === 'list') {
        $jackpots = $wpdb->get_results("
            SELECT * FROM {$wpdb->prefix}cfp_jackpots ORDER BY game_type ASC
        ");
        wp_send_json_success(['jackpots' => $jackpots]);
    }
    
    if($action === 'save') {
        $id = intval($_POST['id'] ?? 0);
        $data = [
            'game_type' => sanitize_text_field($_POST['game_type']),
            'current_amount' => intval($_POST['current_amount']),
            'min_contribution' => intval($_POST['min_contribution']),
            'contribution_percent' => floatval($_POST['contribution_percent']),
            'min_bet_for_jackpot' => intval($_POST['min_bet_for_jackpot']),
            'win_chance' => floatval($_POST['win_chance']),
            'max_win' => intval($_POST['max_win']),
            'is_active' => isset($_POST['is_active']) ? 1 : 0,
            'last_winner_id' => intval($_POST['last_winner_id'] ?? 0),
            'last_win_amount' => intval($_POST['last_win_amount'] ?? 0),
            'last_win_date' => sanitize_text_field($_POST['last_win_date'] ?? null)
        ];
        
        if($id > 0) {
            $wpdb->update($wpdb->prefix . 'cfp_jackpots', $data, ['id' => $id]);
        } else {
            $wpdb->insert($wpdb->prefix . 'cfp_jackpots', $data);
            $id = $wpdb->insert_id;
        }
        
        wp_send_json_success(['msg' => 'Jackpot saved', 'id' => $id]);
    }
    
    if($action === 'reset') {
        $id = intval($_POST['id'] ?? 0);
        $amount = intval($_POST['reset_amount'] ?? 1000000);
        $wpdb->update($wpdb->prefix . 'cfp_jackpots', ['current_amount' => $amount], ['id' => $id]);
        wp_send_json_success(['msg' => 'Jackpot reset']);
    }
    
    if($action === 'manual_win') {
        $id = intval($_POST['id'] ?? 0);
        $user_id = intval($_POST['user_id'] ?? 0);
        $amount = intval($_POST['amount'] ?? 0);
        
        if($user_id > 0 && $amount > 0) {
            $wpdb->update($wpdb->prefix . 'cfp_jackpots', [
                'current_amount' => 0,
                'last_winner_id' => $user_id,
                'last_win_amount' => $amount,
                'last_win_date' => current_time('mysql')
            ], ['id' => $id]);
            
            $wpdb->query($wpdb->prepare(
                "UPDATE " . CFP_TABLE_USERS . " SET balance_sat = balance_sat + %d WHERE id = %d",
                $amount, $user_id
            ));
            
            wp_send_json_success(['msg' => 'Manual win credited']);
        } else {
            wp_send_json_error(['msg' => 'Invalid user or amount']);
        }
    }
}

/* ============================================================
   ADMIN: JACKPOT MANAGER PAGE
   ============================================================ */
function cfp_admin_jackpot_manager() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_jackpot_nonce');
    
    $jackpots = $wpdb->get_results("
        SELECT * FROM {$wpdb->prefix}cfp_jackpots ORDER BY game_type ASC
    ");
    
    $total_jackpot = 0;
    foreach($jackpots as $j) {
        $total_jackpot += $j->current_amount;
    }
    
    $recent_wins = $wpdb->get_results("
        SELECT j.game_type, j.last_winner_id, j.last_win_amount, j.last_win_date, u.username
        FROM {$wpdb->prefix}cfp_jackpots j
        LEFT JOIN " . CFP_TABLE_USERS . " u ON j.last_winner_id = u.id
        WHERE j.last_win_amount > 0
        ORDER BY j.last_win_date DESC LIMIT 10
    ");
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">💰</span>
            <h1>💰 Jackpot Manager</h1>
            <button onclick="cfpShowJackpotModal()" class="cfp-btn cfp-btn-gold" style="margin-left:auto">➕ Add Jackpot</button>
        </div>

        <!-- OVERVIEW STATS -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card green">
                <div class="label">💰 Total Jackpot Pool</div>
                <div class="value"><?=number_format($total_jackpot)?></div>
                <div class="sub">satoshis</div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">🎮 Active Jackpots</div>
                <div class="value"><?=count(array_filter($jackpots, function($j) { return $j->is_active; }))?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">🏆 Total Paid Out</div>
                <div class="value"><?=number_format(array_sum(array_column($jackpots, 'last_win_amount')))?></div>
                <div class="sub">all time</div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">🎯 Games with Jackpot</div>
                <div class="value"><?=count($jackpots)?></div>
            </div>
        </div>

        <!-- JACKPOTS TABLE -->
        <div class="cfp-card">
            <h2>🎰 Game Jackpots</h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>Game</th>
                            <th>Current Amount</th>
                            <th>Contribution %</th>
                            <th>Min Bet</th>
                            <th>Win Chance</th>
                            <th>Max Win</th>
                            <th>Status</th>
                            <th>Last Winner</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach($jackpots as $j): 
                        $game_name = ucfirst($j->game_type);
                        $game_icons = ['slots' => '🎰', 'hilo' => '🎲', 'dice' => '🎲', 'wheel' => '🎡', 'crash' => '📈', 'blackjack' => '🃏'];
                        $icon = $game_icons[$j->game_type] ?? '🎮';
                    ?>
                        <tr>
                            <td><span style="font-size:1.2rem"><?=$icon?></span> <strong><?=$game_name?></strong></td>
                            <td style="color:#f7931a;font-weight:700;font-size:1.1rem"><?=number_format($j->current_amount)?> sat</td>
                            <td><?=$j->contribution_percent?>%</td>
                            <td><?=number_format($j->min_bet_for_jackpot)?> sat</td>
                            <td><?=$j->win_chance?>%</td>
                            <td><?=number_format($j->max_win)?> sat</td>
                            <td><span class="cfp-badge <?=$j->is_active ? 'active' : 'rejected'?>"><?=$j->is_active ? 'Active' : 'Disabled'?></span></td>
                            <td>
                                <?php if($j->last_winner_id): ?>
                                <span style="color:#888;font-size:.85rem">User #<?=$j->last_winner_id?></span><br>
                                <span style="color:#22c55e"><?=number_format($j->last_win_amount)?> sat</span>
                                <?php else: ?>
                                <span style="color:#555">No winner yet</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button onclick="cfpEditJackpot(<?=esc_html(json_encode($j))?>)" class="cfp-btn cfp-btn-sm cfp-btn-ghost">Edit</button>
                                <button onclick="cfpResetJackpot(<?=$j->id?>)" class="cfp-btn cfp-btn-sm cfp-btn-ghost">Reset</button>
                                <button onclick="cfpManualWin(<?=$j->id?>)" class="cfp-btn cfp-btn-sm cfp-btn-green">Manual Win</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($jackpots)): ?>
                        <tr><td colspan="9" style="text-align:center;padding:40px;color:#555">No jackpots configured. Click "Add Jackpot" to create one.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- RECENT WINS -->
        <div class="cfp-card" style="margin-top:24px">
            <h2>🏆 Recent Jackpot Wins</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px">
                <?php foreach($recent_wins as $w): ?>
                <div style="background:#0d0d0d;padding:16px;border-radius:10px;border-left:3px solid #f7931a">
                    <div style="display:flex;justify-content:space-between;align-items:start;margin-bottom:8px">
                        <span style="font-weight:700;color:#fff"><?=ucfirst($w->game_type)?></span>
                        <span style="color:#555;font-size:.75rem"><?=human_time_diff(strtotime($w->last_win_date), current_time('timestamp'))?> ago</span>
                    </div>
                    <div style="font-size:1.3rem;font-weight:800;color:#22c55e"><?=number_format($w->last_win_amount)?> sat</div>
                    <div style="font-size:.8rem;color:#888;margin-top:4px">Won by <?=esc_html($w->username ?? 'User #'.$w->last_winner_id)?></div>
                </div>
                <?php endforeach; ?>
                <?php if(empty($recent_wins)): ?>
                <div style="grid-column:1/-1;text-align:center;padding:20px;color:#555">No jackpot wins recorded yet</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- JACKPOT CONFIGURATION INFO -->
        <div class="cfp-card" style="margin-top:24px">
            <h2>⚙️ How Jackpots Work</h2>
            <div style="display:grid;grid-template-columns:repeat(2, 1fr);gap:24px">
                <div>
                    <h3 style="color:#f7931a;margin-bottom:12px;font-size:.95rem">🎯 Contribution System</h3>
                    <p style="color:#888;font-size:.85rem;line-height:1.6">
                        When players bet on games with jackpots, a percentage of each bet is automatically added to the jackpot pool. 
                        This percentage is configurable per game (e.g., 1% of each bet goes to the jackpot).
                    </p>
                </div>
                <div>
                    <h3 style="color:#22c55e;margin-bottom:12px;font-size:.95rem">🎲 Win Mechanics</h3>
                    <p style="color:#888;font-size:.85rem;line-height:1.6">
                        Each bet that meets the minimum bet threshold has a chance to trigger the jackpot win. 
                        The win chance is configurable (e.g., 0.1% chance per qualifying bet). 
                        When won, the jackpot resets to the minimum amount.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- JACKPOT MODAL -->
    <div id="cfp-jackpot-modal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.8);z-index:9999;align-items:center;justify-content:center">
        <div style="background:#161616;border:1px solid #2a2a2a;border-radius:16px;padding:28px;max-width:600px;width:90%;max-height:90vh;overflow-y:auto">
            <h2 id="cfp-jackpot-modal-title" style="color:#fff;margin-bottom:20px;font-size:1.3rem">Add Jackpot</h2>
            <form id="cfp-jackpot-form">
                <input type="hidden" id="cfp-jackpot-id" value="0">
                <div class="cfp-field">
                    <label>Game Type</label>
                    <select id="cfp-jackpot-game">
                        <option value="slots">Slots</option>
                        <option value="hilo">Hi-Lo</option>
                        <option value="dice">Dice</option>
                        <option value="wheel">Wheel</option>
                        <option value="crash">Crash</option>
                        <option value="blackjack">Blackjack</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Initial Amount (satoshis)</label>
                    <input type="number" id="cfp-jackpot-amount" value="1000000" min="0">
                </div>
                <div class="cfp-field">
                    <label>Contribution % per bet</label>
                    <input type="number" id="cfp-jackpot-contrib" value="1" min="0.1" max="100" step="0.1">
                </div>
                <div class="cfp-field">
                    <label>Min Bet for Jackpot Eligibility (satoshis)</label>
                    <input type="number" id="cfp-jackpot-min-bet" value="100" min="1">
                </div>
                <div class="cfp-field">
                    <label>Win Chance %</label>
                    <input type="number" id="cfp-jackpot-chance" value="0.1" min="0.001" max="100" step="0.001">
                </div>
                <div class="cfp-field">
                    <label>Max Win Amount (satoshis)</label>
                    <input type="number" id="cfp-jackpot-max" value="10000000" min="1">
                </div>
                <div class="cfp-field">
                    <label>
                        <input type="checkbox" id="cfp-jackpot-active" checked> Active
                    </label>
                </div>
                <div style="display:flex;gap:12px;margin-top:20px">
                    <button type="submit" class="cfp-btn cfp-btn-gold">Save Jackpot</button>
                    <button type="button" onclick="cfpCloseJackpotModal()" class="cfp-btn cfp-btn-ghost">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        cfpLoadJackpots();
    });

    function cfpLoadJackpots() {
        // Jackpots are loaded directly from PHP
    }

    function cfpShowJackpotModal() {
        document.getElementById('cfp-jackpot-modal-title').textContent = 'Add Jackpot';
        document.getElementById('cfp-jackpot-id').value = '0';
        document.getElementById('cfp-jackpot-form').reset();
        document.getElementById('cfp-jackpot-modal').style.display = 'flex';
    }

    function cfpCloseJackpotModal() {
        document.getElementById('cfp-jackpot-modal').style.display = 'none';
    }

    function cfpEditJackpot(jackpot) {
        document.getElementById('cfp-jackpot-modal-title').textContent = 'Edit Jackpot: ' + jackpot.game_type;
        document.getElementById('cfp-jackpot-id').value = jackpot.id;
        document.getElementById('cfp-jackpot-game').value = jackpot.game_type;
        document.getElementById('cfp-jackpot-amount').value = jackpot.current_amount;
        document.getElementById('cfp-jackpot-contrib').value = jackpot.contribution_percent;
        document.getElementById('cfp-jackpot-min-bet').value = jackpot.min_bet_for_jackpot;
        document.getElementById('cfp-jackpot-chance').value = jackpot.win_chance;
        document.getElementById('cfp-jackpot-max').value = jackpot.max_win;
        document.getElementById('cfp-jackpot-active').checked = jackpot.is_active == 1;
        document.getElementById('cfp-jackpot-modal').style.display = 'flex';
    }

    document.getElementById('cfp-jackpot-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const fd = new FormData();
        fd.append('action', 'cfp_jackpot_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'save');
        fd.append('id', document.getElementById('cfp-jackpot-id').value);
        fd.append('game_type', document.getElementById('cfp-jackpot-game').value);
        fd.append('current_amount', document.getElementById('cfp-jackpot-amount').value);
        fd.append('contribution_percent', document.getElementById('cfp-jackpot-contrib').value);
        fd.append('min_bet_for_jackpot', document.getElementById('cfp-jackpot-min-bet').value);
        fd.append('win_chance', document.getElementById('cfp-jackpot-chance').value);
        fd.append('max_win', document.getElementById('cfp-jackpot-max').value);
        fd.append('is_active', document.getElementById('cfp-jackpot-active').checked ? '1' : '0');

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    cfpCloseJackpotModal();
                    location.reload();
                }
            });
    });

    function cfpResetJackpot(id) {
        const amount = prompt('Enter reset amount (satoshis):', '1000000');
        if(!amount) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_jackpot_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'reset');
        fd.append('id', id);
        fd.append('reset_amount', amount);
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(() => location.reload());
    }

    function cfpManualWin(id) {
        const userId = prompt('Enter User ID to credit:');
        if(!userId) return;
        const amount = prompt('Enter win amount (satoshis):');
        if(!amount) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_jackpot_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'manual_win');
        fd.append('id', id);
        fd.append('user_id', userId);
        fd.append('amount', amount);
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    alert('Manual win credited successfully!');
                    location.reload();
                } else {
                    alert('Error: ' + d.data.msg);
                }
            });
    }
    </script>
    <?php
}