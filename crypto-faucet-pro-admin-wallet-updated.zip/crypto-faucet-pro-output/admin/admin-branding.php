<?php
/**
 * Admin page: Custom Branding & White-Label
 * Part of Crypto Faucet Pro plugin.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_branding() {
    $notice = '';

    if ( isset($_POST['cfp_save_branding']) && check_admin_referer('cfp_branding') ) {
        $fields = [
            'branding_site_name',
            'branding_tagline',
            'branding_logo_url',
            'branding_favicon_url',
            'branding_primary_color',
            'branding_accent_color',
            'branding_button_color',
            'branding_footer_text',
            'branding_show_powered_by',
            'branding_custom_css',
            'branding_dark_mode_default',
            'branding_card_style',
            'branding_font_family',
            'branding_allow_user_themes',
        ];
        foreach ( $fields as $f ) {
            if ( isset($_POST[$f]) ) {
                cfp_update_setting($f, sanitize_text_field($_POST[$f]));
            }
        }
        
        if ( isset($_POST['branding_custom_js']) ) {
            cfp_update_setting('branding_custom_js', sanitize_textarea_field($_POST['branding_custom_js']));
        }
        
        $notice = "<div class='cfp-notice success'>✅ Branding settings saved!</div>";
    }

    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🎨</span>
            <h1>🎨 Custom Branding & White-Label</h1>
        </div>
        <?=$notice?>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px">
            <div class="cfp-stat-card">
                <div class="label">Site Name</div>
                <div class="value" style="font-size:1.2rem"><?=esc_html($gs('branding_site_name','Crypto Faucet Pro'))?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Primary Color</div>
                <div class="value" style="color:<?=$gs('branding_primary_color','#f7931a')?>"><?=$gs('branding_primary_color','#f7931a')?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Custom CSS</div>
                <div class="value"><?=!empty($gs('branding_custom_css','')) ? '✓ Enabled' : '✗ None'?></div>
            </div>
            <div class="cfp-stat-card <?=$gs('branding_show_powered_by','1') === '1' ? 'blue' : 'red'?>">
                <div class="label">Powered By</div>
                <div class="value"><?=$gs('branding_show_powered_by','1') === '1' ? 'Visible' : 'Hidden'?></div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field('cfp_branding'); ?>
            
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🏷️ Basic Information</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Site Name</label>
                        <input type="text" name="branding_site_name" value="<?=esc_attr($gs('branding_site_name','Crypto Faucet Pro'))?>" placeholder="My Faucet">
                    </div>
                    <div class="cfp-field">
                        <label>Tagline</label>
                        <input type="text" name="branding_tagline" value="<?=esc_attr($gs('branding_tagline','Free Bitcoin Faucet'))?>" placeholder="Free Bitcoin Every Hour">
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🖼️ Logo & Icons</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Logo URL</label>
                        <input type="url" name="branding_logo_url" value="<?=esc_attr($gs('branding_logo_url',''))?>" placeholder="https://example.com/logo.png">
                        <span class="hint">Recommended: 200x60px PNG with transparent background</span>
                    </div>
                    <div class="cfp-field">
                        <label>Favicon URL</label>
                        <input type="url" name="branding_favicon_url" value="<?=esc_attr($gs('branding_favicon_url',''))?>" placeholder="https://example.com/favicon.ico">
                        <span class="hint">16x16 or 32x32 ICO/PNG</span>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🎨 Color Scheme</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Primary Color</label>
                        <div style="display:flex;gap:10px;align-items:center">
                            <input type="color" name="branding_primary_color" value="<?=esc_attr($gs('branding_primary_color','#f7931a'))?>" style="width:50px;height:40px;padding:0;border:none">
                            <input type="text" value="<?=esc_attr($gs('branding_primary_color','#f7931a'))?>" style="width:100px;background:#111;border:1px solid #2a2a2a;padding:8px;border-radius:6px;color:#e8e8e8" onchange="this.previousElementSibling.value=this.value">
                        </div>
                    </div>
                    <div class="cfp-field">
                        <label>Accent Color</label>
                        <div style="display:flex;gap:10px;align-items:center">
                            <input type="color" name="branding_accent_color" value="<?=esc_attr($gs('branding_accent_color','#a855f7'))?>" style="width:50px;height:40px;padding:0;border:none">
                            <input type="text" value="<?=esc_attr($gs('branding_accent_color','#a855f7'))?>" style="width:100px;background:#111;border:1px solid #2a2a2a;padding:8px;border-radius:6px;color:#e8e8e8" onchange="this.previousElementSibling.value=this.value">
                        </div>
                    </div>
                    <div class="cfp-field">
                        <label>Button Color</label>
                        <div style="display:flex;gap:10px;align-items:center">
                            <input type="color" name="branding_button_color" value="<?=esc_attr($gs('branding_button_color','#22c55e'))?>" style="width:50px;height:40px;padding:0;border:none">
                            <input type="text" value="<?=esc_attr($gs('branding_button_color','#22c55e'))?>" style="width:100px;background:#111;border:1px solid #2a2a2a;padding:8px;border-radius:6px;color:#e8e8e8" onchange="this.previousElementSibling.value=this.value">
                        </div>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>📝 Content & Footer</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field" style="grid-column:1/-1">
                        <label>Footer Text</label>
                        <input type="text" name="branding_footer_text" value="<?=esc_attr($gs('branding_footer_text','© 2024 My Faucet. All rights reserved.'))?>" placeholder="© 2024 My Faucet. All rights reserved.">
                    </div>
                    <div class="cfp-field">
                        <label>Show "Powered By"</label>
                        <select name="branding_show_powered_by">
                            <option value="1" <?=selected($gs('branding_show_powered_by','1'),'1',false)?>>✅ Yes - show credit</option>
                            <option value="0" <?=selected($gs('branding_show_powered_by','1'),'0',false)?>>⏸ Hide - white-label</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Dark Mode Default</label>
                        <select name="branding_dark_mode_default">
                            <option value="1" <?=selected($gs('branding_dark_mode_default','1'),'1',false)?>>🌙 Dark (default)</option>
                            <option value="0" <?=selected($gs('branding_dark_mode_default','1'),'0',false)?>>☀️ Light (default)</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🔤 Typography & Style</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Font Family</label>
                        <select name="branding_font_family">
                            <option value="system-ui" <?=selected($gs('branding_font_family','system-ui'),'system-ui',false)?>>System Default (Segoe UI/San Francisco)</option>
                            <option value="'Inter', sans-serif" <?=selected($gs('branding_font_family','system-ui'),"'Inter', sans-serif",false)?>>Inter</option>
                            <option value="'Space Mono', monospace" <?=selected($gs('branding_font_family','system-ui'),"'Space Mono', monospace",false)?>>Space Mono</option>
                            <option value="'Syne', sans-serif" <?=selected($gs('branding_font_family','system-ui'),"'Syne', sans-serif",false)?>>Syne</option>
                            <option value="'Roboto', sans-serif" <?=selected($gs('branding_font_family','system-ui'),"'Roboto', sans-serif",false)?>>Roboto</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Card Style</label>
                        <select name="branding_card_style">
                            <option value="default" <?=selected($gs('branding_card_style','default'),'default',false)?>>Default (dark with border)</option>
                            <option value="glass" <?=selected($gs('branding_card_style','default'),'glass',false)?>>Glassmorphism</option>
                            <option value="flat" <?=selected($gs('branding_card_style','default'),'flat',false)?>>Flat Minimal</option>
                            <option value="rounded" <?=selected($gs('branding_card_style','default'),'rounded',false)?>>Ultra Rounded</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Allow User Themes</label>
                        <select name="branding_allow_user_themes">
                            <option value="1" <?=selected($gs('branding_allow_user_themes','1'),'1',false)?>>✅ Yes - let users customize</option>
                            <option value="0" <?=selected($gs('branding_allow_user_themes','1'),'0',false)?>>⏸ No - enforce site theme</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>💻 Custom CSS</h2>
                <div class="cfp-field">
                    <label>Custom CSS (applied to all pages)</label>
                    <textarea name="branding_custom_css" rows="8" style="width:100%;background:#111;border:1px solid #2a2a2a;color:#e8e8e8;padding:10px;border-radius:8px;font-family:monospace;font-size:.85rem"><?=esc_textarea($gs('branding_custom_css',''))?></textarea>
                    <span class="hint">Advanced: Add custom CSS to further customize the appearance</span>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>📜 Custom JavaScript</h2>
                <div class="cfp-field">
                    <label>Custom JavaScript (applied to all pages)</label>
                    <textarea name="branding_custom_js" rows="6" style="width:100%;background:#111;border:1px solid #2a2a2a;color:#e8e8e8;padding:10px;border-radius:8px;font-family:monospace;font-size:.85rem"><?=esc_textarea($gs('branding_custom_js',''))?></textarea>
                    <span class="hint">Warning: Incorrect JS can break the site. Use carefully.</span>
                </div>
            </div>

            <button type="submit" name="cfp_save_branding" class="cfp-btn cfp-btn-gold">💾 Save Branding Settings</button>
        </form>
    </div>
    <?php
}