<?php
/**
 * Admin page: Ad Manager - Manage banner ads, interstitial ads, ad placements
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AD STORAGE TABLE CREATION
   ============================================================ */
function cfp_create_ad_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    
    $table_ads = $wpdb->prefix . 'cfp_ads';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_ads'") != $table_ads) {
        $wpdb->query("
            CREATE TABLE $table_ads (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                name varchar(100) NOT NULL,
                type varchar(20) NOT NULL,
                content text,
                url varchar(500) DEFAULT NULL,
                image_url varchar(500) DEFAULT NULL,
                code text,
                position varchar(50) DEFAULT 'header',
                placements text,
                impressions int(11) DEFAULT 0,
                clicks int(11) DEFAULT 0,
                enabled tinyint(1) DEFAULT 1,
                start_date datetime DEFAULT NULL,
                end_date datetime DEFAULT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY  (id),
                KEY type (type),
                KEY enabled (enabled)
            ) $charset
        ");
    }
    
    $table_ad_stats = $wpdb->prefix . 'cfp_ad_stats';
    if ($wpdb->get_var("SHOW TABLES LIKE '$table_ad_stats'") != $table_ad_stats) {
        $wpdb->query("
            CREATE TABLE $table_ad_stats (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                ad_id bigint(20) NOT NULL,
                date date NOT NULL,
                impressions int(11) DEFAULT 0,
                clicks int(11) DEFAULT 0,
                PRIMARY KEY  (id),
                UNIQUE KEY ad_date (ad_id, date)
            ) $charset
        ");
    }
}

/* ============================================================
   AJAX: Ad Management
   ============================================================ */
add_action('wp_ajax_cfp_ads_data', 'cfp_ajax_ads_data');
function cfp_ajax_ads_data() {
    check_ajax_referer('cfp_ads_nonce', 'nonce');
    
    global $wpdb;
    $action = sanitize_text_field($_POST['sub_action'] ?? 'list');
    
    if($action === 'list') {
        $ads = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cfp_ads ORDER BY created_at DESC");
        wp_send_json_success(['ads' => $ads]);
    }
    
    if($action === 'save') {
        $id = intval($_POST['id'] ?? 0);
        $data = [
            'name' => sanitize_text_field($_POST['name']),
            'type' => sanitize_text_field($_POST['type']),
            'content' => wp_kses_post($_POST['content'] ?? ''),
            'url' => esc_url_raw($_POST['url'] ?? ''),
            'image_url' => esc_url_raw($_POST['image_url'] ?? ''),
            'code' => wp_kses_post($_POST['code'] ?? ''),
            'position' => sanitize_text_field($_POST['position'] ?? 'header'),
            'enabled' => isset($_POST['enabled']) ? 1 : 0,
            'start_date' => sanitize_text_field($_POST['start_date'] ?? null),
            'end_date' => sanitize_text_field($_POST['end_date'] ?? null)
        ];
        
        if($id > 0) {
            $wpdb->update($wpdb->prefix . 'cfp_ads', $data, ['id' => $id]);
        } else {
            $wpdb->insert($wpdb->prefix . 'cfp_ads', $data);
            $id = $wpdb->insert_id;
        }
        
        wp_send_json_success(['msg' => 'Ad saved', 'id' => $id]);
    }
    
    if($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $wpdb->delete($wpdb->prefix . 'cfp_ads', ['id' => $id]);
        wp_send_json_success(['msg' => 'Ad deleted']);
    }
    
    if($action === 'toggle') {
        $id = intval($_POST['id'] ?? 0);
        $current = (int)$wpdb->get_var($wpdb->prepare("SELECT enabled FROM {$wpdb->prefix}cfp_ads WHERE id = %d", $id));
        $wpdb->update($wpdb->prefix . 'cfp_ads', ['enabled' => $current ? 0 : 1], ['id' => $id]);
        wp_send_json_success(['msg' => 'Ad toggled']);
    }
    
    if($action === 'stats') {
        $period = sanitize_text_field($_POST['period'] ?? '30days');
        $days = $period === '7days' ? 7 : ($period === '90days' ? 90 : 30);
        
        $stats = $wpdb->get_results($wpdb->prepare(
            "SELECT a.id, a.name, a.type, a.position, a.enabled, 
                    COALESCE(SUM(s.impressions), 0) as impressions, 
                    COALESCE(SUM(s.clicks), 0) as clicks
             FROM {$wpdb->prefix}cfp_ads a
             LEFT JOIN {$wpdb->prefix}cfp_ad_stats s ON a.id = s.ad_id AND s.date >= DATE_SUB(CURDATE(), INTERVAL %d DAY)
             GROUP BY a.id
             ORDER BY impressions DESC",
            $days
        ));
        
        wp_send_json_success(['stats' => $stats]);
    }
}

/* ============================================================
   ADMIN: AD MANAGER PAGE
   ============================================================ */
function cfp_admin_ad_manager() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_ads_nonce');
    
    cfp_create_ad_tables();
    
    $ads = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cfp_ads ORDER BY created_at DESC");
    $total_impressions = (int)$wpdb->get_var("SELECT SUM(impressions) FROM {$wpdb->prefix}cfp_ads");
    $total_clicks = (int)$wpdb->get_var("SELECT SUM(clicks) FROM {$wpdb->prefix}cfp_ads");
    $enabled_ads = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}cfp_ads WHERE enabled = 1");
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">📺</span>
            <h1>📺 Ad Manager</h1>
            <button onclick="cfpShowAdModal()" class="cfp-btn cfp-btn-gold" style="margin-left:auto">➕ Create Ad</button>
        </div>

        <!-- OVERVIEW STATS -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card">
                <div class="label">📺 Total Ads</div>
                <div class="value"><?=count($ads)?></div>
            </div>
            <div class="cfp-stat-card green">
                <div class="label">✅ Active Ads</div>
                <div class="value"><?=$enabled_ads?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">👁️ Total Impressions</div>
                <div class="value"><?=number_format($total_impressions)?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">👆 Total Clicks</div>
                <div class="value"><?=number_format($total_clicks)?></div>
            </div>
        </div>

        <!-- ADS TABLE -->
        <div class="cfp-card">
            <h2>📋 All Ads</h2>
            <div class="cfp-tabs" style="margin-bottom:20px">
                <button class="cfp-tab active" onclick="cfpLoadAdStats('30days', this)">30 Days</button>
                <button class="cfp-tab" onclick="cfpLoadAdStats('7days', this)">7 Days</button>
                <button class="cfp-tab" onclick="cfpLoadAdStats('90days', this)">90 Days</button>
            </div>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Type</th>
                            <th>Position</th>
                            <th>Status</th>
                            <th>Impressions</th>
                            <th>Clicks</th>
                            <th>CTR</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="cfp-ads-tbody">
                        <?php foreach($ads as $ad): 
                            $ctr = $ad->impressions > 0 ? round(($ad->clicks / $ad->impressions) * 100, 2) : 0;
                        ?>
                        <tr>
                            <td><strong><?=esc_html($ad->name)?></strong></td>
                            <td><span class="cfp-badge <?=$ad->type === 'banner' ? 'active' : ($ad->type === 'interstitial' ? 'pending' : 'drawn')?>"><?=esc_html($ad->type)?></span></td>
                            <td><?=esc_html($ad->position)?></td>
                            <td><span class="cfp-badge <?=$ad->enabled ? 'active' : 'rejected'?>"><?=$ad->enabled ? 'Active' : 'Disabled'?></span></td>
                            <td><?=number_format($ad->impressions)?></td>
                            <td><?=number_format($ad->clicks)?></td>
                            <td style="color:<?=$ctr > 1 ? '#22c55e' : '#f7931a'?>"><?=$ctr?>%</td>
                            <td>
                                <button onclick="cfpEditAd(<?=esc_html(json_encode($ad))?>)" class="cfp-btn cfp-btn-sm cfp-btn-ghost">Edit</button>
                                <button onclick="cfpToggleAd(<?=$ad->id?>)" class="cfp-btn cfp-btn-sm cfp-btn-ghost"><?=$ad->enabled ? 'Disable' : 'Enable'?></button>
                                <button onclick="cfpDeleteAd(<?=$ad->id?>)" class="cfp-btn cfp-btn-sm cfp-btn-red">Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($ads)): ?>
                        <tr><td colspan="8" style="text-align:center;padding:40px;color:#555">No ads created yet. Click "Create Ad" to get started.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- AD POSITIONS EXPLAINED -->
        <div class="cfp-card" style="margin-top:24px">
            <h2>📍 Ad Positions</h2>
            <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:16px">
                <div style="background:#0d0d0d;padding:16px;border-radius:10px;border-left:3px solid #f7931a">
                    <div style="font-weight:700;color:#fff;margin-bottom:6px">Header</div>
                    <div style="font-size:.75rem;color:#555">Top of every page</div>
                </div>
                <div style="background:#0d0d0d;padding:16px;border-radius:10px;border-left:3px solid #22c55e">
                    <div style="font-weight:700;color:#fff;margin-bottom:6px">Faucet Widget</div>
                    <div style="font-size:.75rem;color:#555">Below claim widget</div>
                </div>
                <div style="background:#0d0d0d;padding:16px;border-radius:10px;border-left:3px solid #3b82f6">
                    <div style="font-weight:700;color:#fff;margin-bottom:6px">Sidebar</div>
                    <div style="font-size:.75rem;color:#555">Side of pages</div>
                </div>
                <div style="background:#0d0d0d;padding:16px;border-radius:10px;border-left:3px solid #a855f7">
                    <div style="font-weight:700;color:#fff;margin-bottom:6px">Interstitial</div>
                    <div style="font-size:.75rem;color:#555">Full page popup</div>
                </div>
            </div>
        </div>
    </div>

    <!-- AD MODAL -->
    <div id="cfp-ad-modal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.8);z-index:9999;align-items:center;justify-content:center">
        <div style="background:#161616;border:1px solid #2a2a2a;border-radius:16px;padding:28px;max-width:600px;width:90%;max-height:90vh;overflow-y:auto">
            <h2 id="cfp-ad-modal-title" style="color:#fff;margin-bottom:20px;font-size:1.3rem">Create New Ad</h2>
            <form id="cfp-ad-form">
                <input type="hidden" id="cfp-ad-id" value="0">
                <div class="cfp-field">
                    <label>Ad Name</label>
                    <input type="text" id="cfp-ad-name" placeholder="My Ad Campaign" required>
                </div>
                <div class="cfp-field">
                    <label>Ad Type</label>
                    <select id="cfp-ad-type">
                        <option value="banner">Banner</option>
                        <option value="interstitial">Interstitial (Popup)</option>
                        <option value="text">Text Ad</option>
                        <option value="code">Custom Code</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Position</label>
                    <select id="cfp-ad-position">
                        <option value="header">Header</option>
                        <option value="faucet">Below Faucet</option>
                        <option value="sidebar">Sidebar</option>
                        <option value="footer">Footer</option>
                        <option value="interstitial">Interstitial</option>
                    </select>
                </div>
                <div class="cfp-field" id="cfp-field-content">
                    <label>Ad Content / Text</label>
                    <textarea id="cfp-ad-content" rows="3" placeholder="Enter your ad text..."></textarea>
                </div>
                <div class="cfp-field" id="cfp-field-url">
                    <label>Target URL</label>
                    <input type="url" id="cfp-ad-url" placeholder="https://example.com">
                </div>
                <div class="cfp-field" id="cfp-field-image">
                    <label>Image URL (for banners)</label>
                    <input type="url" id="cfp-ad-image" placeholder="https://example.com/banner.png">
                </div>
                <div class="cfp-field" id="cfp-field-code" style="display:none">
                    <label>Custom HTML/JS Code</label>
                    <textarea id="cfp-ad-code" rows="4" placeholder="<script>...</script>"></textarea>
                </div>
                <div class="cfp-field">
                    <label>
                        <input type="checkbox" id="cfp-ad-enabled" checked> Enabled
                    </label>
                </div>
                <div style="display:flex;gap:12px;margin-top:20px">
                    <button type="submit" class="cfp-btn cfp-btn-gold">Save Ad</button>
                    <button type="button" onclick="cfpCloseAdModal()" class="cfp-btn cfp-btn-ghost">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        cfpLoadAdStats('30days', document.querySelector('.cfp-tabs .cfp-tab.active'));
    });

    function cfpShowAdModal() {
        document.getElementById('cfp-ad-modal-title').textContent = 'Create New Ad';
        document.getElementById('cfp-ad-id').value = '0';
        document.getElementById('cfp-ad-form').reset();
        document.getElementById('cfp-ad-modal').style.display = 'flex';
    }

    function cfpCloseAdModal() {
        document.getElementById('cfp-ad-modal').style.display = 'none';
    }

    function cfpEditAd(ad) {
        document.getElementById('cfp-ad-modal-title').textContent = 'Edit Ad: ' + ad.name;
        document.getElementById('cfp-ad-id').value = ad.id;
        document.getElementById('cfp-ad-name').value = ad.name;
        document.getElementById('cfp-ad-type').value = ad.type;
        document.getElementById('cfp-ad-position').value = ad.position;
        document.getElementById('cfp-ad-content').value = ad.content || '';
        document.getElementById('cfp-ad-url').value = ad.url || '';
        document.getElementById('cfp-ad-image').value = ad.image_url || '';
        document.getElementById('cfp-ad-code').value = ad.code || '';
        document.getElementById('cfp-ad-enabled').checked = ad.enabled == 1;
        document.getElementById('cfp-ad-modal').style.display = 'flex';
    }

    document.getElementById('cfp-ad-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const fd = new FormData();
        fd.append('action', 'cfp_ads_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'save');
        fd.append('id', document.getElementById('cfp-ad-id').value);
        fd.append('name', document.getElementById('cfp-ad-name').value);
        fd.append('type', document.getElementById('cfp-ad-type').value);
        fd.append('position', document.getElementById('cfp-ad-position').value);
        fd.append('content', document.getElementById('cfp-ad-content').value);
        fd.append('url', document.getElementById('cfp-ad-url').value);
        fd.append('image_url', document.getElementById('cfp-ad-image').value);
        fd.append('code', document.getElementById('cfp-ad-code').value);
        fd.append('enabled', document.getElementById('cfp-ad-enabled').checked ? '1' : '0');

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    cfpCloseAdModal();
                    location.reload();
                }
            });
    });

    function cfpToggleAd(id) {
        const fd = new FormData();
        fd.append('action', 'cfp_ads_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'toggle');
        fd.append('id', id);
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(() => location.reload());
    }

    function cfpDeleteAd(id) {
        if(!confirm('Delete this ad?')) return;
        const fd = new FormData();
        fd.append('action', 'cfp_ads_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'delete');
        fd.append('id', id);
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(() => location.reload());
    }

    function cfpLoadAdStats(period, btn) {
        document.querySelectorAll('.cfp-tabs .cfp-tab').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        // Stats loaded by default, could add AJAX here for dynamic data
    }
    </script>
    <?php
}