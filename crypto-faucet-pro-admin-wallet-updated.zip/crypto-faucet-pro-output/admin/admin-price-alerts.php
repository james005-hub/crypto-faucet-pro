<?php
/**
 * Admin page: Price Alerts - Configure cryptocurrency price alert thresholds
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Price Alerts Management
   ============================================================ */
add_action('wp_ajax_cfp_price_alerts_data', 'cfp_ajax_price_alerts_data');
function cfp_ajax_price_alerts_data() {
    check_ajax_referer('cfp_price_alerts_nonce', 'nonce');
    
    global $wpdb;
    $action = sanitize_text_field($_POST['sub_action'] ?? 'list');
    
    if($action === 'list') {
        $alerts = $wpdb->get_results("
            SELECT * FROM {$wpdb->prefix}cfp_price_alerts ORDER BY crypto ASC, alert_type ASC
        ");
        
        $prices = cfp_fetch_live_prices();
        
        wp_send_json_success(['alerts' => $alerts, 'prices' => $prices]);
    }
    
    if($action === 'save') {
        $id = intval($_POST['id'] ?? 0);
        $data = [
            'crypto' => sanitize_text_field($_POST['crypto']),
            'alert_type' => sanitize_text_field($_POST['alert_type']),
            'threshold' => floatval($_POST['threshold']),
            'direction' => sanitize_text_field($_POST['direction']),
            'is_active' => isset($_POST['is_active']) ? 1 : 0,
            'notify_email' => isset($_POST['notify_email']) ? 1 : 0,
            'notify_telegram' => isset($_POST['notify_telegram']) ? 1 : 0
        ];
        
        if($id > 0) {
            $wpdb->update($wpdb->prefix . 'cfp_price_alerts', $data, ['id' => $id]);
        } else {
            $wpdb->insert($wpdb->prefix . 'cfp_price_alerts', $data);
            $id = $wpdb->insert_id;
        }
        
        wp_send_json_success(['msg' => 'Alert saved', 'id' => $id]);
    }
    
    if($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $wpdb->delete($wpdb->prefix . 'cfp_price_alerts', ['id' => $id]);
        wp_send_json_success(['msg' => 'Alert deleted']);
    }
    
    if($action === 'trigger') {
        $id = intval($_POST['id'] ?? 0);
        $current_price = floatval($_POST['current_price'] ?? 0);
        $alert = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}cfp_price_alerts WHERE id = %d", $id));
        
        if($alert) {
            $wpdb->update($wpdb->prefix . 'cfp_price_alerts', [
                'last_triggered' => current_time('mysql'),
                'last_trigger_price' => $current_price,
                'trigger_count' => $alert->trigger_count + 1
            ], ['id' => $id]);
            
            wp_send_json_success(['msg' => 'Alert triggered']);
        }
    }
}

/* ============================================================
   HELPER: Fetch Live Prices
   ============================================================ */
function cfp_fetch_live_prices() {
    $api_key = get_option('coingecko_api_key', '');
    $url = $api_key 
        ? "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,litecoin,dogecoin,tron,tether&vs_currencies=usd&x_cg_demo_api_key=" . $api_key
        : "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,litecoin,dogecoin,tron,tether&vs_currencies=usd";
    
    $response = wp_remote_get($url);
    
    if(is_wp_error($response)) {
        return ['BTC' => 0, 'ETH' => 0, 'LTC' => 0, 'DOGE' => 0, 'TRX' => 0, 'USDT' => 0];
    }
    
    $data = json_decode(wp_remote_retrieve_body($response), true);
    
    return [
        'BTC' => $data['bitcoin']['usd'] ?? 0,
        'ETH' => $data['ethereum']['usd'] ?? 0,
        'LTC' => $data['litecoin']['usd'] ?? 0,
        'DOGE' => $data['dogecoin']['usd'] ?? 0,
        'TRX' => $data['tron']['usd'] ?? 0,
        'USDT' => $data['tether']['usd'] ?? 0
    ];
}

/* ============================================================
   ADMIN: PRICE ALERTS PAGE
   ============================================================ */
function cfp_admin_price_alerts() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_price_alerts_nonce');
    
    $alerts = $wpdb->get_results("
        SELECT * FROM {$wpdb->prefix}cfp_price_alerts ORDER BY crypto ASC, alert_type ASC
    ");
    
    $prices = cfp_fetch_live_prices();
    
    $active_alerts = count(array_filter($alerts, function($a) { return $a->is_active; }));
    $triggered_today = count(array_filter($alerts, function($a) { 
        return $a->last_triggered && date('Y-m-d', strtotime($a->last_triggered)) === date('Y-m-d'); 
    }));
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🔔</span>
            <h1>🔔 Price Alerts</h1>
            <button onclick="cfpShowAlertModal()" class="cfp-btn cfp-btn-gold" style="margin-left:auto">➕ Add Alert</button>
        </div>

        <!-- LIVE PRICES -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(6, 1fr); margin-bottom:30px">
            <?php foreach($prices as $crypto => $price): ?>
            <div class="cfp-stat-card <?=in_array($crypto, ['BTC', 'ETH']) ? 'green' : ''?>">
                <div class="label"><?=$crypto?></div>
                <div class="value" style="font-size:1.1rem">$<?=number_format($price, 2)?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- OVERVIEW STATS -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(3, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card">
                <div class="label">🔔 Active Alerts</div>
                <div class="value"><?=$active_alerts?></div>
            </div>
            <div class="cfp-stat-card green">
                <div class="label">⚡ Triggered Today</div>
                <div class="value"><?=$triggered_today?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">📊 Total Alerts</div>
                <div class="value"><?=count($alerts)?></div>
            </div>
        </div>

        <!-- ALERTS TABLE -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>📋 Price Alerts</h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>Crypto</th>
                            <th>Alert Type</th>
                            <th>Direction</th>
                            <th>Threshold</th>
                            <th>Current Price</th>
                            <th>Status</th>
                            <th>Last Triggered</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach($alerts as $a): 
                        $current = $prices[$a->crypto] ?? 0;
                        $is_triggered = false;
                        if($a->alert_type === 'price' && $current > 0) {
                            if($a->direction === 'above' && $current >= $a->threshold) $is_triggered = true;
                            if($a->direction === 'below' && $current <= $a->threshold) $is_triggered = true;
                        }
                    ?>
                        <tr>
                            <td><strong><?=$a->crypto?></strong></td>
                            <td><span class="cfp-badge"><?=esc_html($a->alert_type)?></span></td>
                            <td><span class="cfp-badge <?=$a->direction === 'above' ? 'active' : 'pending'?>"><?=$a->direction === 'above' ? '⬆ Above' : '⬇ Below'?></span></td>
                            <td style="font-weight:700;color:#f7931a">$<?=number_format($a->threshold, 2)?></td>
                            <td>$<?=number_format($current, 2)?></td>
                            <td>
                                <?php if($is_triggered): ?>
                                <span class="cfp-badge active">⚡ TRIGGERED</span>
                                <?php else: ?>
                                <span class="cfp-badge <?=$a->is_active ? 'active' : 'rejected'?>"><?=$a->is_active ? 'Active' : 'Disabled'?></span>
                                <?php endif; ?>
                            </td>
                            <td style="color:#555;font-size:.8rem">
                                <?=$a->last_triggered ? human_time_diff(strtotime($a->last_triggered), current_time('timestamp')) . ' ago' : 'Never'?>
                            </td>
                            <td>
                                <button onclick="cfpEditAlert(<?=esc_html(json_encode($a))?>)" class="cfp-btn cfp-btn-sm cfp-btn-ghost">Edit</button>
                                <button onclick="cfpTestAlert(<?=$a->id?>, <?=$current?>)" class="cfp-btn cfp-btn-sm cfp-btn-ghost">Test</button>
                                <button onclick="cfpDeleteAlert(<?=$a->id?>)" class="cfp-btn cfp-btn-sm cfp-btn-red">Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($alerts)): ?>
                        <tr><td colspan="8" style="text-align:center;padding:40px;color:#555">No alerts configured. Click "Add Alert" to create one.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ALERT CONFIGURATION INFO -->
        <div class="cfp-card">
            <h2>💡 How Price Alerts Work</h2>
            <div style="display:grid;grid-template-columns:repeat(2, 1fr);gap:24px">
                <div style="background:#0d0d0d;padding:20px;border-radius:12px">
                    <h3 style="color:#22c55e;margin-bottom:12px">🔔 Alert Types</h3>
                    <ul style="color:#888;font-size:.85rem;line-height:1.8;list-style:disc;padding-left:20px">
                        <li><strong>Price:</strong> Alert when price goes above/below threshold</li>
                        <li><strong>Change %:</strong> Alert on percentage change (e.g., 5% in 1 hour)</li>
                        <li><strong>Volume:</strong> Alert on unusual trading volume</li>
                    </ul>
                </div>
                <div style="background:#0d0d0d;padding:20px;border-radius:12px">
                    <h3 style="color:#f7931a;margin-bottom:12px">📢 Notifications</h3>
                    <ul style="color:#888;font-size:.85rem;line-height:1.8;list-style:disc;padding-left:20px">
                        <li><strong>Email:</strong> Send alert via email to admin</li>
                        <li><strong>Telegram:</strong> Send alert via Telegram bot</li>
                        <li><strong>In-app:</strong> Show notification to users</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- ALERT MODAL -->
    <div id="cfp-alert-modal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.8);z-index:9999;align-items:center;justify-content:center">
        <div style="background:#161616;border:1px solid #2a2a2a;border-radius:16px;padding:28px;max-width:500px;width:90%">
            <h2 id="cfp-alert-modal-title" style="color:#fff;margin-bottom:20px;font-size:1.3rem">Add Price Alert</h2>
            <form id="cfp-alert-form">
                <input type="hidden" id="cfp-alert-id" value="0">
                <div class="cfp-field">
                    <label>Cryptocurrency</label>
                    <select id="cfp-alert-crypto">
                        <option value="BTC">Bitcoin (BTC)</option>
                        <option value="ETH">Ethereum (ETH)</option>
                        <option value="LTC">Litecoin (LTC)</option>
                        <option value="DOGE">Dogecoin (DOGE)</option>
                        <option value="TRX">Tron (TRX)</option>
                        <option value="USDT">Tether (USDT)</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Alert Type</label>
                    <select id="cfp-alert-type">
                        <option value="price">Price Threshold</option>
                        <option value="change">Percentage Change</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Direction</label>
                    <select id="cfp-alert-direction">
                        <option value="above">Above (⬆)</option>
                        <option value="below">Below (⬇)</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Threshold (USD)</label>
                    <input type="number" id="cfp-alert-threshold" placeholder="50000" step="0.01">
                </div>
                <div class="cfp-field">
                    <label>
                        <input type="checkbox" id="cfp-alert-active" checked> Active
                    </label>
                </div>
                <div class="cfp-field">
                    <label>
                        <input type="checkbox" id="cfp-alert-email" checked> Notify via Email
                    </label>
                </div>
                <div style="display:flex;gap:12px;margin-top:20px">
                    <button type="submit" class="cfp-btn cfp-btn-gold">Save Alert</button>
                    <button type="button" onclick="cfpCloseAlertModal()" class="cfp-btn cfp-btn-ghost">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Prices loaded via PHP
    });

    function cfpShowAlertModal() {
        document.getElementById('cfp-alert-modal-title').textContent = 'Add Price Alert';
        document.getElementById('cfp-alert-id').value = '0';
        document.getElementById('cfp-alert-form').reset();
        document.getElementById('cfp-alert-modal').style.display = 'flex';
    }

    function cfpCloseAlertModal() {
        document.getElementById('cfp-alert-modal').style.display = 'none';
    }

    function cfpEditAlert(alert) {
        document.getElementById('cfp-alert-modal-title').textContent = 'Edit Alert: ' + alert.crypto;
        document.getElementById('cfp-alert-id').value = alert.id;
        document.getElementById('cfp-alert-crypto').value = alert.crypto;
        document.getElementById('cfp-alert-type').value = alert.alert_type;
        document.getElementById('cfp-alert-direction').value = alert.direction;
        document.getElementById('cfp-alert-threshold').value = alert.threshold;
        document.getElementById('cfp-alert-active').checked = alert.is_active == 1;
        document.getElementById('cfp-alert-email').checked = alert.notify_email == 1;
        document.getElementById('cfp-alert-modal').style.display = 'flex';
    }

    document.getElementById('cfp-alert-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const fd = new FormData();
        fd.append('action', 'cfp_price_alerts_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'save');
        fd.append('id', document.getElementById('cfp-alert-id').value);
        fd.append('crypto', document.getElementById('cfp-alert-crypto').value);
        fd.append('alert_type', document.getElementById('cfp-alert-type').value);
        fd.append('direction', document.getElementById('cfp-alert-direction').value);
        fd.append('threshold', document.getElementById('cfp-alert-threshold').value);
        fd.append('is_active', document.getElementById('cfp-alert-active').checked ? '1' : '0');
        fd.append('notify_email', document.getElementById('cfp-alert-email').checked ? '1' : '0');

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    cfpCloseAlertModal();
                    location.reload();
                }
            });
    });

    function cfpTestAlert(id, currentPrice) {
        const fd = new FormData();
        fd.append('action', 'cfp_price_alerts_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'trigger');
        fd.append('id', id);
        fd.append('current_price', currentPrice);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(() => {
                alert('Test alert triggered!');
                location.reload();
            });
    }

    function cfpDeleteAlert(id) {
        if(!confirm('Delete this alert?')) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_price_alerts_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'delete');
        fd.append('id', id);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(() => location.reload());
    }
    </script>
    <?php
}