<?php
/**
 * Admin pages: Claims, Withdrawals, Lottery, P2P Events; quick-activate handler
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   ADMIN: CLAIMS
   ============================================================ */
function cfp_admin_claims() {
    global $wpdb;
    $page=max(1,intval($_GET['paged']??1)); $per=30; $offset=($page-1)*$per;
    $total=$wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_CLAIMS);
    $claims=$wpdb->get_results($wpdb->prepare("SELECT c.*,u.username,u.email FROM ".CFP_TABLE_CLAIMS." c LEFT JOIN ".CFP_TABLE_USERS." u ON c.user_id=u.id ORDER BY c.claimed_at DESC LIMIT %d OFFSET %d",$per,$offset));
    $pages=ceil($total/$per);
    $today_sat=$wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_CLAIMS." WHERE DATE(claimed_at)=CURDATE()");
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header"><span class="cfp-logo-badge">⚡ CFP</span><h1>Claims Log</h1><span style="margin-left:auto;color:var(--mt);font-size:.83rem"><?=number_format($total)?> total · <?=number_format($today_sat)?> sat today</span></div>
        <div class="cfp-card"><table class="cfp-table"><thead><tr><th>#</th><th>User</th><th>Amount</th><th>IP</th><th>Time</th></tr></thead><tbody>
        <?php foreach($claims as $c): ?>
        <tr><td style="color:var(--mt)"><?=$c->id?></td><td><strong><?=esc_html($c->username)?></strong><br><span style="font-size:.74rem;color:var(--mt)"><?=esc_html($c->email)?></span></td><td style="color:var(--g);font-weight:700"><?=number_format($c->amount_sat)?></td><td style="font-size:.78rem;font-family:monospace"><?=esc_html($c->ip_address)?></td><td style="font-size:.8rem"><?=$c->claimed_at?></td></tr>
        <?php endforeach; ?>
        </tbody></table>
        <?php if($pages>1): ?><div class="cfp-pagination"><?php for($i=1;$i<=$pages;$i++): ?><a href="<?=admin_url("admin.php?page=cfp-claims&paged=$i")?>" class="<?=$i==$page?'current':''?>"><?=$i?></a><?php endfor; ?></div><?php endif; ?>
        </div>
    </div>
    <?php
}

/* ============================================================
   ADMIN: WITHDRAWALS
   ============================================================ */
function cfp_admin_withdrawals() {
    global $wpdb;
    $notice = '';

    // ── PROCESS APPROVAL / REJECTION / TXID UPDATE ──────────
    if ( isset($_GET['action'],$_GET['id']) && check_admin_referer('cfp_wd') ) {
        $wid = intval($_GET['id']);
        $act = sanitize_text_field($_GET['action']);
        $wd  = $wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_WITHDRAWALS." WHERE id=%d", $wid));

        if ( $wd ) {

            if ( $act === 'approve' && $wd->status === 'pending' ) {
                // Balance was already deducted at submission — just mark approved and log TXID
                $txid = sanitize_text_field($_GET['txid'] ?? '');
                $wpdb->update(CFP_TABLE_WITHDRAWALS, [
                    'status'       => 'approved',
                    'txid'         => $txid,
                    'admin_note'   => sanitize_text_field($_GET['note'] ?? ''),
                    'processed_at' => current_time('mysql'),
                ], ['id' => $wid]);
                // Update transaction record from "pending" to "approved"
                $wpdb->query($wpdb->prepare(
                    "UPDATE ".CFP_TABLE_TRANSACTIONS." SET type='withdrawal', description=%s
                     WHERE user_id=%d AND type='withdrawal_pending'
                     ORDER BY created_at DESC LIMIT 1",
                    "Withdrawal approved — {$wd->amount_sat} sat to {$wd->btc_address}" . ($txid ? " TXID:{$txid}" : ''),
                    $wd->user_id
                ));
                $notice = "<div class='cfp-notice success'>✅ Withdrawal #{$wid} approved." . ($txid ? " TXID recorded." : '') . "</div>";
            }

            if ( $act === 'reject' && $wd->status === 'pending' ) {
                // REFUND: return the held amount (including fee) back to user's balance
                $total_held = $wd->amount_sat + $wd->fee_sat;
                $wpdb->update(CFP_TABLE_WITHDRAWALS, [
                    'status'       => 'rejected',
                    'admin_note'   => sanitize_text_field($_GET['note'] ?? 'Rejected by admin'),
                    'processed_at' => current_time('mysql'),
                ], ['id' => $wid]);
                // Refund balance
                $wpdb->query($wpdb->prepare(
                    "UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",
                    $total_held, $wd->user_id
                ));
                // Also refund the fee from admin wallet since we credited it at submission
                if ( $wd->fee_sat > 0 ) {
                    $wpdb->query($wpdb->prepare(
                        "DELETE FROM ".CFP_TABLE_ADMIN_WALLET." WHERE stream='withdraw_fee' AND description LIKE %s ORDER BY created_at DESC LIMIT 1",
                        "%user #{$wd->user_id}%"
                    ));
                }
                // Update transaction record
                $wpdb->query($wpdb->prepare(
                    "UPDATE ".CFP_TABLE_TRANSACTIONS." SET type='withdrawal_rejected', description=%s
                     WHERE user_id=%d AND type='withdrawal_pending'
                     ORDER BY created_at DESC LIMIT 1",
                    "Withdrawal rejected — {$total_held} sat refunded to balance",
                    $wd->user_id
                ));
                $notice = "<div class='cfp-notice error'>❌ Withdrawal #{$wid} rejected. {$total_held} sat refunded to user.</div>";
            }

            if ( $act === 'set_txid' ) {
                $txid = sanitize_text_field($_GET['txid'] ?? '');
                if ( $txid ) {
                    $wpdb->update(CFP_TABLE_WITHDRAWALS, ['txid'=>$txid], ['id'=>$wid]);
                    $notice = "<div class='cfp-notice success'>✅ TXID saved for withdrawal #{$wid}.</div>";
                }
            }
        }

        if ( empty($notice) ) {
            echo '<script>window.location="'.admin_url('admin.php?page=cfp-withdrawals').'"</script>'; exit;
        }
    }
    $filter=$_GET['filter']??'all'; $where=$filter!=='all'?$wpdb->prepare("WHERE w.status=%s",$filter):'';
    $page=max(1,intval($_GET['paged']??1)); $per=25; $offset=($page-1)*$per;
    $total=$wpdb->get_var("SELECT COUNT(*) FROM ".CFP_TABLE_WITHDRAWALS." w $where");
    $wds=$wpdb->get_results($wpdb->prepare("SELECT w.*,u.username,u.email FROM ".CFP_TABLE_WITHDRAWALS." w LEFT JOIN ".CFP_TABLE_USERS." u ON w.user_id=u.id $where ORDER BY w.requested_at DESC LIMIT %d OFFSET %d",$per,$offset));
    $pages=ceil($total/$per);
    $counts=$wpdb->get_results("SELECT status,COUNT(*) cnt FROM ".CFP_TABLE_WITHDRAWALS." GROUP BY status",OBJECT_K);
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header"><span class="cfp-logo-badge">⚡ CFP</span><h1>Withdrawals</h1></div>
        <div class="cfp-tabs"><?php foreach(['all'=>'All','pending'=>'Pending','approved'=>'Approved','rejected'=>'Rejected'] as $k=>$l): $cnt=$k==='all'?$total:($counts[$k]->cnt??0); ?>
            <a href="<?=admin_url("admin.php?page=cfp-withdrawals&filter=$k")?>" class="cfp-tab <?=$filter===$k?'active':''?>"><?=$l?> <span style="opacity:.55;font-size:.72rem">(<?=$cnt?>)</span></a>
        <?php endforeach; ?></div>
        <div class="cfp-card"><?php if($notice) echo wp_kses($notice, ['div' => ['class' => []], 'strong' => []]); ?>
        <table class="cfp-table"><thead><tr>
            <th>#</th><th>User</th><th>BTC Address</th>
            <th>Amount</th><th>Fee</th><th>Net</th>
            <th>Status</th><th>TXID / Note</th><th>Date</th><th>Actions</th>
        </tr></thead><tbody>
        <?php foreach($wds as $w): ?>
        <tr>
            <td style="color:var(--mt)"><?=$w->id?></td>
            <td><strong><?=esc_html($w->username)?></strong><br><span style="font-size:.73rem;color:var(--mt)"><?=esc_html($w->email)?></span></td>
            <td style="font-size:.76rem;font-family:monospace;color:#3b82f6" title="<?=esc_attr($w->btc_address)?>">
                <?=esc_html(substr($w->btc_address,0,16))?>…
                <button onclick="navigator.clipboard.writeText('<?=esc_js($w->btc_address)?>')" title="Copy address"
                    style="background:none;border:none;color:#555;cursor:pointer;font-size:.75rem;padding:0 4px">📋</button>
            </td>
            <td style="color:#fff;font-weight:700"><?=number_format($w->amount_sat)?></td>
            <td style="color:var(--rd);font-size:.8rem"><?=$w->fee_sat>0?'-'.number_format($w->fee_sat):'—'?></td>
            <td style="color:var(--gr);font-weight:700"><?=number_format($w->amount_sat-$w->fee_sat)?></td>
            <td><span class="cfp-badge <?=$w->status?>"><?=ucfirst($w->status)?></span></td>
            <td style="font-size:.76rem;max-width:160px">
                <?php if(!empty($w->txid)): ?>
                    <div style="font-family:monospace;color:#22c55e" title="<?=esc_attr($w->txid)?>">
                        TXID: <?=esc_html(substr($w->txid,0,12))?>…
                        <button onclick="navigator.clipboard.writeText('<?=esc_js($w->txid)?>')" title="Copy TXID"
                            style="background:none;border:none;color:#555;cursor:pointer;font-size:.72rem">📋</button>
                    </div>
                <?php endif; ?>
                <?php if(!empty($w->admin_note)): ?>
                    <div style="color:#777;margin-top:3px"><?=esc_html($w->admin_note)?></div>
                <?php endif; ?>
            </td>
            <td style="font-size:.78rem;color:var(--mt)"><?=date('M j, Y H:i',strtotime($w->requested_at))?></td>
            <td>
            <?php if($w->status==='pending'):
                $n=wp_create_nonce('cfp_wd');
                $approve_url=admin_url("admin.php?page=cfp-withdrawals&action=approve&id={$w->id}&_wpnonce=$n");
                $reject_url =admin_url("admin.php?page=cfp-withdrawals&action=reject&id={$w->id}&_wpnonce=$n");
            ?>
                <div style="display:flex;flex-direction:column;gap:5px">
                    <input type="text" id="txid-<?=$w->id?>" placeholder="TXID (optional)"
                        style="background:#111;border:1px solid #2a2a2a;color:#aaa;padding:5px 8px;border-radius:5px;font-size:.73rem;font-family:monospace;width:140px">
                    <input type="text" id="note-<?=$w->id?>" placeholder="Admin note (optional)"
                        style="background:#111;border:1px solid #2a2a2a;color:#aaa;padding:5px 8px;border-radius:5px;font-size:.73rem;width:140px">
                    <div style="display:flex;gap:4px;margin-top:2px">
                        <button onclick="cfpApproveWd(<?=$w->id?>,'<?=esc_js($approve_url)?>')"
                            class="cfp-btn cfp-btn-green cfp-btn-sm">✓ Approve</button>
                        <button onclick="cfpRejectWd(<?=$w->id?>,'<?=esc_js($reject_url)?>')"
                            class="cfp-btn cfp-btn-red cfp-btn-sm"
                            onclick="return confirm('Reject and refund user?')">✕ Reject</button>
                    </div>
                </div>
            <?php elseif($w->status==='approved' && empty($w->txid)):
                $n=wp_create_nonce('cfp_wd');
                $txid_url=admin_url("admin.php?page=cfp-withdrawals&action=set_txid&id={$w->id}&_wpnonce=$n");
            ?>
                <div style="display:flex;gap:4px">
                    <input type="text" id="txid-<?=$w->id?>" placeholder="Add TXID"
                        style="background:#111;border:1px solid #2a2a2a;color:#aaa;padding:5px 8px;border-radius:5px;font-size:.73rem;font-family:monospace;width:110px">
                    <button onclick="cfpSetTxid(<?=$w->id?>,'<?=esc_js($txid_url)?>')"
                        style="background:#1a2a1a;border:1px solid #22c55e44;color:#22c55e;padding:5px 10px;border-radius:5px;font-size:.73rem;cursor:pointer">Save</button>
                </div>
            <?php else: ?>
                <span style="color:var(--mt);font-size:.8rem"><?=ucfirst($w->status)?></span>
            <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        </tbody></table>
        <?php if($pages>1): ?><div class="cfp-pagination"><?php for($i=1;$i<=$pages;$i++): ?><a href="<?=admin_url("admin.php?page=cfp-withdrawals&paged=$i&filter=$filter")?>" class="<?=$i==$page?'current':''?>"><?=$i?></a><?php endfor; ?></div><?php endif; ?>
        </div>

        <!-- Summary stats -->
        <?php
        $total_pending  = $wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_WITHDRAWALS." WHERE status='pending'");
        $total_approved = $wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_WITHDRAWALS." WHERE status='approved'");
        $total_fees     = $wpdb->get_var("SELECT COALESCE(SUM(fee_sat),0) FROM ".CFP_TABLE_WITHDRAWALS." WHERE status='approved'");
        ?>
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(3,1fr);margin-top:18px">
            <div class="cfp-stat-card" style="border-top:3px solid #f7931a">
                <div class="label">⏳ Pending Outflow</div>
                <div class="value"><?=number_format($total_pending)?> sat</div>
                <div class="sub">Held from user balances</div>
            </div>
            <div class="cfp-stat-card" style="border-top:3px solid #22c55e">
                <div class="label">✅ Total Paid Out</div>
                <div class="value"><?=number_format($total_approved)?> sat</div>
                <div class="sub">Approved withdrawals</div>
            </div>
            <div class="cfp-stat-card" style="border-top:3px solid #3b82f6">
                <div class="label">💰 Total Fees Collected</div>
                <div class="value"><?=number_format($total_fees)?> sat</div>
                <div class="sub">From manual withdrawals</div>
            </div>
        </div>
    </div>

    <script>
    function cfpApproveWd(id, baseUrl) {
        const txid = document.getElementById('txid-'+id)?.value || '';
        const note = document.getElementById('note-'+id)?.value || '';
        const url  = baseUrl + '&txid=' + encodeURIComponent(txid) + '&note=' + encodeURIComponent(note);
        if(confirm('Approve withdrawal #'+id+'?')) window.location = url;
    }
    function cfpRejectWd(id, baseUrl) {
        const note = document.getElementById('note-'+id)?.value || 'Rejected by admin';
        const url  = baseUrl + '&note=' + encodeURIComponent(note);
        if(confirm('Reject withdrawal #'+id+'? The full amount will be refunded to the user.')) window.location = url;
    }
    function cfpSetTxid(id, baseUrl) {
        const txid = document.getElementById('txid-'+id)?.value || '';
        if(!txid){alert('Enter a TXID first.');return;}
        window.location = baseUrl + '&txid=' + encodeURIComponent(txid);
    }
    </script>
    <?php
}

/* ============================================================
   ADMIN: LOTTERY
   ============================================================ */
function cfp_admin_lottery() {
    global $wpdb;
    if(isset($_POST['cfp_draw_lottery']) && check_admin_referer('cfp_lottery')) {
        $lid=intval($_POST['lottery_id']);
        $lottery=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_LOTTERY." WHERE id=%d AND status='active'",$lid));
        if($lottery) {
            $ticket=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_LOTTERY_TICKETS." WHERE lottery_id=%d ORDER BY RAND() LIMIT 1",$lid));
            if($ticket) {
                $wpdb->update(CFP_TABLE_LOTTERY,['status'=>'drawn','winner_user_id'=>$ticket->user_id,'winning_ticket'=>$ticket->ticket_number,'drawn_at'=>current_time('mysql')],['id'=>$lid]);
                $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$lottery->prize_pool_sat,$ticket->user_id));
                $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$ticket->user_id,'type'=>'lottery_win','amount_sat'=>$lottery->prize_pool_sat,'description'=>'Weekly lottery winner!']);

                // Credit lottery house profit: ticket sale revenue minus prize paid out
                // Ticket sale revenue was already credited to admin wallet stream when tickets were bought.
                // Here we log the prize payout as an expense so wallet shows net position.
                // Also: any surplus (ticket revenue > prize pool) stays as profit already logged.
                // Log the prize payout cost for admin visibility:
                $ticket_revenue = $wpdb->get_var($wpdb->prepare(
                    "SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE stream='lottery_ticket_sales' AND created_at >= %s",
                    $lottery->week_start
                ));
                $lottery_profit = $ticket_revenue - $lottery->prize_pool_sat;
                if ($lottery_profit > 0) {
                    cfp_wallet_credit_game(
                        'admin_wallet_stream_lottery_tickets',
                        'lottery_net_profit',
                        0, // already credited via ticket sales — this is just a reconciliation note
                        "Lottery #{$lid} drawn. Prize: {$lottery->prize_pool_sat} sat. Ticket revenue this week: {$ticket_revenue} sat. Net: {$lottery_profit} sat."
                    );
                }

                // Create next lottery week
                $wpdb->insert(CFP_TABLE_LOTTERY,['week_start'=>date('Y-m-d',strtotime('next monday')),'week_end'=>date('Y-m-d',strtotime('next sunday')),'prize_pool_sat'=>intval(cfp_get_setting('lottery_prize_sat',2000000)),'status'=>'active']);
            }
        }
        echo '<div style="background:#052e16;border:1px solid #22c55e44;color:#22c55e;padding:12px 16px;border-radius:8px;margin:20px;font-family:sans-serif">✅ Lottery drawn!</div>';
    }
    $lotteries=$wpdb->get_results("SELECT l.*,u.username as winner_name FROM ".CFP_TABLE_LOTTERY." l LEFT JOIN ".CFP_TABLE_USERS." u ON l.winner_user_id=u.id ORDER BY l.id DESC LIMIT 10");
    $active=$wpdb->get_row("SELECT l.*,COUNT(lt.id) as ticket_count FROM ".CFP_TABLE_LOTTERY." l LEFT JOIN ".CFP_TABLE_LOTTERY_TICKETS." lt ON lt.lottery_id=l.id WHERE l.status='active' GROUP BY l.id");
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header"><span class="cfp-logo-badge">⚡ CFP</span><h1>Lottery Management</h1></div>
        <?php if($active): ?>
        <div class="cfp-card">
            <h2>🎟 Active Lottery — Week <?=date('M j',strtotime($active->week_start))?>–<?=date('M j Y',strtotime($active->week_end))?></h2>
            <div class="cfp-3col">
                <div style="text-align:center;background:#111;border-radius:10px;padding:20px"><div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt)">Prize Pool</div><div style="font-size:2rem;font-weight:800;color:var(--g)"><?=number_format($active->prize_pool_sat)?> sat</div></div>
                <div style="text-align:center;background:#111;border-radius:10px;padding:20px"><div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt)">Tickets Sold</div><div style="font-size:2rem;font-weight:800;color:#fff"><?=number_format($active->ticket_count)?></div></div>
                <div style="text-align:center;background:#111;border-radius:10px;padding:20px">
                    <form method="post" onsubmit="return confirm('Draw winner now?')">
                        <?php wp_nonce_field('cfp_lottery'); ?>
                        <input type="hidden" name="lottery_id" value="<?=$active->id?>">
                        <button type="submit" name="cfp_draw_lottery" class="cfp-btn cfp-btn-gold" style="font-size:1rem;padding:14px 24px">🎰 Draw Winner Now</button>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>
        <div class="cfp-card">
            <h2>📋 Lottery History</h2>
            <table class="cfp-table"><thead><tr><th>#</th><th>Week</th><th>Prize</th><th>Winner</th><th>Ticket</th><th>Status</th><th>Drawn</th></tr></thead><tbody>
            <?php foreach($lotteries as $l): ?>
            <tr>
                <td style="color:var(--mt)"><?=$l->id?></td>
                <td><?=date('M j',strtotime($l->week_start))?>–<?=date('M j',strtotime($l->week_end))?></td>
                <td style="color:var(--g);font-weight:700"><?=number_format($l->prize_pool_sat)?> sat</td>
                <td><?=$l->winner_name ? esc_html($l->winner_name) : '-'?></td>
                <td><?=$l->winning_ticket ? intval($l->winning_ticket) : '-'?></td>
                <td><span class="cfp-badge <?=esc_attr($l->status)?>"><?=esc_html(ucfirst($l->status))?></span></td>
                <td style="font-size:.78rem"><?=$l->drawn_at ? esc_html($l->drawn_at) : '-'?></td>
            </tr>
            <?php endforeach; ?>
            </tbody></table>
        </div>
    </div>
    <?php
}

/* ============================================================
   ADMIN: P2P EVENTS
   ============================================================ */
function cfp_admin_p2p() {
    global $wpdb;
    $saved=false;
    if(isset($_POST['cfp_save_event']) && check_admin_referer('cfp_p2p')) {
        $wpdb->insert(CFP_TABLE_P2P,[
            'title'      =>sanitize_text_field($_POST['title']),
            'description'=>sanitize_textarea_field($_POST['description']),
            'option_a'   =>sanitize_text_field($_POST['option_a']),
            'option_b'   =>sanitize_text_field($_POST['option_b']),
            'close_time' =>sanitize_text_field($_POST['close_time']),
            'status'     =>'open',
        ]);
        $saved=true;
    }
    if(isset($_GET['action'],$_GET['id'],$_GET['result']) && check_admin_referer('cfp_p2p_resolve')) {
        $eid=intval($_GET['id']); $result=sanitize_text_field($_GET['result']);
        $event=$wpdb->get_row($wpdb->prepare("SELECT * FROM ".CFP_TABLE_P2P." WHERE id=%d",$eid));
        if($event && $event->status==='open') {
            $wpdb->update(CFP_TABLE_P2P,['status'=>'closed','result'=>$result],['id'=>$eid]);
            $total_a=$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_P2P_BETS." WHERE event_id=%d AND choice='a'",$eid));
            $total_b=$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_P2P_BETS." WHERE event_id=%d AND choice='b'",$eid));
            $total=$total_a+$total_b;
            // P2P house cut: admin earns configurable % of losing side pool
            $p2p_house_pct  = floatval(cfp_get_setting('p2p_house_edge', 5)); // default 5%
            $p2p_multiplier = 1 - ($p2p_house_pct / 100);

            $winners=$wpdb->get_results($wpdb->prepare("SELECT * FROM ".CFP_TABLE_P2P_BETS." WHERE event_id=%d AND choice=%s",$eid,$result));
            $winner_total=$result==='a'?$total_a:$total_b;
            $total_paid_out = 0;
            foreach($winners as $bet) {
                if($winner_total>0) {
                    $payout=floor($bet->amount_sat/$winner_total*$total*$p2p_multiplier);
                    $wpdb->update(CFP_TABLE_P2P_BETS,['status'=>'won','payout_sat'=>$payout],['id'=>$bet->id]);
                    $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_USERS." SET balance_sat=balance_sat+%d WHERE id=%d",$payout,$bet->user_id));
                    $wpdb->insert(CFP_TABLE_TRANSACTIONS,['user_id'=>$bet->user_id,'type'=>'p2p_win','amount_sat'=>$payout,'description'=>"P2P win: {$event->title}"]);
                    $total_paid_out += $payout;
                }
            }
            // Credit house cut (total pot minus all payouts) to admin wallet
            $house_cut = $total - $total_paid_out;
            if ( $house_cut > 0 ) {
                cfp_wallet_credit_game(
                    'admin_wallet_stream_p2p',
                    'p2p_house_cut',
                    $house_cut,
                    "P2P house cut ({$p2p_house_pct}%): event #{$eid} '{$event->title}'. Total pot: {$total} sat, paid out: {$total_paid_out} sat"
                );
            }
            $wpdb->query($wpdb->prepare("UPDATE ".CFP_TABLE_P2P_BETS." SET status='lost' WHERE event_id=%d AND choice!=%s",$eid,$result));
        }
        echo '<script>window.location="'.admin_url('admin.php?page=cfp-p2p').'"</script>'; exit;
    }
    $events=$wpdb->get_results("SELECT p.*,(SELECT COUNT(*) FROM ".CFP_TABLE_P2P_BETS." WHERE event_id=p.id) as bet_count,(SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_P2P_BETS." WHERE event_id=p.id) as total_pot FROM ".CFP_TABLE_P2P." p ORDER BY p.created_at DESC LIMIT 20");
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header"><span class="cfp-logo-badge">⚡ CFP</span><h1>P2P Events</h1></div>
        <?php if($saved): ?><div class="cfp-notice success">✅ Event created!</div><?php endif; ?>
        <div class="cfp-2col">
            <div class="cfp-card">
                <h2>➕ Create New Event</h2>
                <form method="post"><?php wp_nonce_field('cfp_p2p'); ?>
                <div style="display:flex;flex-direction:column;gap:12px">
                    <div class="cfp-field"><label>Event Title</label><input type="text" name="title" placeholder="e.g. BTC above $70k by Dec 2024?" required></div>
                    <div class="cfp-field"><label>Description</label><textarea name="description" rows="3" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px"></textarea></div>
                    <div class="cfp-field"><label>Option A Label</label><input type="text" name="option_a" placeholder="YES" value="YES"></div>
                    <div class="cfp-field"><label>Option B Label</label><input type="text" name="option_b" placeholder="NO" value="NO"></div>
                    <div class="cfp-field"><label>Close Time</label><input type="datetime-local" name="close_time"></div>
                    <button type="submit" name="cfp_save_event" class="cfp-btn cfp-btn-gold">Create Event</button>
                </div>
                </form>
            </div>
            <div class="cfp-card">
                <h2>📋 Active & Past Events</h2>
                <table class="cfp-table"><thead><tr><th>Title</th><th>Bets</th><th>Pot</th><th>Status</th><th>Resolve</th></tr></thead><tbody>
                <?php foreach($events as $e): $n=wp_create_nonce('cfp_p2p_resolve'); ?>
                <tr>
                    <td style="max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=esc_attr($e->title)?>"><?=esc_html(substr($e->title,0,35))?><?=strlen($e->title)>35?'…':''?></td>
                    <td><?=$e->bet_count?></td>
                    <td style="color:var(--g)"><?=number_format($e->total_pot)?> sat</td>
                    <td><span class="cfp-badge <?=$e->status?>"><?=ucfirst($e->status)?></span><?php if($e->result): ?> <span style="font-size:.72rem;color:var(--mt)">(<?=strtoupper($e->result)?>)</span><?php endif; ?></td>
                    <td><?php if($e->status==='open'): ?>
                        <a href="<?=admin_url("admin.php?page=cfp-p2p&action=resolve&id={$e->id}&result=a&_wpnonce=$n")?>" class="cfp-btn cfp-btn-green cfp-btn-sm" onclick="return confirm('Resolve as A?')">A wins</a>
                        <a href="<?=admin_url("admin.php?page=cfp-p2p&action=resolve&id={$e->id}&result=b&_wpnonce=$n")?>" class="cfp-btn cfp-btn-red cfp-btn-sm" onclick="return confirm('Resolve as B?')">B wins</a>
                    <?php else: echo '<span style="color:var(--mt);font-size:.78rem">Resolved</span>'; endif; ?></td>
                </tr>
                <?php endforeach; ?>
                </tbody></table>
            </div>
        </div>
    </div>
    <?php
}

/* ============================================================
   ADMIN: CURRENCY CODE EDITOR
   ============================================================ */
function cfp_admin_currencies() {
    $notice = '';
    $currencies_key = 'cfp_currencies_list';

    // Default currencies pool
    $default_currencies = [
        ['code'=>'BTC','name'=>'Bitcoin','symbol'=>'₿','unit_name'=>'Satoshi','unit_plural'=>'Satoshis','units_per_coin'=>100000000,'color'=>'#f7931a','icon'=>'₿','enabled'=>1],
        ['code'=>'ETH','name'=>'Ethereum','symbol'=>'Ξ','unit_name'=>'Gwei','unit_plural'=>'Gwei','units_per_coin'=>1000000000,'color'=>'#627eea','icon'=>'Ξ','enabled'=>0],
        ['code'=>'LTC','name'=>'Litecoin','symbol'=>'Ł','unit_name'=>'Litoshi','unit_plural'=>'Litoshis','units_per_coin'=>100000000,'color'=>'#bebebe','icon'=>'Ł','enabled'=>0],
        ['code'=>'DOGE','name'=>'Dogecoin','symbol'=>'Ð','unit_name'=>'Koinu','unit_plural'=>'Koinus','units_per_coin'=>100000000,'color'=>'#c2a633','icon'=>'Ð','enabled'=>0],
        ['code'=>'BCH','name'=>'Bitcoin Cash','symbol'=>'BCH','unit_name'=>'Satoshi','unit_plural'=>'Satoshis','units_per_coin'=>100000000,'color'=>'#8dc351','icon'=>'B','enabled'=>0],
        ['code'=>'XRP','name'=>'Ripple','symbol'=>'XRP','unit_name'=>'Drop','unit_plural'=>'Drops','units_per_coin'=>1000000,'color'=>'#00aae4','icon'=>'X','enabled'=>0],
        ['code'=>'SOL','name'=>'Solana','symbol'=>'◎','unit_name'=>'Lamport','unit_plural'=>'Lamports','units_per_coin'=>1000000000,'color'=>'#9945ff','icon'=>'◎','enabled'=>0],
        ['code'=>'BNB','name'=>'BNB','symbol'=>'BNB','unit_name'=>'Jager','unit_plural'=>'Jagers','units_per_coin'=>100000000,'color'=>'#f3ba2f','icon'=>'B','enabled'=>0],
        ['code'=>'ADA','name'=>'Cardano','symbol'=>'₳','unit_name'=>'Lovelace','unit_plural'=>'Lovelaces','units_per_coin'=>1000000,'color'=>'#0033ad','icon'=>'₳','enabled'=>0],
        ['code'=>'TRX','name'=>'TRON','symbol'=>'TRX','unit_name'=>'SUN','unit_plural'=>'SUN','units_per_coin'=>1000000,'color'=>'#ef0027','icon'=>'T','enabled'=>0],
    ];

    // Load saved list, fall back to defaults
    $saved_json = cfp_get_setting($currencies_key, '');
    $currencies  = $saved_json ? json_decode($saved_json, true) : $default_currencies;
    if ( ! is_array($currencies) ) $currencies = $default_currencies;

    // ── Handle: Save all currencies ─────────────────────────
    if ( isset($_POST['cfp_save_currencies']) && check_admin_referer('cfp_currencies') ) {
        $new_list = [];
        $codes    = $_POST['cur_code']    ?? [];
        $names    = $_POST['cur_name']    ?? [];
        $symbols  = $_POST['cur_symbol']  ?? [];
        $units    = $_POST['cur_unit']    ?? [];
        $unitp    = $_POST['cur_unitp']   ?? [];
        $upc      = $_POST['cur_upc']     ?? [];
        $colors   = $_POST['cur_color']   ?? [];
        $icons    = $_POST['cur_icon']    ?? [];
        $enabled  = $_POST['cur_enabled'] ?? [];

        foreach ( $codes as $i => $code ) {
            $code = strtoupper(sanitize_text_field($code));
            if ( empty($code) ) continue;
            $new_list[] = [
                'code'          => $code,
                'name'          => sanitize_text_field($names[$i] ?? ''),
                'symbol'        => sanitize_text_field($symbols[$i] ?? $code),
                'unit_name'     => sanitize_text_field($units[$i] ?? 'Unit'),
                'unit_plural'   => sanitize_text_field($unitp[$i] ?? 'Units'),
                'units_per_coin'=> max(1, intval($upc[$i] ?? 100000000)),
                'color'         => sanitize_hex_color($colors[$i] ?? '#f7931a'),
                'icon'          => sanitize_text_field($icons[$i] ?? $code[0]),
                'enabled'       => isset($enabled[$i]) ? 1 : 0,
            ];
        }
        cfp_update_setting($currencies_key, json_encode($new_list));
        $currencies = $new_list;
        $notice = "<div class='cfp-notice success'>&#9989; Currencies saved! ".count($new_list)." currencies configured.</div>";
    }

    // ── Handle: Add new currency ────────────────────────────
    if ( isset($_POST['cfp_add_currency']) && check_admin_referer('cfp_currencies') ) {
        $new_code = strtoupper(sanitize_text_field($_POST['new_code'] ?? ''));
        if ( $new_code && ! in_array($new_code, array_column($currencies,'code')) ) {
            $currencies[] = [
                'code'          => $new_code,
                'name'          => sanitize_text_field($_POST['new_name'] ?? $new_code),
                'symbol'        => sanitize_text_field($_POST['new_symbol'] ?? $new_code),
                'unit_name'     => sanitize_text_field($_POST['new_unit'] ?? 'Unit'),
                'unit_plural'   => sanitize_text_field($_POST['new_unitp'] ?? 'Units'),
                'units_per_coin'=> max(1, intval($_POST['new_upc'] ?? 100000000)),
                'color'         => sanitize_hex_color($_POST['new_color'] ?? '#f7931a'),
                'icon'          => sanitize_text_field($_POST['new_icon'] ?? $new_code[0]),
                'enabled'       => 1,
            ];
            cfp_update_setting($currencies_key, json_encode($currencies));
            $notice = "<div class='cfp-notice success'>&#9989; Currency <strong>{$new_code}</strong> added!</div>";
        } else {
            $notice = "<div class='cfp-notice error'>&#10060; Invalid or duplicate currency code.</div>";
        }
    }

    // ── Handle: Delete currency ─────────────────────────────
    if ( isset($_GET['del_cur']) && check_admin_referer('cfp_del_cur') ) {
        $del = strtoupper(sanitize_text_field($_GET['del_cur']));
        $currencies = array_values(array_filter($currencies, fn($c) => $c['code'] !== $del));
        cfp_update_setting($currencies_key, json_encode($currencies));
        $notice = "<div class='cfp-notice success'>&#9989; Currency {$del} removed.</div>";
    }

    $active_code = cfp_get_setting('faucet_currency','BTC');
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">&#9889; CFP</span>
            <h1>&#129689; Currency Code Editor</h1>
            <span style="margin-left:auto;font-size:.83rem;color:var(--mt)">Active: <strong style="color:var(--g)"><?=esc_html($active_code)?></strong></span>
        </div>
        <?=$notice?>

        <!-- ══ QUICK ACTIVATE ═══════════════════════════════ -->
        <div class="cfp-card" style="margin-bottom:22px">
            <h2>&#9889; Quick Activate</h2>
            <p style="font-size:.84rem;color:var(--mt);margin:0 0 16px">Click any currency below to instantly set it as the active faucet currency. Changes apply to all shortcodes immediately.</p>
            <div style="display:flex;flex-wrap:wrap;gap:10px">
                <?php foreach($currencies as $c): if(!$c['enabled']) continue; ?>
                <form method="post" action="<?=admin_url('options.php')?>" style="display:inline">
                    <?php settings_fields('cfp_quick_activate'); ?>
                    <a href="<?=admin_url('admin.php?page=cfp-settings')?>"
                       onclick="if(confirm('Switch faucet to <?=esc_js($c['code'])?>?')){cfpActivateCurrency('<?=esc_js($c['code'])?>','<?=esc_js($c['symbol'])?>','<?=esc_js($c['unit_name'])?>');return false;}"
                       style="display:inline-flex;align-items:center;gap:8px;padding:9px 16px;border-radius:9px;text-decoration:none;font-weight:700;font-size:.85rem;border:2px solid <?=$c['code']===$active_code?$c['color']:'#2a2a2a'?>;background:<?=$c['code']===$active_code?$c['color'].'22':'#111'?>;color:<?=$c['code']===$active_code?$c['color']:'#aaa'?>;transition:all .15s"
                       onmouseover="this.style.borderColor='<?=$c['color']?>'" onmouseout="this.style.borderColor='<?=$c['code']===$active_code?$c['color']:'#2a2a2a'?>'">
                        <span style="font-size:1.1rem"><?=esc_html($c['icon'])?></span>
                        <?=esc_html($c['code'])?>
                        <?php if($c['code']===$active_code): ?><span style="background:<?=$c['color']?>;color:#000;padding:1px 7px;border-radius:12px;font-size:.65rem">ACTIVE</span><?php endif; ?>
                    </a>
                </form>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- ══ ADD NEW CURRENCY ═════════════════════════════ -->
        <div class="cfp-card" style="margin-bottom:22px">
            <h2>&#10133; Add New Currency</h2>
            <form method="post">
                <?php wp_nonce_field('cfp_currencies'); ?>
                <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(160px,1fr))">
                    <div class="cfp-field"><label>Code *</label><input type="text" name="new_code" placeholder="e.g. MATIC" maxlength="10" style="text-transform:uppercase"></div>
                    <div class="cfp-field"><label>Full Name *</label><input type="text" name="new_name" placeholder="e.g. Polygon"></div>
                    <div class="cfp-field"><label>Symbol</label><input type="text" name="new_symbol" placeholder="e.g. MATIC" maxlength="8"></div>
                    <div class="cfp-field"><label>Unit Name</label><input type="text" name="new_unit" placeholder="e.g. Wei"></div>
                    <div class="cfp-field"><label>Unit Plural</label><input type="text" name="new_unitp" placeholder="e.g. Weis"></div>
                    <div class="cfp-field"><label>Units per Coin</label><input type="number" name="new_upc" placeholder="e.g. 1000000000000000000" value="100000000"><span class="hint">Smallest divisible unit</span></div>
                    <div class="cfp-field"><label>Brand Color</label><input type="color" name="new_color" value="#f7931a"></div>
                    <div class="cfp-field"><label>Icon / Symbol</label><input type="text" name="new_icon" placeholder="e.g. M" maxlength="4"><span class="hint">1–2 char icon</span></div>
                </div>
                <div style="margin-top:16px">
                    <button type="submit" name="cfp_add_currency" class="cfp-btn cfp-btn-gold">&#10133; Add Currency</button>
                </div>
            </form>
        </div>

        <!-- ══ EDIT ALL CURRENCIES ══════════════════════════ -->
        <div class="cfp-card">
            <h2>&#9998; Edit All Currencies</h2>
            <p style="font-size:.84rem;color:var(--mt);margin:0 0 18px">Edit any field inline and click Save All to apply. Toggle the Enabled switch to show/hide currencies in the Quick Activate panel.</p>

            <form method="post" id="cfp-cur-form">
                <?php wp_nonce_field('cfp_currencies'); ?>
                <div class="cfp-table-wrap">
                <table class="cfp-table" style="min-width:900px">
                    <thead>
                        <tr>
                            <th style="width:40px">&#8597;</th>
                            <th>Code</th>
                            <th>Name</th>
                            <th>Symbol</th>
                            <th>Unit (singular)</th>
                            <th>Unit (plural)</th>
                            <th>Units/Coin</th>
                            <th>Color</th>
                            <th>Icon</th>
                            <th style="width:80px">Enabled</th>
                            <th style="width:70px">Del</th>
                        </tr>
                    </thead>
                    <tbody id="cfp-cur-tbody">
                    <?php foreach($currencies as $i => $c):
                        $is_active = $c['code'] === $active_code;
                        $row_bg    = $is_active ? 'background:#1a1000' : '';
                    ?>
                    <tr style="<?=$row_bg?>" draggable="true" ondragstart="cfpDragStart(event,<?=$i?>)" ondragover="event.preventDefault()" ondrop="cfpDrop(event,<?=$i?>)" id="cfp-row-<?=$i?>">
                        <td style="cursor:grab;color:#333;text-align:center;font-size:1.1rem">&#8942;&#8942;</td>
                        <td>
                            <input type="text" name="cur_code[]" value="<?=esc_attr($c['code'])?>"
                                style="background:#111;border:1px solid<?=$is_active?'var(--g)':'var(--br)'?>;color:<?=$is_active?'var(--g)':'var(--tx)'?>;padding:7px 10px;border-radius:6px;font-size:.85rem;width:80px;font-weight:<?=$is_active?'800':'400'?>;text-transform:uppercase"
                                <?=$is_active?'readonly':''?>>
                            <?php if($is_active): ?><br><span style="font-size:.65rem;color:var(--g);font-weight:700">ACTIVE</span><?php endif; ?>
                        </td>
                        <td><input type="text" name="cur_name[]" value="<?=esc_attr($c['name'])?>" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:7px 10px;border-radius:6px;font-size:.85rem;width:130px"></td>
                        <td><input type="text" name="cur_symbol[]" value="<?=esc_attr($c['symbol'])?>" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:7px 10px;border-radius:6px;font-size:.85rem;width:70px"></td>
                        <td><input type="text" name="cur_unit[]" value="<?=esc_attr($c['unit_name'])?>" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:7px 10px;border-radius:6px;font-size:.85rem;width:90px"></td>
                        <td><input type="text" name="cur_unitp[]" value="<?=esc_attr($c['unit_plural'])?>" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:7px 10px;border-radius:6px;font-size:.85rem;width:90px"></td>
                        <td><input type="number" name="cur_upc[]" value="<?=esc_attr($c['units_per_coin'])?>" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:7px 10px;border-radius:6px;font-size:.82rem;width:110px"></td>
                        <td>
                            <div style="display:flex;align-items:center;gap:7px">
                                <input type="color" name="cur_color[]" value="<?=esc_attr($c['color'] ?? '#f7931a')?>" style="width:36px;height:36px;border-radius:6px;border:1px solid var(--br);background:transparent;cursor:pointer;padding:2px">
                                <span style="font-size:.72rem;color:var(--mt);font-family:monospace" id="cfp-color-txt-<?=$i?>"><?=esc_html($c['color'] ?? '#f7931a')?></span>
                            </div>
                        </td>
                        <td>
                            <input type="text" name="cur_icon[]" value="<?=esc_attr($c['icon'] ?? $c['code'][0])?>" maxlength="4"
                                style="background:<?=esc_attr($c['color'] ?? '#1a1a1a')?>22;border:1px solid <?=esc_attr($c['color'] ?? '#2a2a2a')?>;color:<?=esc_attr($c['color'] ?? '#aaa')?>;padding:7px 10px;border-radius:6px;font-size:.95rem;width:54px;text-align:center;font-weight:700">
                        </td>
                        <td style="text-align:center">
                            <label style="display:inline-flex;align-items:center;cursor:pointer;gap:0">
                                <input type="checkbox" name="cur_enabled[<?=$i?>]" value="1" <?=($c['enabled']?'checked':'')?> style="display:none" id="cfp-tog-<?=$i?>">
                                <div onclick="cfpToggle(<?=$i?>)" id="cfp-tog-bg-<?=$i?>"
                                    style="width:42px;height:22px;border-radius:11px;background:<?=($c['enabled']?'var(--g)':'#2a2a2a')?>;position:relative;transition:background .2s;cursor:pointer;border:1px solid <?=($c['enabled']?'var(--g)':'#333')?>">
                                    <div id="cfp-tog-knob-<?=$i?>" style="width:16px;height:16px;background:#fff;border-radius:50%;position:absolute;top:2px;left:<?=($c['enabled']?'22px':'2px')?>;transition:left .2s"></div>
                                </div>
                            </label>
                        </td>
                        <td style="text-align:center">
                            <?php if(!$is_active): ?>
                            <a href="<?=admin_url("admin.php?page=cfp-currencies&del_cur={$c['code']}&_wpnonce=".wp_create_nonce('cfp_del_cur'))?>"
                               onclick="return confirm('Delete <?=esc_js($c['code'])?>? This cannot be undone.')"
                               class="cfp-btn cfp-btn-red cfp-btn-sm" title="Delete">&#10005;</a>
                            <?php else: ?>
                            <span style="font-size:.68rem;color:#333">Active</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                <div style="display:flex;gap:12px;margin-top:20px;align-items:center">
                    <button type="submit" name="cfp_save_currencies" class="cfp-btn cfp-btn-gold" style="font-size:.95rem;padding:11px 28px">&#128190; Save All Currencies</button>
                    <span style="font-size:.78rem;color:var(--mt)"><?=count($currencies)?> currencies configured &middot; <?=count(array_filter($currencies,fn($c)=>$c['enabled']))?> enabled</span>
                </div>
            </form>
        </div>

        <!-- ══ CURRENCY PREVIEW CARDS ═══════════════════════ -->
        <div class="cfp-card">
            <h2>&#128065;&#65039; Live Preview</h2>
            <p style="font-size:.84rem;color:var(--mt);margin:0 0 18px">How each enabled currency will appear to users on the faucet.</p>
            <div style="display:flex;flex-wrap:wrap;gap:14px">
                <?php foreach($currencies as $c): if(!$c['enabled']) continue; ?>
                <div style="background:#0d0d0d;border:1px solid <?=esc_attr($c['color'] ?? '#2a2a2a')?>44;border-radius:12px;padding:18px 20px;min-width:170px;position:relative;overflow:hidden">
                    <div style="position:absolute;top:0;left:0;right:0;height:3px;background:<?=esc_attr($c['color'] ?? '#f7931a')?>"></div>
                    <div style="font-size:2rem;font-weight:900;color:<?=esc_attr($c['color'] ?? '#f7931a')?>;line-height:1;margin-bottom:8px"><?=esc_html($c['icon'] ?? $c['code'][0])?></div>
                    <div style="font-size:1rem;font-weight:700;color:#fff;margin-bottom:2px"><?=esc_html($c['name'])?></div>
                    <div style="font-size:.72rem;color:#555;text-transform:uppercase;letter-spacing:1px;margin-bottom:8px"><?=esc_html($c['code'])?></div>
                    <div style="font-size:.78rem;color:#666">1 coin = <?=number_format($c['units_per_coin'])?> <?=esc_html($c['unit_plural'])?></div>
                    <?php if($c['code']===$active_code): ?>
                    <div style="margin-top:8px;background:<?=esc_attr($c['color'] ?? '#f7931a')?>22;border:1px solid <?=esc_attr($c['color'] ?? '#f7931a')?>44;border-radius:6px;padding:3px 8px;font-size:.68rem;color:<?=esc_attr($c['color'] ?? '#f7931a')?>;font-weight:700;display:inline-block">ACTIVE FAUCET</div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script>
    // Toggle switch
    function cfpToggle(i){
        var cb=document.getElementById('cfp-tog-'+i);
        var bg=document.getElementById('cfp-tog-bg-'+i);
        var knob=document.getElementById('cfp-tog-knob-'+i);
        cb.checked=!cb.checked;
        bg.style.background=cb.checked?'var(--gr)':'#2a2a2a';
        bg.style.borderColor=cb.checked?'var(--gr)':'#333';
        knob.style.left=cb.checked?'22px':'2px';
    }
    // Quick activate via JS — just redirects to settings with preset values
    function cfpActivateCurrency(code,symbol,unit){
        if(!confirm('Switch active faucet currency to '+code+'?\n\nThis will update all shortcodes immediately.')) return;
        var f=document.createElement('form');
        f.method='POST'; f.action='<?=admin_url('admin-post.php')?>';
        var fields={action:'cfp_quick_activate',code:code,symbol:symbol,unit_name:unit,_wpnonce:'<?=wp_create_nonce('cfp_quick_activate')?>'};
        for(var k in fields){var i=document.createElement('input');i.type='hidden';i.name=k;i.value=fields[k];f.appendChild(i);}
        document.body.appendChild(f); f.submit();
    }
    // Drag-to-reorder (visual only, re-submit to save order)
    var dragIdx=null;
    function cfpDragStart(e,i){dragIdx=i; e.dataTransfer.effectAllowed='move';}
    function cfpDrop(e,i){
        e.preventDefault();
        if(dragIdx===null||dragIdx===i) return;
        var tbody=document.getElementById('cfp-cur-tbody');
        var rows=Array.from(tbody.rows);
        var dragRow=rows[dragIdx];
        var dropRow=rows[i];
        if(dragIdx<i) tbody.insertBefore(dragRow,dropRow.nextSibling);
        else tbody.insertBefore(dragRow,dropRow);
        dragIdx=null;
    }
    </script>
    <?php
}

// Handle quick activate POST
add_action('admin_post_cfp_quick_activate', function(){
    if(!current_user_can('manage_options')||!check_admin_referer('cfp_quick_activate')) wp_die('Unauthorized');
    $code   = strtoupper(sanitize_text_field($_POST['code']??''));
    $symbol = sanitize_text_field($_POST['symbol']??$code);
    $unit   = sanitize_text_field($_POST['unit_name']??'Satoshi');
    if($code){
        cfp_update_setting('faucet_currency',$code);
        cfp_update_setting('currency_symbol',$symbol);
        cfp_update_setting('satoshi_label',$unit);
    }
    wp_redirect(admin_url('admin.php?page=cfp-currencies&activated=1')); exit;
});

/* ============================================================
   ADMIN: FAUCETPAY
   ============================================================ */
