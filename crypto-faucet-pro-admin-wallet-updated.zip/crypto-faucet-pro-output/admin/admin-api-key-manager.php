<?php
/**
 * Admin page: API Key Manager - Manage API keys for external integrations
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: API Key Management
   ============================================================ */
add_action('wp_ajax_cfp_api_keys_data', 'cfp_ajax_api_keys_data');
function cfp_ajax_api_keys_data() {
    check_ajax_referer('cfp_api_keys_nonce', 'nonce');
    
    global $wpdb;
    $action = sanitize_text_field($_POST['sub_action'] ?? 'list');
    
    if($action === 'list') {
        $keys = $wpdb->get_results("
            SELECT * FROM {$wpdb->prefix}cfp_api_keys ORDER BY created_at DESC
        ");
        
        wp_send_json_success(['keys' => $keys]);
    }
    
    if($action === 'create') {
        $name = sanitize_text_field($_POST['name']);
        $permissions = sanitize_text_field($_POST['permissions']);
        $rate_limit = intval($_POST['rate_limit'] ?? 60);
        
        $key = 'cfp_' . bin2hex(random_bytes(16));
        $secret = bin2hex(random_bytes(32));
        $hashed_secret = hash('sha256', $secret);
        
        $wpdb->insert($wpdb->prefix . 'cfp_api_keys', [
            'name' => $name,
            'key' => $key,
            'secret_hash' => $hashed_secret,
            'permissions' => $permissions,
            'rate_limit' => $rate_limit,
            'is_active' => 1,
            'created_at' => current_time('mysql'),
            'expires_at' => date('Y-m-d H:i:s', strtotime('+1 year'))
        ]);
        
        $id = $wpdb->insert_id;
        
        wp_send_json_success([
            'msg' => 'API key created',
            'id' => $id,
            'key' => $key,
            'secret' => $secret
        ]);
    }
    
    if($action === 'regenerate') {
        $id = intval($_POST['id'] ?? 0);
        
        $secret = bin2hex(random_bytes(32));
        $hashed_secret = hash('sha256', $secret);
        
        $wpdb->update($wpdb->prefix . 'cfp_api_keys', [
            'secret_hash' => $hashed_secret,
            'last_regenerated' => current_time('mysql')
        ], ['id' => $id]);
        
        wp_send_json_success(['secret' => $secret]);
    }
    
    if($action === 'toggle') {
        $id = intval($_POST['id'] ?? 0);
        $current = (int)$wpdb->get_var($wpdb->prepare("SELECT is_active FROM {$wpdb->prefix}cfp_api_keys WHERE id = %d", $id));
        $wpdb->update($wpdb->prefix . 'cfp_api_keys', ['is_active' => $current ? 0 : 1], ['id' => $id]);
        wp_send_json_success(['msg' => 'Toggled']);
    }
    
    if($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $wpdb->delete($wpdb->prefix . 'cfp_api_keys', ['id' => $id]);
        wp_send_json_success(['msg' => 'Deleted']);
    }
}

/* ============================================================
   ADMIN: API KEY MANAGER PAGE
   ============================================================ */
function cfp_admin_api_key_manager() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_api_keys_nonce');
    
    $keys = $wpdb->get_results("
        SELECT * FROM {$wpdb->prefix}cfp_api_keys ORDER BY created_at DESC
    ");
    
    $active_keys = count(array_filter($keys, function($k) { return $k->is_active; }));
    $total_usage = (int)$wpdb->get_var("SELECT COALESCE(SUM(request_count), 0) FROM {$wpdb->prefix}cfp_api_keys");
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🔑</span>
            <h1>🔑 API Key Manager</h1>
            <button onclick="cfpShowCreateKeyModal()" class="cfp-btn cfp-btn-gold" style="margin-left:auto">➕ Create Key</button>
        </div>

        <!-- OVERVIEW STATS -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card">
                <div class="label">🔑 Total Keys</div>
                <div class="value"><?=count($keys)?></div>
            </div>
            <div class="cfp-stat-card green">
                <div class="label">✅ Active Keys</div>
                <div class="value"><?=$active_keys?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">📊 Total API Calls</div>
                <div class="value"><?=number_format($total_usage)?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">⏳ Expired</div>
                <div class="value"><?=count(array_filter($keys, function($k) { return strtotime($k->expires_at) < time(); }))?></div>
            </div>
        </div>

        <!-- API KEYS TABLE -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>🔐 Your API Keys</h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Key</th>
                            <th>Permissions</th>
                            <th>Rate Limit</th>
                            <th>Created</th>
                            <th>Expires</th>
                            <th>Usage</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach($keys as $k): 
                        $is_expired = strtotime($k->expires_at) < time();
                    ?>
                        <tr>
                            <td><strong><?=esc_html($k->name)?></strong></td>
                            <td style="font-family:monospace;font-size:.8rem"><?=substr($k->key, 0, 12)?>...</td>
                            <td><span class="cfp-badge <?=$k->permissions === 'admin' ? 'rejected' : 'active'?>"><?=esc_html($k->permissions)?></span></td>
                            <td><?=esc_html($k->rate_limit)?>/min</td>
                            <td style="color:#555;font-size:.8rem"><?=human_time_diff(strtotime($k->created_at), current_time('timestamp'))?> ago</td>
                            <td style="color:<?=$is_expired ? '#ef4444' : '#888'?>;font-size:.8rem"><?=date('M j, Y', strtotime($k->expires_at))?></td>
                            <td style="color:#f7931a;font-weight:700"><?=number_format($k->request_count ?? 0)?></td>
                            <td>
                                <?php if($is_expired): ?>
                                <span class="cfp-badge rejected">Expired</span>
                                <?php else: ?>
                                <span class="cfp-badge <?=$k->is_active ? 'active' : 'rejected'?>"><?=$k->is_active ? 'Active' : 'Disabled'?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button onclick="cfpRegenerateKey(<?=$k->id?>)" class="cfp-btn cfp-btn-sm cfp-btn-ghost">🔄</button>
                                <button onclick="cfpToggleKey(<?=$k->id?>)" class="cfp-btn cfp-btn-sm cfp-btn-ghost"><?=$k->is_active ? 'Disable' : 'Enable'?></button>
                                <button onclick="cfpDeleteKey(<?=$k->id?>)" class="cfp-btn cfp-btn-sm cfp-btn-red">Delete</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($keys)): ?>
                        <tr><td colspan="9" style="text-align:center;padding:40px;color:#555">No API keys created. Click "Create Key" to generate one.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- DOCUMENTATION -->
        <div class="cfp-card">
            <h2>📚 API Documentation</h2>
            <div style="background:#0d0d0d;padding:20px;border-radius:12px;margin-bottom:16px">
                <h3 style="color:#f7931a;margin-bottom:12px">🔗 Making API Requests</h3>
                <p style="color:#888;font-size:.85rem;line-height:1.6;margin-bottom:12px">
                    Include your API key in the request header:
                </p>
                <code style="display:block;background:#111;padding:12px;border-radius:8px;color:#22c55e;font-family:monospace">
Authorization: Bearer YOUR_API_KEY
                </code>
            </div>
            
            <div style="display:grid;grid-template-columns:repeat(2, 1fr);gap:16px">
                <div style="background:#0d0d0d;padding:16px;border-radius:10px">
                    <h4 style="color:#fff;margin-bottom:8px">📋 Available Endpoints</h4>
                    <ul style="color:#888;font-size:.8rem;line-height:1.8;padding-left:20px">
                        <li><code>GET /wp-json/cfp/v1/balance</code> - Get user balance</li>
                        <li><code>GET /wp-json/cfp/v1/claims</code> - Get claim history</li>
                        <li><code>POST /wp-json/cfp/v1/claim</code> - Make a claim</li>
                        <li><code>GET /wp-json/cfp/v1/stats</code> - Get site stats</li>
                    </ul>
                </div>
                <div style="background:#0d0d0d;padding:16px;border-radius:10px">
                    <h4 style="color:#fff;margin-bottom:8px">⚠️ Security Notes</h4>
                    <ul style="color:#888;font-size:.8rem;line-height:1.8;padding-left:20px">
                        <li>Keep your secret key secure!</li>
                        <li>Never expose keys in client-side code</li>
                        <li>Regenerate keys periodically</li>
                        <li>Use HTTPS for all requests</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- CREATE KEY MODAL -->
    <div id="cfp-key-modal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.8);z-index:9999;align-items:center;justify-content:center">
        <div style="background:#161616;border:1px solid #2a2a2a;border-radius:16px;padding:28px;max-width:500px;width:90%">
            <h2 style="color:#fff;margin-bottom:20px;font-size:1.3rem">Create API Key</h2>
            <form id="cfp-key-form">
                <div class="cfp-field">
                    <label>Key Name</label>
                    <input type="text" id="cfp-key-name" placeholder="My API Key" required>
                </div>
                <div class="cfp-field">
                    <label>Permissions</label>
                    <select id="cfp-key-permissions">
                        <option value="read">Read Only</option>
                        <option value="write">Read & Write</option>
                        <option value="admin">Full Admin</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Rate Limit (requests/minute)</label>
                    <input type="number" id="cfp-key-rate" value="60" min="1" max="1000">
                </div>
                <div style="display:flex;gap:12px;margin-top:20px">
                    <button type="submit" class="cfp-btn cfp-btn-gold">Create Key</button>
                    <button type="button" onclick="cfpCloseKeyModal()" class="cfp-btn cfp-btn-ghost">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- SHOW KEY MODAL -->
    <div id="cfp-show-key-modal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.8);z-index:9999;align-items:center;justify-content:center">
        <div style="background:#161616;border:1px solid #2a2a2a;border-radius:16px;padding:28px;max-width:500px;width:90%">
            <h2 style="color:#fff;margin-bottom:20px;font-size:1.3rem">🔐 API Key Created</h2>
            <div style="background:#1a1208;border:1px solid #f7931a33;border-radius:12px;padding:16px;margin-bottom:16px">
                <p style="color:#ef4444;font-weight:700;margin-bottom:12px">⚠️ Save this secret now! It won't be shown again.</p>
                <div style="margin-bottom:12px">
                    <div style="font-size:.7rem;color:#555;text-transform:uppercase;margin-bottom:4px">API Key</div>
                    <code id="new-key-display" style="display:block;background:#111;padding:10px;border-radius:6px;color:#22c55e;font-family:monospace;word-break:break-all"></code>
                </div>
                <div>
                    <div style="font-size:.7rem;color:#555;text-transform:uppercase;margin-bottom:4px">Secret</div>
                    <code id="new-secret-display" style="display:block;background:#111;padding:10px;border-radius:6px;color:#f7931a;font-family:monospace;word-break:break-all"></code>
                </div>
            </div>
            <button onclick="cfpCloseShowKeyModal()" class="cfp-btn cfp-btn-gold" style="width:100%">I've Saved My Keys</button>
        </div>
    </div>

    <script>
    let createdKey = '';
    let createdSecret = '';

    function cfpShowCreateKeyModal() {
        document.getElementById('cfp-key-modal').style.display = 'flex';
    }

    function cfpCloseKeyModal() {
        document.getElementById('cfp-key-modal').style.display = 'none';
    }

    function cfpCloseShowKeyModal() {
        document.getElementById('cfp-show-key-modal').style.display = 'none';
    }

    document.getElementById('cfp-key-form').addEventListener('submit', function(e) {
        e.preventDefault();
        const fd = new FormData();
        fd.append('action', 'cfp_api_keys_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'create');
        fd.append('name', document.getElementById('cfp-key-name').value);
        fd.append('permissions', document.getElementById('cfp-key-permissions').value);
        fd.append('rate_limit', document.getElementById('cfp-key-rate').value);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    cfpCloseKeyModal();
                    createdKey = d.data.key;
                    createdSecret = d.data.secret;
                    document.getElementById('new-key-display').textContent = createdKey;
                    document.getElementById('new-secret-display').textContent = createdSecret;
                    document.getElementById('cfp-show-key-modal').style.display = 'flex';
                }
            });
    });

    function cfpRegenerateKey(id) {
        if(!confirm('Regenerate this API key? The old key will stop working immediately.')) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_api_keys_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'regenerate');
        fd.append('id', id);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    alert('New secret: ' + d.data.secret);
                }
            });
    }

    function cfpToggleKey(id) {
        const fd = new FormData();
        fd.append('action', 'cfp_api_keys_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'toggle');
        fd.append('id', id);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(() => location.reload());
    }

    function cfpDeleteKey(id) {
        if(!confirm('Delete this API key permanently?')) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_api_keys_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'delete');
        fd.append('id', id);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(() => location.reload());
    }
    </script>
    <?php
}