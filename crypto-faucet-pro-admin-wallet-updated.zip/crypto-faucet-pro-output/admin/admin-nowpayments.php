<?php
/**
 * Admin page: NOWPayments integration config, stats, and deposit/withdrawal history.
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_nowpayments() {
    global $wpdb;
    $notice = '';

    // ── SAVE SETTINGS ──────────────────────────────────────────
    if ( isset( $_POST['cfp_save_np'] ) && check_admin_referer( 'cfp_nowpayments' ) ) {
        $fields = [
            'np_enabled', 'np_api_key', 'np_ipn_secret', 'np_currency',
            'np_min_deposit_usd', 'np_min_withdraw_sat', 'np_fee_sat',
            'np_sat_per_usd',
            'trezor_active_address', 'trezor_auto_sweep_enabled', 'trezor_email_on_sweep',
        ];
        // Threshold has its own floor/ceiling validation
        if ( isset( $_POST['trezor_sweep_threshold'] ) ) {
            cfp_update_setting( 'trezor_sweep_threshold', min( 100000000, max( 10000, absint( $_POST['trezor_sweep_threshold'] ) ) ) );
        }
        foreach ( $fields as $f ) {
            if ( isset( $_POST[$f] ) ) cfp_update_setting( $f, sanitize_text_field( $_POST[$f] ) );
        }
        delete_transient( 'cfp_np_currencies' );
        $notice = "<div class='cfp-notice success'>✅ NOWPayments settings saved!</div>";
    }

    // ── CLEAR IPN LOG ───────────────────────────────────────────
    if ( isset( $_POST['cfp_clear_np_ipn_log'] ) && check_admin_referer( 'cfp_clear_np_ipn_log' ) ) {
        delete_option( 'cfp_np_ipn_failure_log' );
        $notice = "<div class='cfp-notice success'>✅ IPN failure log cleared.</div>";
    }

    // ── MANUAL RETRY FAILED PAYOUT ──────────────────────────────
    if ( isset( $_GET['np_retry'], $_GET['id'] ) && check_admin_referer( 'cfp_np_retry' ) ) {
        $rec_id = intval( $_GET['id'] );
        $rec    = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . CFP_TABLE_NP_WITHDRAWALS . " WHERE id=%d AND status='failed'", $rec_id
        ) );
        if ( $rec ) {
            $res = cfp_np_send_payout( $rec->to_address, $rec->pay_amount, $rec->currency, "cfp_user_{$rec->user_id}" );
            if ( ! empty( $res['withdrawals'][0]['id'] ) ) {
                $np_id = $res['withdrawals'][0]['id'];
                $wpdb->update( CFP_TABLE_NP_WITHDRAWALS,
                    ['status' => 'pending', 'np_payout_id' => $np_id, 'np_response' => json_encode( $res ), 'processed_at' => current_time( 'mysql' )],
                    ['id' => $rec_id]
                );
                $notice = "<div class='cfp-notice success'>✅ Retry submitted! Payout ID: {$np_id}</div>";
            } else {
                $err    = $res['error'] ?? 'Unknown NOWPayments error.';
                $notice = "<div class='cfp-notice error'>❌ Retry failed: " . esc_html( $err ) . "</div>";
            }
        }
    }

    // ── LOAD CURRENT SETTINGS ───────────────────────────────────
    $np_enabled      = cfp_get_setting( 'np_enabled',         '0' );
    $api_key         = cfp_get_setting( 'np_api_key',         '' );
    $ipn_secret      = cfp_get_setting( 'np_ipn_secret',      '' );
    $np_currency     = cfp_get_setting( 'np_currency',        'btc' );
    $min_dep_usd     = cfp_get_setting( 'np_min_deposit_usd', '1' );
    $min_wd_sat      = cfp_get_setting( 'np_min_withdraw_sat','10000' );
    $fee_sat         = cfp_get_setting( 'np_fee_sat',         '0' );
    $sat_per_usd     = cfp_get_setting( 'np_sat_per_usd',     '0' );

    // ── STATS ───────────────────────────────────────────────────
    $total_deps    = $wpdb->get_var( "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_NP_DEPOSITS . " WHERE status='credited'" );
    $count_deps    = $wpdb->get_var( "SELECT COUNT(*) FROM " . CFP_TABLE_NP_DEPOSITS . " WHERE status='credited'" );
    $total_wds     = $wpdb->get_var( "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_NP_WITHDRAWALS . " WHERE status='paid'" );
    $count_wds     = $wpdb->get_var( "SELECT COUNT(*) FROM " . CFP_TABLE_NP_WITHDRAWALS . " WHERE status='paid'" );
    $pending_wds   = $wpdb->get_var( "SELECT COUNT(*) FROM " . CFP_TABLE_NP_WITHDRAWALS . " WHERE status='pending'" );
    $failed_wds    = $wpdb->get_var( "SELECT COUNT(*) FROM " . CFP_TABLE_NP_WITHDRAWALS . " WHERE status='failed'" );

    // ── LIVE NP BALANCE ─────────────────────────────────────────
    $np_balance_data = null;
    if ( $np_enabled && $api_key ) {
        $np_balance_data = cfp_np_get_balance();
    }

    // ── RECENT ACTIVITY ─────────────────────────────────────────
    $recent_deps = $wpdb->get_results( "
        SELECT d.*,u.username,u.email FROM " . CFP_TABLE_NP_DEPOSITS . " d
        LEFT JOIN " . CFP_TABLE_USERS . " u ON d.user_id=u.id
        ORDER BY d.created_at DESC LIMIT 10
    " );
    $recent_wds = $wpdb->get_results( "
        SELECT w.*,u.username FROM " . CFP_TABLE_NP_WITHDRAWALS . " w
        LEFT JOIN " . CFP_TABLE_USERS . " u ON w.user_id=u.id
        ORDER BY w.requested_at DESC LIMIT 10
    " );
    $failed_list = $wpdb->get_results( "
        SELECT w.*,u.username FROM " . CFP_TABLE_NP_WITHDRAWALS . " w
        LEFT JOIN " . CFP_TABLE_USERS . " u ON w.user_id=u.id
        WHERE w.status='failed' ORDER BY w.requested_at DESC LIMIT 10
    " );

    $ipn_url  = rest_url( 'cfp/v1/nowpayments-ipn' );
    $ipn_url2 = home_url( '/?cfp_np_ipn=1' );
    $ipn_log  = get_option( 'cfp_np_ipn_failure_log', [] );
    ?>
    <div class="cfp-wrap">

        <!-- HEADER -->
        <div class="cfp-header">
            <span class="cfp-logo-badge" style="background:#7b3fe4">NP</span>
            <h1>🪙 NOWPayments Integration</h1>
            <span style="margin-left:auto">
                <?php if ( $np_enabled ): ?>
                    <span class="cfp-badge active">● NOWPayments LIVE</span>
                <?php else: ?>
                    <span class="cfp-badge banned">● NOWPayments DISABLED</span>
                <?php endif; ?>
            </span>
        </div>

        <?= $notice ?>

        <!-- STATS CARDS -->
        <div class="cfp-stats-grid">
            <div class="cfp-stat-card green">
                <div class="label">Total Deposited</div>
                <div class="value"><?= number_format( $total_deps ) ?></div>
                <div class="sub"><?= number_format( $count_deps ) ?> deposits · sat</div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">Total Withdrawn</div>
                <div class="value"><?= number_format( $total_wds ) ?></div>
                <div class="sub"><?= number_format( $count_wds ) ?> payouts · sat</div>
            </div>
            <div class="cfp-stat-card" style="--c:#f7931a">
                <div class="label">Pending Payouts</div>
                <div class="value"><?= number_format( $pending_wds ) ?></div>
                <div class="sub">Awaiting NOWPayments</div>
            </div>
            <div class="cfp-stat-card red">
                <div class="label">Failed Payouts</div>
                <div class="value"><?= number_format( $failed_wds ) ?></div>
                <div class="sub">Need attention</div>
            </div>
            <?php if ( $np_balance_data && ! empty( $np_balance_data['currencies'] ) ): ?>
            <div class="cfp-stat-card purple">
                <div class="label">NP Account Balance</div>
                <div class="value" style="font-size:1rem;line-height:1.7">
                    <?php foreach ( array_slice( $np_balance_data['currencies'], 0, 3 ) as $curr => $bal ): ?>
                        <div><?= esc_html( number_format( $bal, 8 ) ) ?> <?= strtoupper( esc_html( $curr ) ) ?></div>
                    <?php endforeach; ?>
                </div>
                <div class="sub">Live from NOWPayments</div>
            </div>
            <?php endif; ?>
        </div>

        <div class="cfp-2col">

            <!-- SETTINGS FORM -->
            <div>
                <div class="cfp-card">
                    <h2>⚙️ API Configuration</h2>
                    <form method="post">
                        <?php wp_nonce_field( 'cfp_nowpayments' ); ?>
                        <div class="cfp-form-grid">

                            <div class="cfp-field" style="grid-column:1/-1">
                                <label>Enable NOWPayments</label>
                                <select name="np_enabled">
                                    <option value="1" <?= selected( $np_enabled, '1', false ) ?>>✅ Enabled</option>
                                    <option value="0" <?= selected( $np_enabled, '0', false ) ?>>❌ Disabled</option>
                                </select>
                                <div class="hint">Enables the NOWPayments deposit &amp; withdrawal tab for users.</div>
                            </div>

                            <div class="cfp-field" style="grid-column:1/-1">
                                <label>API Key</label>
                                <input type="text" name="np_api_key" value="<?= esc_attr( $api_key ) ?>" placeholder="Your NOWPayments API key" autocomplete="off">
                                <div class="hint">Get this from <a href="https://nowpayments.io/merchant" target="_blank" style="color:var(--g)">NOWPayments Dashboard → Store Settings</a>.</div>
                            </div>

                            <div class="cfp-field" style="grid-column:1/-1">
                                <label>IPN Secret Key</label>
                                <input type="text" name="np_ipn_secret" value="<?= esc_attr( $ipn_secret ) ?>" placeholder="IPN secret for HMAC verification" autocomplete="off">
                                <div class="hint">Set this in NOWPayments → Store Settings → IPN Secret. Used to verify all IPN calls via HMAC-SHA512.</div>
                            </div>

                            <div class="cfp-field">
                                <label>Default Payout Currency</label>
                                <input type="text" name="np_currency" value="<?= esc_attr( $np_currency ) ?>" placeholder="btc">
                                <div class="hint">Lowercase ticker: btc, eth, ltc, usdt, etc.</div>
                            </div>

                            <div class="cfp-field">
                                <label>Sat-per-USD Rate</label>
                                <input type="number" name="np_sat_per_usd" value="<?= esc_attr( $sat_per_usd ) ?>" placeholder="e.g. 1700000" min="0">
                                <div class="hint">How many sats = $1 USD. Used to convert deposit/withdrawal amounts. Set 0 to use live BTC price.</div>
                            </div>

                            <div class="cfp-field">
                                <label>Min Deposit (USD)</label>
                                <input type="number" name="np_min_deposit_usd" value="<?= esc_attr( $min_dep_usd ) ?>" step="0.01" min="0">
                                <div class="hint">Minimum deposit amount in USD equivalent.</div>
                            </div>

                            <div class="cfp-field">
                                <label>Min Withdrawal (sat)</label>
                                <input type="number" name="np_min_withdraw_sat" value="<?= esc_attr( $min_wd_sat ) ?>" min="0">
                            </div>

                            <div class="cfp-field">
                                <label>Withdrawal Fee (sat)</label>
                                <input type="number" name="np_fee_sat" value="<?= esc_attr( $fee_sat ) ?>" min="0">
                                <div class="hint">Fee deducted from user balance on withdrawal. Goes to admin wallet.</div>
                            </div>

                        </div>

                                            <div class="cfp-field" style="grid-column:1/-1;border-top:1px solid #1a1a1a;padding-top:18px;margin-top:6px">
                                <label style="font-size:.9rem;font-weight:700;color:#1dc928">🔐 Trezor Auto-Sweep</label>
                                <div class="hint" style="margin-bottom:12px">Configure how admin wallet earnings are automatically swept to your Trezor hardware wallet.</div>
                            </div>

                            <div class="cfp-field" style="grid-column:1/-1">
                                <label>Trezor Receiving Address</label>
                                <input type="text" name="trezor_active_address"
                                    value="<?= esc_attr( cfp_get_setting( 'trezor_active_address', '' ) ) ?>"
                                    placeholder="bc1q… or 1… or 3…"
                                    style="font-family:monospace">
                                <div class="hint">
                                    Your Trezor's Bitcoin receiving address. This address must be
                                    <strong>whitelisted in your NOWPayments account</strong>:
                                    NOWPayments → Store Settings → Whitelisted Addresses.
                                </div>
                            </div>

                            <div class="cfp-field">
                                <label>Auto-Sweep Threshold (sat)</label>
                                <input type="number" name="trezor_sweep_threshold"
                                    value="<?= esc_attr( cfp_get_setting( 'trezor_sweep_threshold', '100000' ) ) ?>"
                                    min="10000" max="100000000" step="1000">
                                <div class="hint">
                                    Auto-sweep fires via NOWPayments when pending balance reaches this amount.
                                    Default: 100,000 sat (0.001 BTC). Min: 10,000 sat.
                                </div>
                            </div>

                            <div class="cfp-field">
                                <label>Auto-Sweep</label>
                                <select name="trezor_auto_sweep_enabled">
                                    <option value="1" <?= selected( cfp_get_setting( 'trezor_auto_sweep_enabled', '1' ), '1', false ) ?>>✅ Enabled — sweep automatically on threshold</option>
                                    <option value="0" <?= selected( cfp_get_setting( 'trezor_auto_sweep_enabled', '1' ), '0', false ) ?>>❌ Disabled — manual only</option>
                                </select>
                                <div class="hint">When enabled, the plugin calls NOWPayments Mass Payout API automatically whenever pending balance ≥ threshold.</div>
                            </div>

                            <div class="cfp-field">
                                <label>Email on Sweep</label>
                                <select name="trezor_email_on_sweep">
                                    <option value="1" <?= selected( cfp_get_setting( 'trezor_email_on_sweep', '1' ), '1', false ) ?>>✅ Send email on sweep / failure</option>
                                    <option value="0" <?= selected( cfp_get_setting( 'trezor_email_on_sweep', '1' ), '0', false ) ?>>❌ No email notifications</option>
                                </select>
                            </div>

                        <div style="margin-top:20px">
                            <button type="submit" name="cfp_save_np" class="cfp-btn cfp-btn-gold">💾 Save NOWPayments Settings</button>
                            <a href="<?= esc_url( admin_url( 'admin.php?page=cfp-wallet&wstab=trezor_sweep' ) ) ?>"
                               class="cfp-btn cfp-btn-ghost" style="margin-left:10px">
                                🔐 Open Trezor Sweep Dashboard →
                            </a>
                        </div>
                    </form>
                </div>

                <!-- IPN ENDPOINT INFO -->
                <div class="cfp-card">
                    <h2>🔗 IPN Callback URL</h2>
                    <p style="font-size:.82rem;color:var(--mt);margin-bottom:12px">Add one of these URLs to your NOWPayments store settings as the IPN Callback URL. NOWPayments will POST payment status updates to it.</p>

                    <div style="margin-bottom:12px">
                        <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--mt);margin-bottom:4px">REST API (Recommended)</div>
                        <div style="background:#111;border:1px solid var(--br);padding:10px 13px;border-radius:8px;font-family:monospace;font-size:.8rem;color:#22c55e;word-break:break-all">
                            <?= esc_html( $ipn_url ) ?>
                        </div>
                    </div>

                    <div>
                        <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:var(--mt);margin-bottom:4px">Query String (Fallback)</div>
                        <div style="background:#111;border:1px solid var(--br);padding:10px 13px;border-radius:8px;font-family:monospace;font-size:.8rem;color:#3b82f6;word-break:break-all">
                            <?= esc_html( $ipn_url2 ) ?>
                        </div>
                    </div>

                    <div style="margin-top:14px;padding:12px;background:#0d0d0d;border:1px solid #1a1a1a;border-radius:8px;font-size:.78rem;color:var(--mt);line-height:1.6">
                        <strong style="color:#f7931a">⚠️ Security:</strong> Always set an IPN Secret Key and configure it in both NOWPayments and this plugin. The plugin verifies every IPN request with HMAC-SHA512 to prevent fake deposit notifications.
                    </div>
                </div>
            </div>

            <!-- ACTIVITY PANELS -->
            <div>

                <!-- HOW IT WORKS -->
                <div class="cfp-card">
                    <h2>📖 How It Works</h2>
                    <div style="display:grid;gap:12px">
                        <?php
                        $steps = [
                            ['🪙','Deposits','User clicks Deposit → selects currency → plugin creates a NOWPayments invoice → user sends crypto to the given address → NOWPayments sends an IPN → balance credited automatically.'],
                            ['💸','Withdrawals','User enters wallet address + amount → plugin calls NOWPayments Mass Payout API → funds sent on-chain → IPN updates the record status. Supports any coin NOWPayments supports.'],
                            ['🔐','Security','IPN requests are verified with HMAC-SHA512 using your IPN Secret. Duplicate payment IDs are rejected. Failed payouts are automatically refunded to the user balance.'],
                        ];
                        foreach ( $steps as [$icon,$title,$desc] ): ?>
                        <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px;padding:14px;display:flex;gap:12px">
                            <div style="font-size:1.4rem"><?= $icon ?></div>
                            <div>
                                <div style="font-size:.86rem;font-weight:700;color:#fff;margin-bottom:4px"><?= $title ?></div>
                                <div style="font-size:.76rem;color:#555;line-height:1.55"><?= $desc ?></div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- IPN FAILURE LOG -->
                <?php if ( ! empty( $ipn_log ) ): ?>
                <div class="cfp-card" style="border-color:#ef444433">
                    <h2 style="color:var(--rd);display:flex;justify-content:space-between;align-items:center">
                        ⚠️ IPN Failure Log
                        <form method="post" style="display:inline">
                            <?php wp_nonce_field( 'cfp_clear_np_ipn_log' ); ?>
                            <button type="submit" name="cfp_clear_np_ipn_log" class="cfp-btn cfp-btn-ghost cfp-btn-sm">🗑 Clear</button>
                        </form>
                    </h2>
                    <div style="max-height:200px;overflow-y:auto">
                        <?php foreach ( array_slice( $ipn_log, 0, 20 ) as $entry ): ?>
                        <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:6px;padding:9px 12px;margin-bottom:6px;font-size:.74rem">
                            <span style="color:var(--rd);font-weight:600"><?= esc_html( $entry['reason'] ) ?></span>
                            <span style="color:var(--mt);margin-left:8px"><?= esc_html( $entry['time'] ) ?></span>
                            <div style="color:#444;font-family:monospace;margin-top:3px"><?= esc_html( json_encode( $entry['fields'] ) ) ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

            </div>
        </div>

        <!-- RECENT DEPOSITS -->
        <?php if ( ! empty( $recent_deps ) ): ?>
        <div class="cfp-card">
            <h2>📥 Recent Deposits</h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead><tr><th>User</th><th>Payment ID</th><th>Currency</th><th>Paid</th><th>Credited (sat)</th><th>Status</th><th>Time</th></tr></thead>
                    <tbody>
                    <?php foreach ( $recent_deps as $d ):
                        $badge = $d->status === 'credited' ? 'approved' : ( $d->status === 'failed' ? 'rejected' : 'pending' );
                    ?>
                    <tr>
                        <td><strong><?= esc_html( $d->username ?? "#{$d->user_id}" ) ?></strong><br><span style="font-size:.7rem;color:var(--mt)"><?= esc_html( $d->email ?? '' ) ?></span></td>
                        <td style="font-family:monospace;font-size:.72rem;color:var(--mt)"><?= esc_html( substr( $d->np_payment_id, 0, 18 ) ) ?>…</td>
                        <td><span style="font-weight:700;color:var(--g)"><?= strtoupper( esc_html( $d->currency ) ) ?></span></td>
                        <td><?= esc_html( $d->pay_amount ) ?></td>
                        <td style="font-weight:700;color:var(--gr)"><?= number_format( $d->amount_sat ) ?></td>
                        <td><span class="cfp-badge <?= $badge ?>"><?= esc_html( $d->status ) ?></span></td>
                        <td style="font-size:.74rem;color:var(--mt)"><?= esc_html( substr( $d->created_at ?? '', 0, 16 ) ) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- RECENT WITHDRAWALS -->
        <?php if ( ! empty( $recent_wds ) ): ?>
        <div class="cfp-card">
            <h2>📤 Recent Withdrawals</h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead><tr><th>User</th><th>Address</th><th>Currency</th><th>Crypto Amount</th><th>Sat</th><th>Status</th><th>Payout ID</th><th>Time</th></tr></thead>
                    <tbody>
                    <?php foreach ( $recent_wds as $w ):
                        $badge = $w->status === 'paid' ? 'approved' : ( $w->status === 'failed' ? 'rejected' : 'pending' );
                    ?>
                    <tr>
                        <td><strong><?= esc_html( $w->username ?? "#{$w->user_id}" ) ?></strong></td>
                        <td style="font-size:.72rem;font-family:monospace;color:var(--mt)"><?= esc_html( substr( $w->to_address, 0, 20 ) ) ?>…</td>
                        <td><span style="font-weight:700;color:var(--g)"><?= strtoupper( esc_html( $w->currency ) ) ?></span></td>
                        <td><?= esc_html( $w->pay_amount ) ?></td>
                        <td style="color:var(--rd);font-weight:700"><?= number_format( $w->amount_sat ) ?></td>
                        <td><span class="cfp-badge <?= $badge ?>"><?= esc_html( $w->status ) ?></span></td>
                        <td style="font-size:.72rem;font-family:monospace;color:var(--mt)"><?= esc_html( substr( $w->np_payout_id ?? '–', 0, 16 ) ) ?></td>
                        <td style="font-size:.74rem;color:var(--mt)"><?= esc_html( substr( $w->requested_at ?? '', 0, 16 ) ) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- FAILED PAYOUTS RETRY -->
        <?php if ( ! empty( $failed_list ) ): ?>
        <div class="cfp-card" style="border-color:#ef444433">
            <h2 style="color:var(--rd)">⚠️ Failed Payouts — Needs Attention</h2>
            <table class="cfp-table">
                <thead><tr><th>User</th><th>Amount</th><th>Address</th><th>Currency</th><th>Error</th><th>Retry</th></tr></thead>
                <tbody>
                <?php foreach ( $failed_list as $f ):
                    $np_resp = json_decode( $f->np_response, true );
                    $err_msg = $np_resp['error'] ?? ( $np_resp['message'] ?? 'Unknown' );
                    $n = wp_create_nonce( 'cfp_np_retry' );
                ?>
                <tr>
                    <td><strong><?= esc_html( $f->username ?? "#{$f->user_id}" ) ?></strong></td>
                    <td style="color:var(--rd);font-weight:700"><?= number_format( $f->amount_sat ) ?> sat</td>
                    <td style="font-size:.72rem;font-family:monospace;color:var(--mt)"><?= esc_html( substr( $f->to_address, 0, 22 ) ) ?></td>
                    <td><?= strtoupper( esc_html( $f->currency ) ) ?></td>
                    <td style="font-size:.74rem;color:#ef4444"><?= esc_html( substr( $err_msg, 0, 50 ) ) ?></td>
                    <td>
                        <a href="<?= admin_url( "admin.php?page=cfp-nowpayments&np_retry=1&id={$f->id}&_wpnonce={$n}" ) ?>"
                           class="cfp-btn cfp-btn-gold cfp-btn-sm"
                           onclick="return confirm('Retry this payout via NOWPayments?')">⟳ Retry</a>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php endif; ?>

    </div>
    <?php
}
