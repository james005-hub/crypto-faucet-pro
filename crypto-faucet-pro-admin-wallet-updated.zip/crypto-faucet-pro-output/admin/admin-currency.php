<?php
/**
 * Admin page: Currency / multi-coin settings
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_currency() {
    $saved = false;

    // Built-in coin library
    $coins = [
        'BTC'  => ['name'=>'Bitcoin',     'symbol'=>'₿',  'icon'=>'₿',  'color'=>'#f7931a','bg'=>'#1a1000','unit'=>'Satoshi',    'decimals'=>8,'explorer'=>'https://blockchair.com/bitcoin/transaction/'],
        'ETH'  => ['name'=>'Ethereum',    'symbol'=>'Ξ',  'icon'=>'Ξ',  'color'=>'#627eea','bg'=>'#0a0a1a','unit'=>'Gwei',       'decimals'=>18,'explorer'=>'https://etherscan.io/tx/'],
        'LTC'  => ['name'=>'Litecoin',    'symbol'=>'Ł',  'icon'=>'Ł',  'color'=>'#bfbbbb','bg'=>'#141414','unit'=>'Litoshi',    'decimals'=>8,'explorer'=>'https://blockchair.com/litecoin/transaction/'],
        'DOGE' => ['name'=>'Dogecoin',    'symbol'=>'Ð',  'icon'=>'Ð',  'color'=>'#c3a634','bg'=>'#1a1700','unit'=>'Koinu',      'decimals'=>8,'explorer'=>'https://dogechain.info/tx/'],
        'BCH'  => ['name'=>'Bitcoin Cash','symbol'=>'Ƀ',  'icon'=>'Ƀ',  'color'=>'#8dc351','bg'=>'#0d1a00','unit'=>'Satoshi',    'decimals'=>8,'explorer'=>'https://blockchair.com/bitcoin-cash/transaction/'],
        'XRP'  => ['name'=>'Ripple',      'symbol'=>'✕',  'icon'=>'✕',  'color'=>'#00aae4','bg'=>'#001a22','unit'=>'Drop',       'decimals'=>6,'explorer'=>'https://xrpscan.com/tx/'],
        'SOL'  => ['name'=>'Solana',      'symbol'=>'◎',  'icon'=>'◎',  'color'=>'#9945ff','bg'=>'#110022','unit'=>'Lamport',    'decimals'=>9,'explorer'=>'https://solscan.io/tx/'],
        'BNB'  => ['name'=>'BNB',         'symbol'=>'⬡',  'icon'=>'⬡',  'color'=>'#f3ba2f','bg'=>'#1a1400','unit'=>'Jager',      'decimals'=>8,'explorer'=>'https://bscscan.com/tx/'],
        'ADA'  => ['name'=>'Cardano',     'symbol'=>'₳',  'icon'=>'₳',  'color'=>'#0033ad','bg'=>'#000a1a','unit'=>'Lovelace',   'decimals'=>6,'explorer'=>'https://cardanoscan.io/transaction/'],
        'TRX'  => ['name'=>'TRON',        'symbol'=>'T',  'icon'=>'T',  'color'=>'#ef0027','bg'=>'#1a0000','unit'=>'Sun',        'decimals'=>6,'explorer'=>'https://tronscan.org/#/transaction/'],
        'MATIC'=> ['name'=>'Polygon',     'symbol'=>'⬟',  'icon'=>'⬟',  'color'=>'#8247e5','bg'=>'#0e0022','unit'=>'Wei',        'decimals'=>18,'explorer'=>'https://polygonscan.com/tx/'],
        'SHIB' => ['name'=>'Shiba Inu',   'symbol'=>'🐕', 'icon'=>'🐕', 'color'=>'#e63800','bg'=>'#1a0800','unit'=>'Bone',       'decimals'=>18,'explorer'=>'https://etherscan.io/tx/'],
    ];

    // Handle save
    if(isset($_POST['cfp_save_currency']) && check_admin_referer('cfp_currency')) {
        $code      = strtoupper(sanitize_text_field($_POST['currency_code']??'BTC'));
        $name      = sanitize_text_field($_POST['currency_name']??'');
        $symbol    = sanitize_text_field($_POST['currency_symbol']??'');
        $unit      = sanitize_text_field($_POST['satoshi_label']??'Satoshi');
        $color     = sanitize_hex_color($_POST['primary_color']??'#f7931a');
        $accent    = sanitize_hex_color($_POST['accent_color']??'#ffcc02');
        $explorer  = esc_url_raw($_POST['explorer_url']??'');
        $decimals  = intval($_POST['decimals']??8);
        $min_claim = intval($_POST['min_claim_sat']??98);
        $max_claim = intval($_POST['max_claim_sat']??200);
        $min_wd    = intval($_POST['min_withdraw_sat']??30000);
        $wd_fee    = intval($_POST['withdraw_fee_sat']??1000);
        $apy       = floatval($_POST['savings_apy']??4.08);

        cfp_update_setting('faucet_currency',  $code);
        cfp_update_setting('currency_symbol',  $symbol);
        cfp_update_setting('satoshi_label',    $unit);
        cfp_update_setting('primary_color',    $color);
        cfp_update_setting('accent_color',     $accent);
        cfp_update_setting('min_claim_sat',    $min_claim);
        cfp_update_setting('max_claim_sat',    $max_claim);
        cfp_update_setting('min_withdraw_sat', $min_wd);
        cfp_update_setting('withdraw_fee_sat', $wd_fee);
        cfp_update_setting('savings_apy',      $apy);
        if($explorer) cfp_update_setting('explorer_url', $explorer);
        // Also update faucet_name if custom
        if($name) cfp_update_setting('faucet_name', 'Free'.$code.'.in');
        $saved = true;
    }

    $current_code = cfp_get_setting('faucet_currency','BTC');
    $current_coin = $coins[$current_code] ?? $coins['BTC'];
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">⚡ CFP</span>
            <h1>🪙 Cryptocurrency Code Editor</h1>
            <div style="margin-left:auto;display:flex;align-items:center;gap:10px">
                <span style="font-size:.82rem;color:var(--mt)">Active:</span>
                <span style="background:var(--g);color:#000;font-weight:900;padding:5px 14px;border-radius:6px;font-size:.85rem"><?=$current_code?></span>
            </div>
        </div>

        <?php if($saved): ?>
        <div class="cfp-notice success">✅ Currency settings saved! Your faucet now uses <strong><?=esc_html(cfp_get_setting('faucet_currency','BTC'))?></strong>.</div>
        <?php endif; ?>

        <!-- COIN SELECTOR GRID -->
        <div class="cfp-card">
            <h2>🌐 Select Cryptocurrency</h2>
            <p style="font-size:.83rem;color:var(--mt);margin-bottom:18px">Click any coin to auto-fill all settings, or configure manually below.</p>
            <div class="cfp-currency-grid">
                <?php foreach($coins as $code=>$coin): ?>
                <div class="cfp-coin-card <?=$code===$current_code?'active-coin':''?>" onclick="cfpLoadCoin('<?=$code?>')" id="coin-card-<?=$code?>">
                    <?php if($code===$current_code): ?><span class="cfp-active-badge">Active</span><?php endif; ?>
                    <div class="coin-icon" style="background:<?=$coin['bg']?>;color:<?=$coin['color']?>;font-size:1.4rem;font-weight:900;border:1px solid <?=$coin['color']?>33">
                        <?=$coin['icon']?>
                    </div>
                    <div style="font-size:.95rem;font-weight:700;color:#fff;margin-bottom:2px"><?=$coin['name']?></div>
                    <div style="font-size:.72rem;color:var(--mt);text-transform:uppercase;letter-spacing:1px"><?=$code?></div>
                    <div style="margin-top:7px;display:flex;align-items:center;gap:5px">
                        <span style="width:10px;height:10px;border-radius:50%;background:<?=$coin['color']?>;display:inline-block;flex-shrink:0"></span>
                        <span style="font-size:.72rem;color:var(--mt)"><?=$coin['unit']?></span>
                    </div>
                </div>
                <?php endforeach; ?>

                <!-- Custom coin card -->
                <div class="cfp-coin-card" onclick="cfpLoadCoin('CUSTOM')" id="coin-card-CUSTOM" style="border-style:dashed">
                    <div class="coin-icon" style="background:#111;color:var(--mt);font-size:1.2rem;border:1px dashed #333">+</div>
                    <div style="font-size:.95rem;font-weight:700;color:var(--mt);margin-bottom:2px">Custom Token</div>
                    <div style="font-size:.72rem;color:#444;text-transform:uppercase;letter-spacing:1px">Configure manually</div>
                </div>
            </div>
        </div>

        <!-- EDITOR FORM -->
        <div class="cfp-2col">
            <form method="post" id="cfp-currency-form">
                <?php wp_nonce_field('cfp_currency'); ?>
                <div class="cfp-card">
                    <h2>✏️ Currency Configuration</h2>
                    <div style="display:flex;flex-direction:column;gap:14px">

                        <div class="cfp-form-grid" style="grid-template-columns:1fr 1fr">
                            <div class="cfp-field">
                                <label>Currency Code</label>
                                <input type="text" name="currency_code" id="f-code" value="<?=esc_attr($current_code)?>" placeholder="BTC" maxlength="10" style="text-transform:uppercase;font-weight:700;letter-spacing:2px;font-size:1rem">
                                <span class="hint">e.g. BTC, ETH, DOGE, MYTOKEN</span>
                            </div>
                            <div class="cfp-field">
                                <label>Currency Name</label>
                                <input type="text" name="currency_name" id="f-name" value="<?=esc_attr($current_coin['name'])?>" placeholder="Bitcoin">
                            </div>
                            <div class="cfp-field">
                                <label>Currency Symbol</label>
                                <input type="text" name="currency_symbol" id="f-symbol" value="<?=esc_attr(cfp_get_setting('currency_symbol','₿'))?>" placeholder="₿" maxlength="5">
                                <span class="hint">Displayed next to amounts</span>
                            </div>
                            <div class="cfp-field">
                                <label>Smallest Unit Name</label>
                                <input type="text" name="satoshi_label" id="f-unit" value="<?=esc_attr(cfp_get_setting('satoshi_label','Satoshi'))?>" placeholder="Satoshi">
                                <span class="hint">e.g. Satoshi, Gwei, Lamport, Koinu</span>
                            </div>
                            <div class="cfp-field">
                                <label>Decimal Places</label>
                                <input type="number" name="decimals" id="f-decimals" value="<?=esc_attr($current_coin['decimals']??8)?>" min="0" max="18">
                            </div>
                            <div class="cfp-field">
                                <label>Block Explorer URL</label>
                                <input type="url" name="explorer_url" id="f-explorer" value="<?=esc_attr(cfp_get_setting('explorer_url',$current_coin['explorer']??''))?>" placeholder="https://...">
                                <span class="hint">TX hash appended automatically</span>
                            </div>
                        </div>

                        <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:8px;padding:16px">
                            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt);margin-bottom:12px">Brand Colors</div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px">
                                <div class="cfp-field">
                                    <label>Primary Color</label>
                                    <div style="display:flex;gap:8px;align-items:center">
                                        <input type="color" name="primary_color" id="f-primary" value="<?=esc_attr(cfp_get_setting('primary_color','#f7931a'))?>" style="width:48px;height:36px;padding:2px;border:1px solid var(--br);border-radius:6px;background:#111;cursor:pointer">
                                        <input type="text" id="f-primary-hex" value="<?=esc_attr(cfp_get_setting('primary_color','#f7931a'))?>" maxlength="7" placeholder="#f7931a" style="flex:1;background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.86rem;font-family:monospace" oninput="document.getElementById('f-primary').value=this.value">
                                    </div>
                                </div>
                                <div class="cfp-field">
                                    <label>Accent Color</label>
                                    <div style="display:flex;gap:8px;align-items:center">
                                        <input type="color" name="accent_color" id="f-accent" value="<?=esc_attr(cfp_get_setting('accent_color','#ffcc02'))?>" style="width:48px;height:36px;padding:2px;border:1px solid var(--br);border-radius:6px;background:#111;cursor:pointer">
                                        <input type="text" id="f-accent-hex" value="<?=esc_attr(cfp_get_setting('accent_color','#ffcc02'))?>" maxlength="7" placeholder="#ffcc02" style="flex:1;background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.86rem;font-family:monospace" oninput="document.getElementById('f-accent').value=this.value">
                                    </div>
                                </div>
                            </div>
                            <!-- Live preview -->
                            <div style="margin-top:14px">
                                <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1px;color:var(--mt);margin-bottom:8px">Preview</div>
                                <div id="color-preview" style="background:linear-gradient(135deg,<?=cfp_get_setting('primary_color','#f7931a')?>,<?=cfp_get_setting('accent_color','#ffcc02')?>);padding:12px 24px;border-radius:8px;text-align:center;font-weight:900;font-size:1.1rem;color:#000;letter-spacing:2px">
                                    ⚡ CLAIM FREE <span id="prev-code"><?=esc_html($current_code)?></span>
                                </div>
                            </div>
                        </div>

                        <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:8px;padding:16px">
                            <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt);margin-bottom:12px">Payout & Withdrawal Settings</div>
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                                <div class="cfp-field">
                                    <label>Min Claim (units)</label>
                                    <input type="number" name="min_claim_sat" id="f-min" value="<?=esc_attr(cfp_get_setting('min_claim_sat',98))?>" min="1">
                                </div>
                                <div class="cfp-field">
                                    <label>Max Claim (units)</label>
                                    <input type="number" name="max_claim_sat" id="f-max" value="<?=esc_attr(cfp_get_setting('max_claim_sat',200))?>" min="1">
                                </div>
                                <div class="cfp-field">
                                    <label>Min Withdrawal (units)</label>
                                    <input type="number" name="min_withdraw_sat" id="f-minwd" value="<?=esc_attr(cfp_get_setting('min_withdraw_sat',30000))?>" min="0">
                                </div>
                                <div class="cfp-field">
                                    <label>Withdrawal Fee (units)</label>
                                    <input type="number" name="withdraw_fee_sat" id="f-fee" value="<?=esc_attr(cfp_get_setting('withdraw_fee_sat',1000))?>" min="0">
                                </div>
                                <div class="cfp-field">
                                    <label>Savings APY (%)</label>
                                    <input type="number" name="savings_apy" id="f-apy" value="<?=esc_attr(cfp_get_setting('savings_apy',4.08))?>" step="0.01" min="0">
                                </div>
                            </div>
                        </div>

                        <button type="submit" name="cfp_save_currency" class="cfp-btn cfp-btn-gold" style="width:100%;padding:14px;font-size:1rem;justify-content:center">
                            🪙 Save Currency Settings
                        </button>
                    </div>
                </div>
            </form>

            <!-- RIGHT: LIVE PREVIEW PANEL -->
            <div>
                <div class="cfp-card" style="margin-bottom:22px">
                    <h2>👁 Live Preview</h2>
                    <div id="live-preview" style="background:#0d0d0d;border-radius:10px;padding:20px">
                        <div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">
                            <div id="prev-icon" style="width:46px;height:46px;border-radius:50%;background:<?=$current_coin['bg']?>;border:2px solid <?=$current_coin['color']?>;display:flex;align-items:center;justify-content:center;font-size:1.3rem;font-weight:900;color:<?=$current_coin['color']?>"><?=$current_coin['icon']?></div>
                            <div>
                                <div style="font-weight:800;font-size:1rem;color:#fff" id="prev-name"><?=$current_coin['name']?></div>
                                <div style="font-size:.76rem;color:var(--mt)" id="prev-unit">1 <?=$current_code?> = 100,000,000 <span id="prev-unit-label"><?=$current_coin['unit']?></span></div>
                            </div>
                        </div>
                        <div style="background:#060606;border-radius:8px;padding:14px;margin-bottom:12px;text-align:center">
                            <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:2px;color:#444;margin-bottom:5px">Balance</div>
                            <div style="font-size:2rem;font-weight:900;font-family:monospace" id="prev-balance" style="color:<?=cfp_get_setting('primary_color','#f7931a')?>">1,234 <span id="prev-unit2"><?=$current_coin['unit']?></span></div>
                        </div>
                        <button style="width:100%;padding:13px;background:linear-gradient(135deg,<?=cfp_get_setting('primary_color','#f7931a')?>,<?=cfp_get_setting('accent_color','#ffcc02')?>);color:#000;font-weight:900;border:none;border-radius:8px;font-size:1rem;letter-spacing:2px;text-transform:uppercase;cursor:pointer" id="prev-claim-btn">🪙 CLAIM FREE <span id="prev-code2"><?=$current_code?></span></button>
                        <div style="margin-top:12px;font-size:.8rem;color:#444;text-align:center">
                            Min: <span id="prev-min"><?=cfp_get_setting('min_claim_sat',98)?></span> · Max: <span id="prev-max"><?=cfp_get_setting('max_claim_sat',200)?></span> <span id="prev-unit3"><?=$current_coin['unit']?></span>
                        </div>
                    </div>
                </div>

                <div class="cfp-card">
                    <h2>📖 Coin Reference</h2>
                    <table style="width:100%;border-collapse:collapse;font-size:.8rem">
                        <thead><tr><th style="background:#111;color:var(--mt);font-size:.65rem;text-transform:uppercase;letter-spacing:1px;padding:8px 10px;text-align:left;border-bottom:1px solid var(--br)">Coin</th><th style="background:#111;color:var(--mt);font-size:.65rem;text-transform:uppercase;letter-spacing:1px;padding:8px 10px;text-align:left;border-bottom:1px solid var(--br)">Decimals</th><th style="background:#111;color:var(--mt);font-size:.65rem;text-transform:uppercase;letter-spacing:1px;padding:8px 10px;text-align:left;border-bottom:1px solid var(--br)">Unit</th></tr></thead>
                        <tbody>
                        <?php foreach($coins as $c=>$coin): ?>
                        <tr style="border-bottom:1px solid #141414">
                            <td style="padding:8px 10px;font-weight:700;color:#fff"><?=$c?></td>
                            <td style="padding:8px 10px;color:var(--mt)"><?=$coin['decimals']?></td>
                            <td style="padding:8px 10px;color:var(--mt)"><?=$coin['unit']?></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
    const cfpCoins = <?=json_encode($coins)?>;

    function cfpLoadCoin(code) {
        // Highlight card
        document.querySelectorAll('.cfp-coin-card').forEach(c=>c.classList.remove('active-coin'));
        const card = document.getElementById('coin-card-'+code);
        if(card) card.classList.add('active-coin');

        if(code==='CUSTOM') return;
        const c = cfpCoins[code];
        if(!c) return;

        document.getElementById('f-code').value    = code;
        document.getElementById('f-name').value    = c.name;
        document.getElementById('f-symbol').value  = c.icon;
        document.getElementById('f-unit').value    = c.unit;
        document.getElementById('f-decimals').value= c.decimals;
        document.getElementById('f-explorer').value= c.explorer;
        document.getElementById('f-primary').value  = c.color;
        document.getElementById('f-primary-hex').value = c.color;
        document.getElementById('f-accent').value  = '#ffcc02';
        document.getElementById('f-accent-hex').value = '#ffcc02';
        cfpUpdatePreview();
    }

    function cfpUpdatePreview() {
        const code    = document.getElementById('f-code').value.toUpperCase();
        const name    = document.getElementById('f-name').value;
        const unit    = document.getElementById('f-unit').value;
        const primary = document.getElementById('f-primary').value;
        const accent  = document.getElementById('f-accent').value;
        const min     = document.getElementById('f-min').value;
        const max     = document.getElementById('f-max').value;

        document.getElementById('prev-code').textContent  = code;
        document.getElementById('prev-code2').textContent = code;
        document.getElementById('prev-name').textContent  = name;
        document.getElementById('prev-unit').textContent  = `1 ${code} = 100,000,000 ${unit}`;
        document.getElementById('prev-unit2').textContent = unit;
        document.getElementById('prev-unit3').textContent = unit;
        document.getElementById('prev-unit-label').textContent = unit;
        document.getElementById('prev-min').textContent  = parseInt(min).toLocaleString();
        document.getElementById('prev-max').textContent  = parseInt(max).toLocaleString();
        document.getElementById('color-preview').style.background = `linear-gradient(135deg,${primary},${accent})`;
        document.getElementById('prev-claim-btn').style.background = `linear-gradient(135deg,${primary},${accent})`;
        document.getElementById('prev-balance').style.color = primary;
        document.getElementById('prev-icon').style.borderColor = primary;
        document.getElementById('prev-icon').style.color = primary;
    }

    // Sync color hex inputs
    document.getElementById('f-primary').addEventListener('input',function(){
        document.getElementById('f-primary-hex').value=this.value; cfpUpdatePreview();
    });
    document.getElementById('f-accent').addEventListener('input',function(){
        document.getElementById('f-accent-hex').value=this.value; cfpUpdatePreview();
    });
    ['f-code','f-name','f-unit','f-min','f-max'].forEach(id=>{
        document.getElementById(id).addEventListener('input', cfpUpdatePreview);
    });
    </script>
    <?php
}

