<?php
/**
 * Admin pages: Admin Wallet viewer and Fees & Rates configurator
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_wallet() {
    global $wpdb;
    $notice = '';

    // Handle wallet settings save
    if(isset($_POST['cfp_save_wallet_settings']) && check_admin_referer('cfp_wallet_settings')) {
        $wfields = ['admin_wallet_enabled','house_edge_auto_collect','wd_fee_auto_collect',
                    'interest_spread_rate','fun_token_name','fun_token_price_sat','fun_token_total_supply',
                    'premium_silver_sat','premium_gold_sat','premium_platinum_sat',
                    'premium_silver_days','premium_gold_days','premium_platinum_days',
                    'ad_network_name','lottery_ticket_price_sat','lottery_ticket_sale_enabled',
                    'trezor_label','trezor_model','trezor_currency','trezor_xpub',
                    'trezor_active_address','trezor_sweep_threshold','trezor_auto_alert','trezor_sweep_method','trezor_network_fee'];
        foreach($wfields as $f) if(isset($_POST[$f])) cfp_update_setting($f, sanitize_text_field($_POST[$f]));
        // Save Trezor addresses (textarea, one per line)
        if(isset($_POST['trezor_addresses_raw'])) {
            $raw_addrs = sanitize_textarea_field($_POST['trezor_addresses_raw']);
            $addr_arr  = array_values(array_filter(array_map('trim', explode("\n", $raw_addrs))));
            cfp_update_setting('trezor_addresses', json_encode($addr_arr));
        }
        // Handle Set Active address shortcut
        if(isset($_POST['trezor_set_active'])) {
            cfp_update_setting('trezor_active_address', sanitize_text_field($_POST['trezor_set_active']));
        }
        $notice = "<div class='cfp-notice success'>&#9989; Wallet settings saved!</div>";
    }

    // Handle payout to Trezor or generic address
    if(isset($_POST['cfp_wallet_payout']) && check_admin_referer('cfp_wallet_payout')) {
        $payout_addr = sanitize_text_field($_POST['payout_address']??'');
        $payout_amt  = intval($_POST['payout_amount']??0);
        $payout_note = sanitize_text_field($_POST['payout_note']??'');
        $payout_type = sanitize_text_field($_POST['payout_type']??'manual');
        $network_fee = intval($_POST['trezor_network_fee']??0);
        if($payout_amt > 0 && !empty($payout_addr)) {
            $stream = $payout_type === 'trezor' ? 'trezor_payout' : 'admin_payout';
            $total_deduct = $payout_amt + $network_fee;
            $desc = $payout_type === 'trezor'
                ? "Trezor sweep: {$payout_amt} sat + {$network_fee} sat network fee to {$payout_addr}".($payout_note?" — {$payout_note}":'')
                : "Admin payout to {$payout_addr}".($payout_note?": {$payout_note}":'');
            $wpdb->insert(CFP_TABLE_ADMIN_WALLET,['stream'=>$stream,'amount_sat'=>-$total_deduct,'description'=>$desc]);
            $type_label = $payout_type === 'trezor' ? 'Trezor sweep' : 'Admin payout';
            $notice = "<div class='cfp-notice success'>&#9989; {$type_label} of ".number_format($payout_amt)." sat recorded".($network_fee>0?" (+ ".number_format($network_fee)." sat fee)":'').".</div>";
        }
    }

    // ── Aggregate stats per stream ────────────────────────────────
    $streams = [
        'house_edge_hilo'     => ['🎲','Hi-Lo House Edge',    '#f7931a'],
        'house_edge_slots'    => ['🎰','Slots House Edge',    '#a855f7'],
        'house_edge_coinflip' => ['🪙','Coin Flip Edge',      '#ffcc02'],
        'house_edge_dice'     => ['🎲','Dice Roll Edge',      '#22c55e'],
        'house_edge_crash'    => ['📈','Crash House Edge',    '#ef4444'],
        'house_edge_wheel'    => ['🎡','Wheel Edge',          '#3b82f6'],
        'withdrawal_fee'      => ['💸','Withdrawal Fees',     '#888888'],
        'np_withdraw_fee'     => ['💸','NOWPayments Wd Fees', '#6b7280'],
        'web3_metamask_withdraw_fee'      => ['🦊','MetaMask Wd Fees',       '#f6851b'],
        'web3_walletconnect_withdraw_fee' => ['📡','WalletConnect Wd Fees',  '#3b99fc'],
        'lottery_ticket_sales'=> ['🎟','Lottery Ticket Sales','#ffcc02'],
        'interest_spread'     => ['📊','Interest Spread',     '#22c55e'],
        'advertising'         => ['📢','Advertising Revenue', '#f97316'],
        'fun_token_sales'     => ['🪙','FUN Token Sales',     '#06b6d4'],
        'premium_membership'  => ['⭐','Premium Memberships', '#fbbf24'],
        // Revenue Controller streams
        'revenue_withdraw_fee_pct'    => ['💸','Custom Withdrawal Fee', '#f7931a'],
        'revenue_balance_sweep'      => ['🔄','Balance Sweep Revenue',   '#22c55e'],
        'revenue_deposits'        => ['💳','Deposit Revenue',    '#3b82f6'],
        'revenue_claims'         => ['🚿','Claim Revenue',      '#06b6d4'],
        'revenue_game_wins'      => ['🎮','Game Win Revenue',  '#a855f7'],
        'revenue_game_losses'     => ['📉','Game Loss Revenue',  '#ef4444'],
        'revenue_referral_bonus'   => ['👥','Referral Revenue',   '#fbbf24'],
        'revenue_game_addon'     => ['➕','Game Revenue Addon','#f97316'],
        'trezor_network_fee'    => ['⛽','Network Fees (out)', '#ef4444'],
        'admin_payout'        => ['💼','Admin Payouts (out)', '#ef4444'],
        'trezor_payout'       => ['🔐','Trezor Sweeps (out)', '#1dc928'],
    ];

    $stream_totals = [];
    foreach($streams as $key => $info) {
        $stream_totals[$key] = $wpdb->get_var($wpdb->prepare(
            "SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE stream=%s", $key
        ));
    }

    $total_in  = $wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE amount_sat>0");
    $total_out = abs($wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE amount_sat<0"));
    $net_balance = $total_in - $total_out;

    // Today / this week
    $today_in   = $wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE amount_sat>0 AND DATE(created_at)=CURDATE()");
    $week_in    = $wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE amount_sat>0 AND created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)");

    // Game GGR totals
    $game_tables = [
        'Hi-Lo'    => CFP_TABLE_MULTIPLY,
        'Slots'    => CFP_TABLE_SLOTS,
        'Coin Flip'=> CFP_TABLE_COINFLIP,
        'Dice'     => CFP_TABLE_DICE,
        'Crash'    => CFP_TABLE_CRASH,
        'Wheel'    => CFP_TABLE_WHEEL,
    ];
    $ggr_data = [];
    foreach($game_tables as $label => $tbl) {
        $wagered = $wpdb->get_var("SELECT COALESCE(SUM(bet_sat),0) FROM {$tbl}");
        $paid    = $wpdb->get_var("SELECT COALESCE(SUM(payout_sat),0) FROM {$tbl}");
        $ggr_data[$label] = ['wagered'=>$wagered,'paid'=>$paid,'ggr'=>$wagered-$paid,'margin'=>$wagered>0?round(($wagered-$paid)/$wagered*100,2):0];
    }

    // Recent wallet entries
    $recent_entries = $wpdb->get_results("SELECT * FROM ".CFP_TABLE_ADMIN_WALLET." ORDER BY created_at DESC LIMIT 20");

    // Premium stats
    $premium_counts = $wpdb->get_results("SELECT tier,COUNT(*) cnt,SUM(price_sat) total FROM ".CFP_TABLE_PREMIUM." WHERE expires_at>NOW() GROUP BY tier",OBJECT_K);

    // Ad revenue log
    $ad_logs = $wpdb->get_results("SELECT * FROM ".CFP_TABLE_AD_REVENUE." ORDER BY recorded_at DESC LIMIT 10");

    // FUN token stats
    $fun_sold = $wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM ".CFP_TABLE_FUN_TOKENS." WHERE type='purchase'");
    $fun_revenue = $wpdb->get_var("SELECT COALESCE(SUM(price_sat*amount),0) FROM ".CFP_TABLE_FUN_TOKENS." WHERE type='purchase'");

    $btc_price = intval(cfp_get_setting('btc_usd_price',67694));
    $net_usd   = round($net_balance / 100000000 * $btc_price, 2);

    $admin_nonce = wp_create_nonce('cfp_admin_nonce');

    // Tab routing — default tab shows the full Admin Wallet, 'trezor_sweep' shows the sweep page
    $wstab = isset($_GET['wstab']) ? sanitize_text_field($_GET['wstab']) : 'revenue';
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge" style="background:linear-gradient(135deg,#f7931a,#ffcc02)">💰 WALLET</span>
            <h1>Admin Wallet</h1>
            <div style="margin-left:auto;text-align:right">
                <div style="font-family:'Courier New',monospace;font-size:1.8rem;font-weight:900;color:var(--g)"><?=number_format($net_balance)?> sat</div>
                <div style="font-size:.8rem;color:var(--mt)">≈ $<?=number_format($net_usd,2)?> USD · Net balance</div>
            </div>
        </div>

        <!-- TAB NAV -->
        <div style="display:flex;gap:8px;margin-bottom:22px;border-bottom:1px solid #1a1a1a;padding-bottom:0">
            <a href="<?=esc_url(remove_query_arg('wstab'))?>"
               style="padding:10px 18px;border-radius:8px 8px 0 0;font-size:.85rem;font-weight:700;text-decoration:none;border:1px solid <?=$wstab==='revenue'?'#f7931a':'#1a1a1a'?>;border-bottom:none;color:<?=$wstab==='revenue'?'#f7931a':'#888'?>;background:<?=$wstab==='revenue'?'#1a0d00':'transparent'?>">
               💰 Admin Wallet
            </a>
            <a href="<?=esc_url(add_query_arg('wstab','trezor_sweep'))?>"
               style="padding:10px 18px;border-radius:8px 8px 0 0;font-size:.85rem;font-weight:700;text-decoration:none;border:1px solid <?=$wstab==='trezor_sweep'?'#1dc928':'#1a1a1a'?>;border-bottom:none;color:<?=$wstab==='trezor_sweep'?'#1dc928':'#888'?>;background:<?=$wstab==='trezor_sweep'?'#0a1a0a':'transparent'?>;display:flex;align-items:center;gap:6px">
               🔐 Trezor Sweep
               <?php
               global $wpdb;
               $sweep_pending = $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}cfp_trezor_sweep_queue WHERE status='pending'");
               if ($sweep_pending): ?>
               <span style="background:#f97316;color:#000;font-size:.65rem;padding:2px 6px;border-radius:10px;font-weight:900"><?=(int)$sweep_pending?></span>
               <?php endif; ?>
            </a>
            <?php do_action('cfp_admin_wallet_extra_tabs', $wstab); ?>
        </div>

        <?php if ($wstab === 'trezor_sweep'):
            do_action('cfp_admin_wallet_extra_content', 'trezor_sweep');
            echo '</div>'; // close cfp-wrap
            return;
        endif; ?>

        <?php if ($wstab === 'hw_wallet'):
            do_action('cfp_admin_wallet_extra_content', 'hw_wallet');
            echo '</div>'; // close cfp-wrap
            return;
        endif; ?>

        <?=$notice?>

        <!-- TOP STATS -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(175px,1fr));margin-bottom:26px">
            <div class="cfp-stat-card green">
                <div class="label">Net Wallet Balance</div>
                <div class="value" style="color:var(--g)"><?=number_format($net_balance)?></div>
                <div class="sub">sat · $<?=number_format($net_usd,2)?> USD</div>
            </div>
            <div class="cfp-stat-card green">
                <div class="label">Total Revenue (all time)</div>
                <div class="value"><?=number_format($total_in)?></div>
                <div class="sub">sat earned</div>
            </div>
            <div class="cfp-stat-card red">
                <div class="label">Total Paid Out</div>
                <div class="value"><?=number_format($total_out)?></div>
                <div class="sub">sat withdrawn</div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Today's Revenue</div>
                <div class="value"><?=number_format($today_in)?></div>
                <div class="sub">sat today</div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">This Week</div>
                <div class="value"><?=number_format($week_in)?></div>
                <div class="sub">sat (7 days)</div>
            </div>
        </div>
        
        <!-- REAL ONCHAIN BALANCE FROM NOWPAYMENTS -->
        <?php
        // Fetch real onchain balance from NOWPayments
        $np_balance = null;
        $np_error = '';
        if ( function_exists('cfp_np_enabled') && cfp_np_enabled() && function_exists('cfp_np_get_balance') ) {
            $np_balance = @cfp_np_get_balance();
            if ( ! empty( $np_balance['error'] ) ) {
                $np_error = $np_balance['error'];
                $np_balance = null;
            }
        }
        if ( $np_balance && ! empty( $np_balance['currencies'] ) ):
        ?>
        <div class="cfp-card" style="margin-bottom:22px;background:linear-gradient(135deg,#0a1520 0%,#0d1a24 100%)">
            <h2 style="color:#22c55e">⛓️ REAL Onchain Wallet Balance</h2>
            <p style="color:#777;font-size:.82rem;margin-bottom:14px">Live balance from your NOWPayments hot wallet — actual crypto ready to withdraw.</p>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px">
                <?php 
                $display_currencies = ['btc','eth','ltc','doge','usdt','trx'];
                foreach ( $display_currencies as $curr ):
                    if ( isset( $np_balance['currencies'][$curr] ) ):
                        $bal = $np_balance['currencies'][$curr];
                        $bal_amt = floatval($bal['available'] ?? 0);
                        if ( $bal_amt > 0 ):
                ?>
                <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px;padding:14px">
                    <div style="font-size:.72rem;color:#777;text-transform:uppercase;letter-spacing:1px;margin-bottom:6px"><?=strtoupper($curr)?></div>
                    <div style="font-size:1.1rem;font-weight:700;color:#22c55e"><?=number_format($bal_amt, $curr==='btc'?8:6)?></div>
                    <div style="font-size:.7rem;color:#555">available</div>
                </div>
                <?php 
                        endif;
                    endif;
                endforeach; 
                ?>
            </div>
            <div style="margin-top:12px;font-size:.78rem;color:#555">
                <span style="color:#22c55e">●</span> Live data — updated on page load
            </div>
        </div>
        <?php elseif ( $np_error ): ?>
        <div class="cfp-card" style="margin-bottom:22px;background:#1a0a0a">
            <h2 style="color:#ef4444">⛓️ Onchain Balance</h2>
            <p style="color:#777;font-size:.82rem">NOWPayments Error: <?=esc_html($np_error)?></p>
        </div>
        <?php endif; ?>

        <!-- REVENUE CHARTS -->
        <div class="cfp-card" style="margin-bottom:22px">
            <h2>📈 Revenue Trends</h2>
            <div style="display:flex;gap:10px;margin-bottom:16px">
                <button onclick="cfpLoadRevenueChart('7')" class="cfp-btn cfp-btn-ghost cfp-btn-sm" id="chart-7btn">7 Days</button>
                <button onclick="cfpLoadRevenueChart('30')" class="cfp-btn cfp-btn-ghost cfp-btn-sm" id="chart-30btn">30 Days</button>
                <button onclick="cfpLoadRevenueChart('90')" class="cfp-btn cfp-btn-ghost cfp-btn-sm" id="chart-90btn">90 Days</button>
            </div>
            <div style="height:300px;position:relative">
                <canvas id="cfpRevenueChart"></canvas>
            </div>
        </div>

        <!-- SCHEDULED PAYOUTS -->
        <?php
        // Handle scheduled payout save
        if(isset($_POST['cfp_save_scheduled_payout']) && check_admin_referer('cfp_scheduled_payout')) {
            $scheduled_amount = intval($_POST['scheduled_amount'] ?? 0);
            $scheduled_address = sanitize_text_field($_POST['scheduled_address'] ?? '');
            $scheduled_frequency = sanitize_text_field($_POST['scheduled_frequency'] ?? 'daily');
            $scheduled_threshold = intval($_POST['scheduled_threshold'] ?? 0);
            
            if($scheduled_amount > 0 && !empty($scheduled_address)) {
                cfp_update_setting('scheduled_payout_enabled', '1');
                cfp_update_setting('scheduled_payout_amount', $scheduled_amount);
                cfp_update_setting('scheduled_payout_address', $scheduled_address);
                cfp_update_setting('scheduled_payout_frequency', $scheduled_frequency);
                cfp_update_setting('scheduled_payout_threshold', $scheduled_threshold);
                $notice = "<div class='cfp-notice success'>✅ Scheduled payout configured!</div>";
            }
        }
        
        // Cancel scheduled payout
        if(isset($_POST['cfp_cancel_scheduled']) && check_admin_referer('cfp_scheduled_payout')) {
            cfp_update_setting('scheduled_payout_enabled', '0');
            $notice = "<div class='cfp-notice success'>✅ Scheduled payout disabled.</div>";
        }
        
        $scheduled_enabled = cfp_get_setting('scheduled_payout_enabled', '0');
        ?>
        <div class="cfp-card" style="margin-bottom:22px">
            <h2>⏰ Scheduled Auto-Payouts</h2>
            <p style="color:#777;font-size:.85rem;margin-bottom:14px">Automatically transfer earnings to your external wallet on a schedule or when threshold is reached.</p>
            
            <?php if($scheduled_enabled === '1'): ?>
            <div style="background:#052e16;border:1px solid #22c55e44;border-radius:10px;padding:16px;margin-bottom:16px">
                <div style="display:flex;align-items:center;justify-content:space-between">
                    <div>
                        <div style="color:#22c55e;font-weight:700;margin-bottom:4px">✅ Scheduled Payout Active</div>
                        <div style="color:#777;font-size:.82rem">
                            Amount: <?=number_format(cfp_get_setting('scheduled_payout_amount', 0))?> sat |
                            Threshold: <?=number_format(cfp_get_setting('scheduled_payout_threshold', 0))?> sat |
                            Frequency: <?=ucfirst(cfp_get_setting('scheduled_payout_frequency', 'daily'))?>
                        </div>
                        <div style="color:#555;font-size:.78rem;margin-top:4px">To: <?=esc_html(substr(cfp_get_setting('scheduled_payout_address', ''), 0, 20))?>...</div>
                    </div>
                    <form method="post">
                        <?php wp_nonce_field('cfp_scheduled_payout'); ?>
                        <button type="submit" name="cfp_cancel_scheduled" class="cfp-btn cfp-btn-red cfp-btn-sm" onclick="return confirm('Disable scheduled payout?')">Disable</button>
                    </form>
                </div>
            </div>
            <?php endif; ?>
            
            <form method="post">
                <?php wp_nonce_field('cfp_scheduled_payout'); ?>
                <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px">
                    <div class="cfp-field">
                        <label>Payout Amount (sat)</label>
                        <input type="number" name="scheduled_amount" value="<?=esc_attr(cfp_get_setting('scheduled_payout_amount', 100000))?>" min="1" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                        <span class="hint">Fixed amount to send each time</span>
                    </div>
                    <div class="cfp-field">
                        <label>Trigger Threshold (sat)</label>
                        <input type="number" name="scheduled_threshold" value="<?=esc_attr(cfp_get_setting('scheduled_payout_threshold', 500000))?>" min="0" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                        <span class="hint">0 = disabled, or set minimum balance</span>
                    </div>
                    <div class="cfp-field">
                        <label>Frequency</label>
                        <select name="scheduled_frequency" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                            <option value="daily" <?=selected(cfp_get_setting('scheduled_payout_frequency', 'daily'), 'daily', false)?>>Daily</option>
                            <option value="weekly" <?=selected(cfp_get_setting('scheduled_payout_frequency', 'daily'), 'weekly', false)?>>Weekly</option>
                            <option value="monthly" <?=selected(cfp_get_setting('scheduled_payout_frequency', 'daily'), 'monthly', false)?>>Monthly</option>
                        </select>
                    </div>
                    <div class="cfp-field" style="grid-column:1/-1">
                        <label>Destination Address</label>
                        <input type="text" name="scheduled_address" value="<?=esc_attr(cfp_get_setting('scheduled_payout_address', ''))?>" placeholder="bc1q..." style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px;width:100%">
                        <span class="hint">Your external wallet address (BTC, ETH, etc.)</span>
                    </div>
                </div>
                <button type="submit" name="cfp_save_scheduled_payout" class="cfp-btn cfp-btn-gold" style="margin-top:16px">💾 Configure Scheduled Payout</button>
            </form>
        </div>

        <!-- REVENUE STREAM BREAKDOWN -->
        <div class="cfp-card" style="margin-bottom:22px">
            <h2>📊 Revenue Streams Breakdown</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:12px">
            <?php foreach($streams as $key => [$icon,$label,$color]):
                $amt = intval($stream_totals[$key]);
                $is_out = in_array($key, ['admin_payout', 'trezor_payout']);
                if($is_out) $amt = abs($amt);
                $pct = $total_in > 0 ? round(abs($amt)/$total_in*100,1) : 0;
            ?>
            <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px;padding:14px;position:relative;overflow:hidden">
                <div style="position:absolute;top:0;left:0;bottom:0;width:3px;background:<?=$color?>"></div>
                <div style="padding-left:8px">
                    <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:1.2px;color:#444;margin-bottom:5px"><?=$icon?> <?=$label?></div>
                    <div style="font-size:1.3rem;font-weight:800;color:<?=$is_out?'var(--rd)':$color?>;font-family:monospace"><?=$is_out?'-':''?><?=number_format($amt)?></div>
                    <div style="font-size:.7rem;color:#333;margin-top:3px"><?=$pct?>% of total</div>
                    <div style="height:3px;background:#1a1a1a;border-radius:2px;margin-top:7px;overflow:hidden">
                        <div style="height:100%;width:<?=min(100,$pct)?>%;background:<?=$color?>;border-radius:2px"></div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
            </div>
        </div>

        <div class="cfp-2col">
            <!-- LEFT: GGR TABLE + PAYOUT FORM -->
            <div>
                <!-- GAME GGR TABLE -->
                <div class="cfp-card">
                    <h2>🎮 Game Gross Gaming Revenue (GGR)</h2>
                    <table class="cfp-table">
                        <thead><tr><th>Game</th><th>Wagered</th><th>Paid Out</th><th>GGR</th><th>Margin</th></tr></thead>
                        <tbody>
                        <?php foreach($ggr_data as $game=>$g):
                            $bar_w = $g['margin'];
                        ?>
                        <tr>
                            <td style="font-weight:600"><?=$game?></td>
                            <td style="font-family:monospace;font-size:.82rem;color:var(--mt)"><?=number_format($g['wagered'])?></td>
                            <td style="font-family:monospace;font-size:.82rem;color:#ef4444"><?=number_format($g['paid'])?></td>
                            <td style="font-weight:700;color:var(--g)"><?=number_format($g['ggr'])?></td>
                            <td>
                                <div style="display:flex;align-items:center;gap:8px">
                                    <div style="flex:1;height:5px;background:#1a1a1a;border-radius:3px;overflow:hidden">
                                        <div style="width:<?=min(100,$bar_w*4)?>%;height:100%;background:var(--g);border-radius:3px"></div>
                                    </div>
                                    <span style="font-size:.78rem;color:var(--g);min-width:38px"><?=$g['margin']?>%</span>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- TREZOR HARDWARE WALLET -->
                <div class="cfp-card" style="border-color:<?=cfp_get_setting('trezor_xpub','')?'#22c55e44':'#2a2a2a'?>">
                    <h2 style="display:flex;align-items:center;gap:10px">
                        <span style="background:linear-gradient(135deg,#1dc928,#009900);color:#fff;padding:4px 10px;border-radius:6px;font-size:.72rem;font-weight:800;letter-spacing:1px">TREZOR</span>
                        Hardware Wallet Integration
                        <?php if(cfp_get_setting('trezor_xpub','')): ?>
                            <span class="cfp-badge active" style="margin-left:auto">&#9679; Configured</span>
                        <?php else: ?>
                            <span class="cfp-badge banned" style="margin-left:auto">&#9679; Not Configured</span>
                        <?php endif; ?>
                    </h2>

                    <?php
                    $trezor_xpub      = cfp_get_setting('trezor_xpub','');
                    $trezor_addresses = json_decode(cfp_get_setting('trezor_addresses','[]'),true) ?: [];
                    $trezor_label     = cfp_get_setting('trezor_label','My Trezor');
                    $trezor_model     = cfp_get_setting('trezor_model','Model T');
                    $trezor_currency  = cfp_get_setting('trezor_currency', cfp_get_setting('faucet_currency','BTC'));
                    $trezor_active_addr = cfp_get_setting('trezor_active_address','');
                    $trezor_threshold = intval(cfp_get_setting('trezor_sweep_threshold',100000));
                    $trezor_auto_alert= cfp_get_setting('trezor_auto_alert','1');
                    $trezor_payout_history = $wpdb->get_results("SELECT * FROM ".CFP_TABLE_ADMIN_WALLET." WHERE stream='trezor_payout' ORDER BY created_at DESC LIMIT 5");
                    $total_sent_trezor = abs((int)$wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE stream='trezor_payout'"));
                    ?>

                    <!-- DEVICE PANEL -->
                    <div style="background:#060606;border:1px solid #1a1a1a;border-radius:12px;padding:20px;margin-bottom:18px">
                        <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px">
                            <!-- Trezor Device SVG -->
                            <div style="flex-shrink:0">
                                <svg width="52" height="76" viewBox="0 0 52 76" fill="none" xmlns="http://www.w3.org/2000/svg">
                                  <rect x="1" y="1" width="50" height="74" rx="6" fill="#111" stroke="#1dc928" stroke-width="1.5"/>
                                  <rect x="8" y="8" width="36" height="28" rx="3" fill="#0d2010" stroke="#1dc928" stroke-width="1"/>
                                  <rect x="11" y="11" width="30" height="22" rx="2" fill="#0a1a0a"/>
                                  <?php if($trezor_xpub): ?>
                                  <text x="16" y="24" font-family="monospace" font-size="5" fill="#1dc928" font-weight="bold">READY</text>
                                  <?php else: ?>
                                  <text x="13" y="24" font-family="monospace" font-size="5" fill="#555">CONNECT</text>
                                  <?php endif; ?>
                                  <circle cx="26" cy="52" r="7" fill="#0d1a0d" stroke="#1dc928" stroke-width="1.2"/>
                                  <circle cx="26" cy="52" r="3" fill="<?=$trezor_xpub?'#1dc928':'#333'?>"/>
                                  <rect x="20" y="64" width="12" height="6" rx="2" fill="#0d2010" stroke="#1dc928" stroke-width="0.8"/>
                                  <rect x="22" y="66" width="8" height="2" rx="1" fill="#1dc928" opacity="0.5"/>
                                  <text x="7" y="73" font-family="monospace" font-size="4" fill="#1dc928" opacity="0.7">TREZOR</text>
                                </svg>
                            </div>
                            <div style="flex:1">
                                <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:#3a6a3a;margin-bottom:3px">Device</div>
                                <div style="font-size:1.1rem;font-weight:700;color:#fff;margin-bottom:2px"><?=esc_html($trezor_label)?> — <?=esc_html($trezor_model)?></div>
                                <div style="font-size:.78rem;color:#444"><?=esc_html($trezor_currency)?> <?php if($trezor_xpub): ?>&#183; xPub configured &#183; <?=count($trezor_addresses)?> addresses loaded<?php else: ?>&#183; Configure below to connect<?php endif; ?></div>
                                <?php if($total_sent_trezor > 0): ?>
                                <div style="margin-top:6px;font-size:.78rem;color:#22c55e">Total sent to Trezor: <strong><?=number_format($total_sent_trezor)?> sat</strong></div>
                                <?php endif; ?>
                            </div>
                            <?php if($net_balance >= $trezor_threshold && $trezor_xpub && $trezor_auto_alert): ?>
                            <div style="background:#052e16;border:1px solid #22c55e44;border-radius:9px;padding:12px 16px;text-align:center;flex-shrink:0">
                                <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:1px;color:#22c55e;margin-bottom:4px">&#9888; Threshold Reached</div>
                                <div style="font-size:.84rem;font-weight:700;color:#fff">Ready to sweep</div>
                                <div style="font-size:.72rem;color:#3a6a3a;margin-top:2px"><?=number_format($net_balance)?> sat available</div>
                            </div>
                            <?php endif; ?>
                        </div>

                        <!-- Active Address Display -->
                        <?php if($trezor_active_addr): ?>
                        <div style="background:#0a1a0a;border:1px solid #1dc92833;border-radius:9px;padding:14px;margin-bottom:14px">
                            <div style="font-size:.66rem;text-transform:uppercase;letter-spacing:2px;color:#3a6a3a;margin-bottom:7px">Active Deposit Address (Trezor)</div>
                            <div style="display:flex;align-items:center;gap:10px">
                                <code style="font-family:monospace;font-size:.82rem;color:#1dc928;word-break:break-all;flex:1;background:#060606;padding:10px 13px;border-radius:7px;border:1px solid #1dc92822"><?=esc_html($trezor_active_addr)?></code>
                                <button onclick="cfpCopyTrezorAddr('<?=esc_js($trezor_active_addr)?>')" style="background:#0d2010;border:1px solid #1dc92844;color:#1dc928;padding:9px 14px;border-radius:7px;font-size:.78rem;cursor:pointer;font-weight:700;white-space:nowrap">&#128203; Copy</button>
                            </div>
                            <div style="display:flex;gap:8px;margin-top:10px;flex-wrap:wrap">
                                <a href="bitcoin:<?=esc_attr($trezor_active_addr)?>" style="font-size:.74rem;color:#3a6a3a;text-decoration:none;background:#060606;padding:4px 10px;border-radius:5px;border:1px solid #1a2a1a">&#128279; Open in wallet</a>
                                <a href="https://blockstream.info/address/<?=esc_attr($trezor_active_addr)?>" target="_blank" style="font-size:.74rem;color:#3a6a3a;text-decoration:none;background:#060606;padding:4px 10px;border-radius:5px;border:1px solid #1a2a1a">&#128269; View on explorer</a>
                                <span style="font-size:.74rem;color:#333;background:#060606;padding:4px 10px;border-radius:5px;border:1px solid #1a1a1a">Derivation: m/84&apos;/0&apos;/0&apos;/0/0</span>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Address Book -->
                        <?php if(!empty($trezor_addresses)): ?>
                        <div style="margin-bottom:14px">
                            <div style="font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;color:#444;margin-bottom:8px">Saved Trezor Addresses</div>
                            <div style="display:flex;flex-direction:column;gap:5px;max-height:160px;overflow-y:auto">
                            <?php foreach(array_slice($trezor_addresses,0,8) as $i=>$addr): ?>
                            <div style="display:flex;align-items:center;gap:8px;background:#0a0a0a;border:1px solid <?=$trezor_active_addr===$addr?'#1dc928':'#1a1a1a'?>;border-radius:7px;padding:8px 11px">
                                <span style="font-size:.7rem;color:#333;width:22px">#{<?=$i+1?>}</span>
                                <code style="font-family:monospace;font-size:.76rem;color:<?=$trezor_active_addr===$addr?'#1dc928':'#555'?>;flex:1;word-break:break-all"><?=esc_html($addr)?></code>
                                <?php if($trezor_active_addr===$addr): ?>
                                    <span style="font-size:.65rem;color:#1dc928;font-weight:700;white-space:nowrap">&#9679; ACTIVE</span>
                                <?php else: ?>
                                    <form method="post" style="margin:0">
                                        <?php wp_nonce_field('cfp_wallet_settings'); ?>
                                        <input type="hidden" name="trezor_set_active" value="<?=esc_attr($addr)?>">
                                        <button type="submit" style="background:transparent;border:1px solid #2a2a2a;color:#555;padding:3px 9px;border-radius:5px;font-size:.68rem;cursor:pointer">Set Active</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- SEND TO TREZOR FORM -->
                    <div style="background:#0a1a0a;border:1px solid #1dc92822;border-radius:12px;padding:18px;margin-bottom:16px">
                        <div style="font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:#1dc928;margin-bottom:14px;display:flex;align-items:center;gap:8px">
                            <span style="width:8px;height:8px;background:#1dc928;border-radius:50%;display:inline-block"></span>
                            Sweep Earnings to Trezor
                        </div>

                        <?php
                        // Show post-sweep instructions if a trezor payout was just recorded
                        $last_trezor = $wpdb->get_row("SELECT * FROM ".CFP_TABLE_ADMIN_WALLET." WHERE stream='trezor_payout' ORDER BY created_at DESC LIMIT 1");
                        $just_swept = $last_trezor && (time() - strtotime($last_trezor->created_at) < 60);
                        if($just_swept):
                            // Extract address from description
                            preg_match('/to ([\w]+)/', $last_trezor->description, $addr_match);
                            $swept_addr = $addr_match[1] ?? '';
                            $swept_amt  = abs($last_trezor->amount_sat);
                        ?>
                        <div style="background:#052e16;border:2px solid #22c55e66;border-radius:10px;padding:18px;margin-bottom:16px">
                            <div style="font-size:.9rem;font-weight:800;color:#22c55e;margin-bottom:10px">✅ Payout Recorded — Complete the Transfer</div>
                            <div style="font-size:.82rem;color:#aaa;margin-bottom:14px">The ledger has been updated. Now send <strong style="color:#1dc928"><?=number_format($swept_amt)?> sat</strong> on-chain to your Trezor address:</div>
                            <div style="background:#060606;border:1px solid #1dc92833;border-radius:8px;padding:12px;display:flex;align-items:center;gap:10px;margin-bottom:14px">
                                <code id="cfp-swept-addr" style="font-family:monospace;font-size:.82rem;color:#1dc928;flex:1;word-break:break-all"><?=esc_html($trezor_active_addr ?: $swept_addr)?></code>
                                <button onclick="navigator.clipboard.writeText(document.getElementById('cfp-swept-addr').textContent).then(()=>{this.textContent='✓ Copied!';setTimeout(()=>this.textContent='📋 Copy',2000)})"
                                    style="background:#0d2010;border:1px solid #1dc92844;color:#1dc928;padding:8px 13px;border-radius:6px;font-size:.76rem;cursor:pointer;font-weight:700;white-space:nowrap;flex-shrink:0">📋 Copy</button>
                            </div>
                            <div style="font-size:.78rem;color:#3a6a3a;display:flex;flex-direction:column;gap:6px">
                                <div>① Copy the address above</div>
                                <div>② Open your Coinbase wallet → Withdraw, or use your hot wallet to send</div>
                                <div>③ Verify the address on your Trezor screen before confirming</div>
                                <div>④ After the tx confirms, rotate to a fresh receiving address</div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <form method="post" id="cfp-trezor-payout-form">
                            <?php wp_nonce_field('cfp_wallet_payout'); ?>
                            <input type="hidden" name="payout_type" value="trezor">
                            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px">
                                <div class="cfp-field">
                                    <label>Destination Trezor Address</label>
                                    <div style="display:flex;gap:8px">
                                        <input type="text" name="payout_address" id="trezor-dest-addr"
                                            value="<?=esc_attr($trezor_active_addr)?>"
                                            placeholder="bc1q… (your Trezor address)"
                                            style="background:#060606;border:1px solid #1dc92833;color:#1dc928;padding:10px 12px;border-radius:8px;font-family:monospace;font-size:.82rem;flex:1">
                                        <?php if(!empty($trezor_addresses)): ?>
                                        <select onchange="document.getElementById('trezor-dest-addr').value=this.value;this.value=''" style="background:#060606;border:1px solid #1a2a1a;color:#3a6a3a;padding:10px 8px;border-radius:8px;font-size:.76rem;cursor:pointer;width:90px">
                                            <option value="">Saved&#8230;</option>
                                            <?php foreach($trezor_addresses as $i=>$addr): ?>
                                            <option value="<?=esc_attr($addr)?>">#<?=$i+1?> <?=esc_html(substr($addr,0,10))?>&#8230;</option>
                                            <?php endforeach; ?>
                                        </select>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                <div class="cfp-field">
                                    <label>Amount (satoshis)</label>
                                    <div style="position:relative">
                                        <input type="number" name="payout_amount" id="trezor-payout-amt"
                                            placeholder="e.g. <?=number_format($net_balance)?>" min="1"
                                            oninput="cfpTrezorCalc()"
                                            style="background:#060606;border:1px solid #1dc92833;color:#1dc928;padding:10px 12px;border-radius:8px;font-size:.9rem;width:100%">
                                        <button type="button" onclick="document.getElementById('trezor-payout-amt').value=<?=$net_balance?>;cfpTrezorCalc()"
                                            style="position:absolute;right:8px;top:50%;transform:translateY(-50%);background:#0d2010;border:1px solid #1dc92833;color:#1dc928;padding:3px 8px;border-radius:5px;font-size:.68rem;cursor:pointer;font-weight:700">MAX</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Quick Amount Presets -->
                            <div style="display:flex;gap:7px;flex-wrap:wrap;margin-bottom:12px">
                                <span style="font-size:.7rem;color:#3a6a3a;align-self:center">Quick:</span>
                                <?php foreach([10000,50000,100000,500000] as $qa): ?>
                                <button type="button" onclick="document.getElementById('trezor-payout-amt').value=<?=$qa?>;cfpTrezorCalc()"
                                    style="background:#060606;border:1px solid #1dc92822;color:#3a6a3a;padding:4px 11px;border-radius:5px;font-size:.73rem;cursor:pointer;transition:all .15s"
                                    onmouseover="this.style.borderColor='#1dc928';this.style.color='#1dc928'"
                                    onmouseout="this.style.borderColor='#1dc92822';this.style.color='#3a6a3a'"><?=number_format($qa)?></button>
                                <?php endforeach; ?>
                                <button type="button" onclick="document.getElementById('trezor-payout-amt').value=<?=$net_balance?>;cfpTrezorCalc()"
                                    style="background:#0d2010;border:1px solid #1dc92844;color:#1dc928;padding:4px 11px;border-radius:5px;font-size:.73rem;cursor:pointer;font-weight:700">SWEEP ALL</button>
                            </div>

                            <!-- Preview Box -->
                            <div id="trezor-calc-box" style="display:none;background:#060606;border:1px solid #1dc92833;border-radius:9px;padding:13px;margin-bottom:13px">
                                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;text-align:center">
                                    <div>
                                        <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1px;color:#3a6a3a;margin-bottom:4px">Sending</div>
                                        <div style="font-family:monospace;font-size:1.1rem;font-weight:800;color:#1dc928" id="tz-send-amt">0</div>
                                        <div style="font-size:.68rem;color:#3a6a3a">sat</div>
                                    </div>
                                    <div>
                                        <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1px;color:#3a6a3a;margin-bottom:4px">&#8776; USD</div>
                                        <div style="font-family:monospace;font-size:1.1rem;font-weight:800;color:#fff" id="tz-usd-amt">$0.00</div>
                                        <div style="font-size:.68rem;color:#444">@ $<?=number_format($btc_price)?>/BTC</div>
                                    </div>
                                    <div>
                                        <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1px;color:#3a6a3a;margin-bottom:4px">Remaining</div>
                                        <div style="font-family:monospace;font-size:1.1rem;font-weight:800;color:#888" id="tz-remain">0</div>
                                        <div style="font-size:.68rem;color:#444">sat in wallet</div>
                                    </div>
                                </div>
                            </div>

                            <div class="cfp-field" style="margin-bottom:14px">
                                <label>Network Fee Estimate (sat) — deducted from wallet ledger</label>
                                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px">
                                    <?php foreach(['Economy'=>1500,'Standard'=>3000,'Priority'=>6000] as $lbl=>$fee): ?>
                                    <label style="cursor:pointer;background:#060606;border:1px solid #1a2a1a;border-radius:7px;padding:9px;text-align:center;transition:all .15s" id="fee-label-<?=strtolower($lbl)?>"
                                        onmouseover="this.style.borderColor='#1dc928'" onmouseout="cfpUpdateFeeStyle()">
                                        <input type="radio" name="trezor_network_fee" value="<?=$fee?>" <?=$lbl==='Standard'?'checked':''?> onclick="cfpTrezorCalc()" style="display:none" id="fee-<?=strtolower($lbl)?>">
                                        <div style="font-size:.72rem;font-weight:700;color:#aaa"><?=$lbl?></div>
                                        <div style="font-size:.85rem;font-weight:800;color:#1dc928;margin-top:2px"><?=number_format($fee)?></div>
                                        <div style="font-size:.66rem;color:#444">sat</div>
                                    </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <div class="cfp-field">
                                <label>Payout Note (for ledger)</label>
                                <input type="text" name="payout_note" placeholder="e.g. Weekly profit sweep to Trezor" style="background:#060606;border:1px solid #1dc92822;color:#aaa;padding:10px 12px;border-radius:8px;font-size:.87rem">
                            </div>

                            <button type="submit" name="cfp_wallet_payout" id="trezor-submit-btn"
                                style="width:100%;margin-top:8px;padding:14px;background:linear-gradient(135deg,#1dc928,#009900);color:#000;font-weight:900;font-size:1rem;border:none;border-radius:10px;cursor:pointer;letter-spacing:1.5px;text-transform:uppercase;font-family:'Segoe UI',sans-serif"
                                onclick="return cfpConfirmTrezorPayout()">
                                &#128423; SWEEP TO TREZOR
                            </button>
                        </form>
                    </div>

                    <!-- TREZOR PAYOUT HISTORY -->
                    <?php if(!empty($trezor_payout_history)): ?>
                    <div style="margin-bottom:14px">
                        <div style="font-size:.66rem;text-transform:uppercase;letter-spacing:1.5px;color:#3a6a3a;margin-bottom:8px">Recent Trezor Payouts</div>
                        <table class="cfp-table" style="font-size:.78rem">
                            <thead><tr><th>Amount</th><th>Description</th><th>Date</th></tr></thead>
                            <tbody>
                            <?php foreach($trezor_payout_history as $tp): ?>
                            <tr>
                                <td style="color:#1dc928;font-weight:700;font-family:monospace"><?=number_format(abs($tp->amount_sat))?> sat</td>
                                <td style="color:#3a6a3a;font-size:.76rem"><?=esc_html(substr($tp->description,0,50))?></td>
                                <td style="color:#333;font-size:.74rem"><?=date('M j, Y H:i',strtotime($tp->created_at))?></td>
                            </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>

                    <!-- TREZOR SETTINGS FORM -->
                    <details style="background:#060606;border:1px solid #1a2a1a;border-radius:10px;overflow:hidden">
                        <summary style="padding:13px 16px;cursor:pointer;font-size:.84rem;font-weight:600;color:#3a6a3a;list-style:none;display:flex;align-items:center;gap:8px">
                            <span style="width:6px;height:6px;background:#1dc928;border-radius:50%"></span>
                            Trezor Configuration &amp; Address Manager
                        </summary>
                        <div style="padding:16px;border-top:1px solid #1a2a1a">
                            <form method="post">
                                <?php wp_nonce_field('cfp_wallet_settings'); ?>
                                <div style="display:grid;grid-template-columns:1fr 1fr;gap:13px;margin-bottom:13px">
                                    <div class="cfp-field">
                                        <label>Device Label</label>
                                        <input type="text" name="trezor_label" value="<?=esc_attr($trezor_label)?>" placeholder="e.g. My Trezor Model T" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:7px;font-size:.85rem">
                                    </div>
                                    <div class="cfp-field">
                                        <label>Device Model</label>
                                        <select name="trezor_model" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:7px;font-size:.85rem">
                                            <?php foreach(['Trezor One','Model T','Model T2T1','Safe 3','Safe 5'] as $m): ?>
                                            <option value="<?=$m?>" <?=selected($trezor_model,$m,false)?> style="background:#222"><?=$m?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="cfp-field">
                                        <label>Currency</label>
                                        <select name="trezor_currency" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:7px;font-size:.85rem">
                                            <?php foreach(['BTC','ETH','LTC','DOGE','BCH','XRP','SOL','BNB'] as $c): ?>
                                            <option value="<?=$c?>" <?=selected($trezor_currency,$c,false)?> style="background:#222"><?=$c?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="cfp-field">
                                        <label>Sweep Threshold (sat)</label>
                                        <input type="number" name="trezor_sweep_threshold" value="<?=esc_attr($trezor_threshold)?>" min="1000" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:7px;font-size:.85rem">
                                        <span class="hint">Alert when wallet balance exceeds this</span>
                                    </div>
                                    <div class="cfp-field">
                                        <label>Sweep Method</label>
                                        <select name="trezor_sweep_method" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:7px;font-size:.85rem">
                                            <option value="nowpayments" <?=selected(cfp_get_setting('trezor_sweep_method','nowpayments'),'nowpayments',false)?>>NOWPayments (auto-send)</option>
                                            <option value="direct" <?=selected(cfp_get_setting('trezor_sweep_method','nowpayments'),'direct',false)?>>Direct (you send manually)</option>
                                        </select>
                                        <span class="hint">NOWPayments sends automatically. Direct records for you to send.</span>
                                    </div>
                                    <div class="cfp-field">
                                        <label>Network Fee (sat)</label>
                                        <input type="number" name="trezor_network_fee" value="<?=esc_attr(cfp_get_setting('trezor_network_fee',3000))?>" min="0" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:7px;font-size:.85rem">
                                        <span class="hint">Fee deducted for blockchain validation (e.g., 3000 sat)</span>
                                    </div>
                                </div>
                                <div class="cfp-field" style="margin-bottom:13px">
                                    <label>Extended Public Key (xPub / zpub) <span style="color:#333;font-weight:400">— from Trezor Suite → Account → Show public key</span></label>
                                    <input type="text" name="trezor_xpub" value="<?=esc_attr($trezor_xpub)?>" placeholder="xpub6… or zpub…" style="background:#111;border:1px solid var(--br);color:#1dc928;padding:9px 12px;border-radius:7px;font-size:.82rem;font-family:monospace">
                                    <span class="hint">Read-only — used to display your Trezor address. Your private keys never leave your device.</span>
                                </div>
                                <div class="cfp-field" style="margin-bottom:13px">
                                    <label>Trezor Receiving Addresses <span style="color:#333;font-weight:400">— one per line, from Trezor Suite → Receive</span></label>
                                    <textarea name="trezor_addresses_raw" rows="4" placeholder="bc1q...&#10;bc1q...&#10;bc1q..." style="background:#111;border:1px solid var(--br);color:#1dc928;padding:9px 12px;border-radius:7px;font-size:.8rem;font-family:monospace;width:100%;resize:vertical"><?=esc_textarea(implode("\n",$trezor_addresses))?></textarea>
                                    <span class="hint">Generate fresh addresses in Trezor Suite. Use a new address for each sweep for privacy.</span>
                                </div>
                                <div class="cfp-field" style="margin-bottom:14px">
                                    <label>Active Receiving Address</label>
                                    <input type="text" name="trezor_active_address" value="<?=esc_attr($trezor_active_addr)?>" placeholder="bc1q… (current address to receive funds)" style="background:#111;border:1px solid #1dc92833;color:#1dc928;padding:9px 12px;border-radius:7px;font-size:.82rem;font-family:monospace">
                                    <span class="hint">This address pre-fills the payout form. Rotate after each withdrawal for privacy.</span>
                                </div>
                                <div class="cfp-field" style="margin-bottom:14px">
                                    <label>Auto-Alert on Threshold</label>
                                    <select name="trezor_auto_alert" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:7px;font-size:.85rem">
                                        <option value="1" <?=selected($trezor_auto_alert,'1',false)?>>&#9989; Show alert when balance hits threshold</option>
                                        <option value="0" <?=selected($trezor_auto_alert,'0',false)?>>&#10060; Disabled</option>
                                    </select>
                                </div>
                                <div style="background:#060606;border:1px solid #1a2a1a;border-radius:9px;padding:13px;margin-bottom:14px">
                                    <div style="font-size:.73rem;font-weight:700;color:#1dc928;margin-bottom:9px">&#128274; Security Notes</div>
                                    <?php foreach([
                                        'Your Trezor private keys never touch this server',
                                        'xPub is read-only — it only derives public addresses',
                                        'Always verify the destination address on your Trezor display before confirming',
                                        'This plugin records payouts in the ledger — it does NOT broadcast transactions',
                                        'To complete a payout: copy the address, send via your Coinbase wallet or hot wallet',
                                        'Rotate receiving addresses regularly for privacy (HD wallet)',
                                    ] as $note): ?>
                                    <div style="display:flex;gap:8px;margin-bottom:6px;align-items:flex-start">
                                        <span style="color:#1dc928;font-size:.8rem;flex-shrink:0">&#10003;</span>
                                        <span style="font-size:.78rem;color:#3a6a3a;line-height:1.45"><?=$note?></span>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                                <button type="submit" name="cfp_save_wallet_settings" class="cfp-btn cfp-btn-ghost" style="border-color:#1dc92844;color:#1dc928;font-size:.88rem;padding:10px 22px">
                                    &#128190; Save Trezor Configuration
                                </button>
                            </form>
                        </div>
                    </details>
                </div>

                <!-- PREMIUM MEMBERSHIP (moved here) -->
                <div class="cfp-card">
                    <h2>&#11088; Premium Membership Revenue</h2>
                    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:16px">
                        <?php
                        $tiers = ['silver'=>['#888','&#129352;'],'gold'=>['#f7931a','&#129351;'],'platinum'=>['#a78bfa','&#128142;']];
                        foreach($tiers as $t=>[$col,$ico]):
                            $cnt = $premium_counts[$t]->cnt ?? 0;
                            $rev = $premium_counts[$t]->total ?? 0;
                        ?>
                        <div style="background:#0d0d0d;border:1px solid <?=$col?>33;border-radius:10px;padding:14px;text-align:center">
                            <div style="font-size:1.6rem;margin-bottom:5px"><?=$ico?></div>
                            <div style="font-size:.82rem;font-weight:700;color:<?=$col?>;text-transform:uppercase;margin-bottom:4px"><?=$t?></div>
                            <div style="font-size:1.2rem;font-weight:800;color:#fff"><?=$cnt?></div>
                            <div style="font-size:.72rem;color:#444;margin-top:2px">active &middot; <?=number_format($rev)?> sat earned</div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div><!-- /.left-col -->

            <!-- RIGHT: AD REVENUE + FUN TOKEN + SETTINGS + LEDGER -->
            <div>
                <!-- AD REVENUE LOG -->
                <div class="cfp-card">
                    <h2>📢 Advertising Revenue</h2>
                    <div id="ad-notice" style="margin-bottom:10px"></div>
                    <div style="display:flex;gap:10px;margin-bottom:14px">
                        <input type="text" id="ad-network" placeholder="Network (e.g. Coinzilla)" style="flex:1;background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.85rem">
                        <input type="number" id="ad-amount" placeholder="Amount (sat)" style="width:130px;background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.85rem">
                        <input type="text" id="ad-period" placeholder="Period" style="width:100px;background:#111;border:1px solid var(--br);color:var(--tx);padding:9px 12px;border-radius:8px;font-size:.85rem">
                        <button onclick="cfpLogAd('<?=$admin_nonce?>')" class="cfp-btn cfp-btn-gold" style="white-space:nowrap;padding:9px 14px">+ Add</button>
                    </div>
                    <?php if(!empty($ad_logs)): ?>
                    <table class="cfp-table" style="font-size:.8rem">
                        <thead><tr><th>Network</th><th>Amount</th><th>Period</th><th>Date</th></tr></thead>
                        <tbody>
                        <?php foreach($ad_logs as $al): ?>
                        <tr>
                            <td style="font-weight:600"><?=esc_html($al->network)?></td>
                            <td style="color:var(--g);font-weight:700"><?=number_format($al->amount_sat)?> sat</td>
                            <td style="color:var(--mt)"><?=esc_html($al->period_label)?></td>
                            <td style="color:#444;font-size:.75rem"><?=date('M j',strtotime($al->recorded_at))?></td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <?php else: ?>
                    <div style="text-align:center;color:var(--mt);padding:16px;font-size:.85rem">No ad revenue logged yet. Add your first entry above.</div>
                    <?php endif; ?>
                </div>

                <!-- FUN TOKEN STATS -->
                <div class="cfp-card">
                    <h2>🪙 <?=cfp_get_setting('fun_token_name','FUN')?> Token Revenue</h2>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:14px">
                        <div style="background:#0d1a2a;border:1px solid #3b82f633;border-radius:9px;padding:14px;text-align:center">
                            <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#3b82f6;margin-bottom:5px">Tokens Sold</div>
                            <div style="font-size:1.5rem;font-weight:800;color:#fff"><?=number_format($fun_sold)?></div>
                        </div>
                        <div style="background:#0a1a0a;border:1px solid #22c55e33;border-radius:9px;padding:14px;text-align:center">
                            <div style="font-size:.65rem;text-transform:uppercase;letter-spacing:1.5px;color:#22c55e;margin-bottom:5px">Total Revenue</div>
                            <div style="font-size:1.5rem;font-weight:800;color:#fff"><?=number_format($fun_revenue)?> sat</div>
                        </div>
                    </div>
                    <div style="font-size:.8rem;color:var(--mt)">
                        Price: <?=number_format(cfp_get_setting('fun_token_price_sat',100))?> sat/token ·
                        Supply: <?=number_format(cfp_get_setting('fun_token_total_supply',1000000))?> tokens
                    </div>
                </div>

                <!-- RECENT WALLET LEDGER -->
                <div class="cfp-card">
                    <h2>📒 Recent Wallet Ledger</h2>
                    <div style="max-height:320px;overflow-y:auto">
                    <table class="cfp-table" style="font-size:.78rem">
                        <thead><tr><th>Stream</th><th>Amount</th><th>Note</th><th>Time</th></tr></thead>
                        <tbody>
                        <?php foreach($recent_entries as $e):
                            $stream_info = $streams[$e->stream] ?? ['📌',$e->stream,'#888'];
                        ?>
                        <tr>
                            <td><span style="color:<?=$stream_info[2]?>;font-size:.75rem;font-weight:600"><?=$stream_info[0]?> <?=esc_html($stream_info[1])?></span></td>
                            <td style="font-weight:700;color:<?=$e->amount_sat>=0?'var(--g)':'var(--rd)'?>;font-family:monospace"><?=$e->amount_sat>=0?'+':''?><?=number_format($e->amount_sat)?></td>
                            <td style="color:#444;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?=esc_attr($e->description)?>"><?=esc_html(substr($e->description,0,35))?></td>
                            <td style="color:#333;font-size:.72rem"><?=human_time_diff(strtotime($e->created_at),current_time('timestamp'))?> ago</td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($recent_entries)): ?><tr><td colspan="4" style="text-align:center;color:#444;padding:20px">No wallet entries yet. Revenue accumulates automatically as users play and withdraw.</td></tr><?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- WALLET SETTINGS -->
        <div class="cfp-card">
            <h2>⚙️ Wallet & Revenue Settings</h2>
            <form method="post">
                <?php wp_nonce_field('cfp_wallet_settings'); ?>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Admin Wallet Enabled</label>
                        <select name="admin_wallet_enabled" style="background:#222">
                            <option value="1" <?=selected(cfp_get_setting('admin_wallet_enabled','1'),'1',false)?>>✅ On — Track all revenue</option>
                            <option value="0" <?=selected(cfp_get_setting('admin_wallet_enabled','1'),'0',false)?>>❌ Off</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Interest Spread Rate (%)</label>
                        <input type="number" name="interest_spread_rate" value="<?=esc_attr(cfp_get_setting('interest_spread_rate','2.0'))?>" step="0.1" min="0" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                        <span class="hint">Admin earns this % above the APY paid to users</span>
                    </div>
                    <div class="cfp-field">
                        <label>FUN Token Name</label>
                        <input type="text" name="fun_token_name" value="<?=esc_attr(cfp_get_setting('fun_token_name','FUN'))?>" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                    </div>
                    <div class="cfp-field">
                        <label>FUN Token Price (sat)</label>
                        <input type="number" name="fun_token_price_sat" value="<?=esc_attr(cfp_get_setting('fun_token_price_sat','100'))?>" min="1" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                    </div>
                    <div class="cfp-field">
                        <label>FUN Token Total Supply</label>
                        <input type="number" name="fun_token_total_supply" value="<?=esc_attr(cfp_get_setting('fun_token_total_supply','1000000'))?>" min="1" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                    </div>
                    <div class="cfp-field">
                        <label>Lottery Ticket Price (sat)</label>
                        <input type="number" name="lottery_ticket_price_sat" value="<?=esc_attr(cfp_get_setting('lottery_ticket_price_sat','500'))?>" min="1" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:10px;border-radius:8px">
                    </div>
                    <div class="cfp-field">
                        <label>Lottery Ticket Sales</label>
                        <select name="lottery_ticket_sale_enabled" style="background:#222">
                            <option value="1" <?=selected(cfp_get_setting('lottery_ticket_sale_enabled','1'),'1',false)?>>✅ Enabled</option>
                            <option value="0" <?=selected(cfp_get_setting('lottery_ticket_sale_enabled','1'),'0',false)?>>❌ Disabled</option>
                        </select>
                    </div>
                </div>
                <div style="margin-top:18px;padding-top:16px;border-top:1px solid var(--br)">
                    <div style="font-size:.75rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt);margin-bottom:14px">Premium Membership Tiers</div>
                    <div class="cfp-form-grid">
                    <?php foreach(['silver'=>['🥈','#888'],'gold'=>['🥇','#f7931a'],'platinum'=>['💎','#a78bfa']] as $t=>[$ico,$col]): ?>
                        <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:10px;padding:14px">
                            <div style="color:<?=$col?>;font-weight:700;font-size:.85rem;margin-bottom:10px"><?=$ico?> <?=ucfirst($t)?></div>
                            <div class="cfp-field" style="margin-bottom:8px">
                                <label>Price (sat)</label>
                                <input type="number" name="premium_<?=$t?>_sat" value="<?=esc_attr(cfp_get_setting("premium_{$t}_sat",$t==='silver'?50000:($t==='gold'?100000:200000)))?>" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:8px 10px;border-radius:7px;font-size:.84rem">
                            </div>
                            <div class="cfp-field" style="margin:0">
                                <label>Duration (days)</label>
                                <input type="number" name="premium_<?=$t?>_days" value="<?=esc_attr(cfp_get_setting("premium_{$t}_days",'30'))?>" style="background:#111;border:1px solid var(--br);color:var(--tx);padding:8px 10px;border-radius:7px;font-size:.84rem">
                            </div>
                        </div>
                    <?php endforeach; ?>
                    </div>
                </div>
                <button type="submit" name="cfp_save_wallet_settings" class="cfp-btn cfp-btn-gold" style="margin-top:18px;font-size:.95rem;padding:12px 28px">💾 Save Wallet Settings</button>
            </form>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
    let cfpRevenueChart = null;
    
    document.addEventListener('DOMContentLoaded', function() {
        cfpLoadRevenueChart('7');
    });
    
    function cfpLoadRevenueChart(days) {
        // Update button states
        ['7', '30', '90'].forEach(d => {
            const btn = document.getElementById('chart-' + d + 'btn');
            if(btn) btn.classList.toggle('active', d === days);
        });
        
        // Fetch data via AJAX
        const fd = new FormData();
        fd.append('action', 'cfp_wallet_chart_data');
        fd.append('nonce', '<?=$admin_nonce?>');
        fd.append('days', days);
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(data => {
                if(data.success) {
                    cfpRenderRevenueChart(data.data, days);
                }
            });
    }
    
    function cfpRenderRevenueChart(chartData, days) {
        const ctx = document.getElementById('cfpRevenueChart');
        if(!ctx) return;
        
        if(cfpRevenueChart) cfpRevenueChart.destroy();
        
        const labels = chartData.dates || [];
        const revenueData = chartData.revenue || [];
        const payoutData = chartData.payouts || [];
        
        cfpRevenueChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [
                    {
                        label: 'Revenue (sat)',
                        data: revenueData,
                        borderColor: '#22c55e',
                        backgroundColor: 'rgba(34, 197, 94, 0.1)',
                        fill: true,
                        tension: 0.4
                    },
                    {
                        label: 'Payouts (sat)',
                        data: payoutData,
                        borderColor: '#ef4444',
                        backgroundColor: 'rgba(239, 68, 68, 0.1)',
                        fill: true,
                        tension: 0.4
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                interaction: {
                    mode: 'index',
                    intersect: false,
                },
                plugins: {
                    legend: {
                        labels: { color: '#888' }
                    }
                },
                scales: {
                    x: { 
                        ticks: { color: '#666' }, 
                        grid: { color: '#222' } 
                    },
                    y: { 
                        ticks: { color: '#666' }, 
                        grid: { color: '#222' } 
                    }
                }
            }
        });
    }
    </script>
    <script>
    const cfpNetBal = <?=$net_balance?>;
    const cfpBtcPrice = <?=$btc_price?>;

    async function cfpLogAd(nonce){
        const network = document.getElementById('ad-network').value;
        const amount  = document.getElementById('ad-amount').value;
        const period  = document.getElementById('ad-period').value;
        if(!network||!amount){document.getElementById('ad-notice').innerHTML='<div class="cfp-notice error">Enter network and amount.</div>';return;}
        const fd = new FormData();
        fd.append('action','cfp_log_ad_revenue'); fd.append('nonce',nonce);
        fd.append('network',network); fd.append('amount',amount); fd.append('period',period);
        const r = await fetch(ajaxurl,{method:'POST',body:fd});
        const d = await r.json();
        document.getElementById('ad-notice').innerHTML=`<div class="cfp-notice ${d.success?'success':'error'}">${d.data.msg}</div>`;
        if(d.success){document.getElementById('ad-network').value='';document.getElementById('ad-amount').value='';document.getElementById('ad-period').value='';setTimeout(()=>location.reload(),1500);}
    }

    function cfpTrezorCalc() {
        const amt  = parseInt(document.getElementById('trezor-payout-amt').value)||0;
        const fee  = parseInt(document.querySelector('input[name="trezor_network_fee"]:checked')?.value||3000);
        const box  = document.getElementById('trezor-calc-box');
        if(amt > 0) {
            box.style.display = '';
            document.getElementById('tz-send-amt').textContent = amt.toLocaleString();
            document.getElementById('tz-usd-amt').textContent  = '$'+(amt/100000000*cfpBtcPrice).toFixed(2);
            document.getElementById('tz-remain').textContent   = Math.max(0,cfpNetBal-amt-fee).toLocaleString();
        } else {
            box.style.display = 'none';
        }
        cfpUpdateFeeStyle();
    }

    function cfpUpdateFeeStyle() {
        ['economy','standard','priority'].forEach(function(l){
            const lbl = document.getElementById('fee-label-'+l);
            const inp = document.getElementById('fee-'+l);
            if(!lbl||!inp) return;
            lbl.style.borderColor = inp.checked ? '#1dc928' : '#1a2a1a';
            lbl.style.background  = inp.checked ? '#0a1a0a' : '#060606';
        });
    }
    cfpUpdateFeeStyle();

    function cfpConfirmTrezorPayout() {
        const amt  = parseInt(document.getElementById('trezor-payout-amt').value)||0;
        const addr = document.getElementById('trezor-dest-addr').value;
        const fee  = parseInt(document.querySelector('input[name="trezor_network_fee"]:checked')?.value||3000);
        if(!addr) { alert('Please enter a Trezor destination address.'); return false; }
        if(!amt)  { alert('Please enter an amount to send.'); return false; }
        if(amt + fee > cfpNetBal) { alert('Amount + fee exceeds wallet balance (' + cfpNetBal.toLocaleString() + ' sat).'); return false; }
        const usd = (amt/100000000*cfpBtcPrice).toFixed(2);
        const confirmed = confirm(
            'SWEEP TO TREZOR\n\n' +
            'Send: ' + amt.toLocaleString() + ' sat ($' + usd + ' USD)\n' +
            'Network fee: ' + fee.toLocaleString() + ' sat\n' +
            'Total deducted: ' + (amt+fee).toLocaleString() + ' sat\n\n' +
            'To: ' + addr + '\n\n' +
            'This records the payout in your ledger.\n' +
            'After saving, copy the address and send via\n' +
            'your Coinbase wallet or hot wallet.\n\n' +
            'Proceed?'
        );
        if(confirmed) {
            // Pre-copy address to clipboard so it's ready immediately after page reload
            if(navigator.clipboard) navigator.clipboard.writeText(addr).catch(()=>{});
        }
        return confirmed;
    }

    function cfpCopyTrezorAddr(addr) {
        navigator.clipboard.writeText(addr).then(function() {
            const btns = document.querySelectorAll('[onclick*="cfpCopyTrezorAddr"]');
            btns.forEach(function(b){ b.textContent = '&#10003; Copied!'; setTimeout(()=>b.textContent='&#128203; Copy', 2000); });
        });
    }
    </script>
    <?php
}

/* ============================================================
   SHORTCODE: [cfp_buy_tickets]  — Purchase extra lottery tickets
   ============================================================ */
add_shortcode('cfp_buy_tickets', function() {
    if(!cfp_get_setting('lottery_ticket_sale_enabled','1')) return '';
    $price  = cfp_get_setting('lottery_ticket_price_sat',500);
    $nonce  = wp_create_nonce('cfp_nonce');
    $ajax   = admin_url('admin-ajax.php');
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>🎟 Buy Lottery Tickets</h2>
        <p class="sub"><?=number_format($price)?> sat per ticket · More tickets = higher winning odds</p>
        <div id="cfp-bt-msg"></div>
        <input class="cfp-input" type="email" id="cfp-bt-email" placeholder="Account email" onblur="cfpLoadBtBal()">
        <div id="cfp-bt-bal"></div>
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:14px">
            <label style="font-size:.78rem;color:#555;white-space:nowrap">Qty:</label>
            <input type="range" id="cfp-bt-qty" min="1" max="20" value="1" oninput="updateBtTotal()" style="flex:1">
            <span style="font-family:'Oswald',sans-serif;font-size:1.2rem;font-weight:800;color:var(--cfp-p)" id="cfp-bt-qty-val">1</span>
        </div>
        <div id="cfp-bt-total" style="background:#0d0d0d;border:1px solid #1e1e1e;border-radius:9px;padding:12px;text-align:center;margin-bottom:14px">
            <span style="font-size:.72rem;color:#555;text-transform:uppercase;letter-spacing:1px">Total Cost</span>
            <div style="font-family:'Oswald',sans-serif;font-size:1.6rem;font-weight:900;color:var(--cfp-p)" id="cfp-bt-cost"><?=number_format($price)?> sat</div>
        </div>
        <button class="cfp-btn-full" style="background:linear-gradient(135deg,var(--cfp-p),var(--cfp-a))" onclick="cfpBuyTickets()">🎟 Buy Tickets</button>
    </div>
    <script>
    const cfpTicketPrice=<?=$price?>;
    function updateBtTotal(){
        const qty=document.getElementById('cfp-bt-qty').value;
        document.getElementById('cfp-bt-qty-val').textContent=qty;
        document.getElementById('cfp-bt-cost').textContent=(qty*cfpTicketPrice).toLocaleString()+' sat';
    }
    async function cfpLoadBtBal(){
        const email=document.getElementById('cfp-bt-email').value; if(!email) return;
        const fd=new FormData(); fd.append('action','cfp_get_user');fd.append('nonce','<?=$nonce?>');fd.append('email',email);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        if(d.success) document.getElementById('cfp-bt-bal').innerHTML=`<div style="text-align:center;font-size:.82rem;color:#555;margin-bottom:10px">Balance: <strong style="color:var(--cfp-p)">${d.data.balance} sat</strong> · Current tickets: <strong style="color:var(--cfp-a)">${d.data.lottery_tickets}</strong></div>`;
    }
    async function cfpBuyTickets(){
        const email=document.getElementById('cfp-bt-email').value;
        const qty=document.getElementById('cfp-bt-qty').value;
        if(!email){document.getElementById('cfp-bt-msg').innerHTML='<div class="cfp-msg error">Enter your email.</div>';return;}
        const fd=new FormData(); fd.append('action','cfp_buy_lottery_ticket');fd.append('nonce','<?=$nonce?>');fd.append('email',email);fd.append('qty',qty);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        document.getElementById('cfp-bt-msg').innerHTML=`<div class="cfp-msg ${d.success?'success':'error'}">${d.data.msg}</div>`;
        if(d.success) cfpLoadBtBal();
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_premium]  — Premium Membership Purchase
   ============================================================ */
add_shortcode('cfp_premium', function() {
    $nonce  = wp_create_nonce('cfp_nonce');
    $ajax   = admin_url('admin-ajax.php');
    $tiers  = [
        'silver'   => ['🥈','Silver',   cfp_get_setting('premium_silver_sat',50000),   cfp_get_setting('premium_silver_days',30),   '#888888', ['2x faster claims','Extra lottery ticket per claim','Silver badge']],
        'gold'     => ['🥇','Gold',     cfp_get_setting('premium_gold_sat',100000),     cfp_get_setting('premium_gold_days',30),     '#f7931a', ['All Silver perks','5x faster claims','3 extra lottery tickets','Priority withdrawals','Gold badge']],
        'platinum' => ['💎','Platinum', cfp_get_setting('premium_platinum_sat',200000), cfp_get_setting('premium_platinum_days',30), '#a78bfa', ['All Gold perks','10x faster claims','Golden ticket every claim','Instant withdrawals','Zero fees','Platinum badge']],
    ];
    ob_start(); ?>
    <div style="background:var(--cfp-dk,#0a0a0a);padding:30px 20px;font-family:'Source Sans 3',sans-serif">
        <h2 style="font-family:'Oswald',sans-serif;font-size:1.7rem;font-weight:900;color:#fff;text-align:center;text-transform:uppercase;letter-spacing:3px;margin-bottom:8px">⭐ Premium Membership</h2>
        <p style="text-align:center;color:#555;font-size:.88rem;margin-bottom:28px">Unlock higher rewards, faster claims, and exclusive perks</p>
        <div id="cfp-prem-msg" style="max-width:600px;margin:0 auto 16px"></div>
        <input class="cfp-input" type="email" id="cfp-prem-email" placeholder="Account email" style="display:block;max-width:400px;margin:0 auto 24px">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:18px;max-width:800px;margin:0 auto">
        <?php foreach($tiers as $key => [$ico,$label,$price,$days,$color,$perks]): ?>
        <div style="background:#111;border:2px solid <?=$color?>44;border-radius:14px;padding:24px;text-align:center;position:relative;overflow:hidden">
            <div style="position:absolute;top:0;left:0;right:0;height:4px;background:<?=$color?>"></div>
            <div style="font-size:2.5rem;margin-bottom:8px"><?=$ico?></div>
            <div style="font-family:'Oswald',sans-serif;font-size:1.3rem;font-weight:800;color:<?=$color?>;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:12px"><?=$label?></div>
            <div style="font-family:'Oswald',sans-serif;font-size:2rem;font-weight:900;color:#fff;margin-bottom:4px"><?=number_format($price)?><span style="font-size:1rem;color:#555"> sat</span></div>
            <div style="font-size:.78rem;color:#444;margin-bottom:18px"><?=$days?> days</div>
            <ul style="list-style:none;text-align:left;margin-bottom:20px;padding:0;display:flex;flex-direction:column;gap:6px">
            <?php foreach($perks as $perk): ?>
                <li style="display:flex;align-items:center;gap:7px;font-size:.82rem;color:#aaa">
                    <span style="color:<?=$color?>;font-size:.8rem">✓</span><?=esc_html($perk)?>
                </li>
            <?php endforeach; ?>
            </ul>
            <button onclick="cfpBuyPremium('<?=$key?>')"
                style="width:100%;padding:12px;background:linear-gradient(135deg,<?=$color?>,<?=$color?>aa);color:<?=$key==='gold'?'#000':'#fff'?>;font-weight:800;font-size:.9rem;border:none;border-radius:9px;cursor:pointer;font-family:'Oswald',sans-serif;letter-spacing:1px;text-transform:uppercase">
                Activate <?=$label?>
            </button>
        </div>
        <?php endforeach; ?>
        </div>
    </div>
    <script>
    async function cfpBuyPremium(tier){
        const email=document.getElementById('cfp-prem-email').value;
        if(!email){document.getElementById('cfp-prem-msg').innerHTML='<div class="cfp-msg error" style="text-align:center">Enter your email first.</div>';return;}
        const fd=new FormData(); fd.append('action','cfp_buy_premium');fd.append('nonce','<?=$nonce?>');fd.append('email',email);fd.append('tier',tier);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        document.getElementById('cfp-prem-msg').innerHTML=`<div class="cfp-msg ${d.success?'success':'error'}" style="text-align:center;max-width:500px;margin:0 auto">${d.data.msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   SHORTCODE: [cfp_fun_token]  — FUN Token Purchase Widget
   ============================================================ */
add_shortcode('cfp_fun_token', function() {
    $name       = cfp_get_setting('fun_token_name','FUN');
    $price_sat  = cfp_get_setting('fun_token_price_sat',100);
    $supply     = cfp_get_setting('fun_token_total_supply',1000000);
    $nonce      = wp_create_nonce('cfp_nonce');
    $ajax       = admin_url('admin-ajax.php');
    global $wpdb;
    $sold       = (float)$wpdb->get_var("SELECT COALESCE(SUM(amount),0) FROM ".CFP_TABLE_FUN_TOKENS." WHERE type='purchase'");
    $remaining  = max(0,$supply-$sold);
    $pct_sold   = $supply>0 ? round($sold/$supply*100,1) : 0;
    ob_start(); ?>
    <div class="cfp-widget">
        <h2>🪙 <?=esc_html($name)?> Token</h2>
        <p class="sub">Buy <?=esc_html($name)?> tokens with your satoshi balance. Use for staking, premium perks &amp; governance.</p>
        <div id="cfp-ft-msg"></div>
        <div style="background:#0d1a2a;border:1px solid #3b82f633;border-radius:10px;padding:14px;margin-bottom:14px">
            <div style="display:flex;justify-content:space-between;font-size:.75rem;color:#3b82f6;margin-bottom:6px"><span>Token Sale Progress</span><span><?=$pct_sold?>% sold</span></div>
            <div style="height:8px;background:#1a1a1a;border-radius:4px;overflow:hidden;margin-bottom:8px">
                <div style="height:100%;width:<?=$pct_sold?>%;background:linear-gradient(90deg,#3b82f6,#22c55e);border-radius:4px"></div>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:.76rem;color:#444">
                <span><?=number_format($sold)?> sold</span><span><?=number_format($remaining)?> remaining</span>
            </div>
        </div>
        <div style="text-align:center;background:#0d0d0d;border:1px solid #1e1e1e;border-radius:9px;padding:14px;margin-bottom:14px">
            <div style="font-size:.68rem;text-transform:uppercase;letter-spacing:2px;color:#444;margin-bottom:5px">Price per token</div>
            <div style="font-family:'Oswald',sans-serif;font-size:2rem;font-weight:900;color:var(--cfp-p)"><?=number_format($price_sat)?> <span style="font-size:1rem">sat</span></div>
        </div>
        <input class="cfp-input" type="email" id="cfp-ft-email" placeholder="Account email">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
            <label style="font-size:.78rem;color:#555">Amount:</label>
            <input type="range" id="cfp-ft-range" min="1" max="100" value="10" oninput="updateFtCalc()" style="flex:1">
            <span style="font-family:'Oswald',sans-serif;font-size:1.1rem;font-weight:800;color:var(--cfp-p)" id="cfp-ft-amt">10</span>
        </div>
        <div style="text-align:center;font-size:.85rem;color:#555;margin-bottom:12px">Cost: <strong style="color:var(--cfp-p)" id="cfp-ft-cost"><?=number_format($price_sat*10)?> sat</strong></div>
        <button class="cfp-btn-full" onclick="cfpBuyFun()">🪙 Buy <?=esc_html($name)?> Tokens</button>
    </div>
    <script>
    const cfpFtPrice=<?=$price_sat?>;
    function updateFtCalc(){const amt=document.getElementById('cfp-ft-range').value;document.getElementById('cfp-ft-amt').textContent=amt;document.getElementById('cfp-ft-cost').textContent=(amt*cfpFtPrice).toLocaleString()+' sat';}
    async function cfpBuyFun(){
        const email=document.getElementById('cfp-ft-email').value;
        const amount=document.getElementById('cfp-ft-range').value;
        if(!email){document.getElementById('cfp-ft-msg').innerHTML='<div class="cfp-msg error">Enter your email.</div>';return;}
        const fd=new FormData(); fd.append('action','cfp_buy_fun_token');fd.append('nonce','<?=$nonce?>');fd.append('email',email);fd.append('amount',amount);
        const r=await fetch('<?=$ajax?>',{method:'POST',body:fd}); const d=await r.json();
        document.getElementById('cfp-ft-msg').innerHTML=`<div class="cfp-msg ${d.success?'success':'error'}">${d.data.msg}</div>`;
    }
    </script>
    <?php return ob_get_clean();
});

/* ============================================================
   AJAX: Wallet Revenue Chart Data
   ============================================================ */
add_action('wp_ajax_cfp_wallet_chart_data', 'cfp_ajax_wallet_chart_data');
function cfp_ajax_wallet_chart_data() {
    check_ajax_referer('cfp_admin_nonce', 'nonce');
    
    global $wpdb;
    $days = intval($_POST['days'] ?? 7);
    
    $revenue = $wpdb->get_results($wpdb->prepare("
        SELECT DATE(created_at) as date,
               SUM(amount_sat) as total
        FROM " . CFP_TABLE_ADMIN_WALLET . "
        WHERE amount_sat > 0
        AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
        GROUP BY DATE(created_at)
        ORDER BY date ASC
    ", $days));
    
    $payouts = $wpdb->get_results($wpdb->prepare("
        SELECT DATE(created_at) as date,
               SUM(ABS(amount_sat)) as total
        FROM " . CFP_TABLE_ADMIN_WALLET . "
        WHERE amount_sat < 0
        AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
        GROUP BY DATE(created_at)
        ORDER BY date ASC
    ", $days));
    
    $all_dates = [];
    $revenue_by_date = [];
    $payouts_by_date = [];
    
    foreach($revenue as $r) { $revenue_by_date[$r->date] = intval($r->total); }
    foreach($payouts as $p) { $payouts_by_date[$p->date] = intval($p->total); }
    
    for($i = $days - 1; $i >= 0; $i--) {
        $all_dates[] = date('Y-m-d', strtotime("-{$i} days"));
    }
    
    $revenue_data = [];
    $payout_data = [];
    
    foreach($all_dates as $date) {
        $revenue_data[] = $revenue_by_date[$date] ?? 0;
        $payout_data[] = $payouts_by_date[$date] ?? 0;
    }
    
    wp_send_json_success([
        'dates' => $all_dates,
        'revenue' => $revenue_data,
        'payouts' => $payout_data
    ]);
}
