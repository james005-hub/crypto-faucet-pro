<?php
/**
 * Admin page: Game settings — house edge, payout multipliers, win odds, admin wallet routing.
 * ALL user losses are credited to the admin wallet automatically by the game AJAX handlers.
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: LINK FAUCETPAY ADDRESS
   ============================================================ */
add_action('wp_ajax_cfp_link_fp_address','cfp_ajax_link_fp_address');
add_action('wp_ajax_nopriv_cfp_link_fp_address','cfp_ajax_link_fp_address');
function cfp_ajax_link_fp_address() {
    check_ajax_referer('cfp_nonce','nonce');
    $email   = sanitize_email($_POST['email']   ?? '');
    $address = sanitize_text_field($_POST['address'] ?? '');
    $currency= strtoupper(sanitize_text_field($_POST['currency'] ?? cfp_get_setting('blockchain_currency','BTC')));
    if(!is_email($email) || empty($address)) wp_send_json_error(['msg'=>'Invalid email or address.']);
    global $wpdb;
    $user = cfp_get_user_by_email($email);
    if(!$user) wp_send_json_error(['msg'=>'Account not found.']);
    // Basic address sanity check
    if ( strlen(trim($address)) < 25 || strpos($address, ' ') !== false ) {
        wp_send_json_error(['msg' => 'Invalid address format.']);
    }
    $taken = $wpdb->get_var($wpdb->prepare(
        "SELECT id FROM " . CFP_TABLE_USERS . " WHERE btc_address=%s AND id!=%d", $address, $user->id
    ));
    if($taken) wp_send_json_error(['msg'=>'This address is already linked to another account.']);
    $wpdb->update(CFP_TABLE_USERS, ['btc_address'=>$address], ['id'=>$user->id]);
    wp_send_json_success(['msg'=>'Address linked!','address'=>$address]);
}

/* ============================================================
   FILTER: Patch cfp_get_user to include fp_address
   ============================================================ */
remove_action('wp_ajax_cfp_get_user','cfp_ajax_get_user');
remove_action('wp_ajax_nopriv_cfp_get_user','cfp_ajax_get_user');
add_action('wp_ajax_cfp_get_user','cfp_ajax_get_user_v2');
add_action('wp_ajax_nopriv_cfp_get_user','cfp_ajax_get_user_v2');
function cfp_ajax_get_user_v2() {
    check_ajax_referer('cfp_nonce','nonce');
    $email=sanitize_email($_POST['email']??'');
    global $wpdb;
    $user=cfp_get_user_by_email($email);
    if(!$user) wp_send_json_error(['msg'=>'Account not found.']);
    $remaining=0;
    if($user->last_claim) {
        $interval=intval(cfp_get_setting('claim_interval_minutes',60))*60;
        $remaining=max(0,$interval-(current_time('timestamp')-strtotime($user->last_claim)));
    }
    wp_send_json_success([
        'balance'        => number_format($user->balance_sat),
        'balance_raw'    => $user->balance_sat,
        'savings'        => number_format($user->savings_sat),
        'savings_raw'    => $user->savings_sat,
        'username'       => $user->username,
        'ref_code'       => $user->ref_code,
        'lottery_tickets'=> $user->lottery_tickets,
        'golden_tickets' => $user->golden_tickets,
        'total_earned'   => number_format($user->total_earned),
        'remaining'      => $remaining,
        'fp_address'     => $user->btc_address,
    ]);
}

/* ============================================================
   ADMIN: GAMES MANAGEMENT PAGE
   ============================================================ */
function cfp_admin_games() {
    global $wpdb;
    $saved = false;

    if ( isset($_POST['cfp_save_game_settings']) && check_admin_referer('cfp_game_settings') ) {
        $all_fields = [
            'slots_enabled','slots_house_edge',
            'coinflip_enabled','coinflip_house_edge',
            'dice_enabled','dice_house_edge',
            'crash_enabled','crash_house_edge',
            'wheel_enabled','wheel_house_edge',
            'multiply_enabled','multiply_house_edge',
            'slots_mult_seven','slots_mult_bar','slots_mult_bell',
            'slots_mult_cherry','slots_mult_lemon','slots_mult_orange','slots_mult_grape',
            'slots_mult_pair','slots_mult_cherry_any',
            'coinflip_win_mult',
            'multiply_win_mult',
            'wheel_mult_2x','wheel_weight_2x',
            'wheel_mult_1_5x','wheel_weight_1_5x',
            'wheel_mult_3x','wheel_weight_3x',
            'wheel_mult_5x','wheel_weight_5x',
            'wheel_mult_10x','wheel_weight_10x',
            'wheel_mult_half','wheel_weight_half',
            'wheel_lose_weight',
            'crash_max_mult',
            'admin_wallet_enabled',
            'admin_wallet_stream_hilo','admin_wallet_stream_slots',
            'admin_wallet_stream_coinflip','admin_wallet_stream_dice',
            'admin_wallet_stream_crash','admin_wallet_stream_wheel',
            'admin_wallet_stream_blackjack','admin_wallet_stream_roulette',
            'admin_wallet_stream_baccarat','admin_wallet_stream_plinko',
            'admin_wallet_stream_mines','admin_wallet_stream_videopoker',
            'admin_wallet_stream_keno','admin_wallet_stream_raffle',
            'admin_wallet_stream_withdraw_fee','admin_wallet_stream_interest_spread',
            'admin_wallet_stream_lottery_tickets','admin_wallet_stream_fun_tokens',
            'admin_wallet_stream_premium','admin_wallet_stream_advertising',
            'admin_wallet_stream_p2p',
            'p2p_house_edge',
        ];
        foreach ( $all_fields as $f ) {
            if ( isset($_POST[$f]) ) cfp_update_setting( $f, sanitize_text_field($_POST[$f]) );
        }
        $saved = true;
    }

    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };

    $stat_tables = [
        'hilo'     => ['Hi-Lo Multiply','🎲',CFP_TABLE_MULTIPLY],
        'slots'    => ['Slots','🎰',CFP_TABLE_SLOTS],
        'coinflip' => ['Coin Flip','🪙',CFP_TABLE_COINFLIP],
        'dice'     => ['Dice Roll','🎲',CFP_TABLE_DICE],
        'crash'    => ['Crash','📈',CFP_TABLE_CRASH],
        'wheel'    => ['Wheel','🎡',CFP_TABLE_WHEEL],
    ];
    $colors=['hilo'=>'#f7931a','slots'=>'#a855f7','coinflip'=>'#ffcc02','dice'=>'#22c55e','crash'=>'#ef4444','wheel'=>'#3b82f6'];
    ?>
    <div class="cfp-wrap">
    <div class="cfp-header">
        <span class="cfp-logo-badge">⚡ CFP</span>
        <h1>🎮 Games Management</h1>
        <p style="color:#777;margin:4px 0 0;font-size:.9rem">
            Control house edge, payout multipliers, win odds, and admin wallet routing.
            <strong style="color:#22c55e">All user losses automatically go to your Admin Admin Wallet.</strong>
        </p>
    </div>
    <?php if($saved): ?><div class="cfp-notice success">✅ Game settings saved!</div><?php endif; ?>

    <!-- LIVE STATS -->
    <h2 style="color:#fff;margin:24px 0 12px;font-size:1rem;text-transform:uppercase;letter-spacing:2px">📊 Live Game Stats</h2>
    <div class="cfp-stats-grid" style="grid-template-columns:repeat(auto-fit,minmax(190px,1fr));margin-bottom:30px">
    <?php foreach($stat_tables as $key=>[$label,$icon,$tbl]):
        $plays=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$tbl}");
        $wagered=(int)$wpdb->get_var("SELECT COALESCE(SUM(bet_sat),0) FROM {$tbl}");
        $paid=(int)$wpdb->get_var("SELECT COALESCE(SUM(payout_sat),0) FROM {$tbl}");
        $ggr=$wagered-$paid;
        $rtp=$wagered>0?round($paid/$wagered*100,1):0;
        $today=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$tbl} WHERE DATE(played_at)=CURDATE()");
    ?>
    <div class="cfp-stat-card" style="border-top:3px solid <?=$colors[$key]?>">
        <div class="label"><?=$icon?> <?=$label?></div>
        <div class="value" style="font-size:1.3rem"><?=number_format($plays)?> plays</div>
        <div class="sub" style="line-height:1.8">
            Today: <?=$today?><br>
            Wagered: <?=number_format($wagered)?> sat<br>
            Paid out: <?=number_format($paid)?> sat<br>
            <strong style="color:<?=$colors[$key]?>">GGR (yours): <?=number_format($ggr)?> sat</strong><br>
            <span style="color:#555">RTP: <?=$rtp?>%</span>
        </div>
    </div>
    <?php endforeach; ?>
    </div>

    <form method="post">
    <?php wp_nonce_field('cfp_game_settings'); ?>

    <!-- FAUCET CLAIM PAYOUTS (read-only links) -->
    <div class="cfp-card" style="margin-bottom:24px">
        <h2>⏰ Faucet Claim Payouts</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:14px">
            Manage claim amounts and interval in
            <a href="<?=admin_url('admin.php?page=cfp-settings')?>" style="color:var(--or)">General Settings → Faucet Settings</a>.
        </p>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr))">
            <div class="cfp-field"><label>Min Claim (sat)</label>
                <input type="number" readonly value="<?=esc_attr($gs('min_claim_sat',98))?>" style="opacity:.5;cursor:not-allowed">
                <small style="color:#555">Edit in General Settings</small></div>
            <div class="cfp-field"><label>Max Claim (sat)</label>
                <input type="number" readonly value="<?=esc_attr($gs('max_claim_sat',200))?>" style="opacity:.5;cursor:not-allowed">
                <small style="color:#555">Edit in General Settings</small></div>
            <div class="cfp-field"><label>Referral Bonus (%)</label>
                <input type="number" readonly value="<?=esc_attr($gs('referral_percent',50))?>" style="opacity:.5;cursor:not-allowed">
                <small style="color:#555">Edit in General Settings</small></div>
        </div>
    </div>

    <!-- HI-LO -->
    <div class="cfp-card" style="margin-bottom:24px">
        <h2>🎲 Hi-Lo / Multiply Game</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:14px">Win payout = bet × multiplier × (1 − house_edge%). Losses go entirely to Admin Wallet.</p>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr))">
            <div class="cfp-field"><label>Status</label>
                <select name="multiply_enabled" style="background:#222">
                    <option value="1" <?=selected($gs('multiply_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('multiply_enabled','1'),'0',false)?>>❌ Disabled</option>
                </select></div>
            <div class="cfp-field"><label>House Edge (%)</label>
                <input type="number" name="multiply_house_edge" value="<?=esc_attr($gs('multiply_house_edge','1'))?>" min="0" max="50" step="0.1">
                <small style="color:#555">Deducted from winning payout</small></div>
            <div class="cfp-field"><label>Win Multiplier (×)</label>
                <input type="number" name="multiply_win_mult" value="<?=esc_attr($gs('multiply_win_mult','2'))?>" min="1.1" max="10" step="0.1">
                <small style="color:#555">Default: 2× (doubles the bet on win)</small></div>
        </div>
    </div>

    <!-- SLOTS -->
    <div class="cfp-card" style="margin-bottom:24px">
        <h2>🎰 Slots Machine</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:14px">Jackpot = 3 matching symbols. Pair = any 2 match. Cherry = any cherry on reels. All losses → Admin Wallet.</p>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin-bottom:16px">
            <div class="cfp-field"><label>Status</label>
                <select name="slots_enabled" style="background:#222">
                    <option value="1" <?=selected($gs('slots_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('slots_enabled','1'),'0',false)?>>❌ Disabled</option>
                </select></div>
            <div class="cfp-field"><label>House Edge (%)</label>
                <input type="number" name="slots_house_edge" value="<?=esc_attr($gs('slots_house_edge','5'))?>" min="0" max="50" step="0.1">
                <small style="color:#555">Cut from every win payout</small></div>
        </div>
        <h3 style="color:#aaa;font-size:.82rem;text-transform:uppercase;letter-spacing:1px;margin:0 0 10px">Jackpot Multipliers (3 of a kind)</h3>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(150px,1fr))">
        <?php $slot_syms=['seven'=>['🔴 7 (rarest)','20'],'bar'=>['BAR','8'],'bell'=>['🔔 Bell','5'],
            'cherry'=>['🍒 Cherry','3'],'lemon'=>['🍋 Lemon','2'],'orange'=>['🍊 Orange','1.5'],'grape'=>['🍇 Grape','1.2']];
        foreach($slot_syms as $sym=>[$sl,$sd]): ?>
            <div class="cfp-field"><label><?=$sl?> ×</label>
                <input type="number" name="slots_mult_<?=$sym?>" value="<?=esc_attr($gs('slots_mult_'.$sym,$sd))?>" min="0.5" max="100" step="0.1"></div>
        <?php endforeach; ?>
        </div>
        <h3 style="color:#aaa;font-size:.82rem;text-transform:uppercase;letter-spacing:1px;margin:16px 0 10px">Partial Win Multipliers</h3>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
            <div class="cfp-field"><label>Pair (any 2 match) ×</label>
                <input type="number" name="slots_mult_pair" value="<?=esc_attr($gs('slots_mult_pair','1.5'))?>" min="0.1" max="20" step="0.1">
                <small style="color:#555">Default: 1.5×</small></div>
            <div class="cfp-field"><label>Any Cherry on reels ×</label>
                <input type="number" name="slots_mult_cherry_any" value="<?=esc_attr($gs('slots_mult_cherry_any','0.5'))?>" min="0.1" max="5" step="0.1">
                <small style="color:#555">Default: 0.5× (half back)</small></div>
        </div>
    </div>

    <!-- COIN FLIP -->
    <div class="cfp-card" style="margin-bottom:24px">
        <h2>🪙 Coin Flip</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:14px">50/50. Win payout = bet × multiplier × (1 − edge%). Losses → Admin Wallet.</p>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr))">
            <div class="cfp-field"><label>Status</label>
                <select name="coinflip_enabled" style="background:#222">
                    <option value="1" <?=selected($gs('coinflip_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('coinflip_enabled','1'),'0',false)?>>❌ Disabled</option>
                </select></div>
            <div class="cfp-field"><label>House Edge (%)</label>
                <input type="number" name="coinflip_house_edge" value="<?=esc_attr($gs('coinflip_house_edge','2'))?>" min="0" max="50" step="0.1"></div>
            <div class="cfp-field"><label>Win Multiplier (×)</label>
                <input type="number" name="coinflip_win_mult" value="<?=esc_attr($gs('coinflip_win_mult','2'))?>" min="1.1" max="10" step="0.1">
                <small style="color:#555">Default: 2× (doubles the bet)</small></div>
        </div>
    </div>

    <!-- DICE -->
    <div class="cfp-card" style="margin-bottom:24px">
        <h2>🎲 Dice Roll</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:14px">Multiplier is auto-calculated from win probability. House edge lowers all payouts. Losses → Admin Wallet.</p>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr))">
            <div class="cfp-field"><label>Status</label>
                <select name="dice_enabled" style="background:#222">
                    <option value="1" <?=selected($gs('dice_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('dice_enabled','1'),'0',false)?>>❌ Disabled</option>
                </select></div>
            <div class="cfp-field"><label>House Edge (%)</label>
                <input type="number" name="dice_house_edge" value="<?=esc_attr($gs('dice_house_edge','2'))?>" min="0" max="50" step="0.1">
                <small style="color:#555">e.g. 2% edge → OVER 50 pays ~1.96×</small></div>
        </div>
    </div>

    <!-- CRASH -->
    <div class="cfp-card" style="margin-bottom:24px">
        <h2>📈 Crash Game</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:14px">House edge controls how often it crashes early. Max multiplier caps the max possible win. Losses → Admin Wallet.</p>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr))">
            <div class="cfp-field"><label>Status</label>
                <select name="crash_enabled" style="background:#222">
                    <option value="1" <?=selected($gs('crash_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('crash_enabled','1'),'0',false)?>>❌ Disabled</option>
                </select></div>
            <div class="cfp-field"><label>House Edge (%)</label>
                <input type="number" name="crash_house_edge" value="<?=esc_attr($gs('crash_house_edge','5'))?>" min="0" max="50" step="0.1"></div>
            <div class="cfp-field"><label>Max Crash Multiplier</label>
                <input type="number" name="crash_max_mult" value="<?=esc_attr($gs('crash_max_mult','10'))?>" min="2" max="1000" step="1">
                <small style="color:#555">Game never rises above this (default: 10×)</small></div>
        </div>
    </div>

    <!-- WHEEL -->
    <div class="cfp-card" style="margin-bottom:24px">
        <h2>🎡 Wheel of Fortune</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:14px">
            Each segment has a <strong>Multiplier</strong> (what players win) and a <strong>Weight</strong> (how likely it lands).
            Higher weight = lands more often. LOSE segments send the full bet to Admin Wallet.
        </p>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(180px,1fr));margin-bottom:18px">
            <div class="cfp-field"><label>Status</label>
                <select name="wheel_enabled" style="background:#222">
                    <option value="1" <?=selected($gs('wheel_enabled','1'),'1',false)?>>✅ Enabled</option>
                    <option value="0" <?=selected($gs('wheel_enabled','1'),'0',false)?>>❌ Disabled</option>
                </select></div>
            <div class="cfp-field"><label>House Edge (%)</label>
                <input type="number" name="wheel_house_edge" value="<?=esc_attr($gs('wheel_house_edge','3'))?>" min="0" max="50" step="0.1">
                <small style="color:#555">Deducted from every win payout</small></div>
        </div>
        <div style="overflow-x:auto">
        <table style="width:100%;border-collapse:collapse;font-size:.85rem">
            <thead><tr style="color:#555;font-size:.72rem;text-transform:uppercase;letter-spacing:1px">
                <th style="text-align:left;padding:8px 12px;border-bottom:1px solid #1c1c1c">Segment</th>
                <th style="padding:8px 12px;border-bottom:1px solid #1c1c1c">Win Multiplier (×)</th>
                <th style="padding:8px 12px;border-bottom:1px solid #1c1c1c">Weight (odds)</th>
                <th style="padding:8px 12px;border-bottom:1px solid #1c1c1c">Note</th>
            </tr></thead>
            <tbody>
            <?php $wheel_segs=[
                ['2x','wheel_mult_2x','2','wheel_weight_2x','25','🟢 Common win'],
                ['1.5x','wheel_mult_1_5x','1.5','wheel_weight_1_5x','20','🟡 Small win'],
                ['3x','wheel_mult_3x','3','wheel_weight_3x','10','🟣 Medium win'],
                ['5x','wheel_mult_5x','5','wheel_weight_5x','5','🔵 Big win'],
                ['10x','wheel_mult_10x','10','wheel_weight_10x','2','🟡 Jackpot'],
                ['0.5x','wheel_mult_half','0.5','wheel_weight_half','8','⚪ Partial return'],
            ];
            foreach($wheel_segs as [$slab,$mk,$md,$wk,$wd,$note]): ?>
            <tr style="border-bottom:1px solid #111">
                <td style="padding:10px 12px;color:#fff;font-weight:700"><?=$slab?></td>
                <td style="padding:10px 12px;text-align:center">
                    <input type="number" name="<?=$mk?>" value="<?=esc_attr($gs($mk,$md))?>" min="0.1" max="100" step="0.1" style="width:80px;text-align:center"></td>
                <td style="padding:10px 12px;text-align:center">
                    <input type="number" name="<?=$wk?>" value="<?=esc_attr($gs($wk,$wd))?>" min="0" max="1000" step="1" style="width:80px;text-align:center"></td>
                <td style="padding:10px 12px;color:#555;font-size:.8rem"><?=$note?></td>
            </tr>
            <?php endforeach; ?>
            <tr style="background:#1a0000">
                <td style="padding:10px 12px;color:#ef4444;font-weight:700">LOSE</td>
                <td style="padding:10px 12px;text-align:center;color:#555">0×</td>
                <td style="padding:10px 12px;text-align:center">
                    <input type="number" name="wheel_lose_weight" value="<?=esc_attr($gs('wheel_lose_weight','30'))?>" min="0" max="1000" step="1" style="width:80px;text-align:center;border-color:#ef444444"></td>
                <td style="padding:10px 12px;color:#ef4444;font-size:.8rem">🔴 Full bet → Admin Wallet</td>
            </tr>
            </tbody>
        </table>
        </div>
    </div>

    <!-- P2P HOUSE EDGE -->
    <div class="cfp-card" style="margin-bottom:24px">
        <h2>🤝 P2P Events — House Cut</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:14px">
            When an event resolves, winners share the losing side's pot minus the house cut.
            The house cut goes directly to your Admin Admin Wallet.
        </p>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
            <div class="cfp-field">
                <label>P2P House Cut (%)</label>
                <input type="number" name="p2p_house_edge"
                    value="<?=esc_attr($gs('p2p_house_edge','5'))?>"
                    min="0" max="50" step="0.1">
                <small style="color:#555">Default 5% — taken from total pot before paying winners</small>
            </div>
        </div>
    </div>

    <!-- ADMIN WALLET ROUTING -->
    <div class="cfp-card" style="margin-bottom:24px;border:1px solid #1a3a1a">
        <h2 style="color:#22c55e">💰 Admin Wallet — Revenue Routing</h2>
        <p style="color:#777;font-size:.85rem;margin-bottom:18px">
            Every sat a user loses, and every purchase/fee, is automatically credited to your Admin Admin Wallet.
            Toggle individual streams on or off. The sat still leave the user regardless.
        </p>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr));margin-bottom:22px">
            <div class="cfp-field" style="border:1px solid #22c55e33;border-radius:8px;padding:14px;background:#0a1a0a">
                <label style="color:#22c55e">🟢 Master Switch</label>
                <select name="admin_wallet_enabled" style="background:#0a1a0a;color:#22c55e;border-color:#22c55e44">
                    <option value="1" <?=selected($gs('admin_wallet_enabled','1'),'1',false)?>>✅ Wallet ON — collecting all revenue</option>
                    <option value="0" <?=selected($gs('admin_wallet_enabled','1'),'0',false)?>>⏸ Wallet OFF — no revenue logging</option>
                </select>
            </div>
        </div>
        <h3 style="color:#aaa;font-size:.82rem;text-transform:uppercase;letter-spacing:1px;margin:0 0 12px">Per-Stream Controls</h3>
        <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">
        <?php $streams=[
            // ── Casino Games (original) ────────────────────────────────
            'admin_wallet_stream_hilo'            =>['🎲 Hi-Lo / Multiply — losses + edge','house_edge_hilo'],
            'admin_wallet_stream_slots'           =>['🎰 Slots — losses + edge','house_edge_slots'],
            'admin_wallet_stream_coinflip'        =>['🪙 Coin Flip — losses + edge','house_edge_coinflip'],
            'admin_wallet_stream_dice'            =>['🎲 Dice Roll — losses + edge','house_edge_dice'],
            'admin_wallet_stream_crash'           =>['📈 Crash — losses + edge','house_edge_crash'],
            'admin_wallet_stream_wheel'           =>['🎡 Wheel of Fortune — losses + edge','house_edge_wheel'],
            // ── Casino Games (new) ─────────────────────────────────────
            'admin_wallet_stream_blackjack'       =>['🃏 Blackjack — losses + edge','house_edge_blackjack'],
            'admin_wallet_stream_roulette'        =>['🎡 Roulette — losses + edge','house_edge_roulette'],
            'admin_wallet_stream_baccarat'        =>['🎴 Baccarat — losses + edge','house_edge_baccarat'],
            'admin_wallet_stream_plinko'          =>['🎯 Plinko — losses + edge','house_edge_plinko'],
            'admin_wallet_stream_mines'           =>['💣 Mines — losses + edge','house_edge_mines'],
            'admin_wallet_stream_videopoker'      =>['🃏 Video Poker — losses + edge','house_edge_videopoker'],
            'admin_wallet_stream_keno'            =>['🎱 Keno — losses + edge','house_edge_keno'],
            'admin_wallet_stream_raffle'          =>['🎟️ Raffle — house cut','house_edge_raffle'],
            // ── P2P Events ─────────────────────────────────────────────
            'admin_wallet_stream_p2p'             =>['🤝 P2P Events — house cut from pot','p2p_house_cut'],
            // ── Withdrawals & Fees ─────────────────────────────────────
            'admin_wallet_stream_withdraw_fee'    =>['💸 Withdrawal Fees','withdraw_fee'],
            // ── Savings ────────────────────────────────────────────────
            'admin_wallet_stream_interest_spread' =>['🏦 Savings Interest Spread','interest_spread'],
            // ── Store / Purchases ──────────────────────────────────────
            'admin_wallet_stream_lottery_tickets' =>['🎟️ Lottery Ticket Sales','lottery_ticket_sales'],
            'admin_wallet_stream_fun_tokens'      =>['🪙 FUN Token Sales','fun_token_sales'],
            'admin_wallet_stream_premium'         =>['⭐ Premium Memberships','premium_membership'],
            'admin_wallet_stream_advertising'     =>['📢 Advertising Revenue','advertising'],
        ];
        foreach($streams as $sk=>[$sl,$ws]):
            $total=(int)$wpdb->get_var($wpdb->prepare("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE stream=%s",$ws));
        ?>
        <div class="cfp-field" style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:8px;padding:12px">
            <label><?=$sl?></label>
            <select name="<?=$sk?>" style="background:#111;margin-bottom:8px">
                <option value="1" <?=selected($gs($sk,'1'),'1',false)?>>✅ Routing to wallet</option>
                <option value="0" <?=selected($gs($sk,'1'),'0',false)?>>⏸ Paused</option>
            </select>
            <div style="font-size:.78rem;color:#22c55e;font-weight:700">Earned: <?=number_format($total)?> sat</div>
        </div>
        <?php endforeach; ?>
        </div>
        <?php
        $wallet_total=(int)$wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET);
        $wallet_today=(int)$wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE DATE(created_at)=CURDATE()");
        $wallet_week=(int)$wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM ".CFP_TABLE_ADMIN_WALLET." WHERE created_at>=DATE_SUB(NOW(),INTERVAL 7 DAY)");
        ?>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:20px">
            <div style="background:#0a1a0a;border:1px solid #22c55e33;border-radius:8px;padding:14px;text-align:center">
                <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:2px;color:#22c55e;margin-bottom:4px">All-Time Revenue</div>
                <div style="font-size:1.6rem;font-weight:900;color:#22c55e"><?=number_format($wallet_total)?> sat</div>
            </div>
            <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:8px;padding:14px;text-align:center">
                <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:4px">This Week</div>
                <div style="font-size:1.6rem;font-weight:900;color:#fff"><?=number_format($wallet_week)?> sat</div>
            </div>
            <div style="background:#0d0d0d;border:1px solid #1c1c1c;border-radius:8px;padding:14px;text-align:center">
                <div style="font-size:.7rem;text-transform:uppercase;letter-spacing:2px;color:#555;margin-bottom:4px">Today</div>
                <div style="font-size:1.6rem;font-weight:900;color:#fff"><?=number_format($wallet_today)?> sat</div>
            </div>
        </div>
        <p style="color:#555;font-size:.78rem;margin-top:10px">
            Full log: <a href="<?=admin_url('admin.php?page=cfp-wallet')?>" style="color:var(--or)">Admin Wallet →</a>
        </p>
    </div>

    <!-- RECENT PLAYS -->
    <div class="cfp-card" style="margin-bottom:24px">
        <h2>🕹️ Recent Plays — All Games</h2>
        <?php
        $game_tables2=['Hi-Lo'=>CFP_TABLE_MULTIPLY,'Slots'=>CFP_TABLE_SLOTS,'Coin Flip'=>CFP_TABLE_COINFLIP,'Dice'=>CFP_TABLE_DICE,'Crash'=>CFP_TABLE_CRASH,'Wheel'=>CFP_TABLE_WHEEL];
        $recent_plays=[];
        foreach($game_tables2 as $gname=>$gtbl) {
            $rows=$wpdb->get_results("SELECT '{$gname}' AS game, user_id, bet_sat, payout_sat, played_at FROM {$gtbl} ORDER BY played_at DESC LIMIT 5");
            foreach($rows as $r) $recent_plays[]=$r;
        }
        usort($recent_plays,fn($a,$b)=>strtotime($b->played_at)-strtotime($a->played_at));
        $recent_plays=array_slice($recent_plays,0,20);
        ?>
        <table class="cfp-table" style="font-size:.82rem">
            <thead><tr><th>Game</th><th>User</th><th>Bet</th><th>Payout</th><th>Net</th><th>Time</th></tr></thead>
            <tbody>
            <?php foreach($recent_plays as $p):
                $uname=$wpdb->get_var($wpdb->prepare("SELECT username FROM ".CFP_TABLE_USERS." WHERE id=%d",$p->user_id));
                $net=$p->payout_sat-$p->bet_sat;
            ?>
            <tr>
                <td><?=$p->game?></td>
                <td><?=esc_html($uname)?></td>
                <td><?=number_format($p->bet_sat)?> sat</td>
                <td><?=number_format($p->payout_sat)?> sat</td>
                <td style="color:<?=$net>=0?'var(--gr)':'var(--rd)'?>;font-weight:700"><?=$net>=0?'+':''?><?=number_format($net)?></td>
                <td style="color:var(--mt)"><?=human_time_diff(strtotime($p->played_at),current_time('timestamp'))?> ago</td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <button type="submit" name="cfp_save_game_settings" class="cfp-btn cfp-btn-gold" style="font-size:1rem;padding:13px 36px">
        💾 Save All Game Settings
    </button>
    </form>
    </div>
    <?php
}
