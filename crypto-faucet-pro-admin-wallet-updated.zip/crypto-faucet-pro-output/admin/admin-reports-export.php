<?php
/**
 * Admin page: Reports & Export - Export data to CSV/JSON, scheduled reports
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Generate Reports
   ============================================================ */
add_action('wp_ajax_cfp_generate_report', 'cfp_ajax_generate_report');
function cfp_ajax_generate_report() {
    check_ajax_referer('cfp_report_nonce', 'nonce');
    
    $report_type = sanitize_text_field($_POST['report_type'] ?? 'users');
    $format = sanitize_text_field($_POST['format'] ?? 'csv');
    $date_from = sanitize_text_field($_POST['date_from'] ?? '');
    $date_to = sanitize_text_field($_POST['date_to'] ?? '');
    
    global $wpdb;
    
    $data = [];
    $headers = [];
    
    switch($report_type) {
        case 'users':
            $headers = ['ID', 'Username', 'Email', 'Balance (sat)', 'Total Earned', 'Total Claims', 'Referrer ID', 'Created At'];
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM " . CFP_TABLE_USERS . " WHERE created_at >= %s AND created_at <= %s",
                $date_from . ' 00:00:00', $date_to . ' 23:59:59'
            ));
            foreach($results as $r) {
                $data[] = [$r->id, $r->username, $r->email, $r->balance_sat, $r->total_earned, $r->total_claims, $r->referrer_id, $r->created_at];
            }
            break;
            
        case 'claims':
            $headers = ['ID', 'User ID', 'Amount (sat)', 'IP Address', 'Claimed At'];
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM " . CFP_TABLE_CLAIMS . " WHERE claimed_at >= %s AND claimed_at <= %s",
                $date_from . ' 00:00:00', $date_to . ' 23:59:59'
            ));
            foreach($results as $r) {
                $data[] = [$r->id, $r->user_id, $r->amount_sat, $r->ip_address, $r->claimed_at];
            }
            break;
            
        case 'transactions':
            $headers = ['ID', 'User ID', 'Type', 'Amount (sat)', 'Fee (sat)', 'Status', 'Created At'];
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM " . CFP_TABLE_TRANSACTIONS . " WHERE created_at >= %s AND created_at <= %s",
                $date_from . ' 00:00:00', $date_to . ' 23:59:59'
            ));
            foreach($results as $r) {
                $data[] = [$r->id, $r->user_id, $r->type, $r->amount_sat, $r->fee_sat, $r->status, $r->created_at];
            }
            break;
            
        case 'withdrawals':
            $headers = ['ID', 'User ID', 'Amount (sat)', 'Address', 'Status', 'Processed At'];
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM " . CFP_TABLE_WITHDRAWALS . " WHERE created_at >= %s AND created_at <= %s",
                $date_from . ' 00:00:00', $date_to . ' 23:59:59'
            ));
            foreach($results as $r) {
                $data[] = [$r->id, $r->user_id, $r->amount_sat, $r->address, $r->status, $r->processed_at ?? $r->created_at];
            }
            break;
            
        case 'games':
            $headers = ['Game', 'User ID', 'Bet (sat)', 'Payout (sat)', 'Profit', 'Played At'];
            $tables = [
                'hilo' => CFP_TABLE_MULTIPLY,
                'slots' => CFP_TABLE_SLOTS,
                'coinflip' => CFP_TABLE_COINFLIP,
                'dice' => CFP_TABLE_DICE,
                'crash' => CFP_TABLE_CRASH,
                'wheel' => CFP_TABLE_WHEEL
            ];
            foreach($tables as $name => $tbl) {
                $results = $wpdb->get_results($wpdb->prepare(
                    "SELECT user_id, bet_sat, payout_sat, played_at FROM {$tbl} WHERE played_at >= %s AND played_at <= %s",
                    $date_from . ' 00:00:00', $date_to . ' 23:59:59'
                ));
                foreach($results as $r) {
                    $profit = $r->bet_sat - $r->payout_sat;
                    $data[] = [$name, $r->user_id, $r->bet_sat, $r->payout_sat, $profit, $r->played_at];
                }
            }
            break;
            
        case 'referrals':
            $headers = ['ID', 'Referrer ID', 'Referred ID', 'Commission (sat)', 'Created At'];
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM " . CFP_TABLE_REFERRALS . " WHERE created_at >= %s AND created_at <= %s",
                $date_from . ' 00:00:00', $date_to . ' 23:59:59'
            ));
            foreach($results as $r) {
                $data[] = [$r->id, $r->referrer_id, $r->referred_id, $r->commission_sat, $r->created_at];
            }
            break;
    }
    
    array_unshift($data, $headers);
    
    if($format === 'json') {
        $export_data = [];
        for($i = 1; $i < count($data); $i++) {
            $row = [];
            for($j = 0; $j < count($headers); $j++) {
                $row[$headers[$j]] = $data[$i][$j];
            }
            $export_data[] = $row;
        }
        wp_send_json_success(['data' => $export_data, 'count' => count($export_data)]);
    } else {
        wp_send_json_success(['data' => $data, 'count' => count($data) - 1]);
    }
}

/* ============================================================
   ADMIN: REPORTS & EXPORT PAGE
   ============================================================ */
function cfp_admin_reports_export() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_report_nonce');
    
    $user_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_USERS);
    $claim_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_CLAIMS);
    $tx_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_TRANSACTIONS);
    $withdraw_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_WITHDRAWALS);
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">📊</span>
            <h1>📊 Reports & Export</h1>
        </div>

        <!-- QUICK EXPORT -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>⚡ Quick Export</h2>
            <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:16px;margin-top:16px">
                <button onclick="cfpQuickExport('users', 'csv')" class="cfp-btn cfp-btn-gold" style="justify-content:center;padding:16px">
                    <span style="font-size:1.5rem">👥</span>
                    <div>
                        <div style="font-weight:700">Users</div>
                        <div style="font-size:.7rem;opacity:.8"><?=number_format($user_count)?> records</div>
                    </div>
                </button>
                <button onclick="cfpQuickExport('claims', 'csv')" class="cfp-btn cfp-btn-gold" style="justify-content:center;padding:16px">
                    <span style="font-size:1.5rem">🎁</span>
                    <div>
                        <div style="font-weight:700">Claims</div>
                        <div style="font-size:.7rem;opacity:.8"><?=number_format($claim_count)?> records</div>
                    </div>
                </button>
                <button onclick="cfpQuickExport('transactions', 'csv')" class="cfp-btn cfp-btn-gold" style="justify-content:center;padding:16px">
                    <span style="font-size:1.5rem">💸</span>
                    <div>
                        <div style="font-weight:700">Transactions</div>
                        <div style="font-size:.7rem;opacity:.8"><?=number_format($tx_count)?> records</div>
                    </div>
                </button>
                <button onclick="cfpQuickExport('withdrawals', 'csv')" class="cfp-btn cfp-btn-gold" style="justify-content:center;padding:16px">
                    <span style="font-size:1.5rem">📤</span>
                    <div>
                        <div style="font-weight:700">Withdrawals</div>
                        <div style="font-size:.7rem;opacity:.8"><?=number_format($withdraw_count)?> records</div>
                    </div>
                </button>
            </div>
        </div>

        <!-- CUSTOM REPORT BUILDER -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>📋 Custom Report Builder</h2>
            <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:16px;align-items:end;margin-top:16px">
                <div class="cfp-field">
                    <label>Report Type</label>
                    <select id="cfp-report-type">
                        <option value="users">Users</option>
                        <option value="claims">Claims</option>
                        <option value="transactions">Transactions</option>
                        <option value="withdrawals">Withdrawals</option>
                        <option value="games">Game Results</option>
                        <option value="referrals">Referrals</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Date From</label>
                    <input type="date" id="cfp-report-from" value="<?=date('Y-m-d', strtotime('-30 days'))?>">
                </div>
                <div class="cfp-field">
                    <label>Date To</label>
                    <input type="date" id="cfp-report-to" value="<?=date('Y-m-d')?>">
                </div>
                <div style="display:flex;gap:8px">
                    <button onclick="cfpGenerateReport('csv')" class="cfp-btn cfp-btn-gold">📥 CSV</button>
                    <button onclick="cfpGenerateReport('json')" class="cfp-btn cfp-btn-ghost">📄 JSON</button>
                </div>
            </div>
            
            <div id="cfp-report-preview" style="margin-top:20px;display:none">
                <h3 style="font-size:.9rem;color:#888;margin-bottom:12px">Preview (First 10 rows)</h3>
                <div class="cfp-table-wrap">
                    <table class="cfp-table" id="cfp-report-preview-table">
                        <thead></thead>
                        <tbody></tbody>
                    </table>
                </div>
                <div style="margin-top:12px;display:flex;justify-content:space-between;align-items:center">
                    <span style="color:#555;font-size:.85rem" id="cfp-report-count"></span>
                    <button onclick="cfpDownloadReport()" class="cfp-btn cfp-btn-green" id="cfp-download-btn">Download Full Report</button>
                </div>
            </div>
        </div>

        <!-- SCHEDULED REPORTS -->
        <div class="cfp-card">
            <h2>📅 Scheduled Reports</h2>
            <p style="color:#555;font-size:.85rem;margin-bottom:20px">Set up automatic report generation and email delivery.</p>
            
            <div style="background:#0d0d0d;padding:16px;border-radius:10px;margin-bottom:16px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div style="font-weight:700;color:#fff">Daily Summary Report</div>
                        <div style="font-size:.75rem;color:#555">Sends daily at 8:00 AM</div>
                    </div>
                    <span class="cfp-badge active">Active</span>
                </div>
            </div>
            
            <div style="background:#0d0d0d;padding:16px;border-radius:10px;margin-bottom:16px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div style="font-weight:700;color:#fff">Weekly Analytics Report</div>
                        <div style="font-size:.75rem;color:#555">Sends every Monday at 9:00 AM</div>
                    </div>
                    <span class="cfp-badge active">Active</span>
                </div>
            </div>
            
            <div style="background:#0d0d0d;padding:16px;border-radius:10px">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div style="font-weight:700;color:#fff">Monthly Financial Report</div>
                        <div style="font-size:.75rem;color:#555">Sends 1st of each month</div>
                    </>
                    <span class="cfp-badge pending">Disabled</span>
                </div>
            </div>
            
            <button class="cfp-btn cfp-btn-ghost" style="margin-top:20px">➕ Add Scheduled Report</button>
        </div>
    </div>

    <script>
    let currentReportData = null;
    let currentReportFormat = 'csv';

    function cfpQuickExport(type, format) {
        const fd = new FormData();
        fd.append('action', 'cfp_generate_report');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('report_type', type);
        fd.append('format', format);
        fd.append('date_from', '2020-01-01');
        fd.append('date_to', '<?=date('Y-m-d')?>');
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    cfpDownloadFile(d.data.data, type + '_export_' + '<?=date('Y-m-d')?>', format);
                }
            });
    }

    function cfpGenerateReport(format) {
        currentReportFormat = format;
        const type = document.getElementById('cfp-report-type').value;
        const from = document.getElementById('cfp-report-from').value;
        const to = document.getElementById('cfp-report-to').value;
        
        const fd = new FormData();
        fd.append('action', 'cfp_generate_report');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('report_type', type);
        fd.append('format', format);
        fd.append('date_from', from);
        fd.append('date_to', to);
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    currentReportData = d.data.data;
                    cfpShowReportPreview(d.data.data, d.data.count);
                }
            });
    }

    function cfpShowReportPreview(data, count) {
        const preview = document.getElementById('cfp-report-preview');
        const table = document.getElementById('cfp-report-preview-table');
        const countSpan = document.getElementById('cfp-report-count');
        
        preview.style.display = 'block';
        
        if(data.length < 2) {
            table.innerHTML = '<tr><td style="text-align:center;color:#555">No data found</td></tr>';
            countSpan.textContent = '0 records';
            return;
        }
        
        const headers = data[0];
        let thead = '<tr>';
        headers.forEach(h => thead += '<th>' + h + '</th>');
        thead += '</tr>';
        table.querySelector('thead').innerHTML = thead;
        
        let tbody = '';
        const previewData = data.slice(1, 11);
        previewData.forEach(row => {
            tbody += '<tr>';
            row.forEach(cell => tbody += '<td>' + cell + '</td>');
            tbody += '</tr>';
        });
        table.querySelector('tbody').innerHTML = tbody;
        
        countSpan.textContent = count + ' records found';
    }

    function cfpDownloadReport() {
        if(!currentReportData) return;
        const type = document.getElementById('cfp-report-type').value;
        cfpDownloadFile(currentReportData, type + '_report_<?=date('Y-m-d')?>', currentReportFormat);
    }

    function cfpDownloadFile(data, filename, format) {
        let content = '';
        if(format === 'csv') {
            content = data.map(row => row.join(',')).join('\n');
        } else {
            content = JSON.stringify(data, null, 2);
        }
        
        const blob = new Blob([content], {type: format === 'csv' ? 'text/csv' : 'application/json'});
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename + '.' + format;
        a.click();
        window.URL.revokeObjectURL(url);
    }
    </script>
    <?php
}