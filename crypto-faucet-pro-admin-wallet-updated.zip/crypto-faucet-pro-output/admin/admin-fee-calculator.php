<?php
/**
 * Admin page: Fee Calculator - Calculate deposit and withdrawal fees
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Fee Calculations
   ============================================================ */
add_action('wp_ajax_cfp_fee_calc_data', 'cfp_ajax_fee_calc_data');
function cfp_ajax_fee_calc_data() {
    check_ajax_referer('cfp_fee_nonce', 'nonce');
    
    $action = sanitize_text_field($_POST['sub_action'] ?? 'calculate');
    
    if($action === 'calculate') {
        $amount = intval($_POST['amount'] ?? 0);
        $crypto = sanitize_text_field($_POST['crypto'] ?? 'BTC');
        $type = sanitize_text_field($_POST['type'] ?? 'withdraw');
        
        $fees = cfp_calculate_fees($amount, $crypto, $type);
        wp_send_json_success($fees);
    }
    
    if($action === 'save_rates') {
        $raw_rates = $_POST['rates'] ?? [];
        $sanitized_rates = [];
        if ( is_array( $raw_rates ) ) {
            foreach ( $raw_rates as $crypto => $types ) {
                $crypto_key = sanitize_text_field( $crypto );
                if ( is_array( $types ) ) {
                    foreach ( $types as $type => $val ) {
                        $sanitized_rates[ $crypto_key ][ sanitize_text_field( $type ) ] = floatval( $val );
                    }
                }
            }
        }
        update_option('cfp_fee_rates', json_encode($sanitized_rates));
        wp_send_json_success(['msg' => 'Fee rates saved']);
    }
}

/* ============================================================
   HELPER: Calculate Fees
   ============================================================ */
function cfp_calculate_fees($amount, $crypto, $type) {
    $rates = get_option('cfp_fee_rates', json_encode([
        'BTC' => ['deposit' => 0, 'withdraw' => 1000, 'network' => 500],
        'ETH' => ['deposit' => 0, 'withdraw' => 2000, 'network' => 1000],
        'LTC' => ['deposit' => 0, 'withdraw' => 1000, 'network' => 500],
        'DOGE' => ['deposit' => 0, 'withdraw' => 10, 'network' => 1],
        'TRX' => ['deposit' => 0, 'withdraw' => 1, 'network' => 1]
    ]));
    $rates = json_decode($rates, true) ?: [];
    
    $crypto_rates = $rates[$crypto] ?? $rates['BTC'];
    $platform_fee = $crypto_rates[$type] ?? 0;
    $network_fee = $crypto_rates['network'] ?? 0;
    $total_fee = $platform_fee + $network_fee;
    $net_amount = $amount - $total_fee;
    
    return [
        'amount' => $amount,
        'crypto' => $crypto,
        'type' => $type,
        'platform_fee' => $platform_fee,
        'network_fee' => $network_fee,
        'total_fee' => $total_fee,
        'net_amount' => $net_amount > 0 ? $net_amount : 0,
        'fee_percent' => $amount > 0 ? round(($total_fee / $amount) * 100, 2) : 0
    ];
}

/* ============================================================
   ADMIN: FEE CALCULATOR PAGE
   ============================================================ */
function cfp_admin_fee_calculator() {
    $nonce = wp_create_nonce('cfp_fee_nonce');
    
    $default_rates = [
        'BTC' => ['deposit' => 0, 'withdraw' => 1000, 'network' => 500],
        'ETH' => ['deposit' => 0, 'withdraw' => 2000, 'network' => 1000],
        'LTC' => ['deposit' => 0, 'withdraw' => 1000, 'network' => 500],
        'DOGE' => ['deposit' => 0, 'withdraw' => 10, 'network' => 1],
        'TRX' => ['deposit' => 0, 'withdraw' => 1, 'network' => 1]
    ];
    $rates = json_decode(get_option('cfp_fee_rates', ''), true) ?: $default_rates;
    
    $cryptos = ['BTC', 'ETH', 'LTC', 'DOGE', 'TRX', 'USDT'];
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🧮</span>
            <h1>🧮 Fee Calculator</h1>
        </div>

        <!-- CALCULATOR -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>💰 Calculate Fees</h2>
            <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:16px;align-items:end;margin-top:16px">
                <div class="cfp-field">
                    <label>Amount (satoshis)</label>
                    <input type="number" id="cfp-calc-amount" value="100000" min="1">
                </div>
                <div class="cfp-field">
                    <label>Cryptocurrency</label>
                    <select id="cfp-calc-crypto">
                        <?php foreach($cryptos as $c): ?>
                        <option value="<?=$c?>"><?=$c?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Transaction Type</label>
                    <select id="cfp-calc-type">
                        <option value="withdraw">Withdrawal</option>
                        <option value="deposit">Deposit</option>
                    </select>
                </div>
                <button onclick="cfpCalculateFee()" class="cfp-btn cfp-btn-gold">Calculate</button>
            </div>
            
            <div id="cfp-calc-result" style="margin-top:24px;display:none">
                <div style="background:#0d0d0d;border-radius:12px;padding:24px">
                    <h3 style="color:#f7931a;margin-bottom:16px">Fee Breakdown</h3>
                    <div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:20px">
                        <div style="text-align:center">
                            <div style="font-size:.7rem;text-transform:uppercase;color:#555;margin-bottom:6px">Platform Fee</div>
                            <div style="font-size:1.5rem;font-weight:800;color:#fff" id="res-platform">0</div>
                            <div style="font-size:.75rem;color:#888">satoshis</div>
                        </div>
                        <div style="text-align:center">
                            <div style="font-size:.7rem;text-transform:uppercase;color:#555;margin-bottom:6px">Network Fee</div>
                            <div style="font-size:1.5rem;font-weight:800;color:#fff" id="res-network">0</div>
                            <div style="font-size:.75rem;color:#888">satoshis</div>
                        </div>
                        <div style="text-align:center">
                            <div style="font-size:.7rem;text-transform:uppercase;color:#555;margin-bottom:6px">Total Fee</div>
                            <div style="font-size:1.5rem;font-weight:800;color:#ef4444" id="res-total">0</div>
                            <div style="font-size:.75rem;color:#888">satoshis</div>
                        </div>
                    </div>
                    <div style="margin-top:20px;padding-top:20px;border-top:1px solid #222;display:flex;justify-content:space-between;align-items:center">
                        <div>
                            <div style="font-size:.7rem;text-transform:uppercase;color:#555">Net Amount Received</div>
                            <div style="font-size:2rem;font-weight:800;color:#22c55e" id="res-net">0</div>
                        </div>
                        <div style="text-align:right">
                            <div style="font-size:.7rem;text-transform:uppercase;color:#555">Fee Percentage</div>
                            <div style="font-size:1.2rem;font-weight:700;color:#f7931a" id="res-percent">0%</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- FEE RATES CONFIGURATION -->
        <div class="cfp-card">
            <h2>⚙️ Configure Fee Rates</h2>
            <p style="color:#555;font-size:.85rem;margin-bottom:20px">Set platform fees and estimated network fees for each cryptocurrency.</p>
            
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>Crypto</th>
                            <th>Deposit Fee (sat)</th>
                            <th>Withdraw Fee (sat)</th>
                            <th>Network Fee (sat)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach($rates as $crypto => $r): ?>
                        <tr>
                            <td><strong><?=$crypto?></strong></td>
                            <td><input type="number" id="deposit-<?=$crypto?>" value="<?=$r['deposit']?>" style="width:100px;background:#111;border:1px solid #222;padding:8px;color:#fff;border-radius:6px"></td>
                            <td><input type="number" id="withdraw-<?=$crypto?>" value="<?=$r['withdraw']?>" style="width:100px;background:#111;border:1px solid #222;padding:8px;color:#fff;border-radius:6px"></td>
                            <td><input type="number" id="network-<?=$crypto?>" value="<?=$r['network']?>" style="width:100px;background:#111;border:1px solid #222;padding:8px;color:#fff;border-radius:6px"></td>
                            <td><button onclick="cfpSaveFeeRate('<?=$crypto?>')" class="cfp-btn cfp-btn-sm cfp-btn-ghost">Save</button></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            
            <button onclick="cfpSaveAllRates()" class="cfp-btn cfp-btn-gold" style="margin-top:16px">Save All Rates</button>
        </div>

        <!-- FEE INFO -->
        <div class="cfp-card" style="margin-top:24px">
            <h2>💡 How Fees Work</h2>
            <div style="display:grid;grid-template-columns:repeat(2, 1fr);gap:24px">
                <div style="background:#0d0d0d;padding:20px;border-radius:12px">
                    <h3 style="color:#22c55e;margin-bottom:12px">📥 Deposits</h3>
                    <p style="color:#888;font-size:.85rem;line-height:1.6">
                        Users deposit crypto to their wallet. Platform may charge a small deposit fee or offer free deposits.
                        Network fees are typically covered by the network (on-chain deposits).
                    </p>
                </div>
                <div style="background:#0d0d0d;padding:20px;border-radius:12px">
                    <h3 style="color:#f7931a;margin-bottom:12px">📤 Withdrawals</h3>
                    <p style="color:#888;font-size:.85rem;line-height:1.6">
                        When users withdraw, platform fee covers operational costs, and network fee covers blockchain transaction costs.
                        Total fee = Platform Fee + Network Fee.
                    </p>
                </div>
            </div>
        </div>
    </div>

    <script>
    function cfpCalculateFee() {
        const amount = document.getElementById('cfp-calc-amount').value;
        const crypto = document.getElementById('cfp-calc-crypto').value;
        const type = document.getElementById('cfp-calc-type').value;
        
        const fd = new FormData();
        fd.append('action', 'cfp_fee_calc_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'calculate');
        fd.append('amount', amount);
        fd.append('crypto', crypto);
        fd.append('type', type);
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    document.getElementById('res-platform').textContent = d.data.platform_fee.toLocaleString();
                    document.getElementById('res-network').textContent = d.data.network_fee.toLocaleString();
                    document.getElementById('res-total').textContent = d.data.total_fee.toLocaleString();
                    document.getElementById('res-net').textContent = d.data.net_amount.toLocaleString();
                    document.getElementById('res-percent').textContent = d.data.fee_percent + '%';
                    document.getElementById('cfp-calc-result').style.display = 'block';
                }
            });
    }

    function cfpSaveFeeRate(crypto) {
        const rates = {
            deposit: document.getElementById('deposit-' + crypto).value,
            withdraw: document.getElementById('withdraw-' + crypto).value,
            network: document.getElementById('network-' + crypto).value
        };
        
        const fd = new FormData();
        fd.append('action', 'cfp_fee_calc_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'save_rates');
        fd.append('rates[' + crypto + ']', JSON.stringify(rates));
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(() => alert('Rate saved for ' + crypto));
    }

    function cfpSaveAllRates() {
        const cryptos = ['BTC', 'ETH', 'LTC', 'DOGE', 'TRX'];
        const allRates = {};
        
        cryptos.forEach(c => {
            allRates[c] = {
                deposit: document.getElementById('deposit-' + c).value,
                withdraw: document.getElementById('withdraw-' + c).value,
                network: document.getElementById('network-' + c).value
            };
        });
        
        const fd = new FormData();
        fd.append('action', 'cfp_fee_calc_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'save_rates');
        fd.append('rates', JSON.stringify(allRates));
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(() => alert('All rates saved!'));
    }
    </script>
    <?php
}