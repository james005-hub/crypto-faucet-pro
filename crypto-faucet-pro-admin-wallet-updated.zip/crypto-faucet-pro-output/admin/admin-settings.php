<?php
/**
 * Admin page: General Settings
 *
 * Covers faucet basics, page URLs, display options, referral,
 * and site-wide feature toggles.
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_settings() {
    $saved = false;

    if ( isset( $_POST['cfp_save_settings'] ) && check_admin_referer( 'cfp_settings' ) ) {
        $fields = [
            // Faucet identity
            'faucet_name', 'faucet_tagline', 'logo_url', 'site_logo_url',
            'support_url', 'tos_url', 'privacy_url',
            // Faucet behaviour
            'faucet_enabled', 'claim_interval_minutes', 'min_claim_sat', 'max_claim_sat',
            'faucet_min_payout_sat',
            // Display / UI
            'show_live_price', 'total_users_display', 'total_btc_display', 'total_games_display',
            'btc_usd_price',
            // Referral
            'referral_percent', 'referral_deposit_bonus_pct',
            // Feature toggles
            'faucet_enabled', 'savings_enabled', 'lottery_enabled', 'golden_ticket_enabled',
            'p2p_enabled', 'provably_fair_enabled', 'pwa_enabled', 'rest_api_enabled',
            'captcha_enabled', 'recaptcha_site_key',
            // Page URLs
            'page_dash_url', 'page_faucet_url', 'page_games_url', 'page_hilo_url',
            'page_slots_url', 'page_coinflip_url', 'page_dice_url', 'page_crash_url',
            'page_wheel_url', 'page_lottery_url', 'page_savings_url', 'page_ref_url',
            'page_lb_url',
        ];
        foreach ( $fields as $f ) {
            if ( isset( $_POST[ $f ] ) ) {
                cfp_update_setting( $f, sanitize_text_field( wp_unslash( $_POST[ $f ] ) ) );
            }
        }
        $saved = true;
    }

    $gs = function( $k, $d = '' ) { return cfp_get_setting( $k, $d ); };

    global $wpdb;
    $total_users = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . CFP_TABLE_USERS );
    $total_claims = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . CFP_TABLE_CLAIMS );
    $total_tx    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . CFP_TABLE_TRANSACTIONS );
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">⚡ CFP</span>
            <h1>⚙️ General Settings</h1>
            <div style="margin-left:auto;font-size:.8rem;color:var(--mt)">v<?= CFP_VERSION ?></div>
        </div>

        <?php if ( $saved ) : ?>
        <div class="cfp-notice success">✅ Settings saved!</div>
        <?php endif; ?>

        <!-- QUICK STATS -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(3,1fr);margin-bottom:24px">
            <div class="cfp-stat-card green">
                <div class="label">👤 Registered Users</div>
                <div class="value"><?= number_format( $total_users ) ?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">🚿 Total Claims</div>
                <div class="value"><?= number_format( $total_claims ) ?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">📋 Transactions</div>
                <div class="value"><?= number_format( $total_tx ) ?></div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field( 'cfp_settings' ); ?>

            <!-- ── FAUCET IDENTITY ── -->
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🏷️ Faucet Identity</h2>
                <p style="color:#777;font-size:.85rem;margin-bottom:16px">Basic branding and contact info shown to users.</p>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Faucet Name</label>
                        <input type="text" name="faucet_name" value="<?= esc_attr( $gs( 'faucet_name', 'FreeBTC.in' ) ) ?>" placeholder="FreeBTC.in">
                        <span class="hint">Displayed in the header and emails.</span>
                    </div>
                    <div class="cfp-field">
                        <label>Faucet Tagline</label>
                        <input type="text" name="faucet_tagline" value="<?= esc_attr( $gs( 'faucet_tagline', 'Earn free Bitcoin every hour!' ) ) ?>" placeholder="Earn free Bitcoin every hour!">
                    </div>
                    <div class="cfp-field">
                        <label>Logo URL</label>
                        <input type="url" name="logo_url" value="<?= esc_attr( $gs( 'logo_url' ) ) ?>" placeholder="https://yoursite.com/logo.png">
                        <span class="hint">Leave blank to use the default logo.</span>
                    </div>
                    <div class="cfp-field">
                        <label>Support URL</label>
                        <input type="url" name="support_url" value="<?= esc_attr( $gs( 'support_url' ) ) ?>" placeholder="https://yoursite.com/support">
                    </div>
                    <div class="cfp-field">
                        <label>Terms of Service URL</label>
                        <input type="url" name="tos_url" value="<?= esc_attr( $gs( 'tos_url' ) ) ?>" placeholder="https://yoursite.com/tos">
                    </div>
                    <div class="cfp-field">
                        <label>Privacy Policy URL</label>
                        <input type="url" name="privacy_url" value="<?= esc_attr( $gs( 'privacy_url' ) ) ?>" placeholder="https://yoursite.com/privacy">
                    </div>
                </div>
            </div>

            <!-- ── FAUCET BEHAVIOUR ── -->
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🚿 Faucet Behaviour</h2>
                <p style="color:#777;font-size:.85rem;margin-bottom:16px">Controls claim amounts and timing.</p>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Faucet Master Switch</label>
                        <select name="faucet_enabled" style="background:#111">
                            <option value="1" <?= selected( $gs( 'faucet_enabled', '1' ), '1', false ) ?>>✅ Enabled</option>
                            <option value="0" <?= selected( $gs( 'faucet_enabled', '1' ), '0', false ) ?>>⏸ Disabled</option>
                        </select>
                        <span class="hint">Disabling stops all new claims without affecting existing balances.</span>
                    </div>
                    <div class="cfp-field">
                        <label>Claim Interval (minutes)</label>
                        <input type="number" name="claim_interval_minutes" value="<?= esc_attr( $gs( 'claim_interval_minutes', 60 ) ) ?>" min="1" max="1440">
                        <span class="hint">How often a user can claim. Default: 60.</span>
                    </div>
                    <div class="cfp-field">
                        <label>Min Claim (sat)</label>
                        <input type="number" name="min_claim_sat" value="<?= esc_attr( $gs( 'min_claim_sat', 98 ) ) ?>" min="1">
                    </div>
                    <div class="cfp-field">
                        <label>Max Claim (sat)</label>
                        <input type="number" name="max_claim_sat" value="<?= esc_attr( $gs( 'max_claim_sat', 200 ) ) ?>" min="1">
                    </div>
                    <div class="cfp-field">
                        <label>BTC/USD Price (manual)</label>
                        <input type="number" name="btc_usd_price" value="<?= esc_attr( $gs( 'btc_usd_price', 67694 ) ) ?>" min="1">
                        <span class="hint">Used when live price feed is off.</span>
                    </div>
                    <div class="cfp-field">
                        <label>Show Live BTC Price</label>
                        <select name="show_live_price" style="background:#111">
                            <option value="1" <?= selected( $gs( 'show_live_price', '1' ), '1', false ) ?>>✅ Yes</option>
                            <option value="0" <?= selected( $gs( 'show_live_price', '1' ), '0', false ) ?>>❌ No (use manual price)</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- ── REFERRAL ── -->
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🔗 Referral Program</h2>
                <p style="color:#777;font-size:.85rem;margin-bottom:16px">Commission rates paid to referrers.</p>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Referral Claim Commission (%)</label>
                        <input type="number" name="referral_percent" value="<?= esc_attr( $gs( 'referral_percent', 50 ) ) ?>" min="0" max="100" step="1">
                        <span class="hint">% of referred user's claim credited to referrer. Default: 50%.</span>
                    </div>
                    <div class="cfp-field">
                        <label>Referral Deposit Bonus (%)</label>
                        <input type="number" name="referral_deposit_bonus_pct" value="<?= esc_attr( $gs( 'referral_deposit_bonus_pct', 0 ) ) ?>" min="0" max="100" step="1">
                        <span class="hint">Bonus % credited to referrer on referred user's first deposit. Set 0 to disable.</span>
                    </div>
                </div>
            </div>

            <!-- ── FEATURE TOGGLES ── -->
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🎛️ Feature Toggles</h2>
                <p style="color:#777;font-size:.85rem;margin-bottom:16px">Enable or disable major site features globally.</p>
                <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr))">
                    <?php
                    $toggles = [
                        'savings_enabled'       => ['💰', 'Savings / Interest',    '1'],
                        'lottery_enabled'       => ['🎟', 'Weekly Lottery',        '1'],
                        'golden_ticket_enabled' => ['🎫', 'Golden Ticket Contest', '1'],
                        'p2p_enabled'           => ['🤝', 'P2P Events',            '1'],
                        'provably_fair_enabled' => ['🔐', 'Provably Fair Games',   '1'],
                        'pwa_enabled'           => ['📱', 'PWA / App Install',     '1'],
                        'rest_api_enabled'      => ['🔌', 'REST API',              '0'],
                    ];
                    foreach ( $toggles as $key => [$icon, $label, $default] ) : ?>
                    <div class="cfp-field">
                        <label><?= $icon ?> <?= $label ?></label>
                        <select name="<?= esc_attr( $key ) ?>" style="background:#111">
                            <option value="1" <?= selected( $gs( $key, $default ), '1', false ) ?>>✅ Enabled</option>
                            <option value="0" <?= selected( $gs( $key, $default ), '0', false ) ?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- ── RECAPTCHA ── -->
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🤖 reCAPTCHA</h2>
                <p style="color:#777;font-size:.85rem;margin-bottom:16px">Google reCAPTCHA v2 protection on claims and registrations.</p>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>reCAPTCHA</label>
                        <select name="captcha_enabled" style="background:#111">
                            <option value="1" <?= selected( $gs( 'captcha_enabled', '0' ), '1', false ) ?>>✅ Enabled</option>
                            <option value="0" <?= selected( $gs( 'captcha_enabled', '0' ), '0', false ) ?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>reCAPTCHA Site Key</label>
                        <input type="text" name="recaptcha_site_key" value="<?= esc_attr( $gs( 'recaptcha_site_key' ) ) ?>" placeholder="6Lc...">
                        <span class="hint">Get your key at <a href="https://www.google.com/recaptcha/admin" target="_blank" style="color:var(--g)">google.com/recaptcha</a></span>
                    </div>
                </div>
            </div>

            <!-- ── PAGE URLs ── -->
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>🔗 Page URLs</h2>
                <p style="color:#777;font-size:.85rem;margin-bottom:16px">WordPress page slugs or full URLs for each shortcode page. Used for internal links.</p>
                <div class="cfp-form-grid" style="grid-template-columns:repeat(auto-fit,minmax(220px,1fr))">
                    <?php
                    $pages = [
                        'page_dash_url'     => ['🏠', 'Dashboard Page'],
                        'page_faucet_url'   => ['🚿', 'Faucet / Claim Page'],
                        'page_games_url'    => ['🎮', 'Games Hub Page'],
                        'page_hilo_url'     => ['🎲', 'Hi-Lo Game Page'],
                        'page_slots_url'    => ['🎰', 'Slots Page'],
                        'page_coinflip_url' => ['🪙', 'Coin Flip Page'],
                        'page_dice_url'     => ['🎲', 'Dice Page'],
                        'page_crash_url'    => ['📈', 'Crash Page'],
                        'page_wheel_url'    => ['🎡', 'Wheel Page'],
                        'page_lottery_url'  => ['🎟', 'Lottery Page'],
                        'page_savings_url'  => ['💰', 'Savings Page'],
                        'page_ref_url'      => ['🔗', 'Referral Page'],
                        'page_lb_url'       => ['🏆', 'Leaderboard Page'],
                    ];
                    foreach ( $pages as $key => [$icon, $label] ) : ?>
                    <div class="cfp-field">
                        <label><?= $icon ?> <?= $label ?></label>
                        <input type="text" name="<?= esc_attr( $key ) ?>" value="<?= esc_attr( $gs( $key ) ) ?>" placeholder="/<?= strtolower( str_replace( ['🏠 ','page_','_url'], '', $key ) ) ?>">
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- ── HOMEPAGE DISPLAY COUNTERS ── -->
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>📊 Homepage Display Counters</h2>
                <p style="color:#777;font-size:.85rem;margin-bottom:16px">Override the live counters shown on the frontend hero section. Leave blank to use real-time DB values.</p>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Total Users (display)</label>
                        <input type="text" name="total_users_display" value="<?= esc_attr( $gs( 'total_users_display' ) ) ?>" placeholder="e.g. 12,400">
                    </div>
                    <div class="cfp-field">
                        <label>Total BTC Paid (display)</label>
                        <input type="text" name="total_btc_display" value="<?= esc_attr( $gs( 'total_btc_display' ) ) ?>" placeholder="e.g. 0.542 BTC">
                    </div>
                    <div class="cfp-field">
                        <label>Total Games Played (display)</label>
                        <input type="text" name="total_games_display" value="<?= esc_attr( $gs( 'total_games_display' ) ) ?>" placeholder="e.g. 1,200,000">
                    </div>
                </div>
            </div>

            <div style="text-align:right;padding-bottom:30px">
                <button type="submit" name="cfp_save_settings" class="cfp-btn cfp-btn-primary" style="padding:12px 32px;font-size:1rem">
                    💾 Save Settings
                </button>
            </div>

        </form>
    </div>
    <?php
}
