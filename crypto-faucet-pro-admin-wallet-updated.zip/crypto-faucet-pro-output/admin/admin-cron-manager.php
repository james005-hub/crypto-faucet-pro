<?php
/**
 * Admin page: Cron Manager - View and manage scheduled tasks
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Get cron events
   ============================================================ */
add_action('wp_ajax_cfp_cron_manager_data', 'cfp_ajax_cron_manager_data');
function cfp_ajax_cron_manager_data() {
    check_ajax_referer('cfp_cron_nonce', 'nonce');
    
    $crons = wp_get_scheduled_event_times();
    $all_events = _get_cron_array();
    
    $cfp_events = [];
    foreach($all_events as $time => $hooks) {
        foreach($hooks as $hook => $details) {
            if(strpos($hook, 'cfp_') === 0 || strpos($hook, 'crypto_faucet') === 0) {
                foreach($details as $key => $event) {
                    $cfp_events[] = [
                        'hook' => $hook,
                        'time' => $time,
                        'time_formatted' => get_date_from_gmt(date('Y-m-d H:i:s', $time), 'M j, Y g:i A'),
                        'schedule' => $event['schedule'] ?? 'one-time',
                        'interval' => $event['interval'] ?? 0
                    ];
                }
            }
        }
    }
    
    usort($cfp_events, function($a, $b) {
        return $a['time'] - $b['time'];
    });
    
    wp_send_json_success([
        'events' => $cfp_events,
        'next_run' => wp_next_scheduled('cfp_daily_traffic_summary_hook'),
        'all_crons' => $all_events
    ]);
}

/* ============================================================
   AJAX: Run a cron event now
   ============================================================ */
add_action('wp_ajax_cfp_run_cron_event', 'cfp_ajax_run_cron_event');
function cfp_ajax_run_cron_event() {
    check_ajax_referer('cfp_cron_nonce', 'nonce');
    
    $hook = sanitize_text_field($_POST['hook'] ?? '');
    
    if(empty($hook)) {
        wp_send_json_error(['msg' => 'No hook specified']);
    }
    
    $result = do_action($hook);
    
    wp_send_json_success(['msg' => 'Cron event triggered successfully']);
}

/* ============================================================
   AJAX: Add new scheduled cron
   ============================================================ */
add_action('wp_ajax_cfp_add_cron_event', 'cfp_ajax_add_cron_event');
function cfp_ajax_add_cron_event() {
    check_ajax_referer('cfp_cron_nonce', 'nonce');
    
    $hook = sanitize_text_field($_POST['hook'] ?? '');
    $schedule = sanitize_text_field($_POST['schedule'] ?? 'hourly');
    $time = sanitize_text_field($_POST['time'] ?? '');
    
    if(empty($hook)) {
        wp_send_json_error(['msg' => 'No hook specified']);
    }
    
    $timestamp = !empty($time) ? strtotime($time) : time();
    
    $intervals = wp_get_schedules();
    $interval = $intervals[$schedule]['interval'] ?? 3600;
    
    $result = wp_schedule_event($timestamp, $schedule, $hook);
    
    if($result) {
        wp_send_json_success(['msg' => 'Cron event scheduled']);
    } else {
        wp_send_json_error(['msg' => 'Failed to schedule event']);
    }
}

/* ============================================================
   AJAX: Delete cron event
   ============================================================ */
add_action('wp_ajax_cfp_delete_cron_event', 'cfp_ajax_delete_cron_event');
function cfp_ajax_delete_cron_event() {
    check_ajax_referer('cfp_cron_nonce', 'nonce');
    
    $hook = sanitize_text_field($_POST['hook'] ?? '');
    
    if(empty($hook)) {
        wp_send_json_error(['msg' => 'No hook specified']);
    }
    
    wp_clear_scheduled_hook($hook);
    
    wp_send_json_success(['msg' => 'Cron event cleared']);
}

/* ============================================================
   ADMIN: CRON MANAGER PAGE
   ============================================================ */
function cfp_admin_cron_manager() {
    $nonce = wp_create_nonce('cfp_cron_nonce');
    
    $schedules = wp_get_schedules();
    $wp_crons = _get_cron_array();
    $cfp_crons = [];
    
    foreach($wp_crons as $time => $hooks) {
        foreach($hooks as $hook => $details) {
            if(strpos($hook, 'cfp_') === 0 || strpos($hook, 'crypto_faucet') === 0) {
                foreach($details as $key => $event) {
                    $cfp_crons[] = [
                        'hook' => $hook,
                        'time' => $time,
                        'next_run' => get_date_from_gmt(date('Y-m-d H:i:s', $time), 'M j, Y g:i A'),
                        'schedule' => $event['schedule'] ?? 'one-time',
                        'interval' => $event['interval'] ?? 0
                    ];
                }
            }
        }
    }
    
    usort($cfp_crons, function($a, $b) {
        return $a['time'] - $b['time'];
    });
    
    $all_crons = wp_get_scheduled_event_times();
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">⏰</span>
            <h1>⏰ Cron Manager</h1>
            <button onclick="cfpRunCronNow('cfp_daily_traffic_summary_hook')" class="cfp-btn cfp-btn-ghost" style="margin-left:auto">▶️ Run Daily Summary</button>
        </div>

        <!-- CRON OVERVIEW -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card green">
                <div class="label">📅 Next Event</div>
                <div class="value" style="font-size:1.2rem">
                    <?php 
                    $next = wp_next_scheduled('cfp_daily_traffic_summary_hook');
                    echo $next ? get_date_from_gmt(date('Y-m-d H:i:s', $next), 'M j, g:i A') : 'N/A';
                    ?>
                </div>
                <div class="sub">Daily Summary</div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">📋 Total CFP Cron Events</div>
                <div class="value"><?=count($cfp_crons)?></div>
                <div class="sub">Crypto Faucet Pro</div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">⚙️ WP Cron Active</div>
                <div class="value">Yes</div>
                <div class="sub">Scheduler working</div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">🔧 Available Schedules</div>
                <div class="value"><?=count($schedules)?></div>
                <div class="sub">Custom intervals</div>
            </div>
        </div>

        <!-- ADD NEW CRON -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>➕ Schedule New Cron Event</h2>
            <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:16px;align-items:end">
                <div class="cfp-field">
                    <label>Hook Name</label>
                    <select id="cfp-new-cron-hook">
                        <option value="cfp_hourly_cleanup">Hourly Cleanup</option>
                        <option value="cfp_daily_summary">Daily Summary</option>
                        <option value="cfp_weekly_report">Weekly Report</option>
                        <option value="cfp_monthly_analytics">Monthly Analytics</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Schedule</label>
                    <select id="cfp-new-cron-schedule">
                        <option value="hourly">Every Hour</option>
                        <option value="twicedaily">Twice Daily</option>
                        <option value="daily">Daily</option>
                        <option value="weekly">Weekly</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Start Time</label>
                    <input type="datetime-local" id="cfp-new-cron-time">
                </div>
                <button onclick="cfpAddCronEvent()" class="cfp-btn cfp-btn-gold">Schedule Event</button>
            </div>
        </div>

        <!-- CFP CRON EVENTS TABLE -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>📋 Crypto Faucet Pro Scheduled Events</h2>
            <?php if(empty($cfp_crons)): ?>
            <div style="text-align:center;padding:40px;color:#555">
                <p>No Crypto Faucet Pro cron events scheduled.</p>
                <p style="font-size:.85rem">The plugin handles cron events internally.</p>
            </div>
            <?php else: ?>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>Hook</th>
                            <th>Next Run</th>
                            <th>Schedule</th>
                            <th>Interval</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach($cfp_crons as $cron): ?>
                        <tr>
                            <td><code style="color:#f7931a"><?=esc_html($cron['hook'])?></code></td>
                            <td><?=esc_html($cron['next_run'])?></td>
                            <td><span class="cfp-badge <?=$cron['schedule'] === 'daily' ? 'active' : 'pending'?>"><?=esc_html($cron['schedule'])?></span></td>
                            <td><?=cfp_format_interval($cron['interval'])?></td>
                            <td>
                                <button onclick="cfpRunCronNow('<?=esc_html($cron['hook'])?>')" class="cfp-btn cfp-btn-sm cfp-btn-ghost">▶ Run</button>
                                <button onclick="cfpDeleteCron('<?=esc_html($cron['hook'])?>')" class="cfp-btn cfp-btn-sm cfp-btn-red" style="margin-left:6px">Delete</button>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>
        </div>

        <!-- ALL WP CRON EVENTS -->
        <div class="cfp-card">
            <h2>⚙️ All WordPress Cron Events (Last 20)</h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>Hook</th>
                            <th>Next Run (GMT)</th>
                            <th>Schedule</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $all_cron_list = [];
                    foreach($wp_crons as $time => $hooks) {
                        foreach($hooks as $hook => $details) {
                            $all_cron_list[] = ['time' => $time, 'hook' => $hook, 'details' => $details];
                        }
                    }
                    usort($all_cron_list, function($a, $b) { return $a['time'] - $b['time']; });
                    $all_cron_list = array_slice($all_cron_list, 0, 20);
                    
                    foreach($all_cron_list as $item): 
                    ?>
                        <tr>
                            <td><code style="color:<?=strpos($item['hook'], 'cfp_') === 0 ? '#22c55e' : '#888'?>"><?=esc_html($item['hook'])?></code></td>
                            <td><?=date('M j, Y g:i A', $item['time'])?></td>
                            <td><?=!empty($item['details']) ? esc_html(key($item['details'])) : 'one-time'?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Set default datetime
        const now = new Date();
        now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
        document.getElementById('cfp-new-cron-time').value = now.toISOString().slice(0, 16);
    });

    function cfpRunCronNow(hook) {
        if(!confirm('Run this cron event now?')) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_run_cron_event');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('hook', hook);
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    alert('Cron event triggered successfully!');
                    location.reload();
                } else {
                    alert('Error: ' + d.data.msg);
                }
            });
    }

    function cfpDeleteCron(hook) {
        if(!confirm('Delete this scheduled cron event?')) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_delete_cron_event');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('hook', hook);
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    location.reload();
                } else {
                    alert('Error: ' + d.data.msg);
                }
            });
    }

    function cfpAddCronEvent() {
        const hook = document.getElementById('cfp-new-cron-hook').value;
        const schedule = document.getElementById('cfp-new-cron-schedule').value;
        const time = document.getElementById('cfp-new-cron-time').value;
        
        const fd = new FormData();
        fd.append('action', 'cfp_add_cron_event');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('hook', hook);
        fd.append('schedule', schedule);
        fd.append('time', time);
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    alert('Cron event scheduled!');
                    location.reload();
                } else {
                    alert('Error: ' + d.data.msg);
                }
            });
    }
    </script>
    <?php
}

function cfp_format_interval($seconds) {
    if(!$seconds) return 'One-time';
    if($seconds < 60) return $seconds . ' seconds';
    if($seconds < 3600) return round($seconds/60) . ' minutes';
    if($seconds < 86400) return round($seconds/3600) . ' hours';
    return round($seconds/86400) . ' days';
}