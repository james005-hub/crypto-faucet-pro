<?php
/**
 * Admin page: MetaMask & WalletConnect Settings
 *
 * Configures:
 *   - Enable/disable Web3 wallet deposits and withdrawals
 *   - Currency for payouts
 *   - Minimum deposit (USD) and minimum withdrawal (sat)
 *   - Withdrawal fee in sat (routed to admin admin wallet)
 *   - WalletConnect v2 Project ID
 *   - Per-stream on/off toggles for MetaMask and WalletConnect fee revenue
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_web3_wallets(): void {
    global $wpdb;
    $notice = '';

    /* ── SAVE ── */
    if ( isset( $_POST['cfp_save_web3'] ) && check_admin_referer( 'cfp_web3_settings' ) ) {
        $fields = [
            'web3_enabled',
            'web3_currency',
            'web3_min_deposit_usd',
            'web3_min_withdraw_sat',
            'web3_fee_sat',
            'web3_walletconnect_project_id',
            // Infura & Etherscan
            'web3_infura_api_key',
            'web3_infura_network',
            'web3_etherscan_api_key',
            'web3_etherscan_base_url',
            'web3_deposit_confirmations',
            'web3_direct_rpc_deposits',
            // Revenue streams
            'admin_wallet_stream_web3_metamask_fee',
            'admin_wallet_stream_web3_walletconnect_fee',
        ];
        foreach ( $fields as $f ) {
            if ( isset( $_POST[ $f ] ) ) {
                cfp_update_setting( $f, sanitize_text_field( $_POST[ $f ] ) );
            }
        }
        $notice = "<div class='cfp-notice success'>✅ Web3 wallet settings saved!</div>";
    }

    /* ── LOAD ── */
    $enabled       = cfp_get_setting( 'web3_enabled',                       '0' );
    $currency      = cfp_get_setting( 'web3_currency',                      'eth' );
    $min_dep_usd   = cfp_get_setting( 'web3_min_deposit_usd',               '1' );
    $min_wd_sat    = cfp_get_setting( 'web3_min_withdraw_sat',               '10000' );
    $fee_sat       = cfp_get_setting( 'web3_fee_sat',                       '500' );
    $wc_project_id   = cfp_get_setting( 'web3_walletconnect_project_id',      '' );
    $mm_fee_on       = cfp_get_setting( 'admin_wallet_stream_web3_metamask_fee',      '1' );
    $wc_fee_on       = cfp_get_setting( 'admin_wallet_stream_web3_walletconnect_fee', '1' );

    // Infura & Etherscan settings
    $infura_key      = cfp_get_setting( 'web3_infura_api_key',          '' );
    $infura_network  = cfp_get_setting( 'web3_infura_network',          'mainnet' );
    $etherscan_key   = cfp_get_setting( 'web3_etherscan_api_key',       '' );
    $etherscan_url   = cfp_get_setting( 'web3_etherscan_base_url',      '' );
    $confirms        = cfp_get_setting( 'web3_deposit_confirmations',   '3' );
    $direct_rpc      = cfp_get_setting( 'web3_direct_rpc_deposits',     '0' );

    // Live API status test (only when keys are set)
    $api_status = null;
    if ( ! empty( $infura_key ) || ! empty( $etherscan_key ) ) {
        if ( function_exists( 'cfp_web3_test_api_connections' ) ) {
            $api_status = cfp_web3_test_api_connections();
        }
    }

    // Network map for dropdown
    $network_map = function_exists( 'cfp_web3_network_map' ) ? cfp_web3_network_map() : [];

    /* ── REVENUE STATS ── */
    $mm_fee_total = $wpdb->get_var( $wpdb->prepare(
        "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE stream=%s",
        'web3_metamask_withdraw_fee'
    ) );
    $wc_fee_total = $wpdb->get_var( $wpdb->prepare(
        "SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_ADMIN_WALLET . " WHERE stream=%s",
        'web3_walletconnect_withdraw_fee'
    ) );

    /* ── DEPOSIT / WITHDRAWAL COUNTS ── */
    $dep_count = $wpdb->get_var(
        "SELECT COUNT(*) FROM " . CFP_TABLE_NP_DEPOSITS .
        " WHERE order_id LIKE 'cfp_web3_%' AND status='credited'"
    );
    $wd_count  = $wpdb->get_var(
        "SELECT COUNT(*) FROM " . CFP_TABLE_NP_WITHDRAWALS .
        " WHERE np_response LIKE '%web3_wallet_type%'"
    );

    /* ── RECENT WEB3 DEPOSITS ── */
    $recent_deps = $wpdb->get_results(
        "SELECT d.*, u.username FROM " . CFP_TABLE_NP_DEPOSITS . " d
         LEFT JOIN " . CFP_TABLE_USERS . " u ON d.user_id=u.id
         WHERE d.order_id LIKE 'cfp_web3_%'
         ORDER BY d.created_at DESC LIMIT 10"
    );

    /* ── RECENT WEB3 WITHDRAWALS ── */
    $recent_wds = $wpdb->get_results(
        "SELECT w.*, u.username FROM " . CFP_TABLE_NP_WITHDRAWALS . " w
         LEFT JOIN " . CFP_TABLE_USERS . " u ON w.user_id=u.id
         WHERE w.np_response LIKE '%web3_wallet_type%'
         ORDER BY w.requested_at DESC LIMIT 10"
    );
    ?>
    <div class="wrap cfp-admin-wrap">
        <h1>🦊 MetaMask &amp; WalletConnect Settings</h1>
        <?= $notice ?>

        <!-- Stats bar -->
        <div style="display:flex;gap:16px;flex-wrap:wrap;margin-bottom:24px">
            <?php foreach ([
                ['🦊 MetaMask Fee Revenue', number_format( $mm_fee_total ) . ' sat', '#f6851b'],
                ['📡 WalletConnect Fee Revenue', number_format( $wc_fee_total ) . ' sat', '#3b99fc'],
                ['✅ Web3 Deposits Credited', $dep_count, '#22c55e'],
                ['⬆️ Web3 Withdrawals Sent', $wd_count,  '#a855f7'],
            ] as [$label, $val, $color]): ?>
            <div style="background:#fff;border:1px solid #e0e0e0;border-radius:10px;padding:14px 20px;min-width:180px;flex:1">
                <div style="font-size:.78rem;color:#888;margin-bottom:4px"><?= esc_html( $label ) ?></div>
                <div style="font-size:1.4rem;font-weight:700;color:<?= esc_attr( $color ) ?>"><?= esc_html( $val ) ?></div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Settings form -->
        <div style="background:#fff;border:1px solid #e0e0e0;border-radius:12px;padding:28px;max-width:700px;margin-bottom:28px">
            <h2 style="margin-top:0">Configuration</h2>
            <form method="post">
                <?php wp_nonce_field( 'cfp_web3_settings' ); ?>

                <!-- Enable toggle -->
                <table class="form-table">
                    <tr>
                        <th>Enable Web3 Wallets</th>
                        <td>
                            <label>
                                <input type="checkbox" name="web3_enabled" value="1" <?php checked( $enabled, '1' ); ?>>
                                Enable MetaMask &amp; WalletConnect deposit and withdrawal widgets
                            </label>
                            <p class="description">When enabled, users can deposit and withdraw using MetaMask or WalletConnect via the NOWPayments hot wallet. Requires NOWPayments to be configured and enabled.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Payout Currency</th>
                        <td>
                            <select name="web3_currency" class="regular-text">
                                <?php foreach ( ['eth' => 'ETH (Ethereum)', 'matic' => 'MATIC (Polygon)', 'btc' => 'BTC (Bitcoin)', 'usdt' => 'USDT', 'usdc' => 'USDC', 'bnb' => 'BNB'] as $val => $label ): ?>
                                    <option value="<?= esc_attr( $val ) ?>" <?php selected( $currency, $val ); ?>><?= esc_html( $label ) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">Currency used for NOWPayments deposits and withdrawals. Must be supported by your NOWPayments account.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Min Deposit (USD)</th>
                        <td>
                            <input type="number" name="web3_min_deposit_usd" value="<?= esc_attr( $min_dep_usd ) ?>" class="small-text" min="0.01" step="0.01">
                            <span class="description"> USD minimum per deposit invoice</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Min Withdrawal (sat)</th>
                        <td>
                            <input type="number" name="web3_min_withdraw_sat" value="<?= esc_attr( $min_wd_sat ) ?>" class="small-text" min="1" step="1">
                            <span class="description"> satoshis</span>
                        </td>
                    </tr>
                    <tr>
                        <th>Withdrawal Fee (sat)</th>
                        <td>
                            <input type="number" name="web3_fee_sat" value="<?= esc_attr( $fee_sat ) ?>" class="small-text" min="0" step="1">
                            <span class="description"> satoshis — deducted from user balance and routed to the admin admin wallet</span>
                        </td>
                    </tr>
                    <tr>
                        <th>WalletConnect Project ID</th>
                        <td>
                            <input type="text" name="web3_walletconnect_project_id" value="<?= esc_attr( $wc_project_id ) ?>" class="regular-text" placeholder="Get one free at cloud.walletconnect.com">
                            <p class="description">Required for the WalletConnect QR-code flow. Leave blank to disable WalletConnect widgets. <a href="https://cloud.walletconnect.com" target="_blank" rel="noopener">Get a Project ID →</a></p>
                        </td>
                    </tr>

                    <!-- ── INFURA ── -->
                    <tr><td colspan="2"><hr style="border:none;border-top:1px solid #e0e0e0;margin:8px 0"></td></tr>
                    <tr>
                        <th colspan="2" style="padding-bottom:4px">
                            <span style="font-size:.95rem;font-weight:700;color:#1a3a7a">⚡ Infura RPC Configuration</span>
                            <?php if ( $api_status !== null ): ?>
                                <span style="margin-left:12px;font-size:.78rem;font-weight:400;color:<?= $api_status['infura'] ? '#22c55e' : '#ef4444' ?>">
                                    <?= $api_status['infura']
                                        ? '● Connected (block #' . number_format( $api_status['block_number'] ?? 0 ) . ')'
                                        : '● ' . esc_html( $api_status['infura_error'] ?? 'Not connected' ) ?>
                                </span>
                            <?php endif; ?>
                        </th>
                    </tr>
                    <tr>
                        <th>Infura API Key</th>
                        <td>
                            <input type="text" name="web3_infura_api_key"
                                   value="<?= esc_attr( $infura_key ) ?>"
                                   class="regular-text"
                                   placeholder="e.g. a1b2c3d4e5f6…"
                                   autocomplete="off">
                            <p class="description">
                                Your Infura project API key — used as the RPC endpoint for on-chain balance checks,
                                transaction receipts, and (optionally) direct deposits.
                                <a href="https://app.infura.io" target="_blank" rel="noopener">Get one free at app.infura.io →</a>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th>Network</th>
                        <td>
                            <select name="web3_infura_network" class="regular-text">
                                <?php foreach ( $network_map as $slug => $net ): ?>
                                    <option value="<?= esc_attr( $slug ) ?>" <?php selected( $infura_network, $slug ); ?>>
                                        <?= esc_html( $net['label'] ) ?> (Chain <?= (int) $net['chain_id'] ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">Network for all Infura RPC calls and Etherscan lookups. Must match the currency you select above.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Direct RPC Deposits</th>
                        <td>
                            <label>
                                <input type="checkbox" name="web3_direct_rpc_deposits" value="1" <?php checked( $direct_rpc, '1' ); ?>>
                                Verify deposits directly via Infura + Etherscan instead of relying solely on NOWPayments IPN
                            </label>
                            <p class="description">
                                When enabled, the plugin will poll Infura for transaction receipts and confirm via Etherscan
                                once the wallet sends funds. The NOWPayments IPN remains the primary credit trigger;
                                this adds a secondary on-chain verification layer.
                            </p>
                        </td>
                    </tr>

                    <!-- ── ETHERSCAN ── -->
                    <tr><td colspan="2"><hr style="border:none;border-top:1px solid #e0e0e0;margin:8px 0"></td></tr>
                    <tr>
                        <th colspan="2" style="padding-bottom:4px">
                            <span style="font-size:.95rem;font-weight:700;color:#1a3a7a">🔍 Etherscan API Configuration</span>
                            <?php if ( $api_status !== null ): ?>
                                <span style="margin-left:12px;font-size:.78rem;font-weight:400;color:<?= $api_status['etherscan'] ? '#22c55e' : '#ef4444' ?>">
                                    <?= $api_status['etherscan']
                                        ? '● Connected'
                                        : '● ' . esc_html( $api_status['etherscan_error'] ?? 'Not connected' ) ?>
                                </span>
                            <?php endif; ?>
                        </th>
                    </tr>
                    <tr>
                        <th>Etherscan API Key</th>
                        <td>
                            <input type="text" name="web3_etherscan_api_key"
                                   value="<?= esc_attr( $etherscan_key ) ?>"
                                   class="regular-text"
                                   placeholder="e.g. ABCDEF123456…"
                                   autocomplete="off">
                            <p class="description">
                                Used to verify deposit transactions on-chain and pull transaction history.
                                For Polygon use a <a href="https://polygonscan.com/apis" target="_blank" rel="noopener">Polygonscan key</a>;
                                for BNB Chain use a <a href="https://bscscan.com/apis" target="_blank" rel="noopener">BscScan key</a>.
                                <a href="https://etherscan.io/apis" target="_blank" rel="noopener">Get an Etherscan key →</a>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th>Custom Explorer API URL <span style="font-weight:400;color:#888">(optional)</span></th>
                        <td>
                            <input type="url" name="web3_etherscan_base_url"
                                   value="<?= esc_attr( $etherscan_url ) ?>"
                                   class="regular-text"
                                   placeholder="Leave blank to use the auto-detected URL for the network above">
                            <p class="description">Override the Etherscan-compatible API base URL (e.g. for self-hosted block explorers or non-default chains). Leave blank to use the standard URL for the network selected above.</p>
                        </td>
                    </tr>
                    <tr>
                        <th>Minimum Deposit Confirmations</th>
                        <td>
                            <input type="number" name="web3_deposit_confirmations"
                                   value="<?= esc_attr( $confirms ) ?>"
                                   class="small-text" min="1" max="100" step="1">
                            <span class="description"> block confirmations required before a deposit is credited</span>
                            <p class="description">Recommended: 3 for ETH mainnet, 10 for Polygon, 15 for BNB Chain.</p>
                        </td>
                    </tr>
                    <tr><td colspan="2"><hr style="border:none;border-top:1px solid #e0e0e0;margin:8px 0"></td></tr>

                    <!-- Revenue stream toggles -->
                    <tr>
                        <th>MetaMask Fee Revenue Stream</th>
                        <td>
                            <label>
                                <input type="checkbox" name="admin_wallet_stream_web3_metamask_fee" value="1" <?php checked( $mm_fee_on, '1' ); ?>>
                                Credit MetaMask withdrawal fees to admin admin wallet
                            </label>
                        </td>
                    </tr>
                    <tr>
                        <th>WalletConnect Fee Revenue Stream</th>
                        <td>
                            <label>
                                <input type="checkbox" name="admin_wallet_stream_web3_walletconnect_fee" value="1" <?php checked( $wc_fee_on, '1' ); ?>>
                                Credit WalletConnect withdrawal fees to admin admin wallet
                            </label>
                        </td>
                    </tr>
                </table>

                <div style="background:#f0f8ff;border-radius:8px;padding:14px;margin:20px 0;font-size:.83rem">
                    <strong>ℹ️ How fee routing works:</strong><br>
                    When a user withdraws via MetaMask or WalletConnect, the fee you configure above is deducted from their balance and recorded in the <strong>admin admin wallet</strong> under the streams
                    <code>web3_metamask_withdraw_fee</code> and <code>web3_walletconnect_withdraw_fee</code>.
                    These streams appear in the Wallet &amp; Fees admin page and can be swept to your hardware wallet just like house-edge revenue.
                </div>

                <input type="submit" name="cfp_save_web3" value="Save Web3 Settings" class="button button-primary button-large">
            </form>
        </div>

        <!-- Shortcode reference -->
        <div style="background:#fff;border:1px solid #e0e0e0;border-radius:12px;padding:24px;max-width:700px;margin-bottom:28px">
            <h2 style="margin-top:0">📋 Shortcodes</h2>
            <table class="widefat" style="border-radius:8px;overflow:hidden">
                <thead><tr><th>Shortcode</th><th>Description</th></tr></thead>
                <tbody>
                    <?php foreach ([
                        ['[cfp_metamask_deposit]',       'MetaMask deposit widget — connects wallet, generates NOWPayments address'],
                        ['[cfp_metamask_withdraw]',      'MetaMask withdrawal widget — sends funds to connected wallet address'],
                        ['[cfp_walletconnect_deposit]',  'WalletConnect deposit widget — QR-code connect, NOWPayments address'],
                        ['[cfp_walletconnect_withdraw]', 'WalletConnect withdrawal widget — sends funds to connected wallet'],
                    ] as [$sc, $desc]): ?>
                    <tr>
                        <td><code><?= esc_html( $sc ) ?></code></td>
                        <td style="font-size:.85rem;color:#555"><?= esc_html( $desc ) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Recent Web3 Deposits -->
        <div style="background:#fff;border:1px solid #e0e0e0;border-radius:12px;padding:24px;max-width:900px;margin-bottom:28px">
            <h2 style="margin-top:0">Recent Web3 Deposits</h2>
            <?php if ( empty( $recent_deps ) ): ?>
                <p style="color:#888;font-size:.85rem">No Web3 deposits yet.</p>
            <?php else: ?>
            <table class="widefat striped" style="border-radius:8px;overflow:hidden">
                <thead><tr><th>User</th><th>Currency</th><th>Amount</th><th>Status</th><th>Date</th></tr></thead>
                <tbody>
                    <?php foreach ( $recent_deps as $d ): ?>
                    <tr>
                        <td><?= esc_html( $d->username ?? "#{$d->user_id}" ) ?></td>
                        <td><?= esc_html( strtoupper( $d->currency ) ) ?></td>
                        <td><?= number_format( $d->amount_sat ) ?> sat</td>
                        <td><span style="color:<?= $d->status === 'credited' ? '#22c55e' : '#f59e0b' ?>"><?= esc_html( $d->status ) ?></span></td>
                        <td><?= esc_html( $d->created_at ) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>

        <!-- Recent Web3 Withdrawals -->
        <div style="background:#fff;border:1px solid #e0e0e0;border-radius:12px;padding:24px;max-width:900px">
            <h2 style="margin-top:0">Recent Web3 Withdrawals</h2>
            <?php if ( empty( $recent_wds ) ): ?>
                <p style="color:#888;font-size:.85rem">No Web3 withdrawals yet.</p>
            <?php else: ?>
            <table class="widefat striped" style="border-radius:8px;overflow:hidden">
                <thead><tr><th>User</th><th>To Address</th><th>Currency</th><th>Amount</th><th>Fee</th><th>Status</th><th>Date</th></tr></thead>
                <tbody>
                    <?php foreach ( $recent_wds as $w ): ?>
                    <tr>
                        <td><?= esc_html( $w->username ?? "#{$w->user_id}" ) ?></td>
                        <td style="font-size:.78rem;word-break:break-all;max-width:140px"><?= esc_html( substr( $w->to_address, 0, 12 ) . '…' ) ?></td>
                        <td><?= esc_html( strtoupper( $w->currency ) ) ?></td>
                        <td><?= number_format( $w->amount_sat ) ?> sat</td>
                        <td><?= number_format( $w->fee_sat ) ?> sat</td>
                        <td><span style="color:<?= $w->status === 'paid' ? '#22c55e' : ( $w->status === 'failed' ? '#ef4444' : '#f59e0b' ) ?>"><?= esc_html( $w->status ) ?></span></td>
                        <td><?= esc_html( $w->requested_at ?? '' ) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>
    <?php
}
