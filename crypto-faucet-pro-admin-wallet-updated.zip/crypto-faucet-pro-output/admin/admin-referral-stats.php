<?php
/**
 * Admin page: Referral Stats Dashboard
 * Part of Crypto Faucet Pro plugin.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_referral_stats() {
    global $wpdb;
    
    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };
    $ref_percent = $gs('referral_percent', 50);
    
    $total_referrals = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_REFERRALS);
    $total_referrers = (int)$wpdb->get_var("SELECT COUNT(DISTINCT referrer_id) FROM " . CFP_TABLE_REFERRALS);
    $total_referred = (int)$wpdb->get_var("SELECT COUNT(DISTINCT referred_id) FROM " . CFP_TABLE_REFERRALS);
    $total_commission = (int)$wpdb->get_var("SELECT COALESCE(SUM(amount_sat),0) FROM " . CFP_TABLE_TRANSACTIONS . " WHERE type='referral_commission'");
    
    $top_referrers = $wpdb->get_results("
        SELECT u.id, u.username, u.email, 
               COUNT(r.id) as ref_count,
               COALESCE(SUM(t.amount_sat),0) as total_earned
        FROM " . CFP_TABLE_USERS . " u
        LEFT JOIN " . CFP_TABLE_REFERRALS . " r ON r.referrer_id = u.id
        LEFT JOIN " . CFP_TABLE_TRANSACTIONS . " t ON t.user_id = u.id AND t.type = 'referral_commission'
        GROUP BY u.id
        ORDER BY total_earned DESC
        LIMIT 20
    ");
    
    $recent_refs = $wpdb->get_results("
        SELECT r.id, r.created_at as ref_date,
               r2.username as referrer,
               r1.username as referred,
               t.amount_sat as commission
        FROM " . CFP_TABLE_REFERRALS . " r
        LEFT JOIN " . CFP_TABLE_USERS . " r1 ON r.referred_id = r1.id
        LEFT JOIN " . CFP_TABLE_USERS . " r2 ON r.referrer_id = r2.id
        LEFT JOIN " . CFP_TABLE_TRANSACTIONS . " t ON t.user_id = r2.id AND t.type = 'referral_commission' AND t.ref_id = r.id
        ORDER BY r.created_at DESC
        LIMIT 30
    ");
    
    $ref_by_day = $wpdb->get_results("
        SELECT DATE(r.created_at) as date, COUNT(*) as refs, COALESCE(SUM(t.amount_sat),0) as commission
        FROM " . CFP_TABLE_REFERRALS . " r
        LEFT JOIN " . CFP_TABLE_TRANSACTIONS . " t ON t.user_id = r.referrer_id AND t.type = 'referral_commission' AND t.ref_id = r.id
        WHERE r.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        GROUP BY DATE(r.created_at)
        ORDER BY date DESC
    ");
    
    $tier_stats = $wpdb->get_results("
        SELECT 
            CASE 
                WHEN COALESCE(SUM(t.amount_sat),0) > 100000 THEN 'Gold'
                WHEN COALESCE(SUM(t.amount_sat),0) > 10000 THEN 'Silver'  
                ELSE 'Bronze'
            END as tier,
            COUNT(DISTINCT r.referrer_id) as count,
            COALESCE(SUM(t.amount_sat),0) as total_earned
        FROM " . CFP_TABLE_REFERRALS . " r
        LEFT JOIN " . CFP_TABLE_TRANSACTIONS . " t ON t.user_id = r.referrer_id AND t.type = 'referral_commission'
        GROUP BY tier
    ");
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🔗</span>
            <h1>🔗 Referral Program Statistics</h1>
            <div style="margin-left:auto">
                <span class="cfp-badge active" style="font-size:.85rem">Default Commission: <?=$ref_percent?>%</span>
            </div>
        </div>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(5,1fr);margin-bottom:24px">
            <div class="cfp-stat-card green">
                <div class="label">Total Referrals</div>
                <div class="value"><?=number_format($total_referrals)?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">Active Referrers</div>
                <div class="value"><?=number_format($total_referrers)?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">Referred Users</div>
                <div class="value"><?=number_format($total_referred)?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Total Paid</div>
                <div class="value"><?=number_format($total_commission)?></div>
                <div class="sub">sat in commissions</div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Conversion Rate</div>
                <div class="value"><?=$total_users = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_USERS);
                    echo $total_users > 0 ? round($total_referred / $total_users * 100, 1) : 0;?>%</div>
                <div class="sub">of all users</div>
            </div>
        </div>

        <div class="cfp-2col" style="margin-bottom:24px">
            <div class="cfp-card">
                <h2>🏆 Top Referrers</h2>
                <div class="cfp-table-wrap">
                    <table class="cfp-table">
                        <thead><tr><th>#</th><th>User</th><th>Referrals</th><th>Total Earned</th></tr></thead>
                        <tbody>
                        <?php foreach($top_referrers as $i => $r): ?>
                        <tr>
                            <td><?=($i+1)?></td>
                            <td>
                                <div style="display:flex;align-items:center;gap:8px">
                                    <div style="width:28px;height:28px;border-radius:50%;background:#1a1a1a;display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--g);font-size:.7rem">
                                        <?=esc_html(strtoupper(substr($r->username,0,1)))?>
                                    </div>
                                    <strong><?=esc_html($r->username)?></strong>
                                </div>
                            </td>
                            <td><?=number_format($r->ref_count)?></td>
                            <td style="color:var(--g);font-weight:700"><?=number_format($r->total_earned)?> sat</td>
                        </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="cfp-card">
                <h2>📊 Tier Distribution</h2>
                <?php 
                $tier_colors = ['Gold' => '#fbbf24', 'Silver' => '#94a3b8', 'Bronze' => '#cd7f32'];
                foreach($tier_stats as $t): 
                ?>
                <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;padding:12px;background:#111;border-radius:8px">
                    <div style="width:40px;height:40px;border-radius:50%;background:<?=$tier_colors[$t->tier]?>22;border:2px solid <?=$tier_colors[$t->tier]?>;display:flex;align-items:center;justify-content:center;font-size:1.2rem">
                        <?=substr($t->tier,0,1)?>
                    </div>
                    <div style="flex:1">
                        <div style="font-weight:700;color:#fff"><?=$t->tier?> Referrers</div>
                        <div style="font-size:.78rem;color:var(--mt)"><?=$t->count?> users · <?=number_format($t->total_earned)?> sat earned</div>
                    </div>
                </div>
                <?php endforeach; ?>
                
                <h3 style="margin-top:20px;font-size:.9rem;color:var(--mt);margin-bottom:10px">Tier Thresholds</h3>
                <div style="font-size:.8rem;color:#555">
                    🥇 Gold: 100,000+ sat earned<br>
                    🥈 Silver: 10,000+ sat earned<br>
                    🥉 Bronze: Under 10,000 sat
                </div>
            </div>
        </div>

        <div class="cfp-card" style="margin-bottom:22px">
            <h2>📈 Last 30 Days Activity</h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead><tr><th>Date</th><th>New Referrals</th><th>Commission Paid</th></tr></thead>
                    <tbody>
                    <?php foreach($ref_by_day as $d): ?>
                    <tr>
                        <td><?=date('M j, Y', strtotime($d->date))?></td>
                        <td><?=$d->refs?></td>
                        <td style="color:var(--g)"><?=number_format($d->commission)?> sat</td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="cfp-card">
            <h2>📜 Recent Referral Signups</h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead><tr><th>Referrer</th><th>Referred User</th><th>Commission</th><th>Date</th></tr></thead>
                    <tbody>
                    <?php foreach($recent_refs as $r): ?>
                    <tr>
                        <td><strong><?=esc_html($r->referrer ?? 'N/A')?></strong></td>
                        <td><?=esc_html($r->referred ?? 'N/A')?></td>
                        <td style="color:var(--g)"><?=$r->commission ? number_format($r->commission).' sat' : '-' ?></td>
                        <td style="color:var(--mt)"><?=human_time_diff(strtotime($r->ref_date), current_time('timestamp'))?> ago</td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('refChart');
        if(ctx) {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: [<?=implode(',', array_map(function($d){ return "'".date('M j',strtotime($d->date))."'"; }, $ref_by_day))?>],
                    datasets: [{
                        label: 'New Referrals',
                        data: [<?=implode(',', array_map(function($d){ return $d->refs; }, $ref_by_day))?>],
                        borderColor: '#f7931a',
                        backgroundColor: 'rgba(247,147,26,0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    plugins: { legend: { labels: { color: '#888' } } },
                    scales: {
                        x: { ticks: { color: '#666' }, grid: { color: '#222' } },
                        y: { ticks: { color: '#666' }, grid: { color: '#222' } }
                    }
                }
            });
        }
    });
    </script>
    <?php
}