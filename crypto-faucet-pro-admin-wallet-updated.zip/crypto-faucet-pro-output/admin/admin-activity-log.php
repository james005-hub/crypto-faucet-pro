<?php
/**
 * Admin page: User Activity Log - Detailed login history and user actions
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Activity Log
   ============================================================ */
add_action('wp_ajax_cfp_activity_log_data', 'cfp_ajax_activity_log_data');
function cfp_ajax_activity_log_data() {
    check_ajax_referer('cfp_activity_nonce', 'nonce');
    
    global $wpdb;
    $action = sanitize_text_field($_POST['sub_action'] ?? 'list');
    
    if($action === 'list') {
        $user_id = intval($_POST['user_id'] ?? 0);
        $type = sanitize_text_field($_POST['type'] ?? 'all');
        $page = max(1, intval($_POST['page'] ?? 1));
        $limit = 50;
        $offset = ($page - 1) * $limit;
        
        $where = "1=1";
        if($user_id > 0) $where .= $wpdb->prepare(" AND user_id = %d", $user_id);
        if($type !== 'all') $where .= $wpdb->prepare(" AND activity_type = %s", $type);
        
        $logs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cfp_activity_log WHERE {$where} ORDER BY created_at DESC LIMIT %d OFFSET %d",
            $limit, $offset
        ));
        
        $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}cfp_activity_log WHERE {$where}");
        
        $stats = $wpdb->get_row("
            SELECT 
                COUNT(*) as total,
                SUM(CASE WHEN activity_type = 'login' THEN 1 ELSE 0 END) as logins,
                SUM(CASE WHEN activity_type = 'claim' THEN 1 ELSE 0 END) as claims,
                SUM(CASE WHEN activity_type = 'withdraw' THEN 1 ELSE 0 END) as withdrawals,
                SUM(CASE WHEN activity_type = 'game' THEN 1 ELSE 0 END) as games
            FROM {$wpdb->prefix}cfp_activity_log
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ");
        
        wp_send_json_success([
            'logs' => $logs,
            'total' => $total,
            'pages' => ceil($total / $limit),
            'current_page' => $page,
            'stats' => $stats
        ]);
    }
    
    if($action === 'user_activities') {
        $user_id = intval($_POST['user_id'] ?? 0);
        
        $logs = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cfp_activity_log WHERE user_id = %d ORDER BY created_at DESC LIMIT 100",
            $user_id
        ));
        
        wp_send_json_success(['logs' => $logs]);
    }
}

/* ============================================================
   ADMIN: ACTIVITY LOG PAGE
   ============================================================ */
function cfp_admin_activity_log() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_activity_nonce');
    
    $recent_logs = $wpdb->get_results("
        SELECT l.*, u.username FROM {$wpdb->prefix}cfp_activity_log l
        LEFT JOIN " . CFP_TABLE_USERS . " u ON l.user_id = u.id
        ORDER BY l.created_at DESC LIMIT 30
    ");
    
    $stats = $wpdb->get_row("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN activity_type = 'login' THEN 1 ELSE 0 END) as logins,
            SUM(CASE WHEN activity_type = 'claim' THEN 1 ELSE 0 END) as claims,
            SUM(CASE WHEN activity_type = 'withdraw' THEN 1 ELSE 0 END) as withdrawals,
            SUM(CASE WHEN activity_type = 'game' THEN 1 ELSE 0 END) as games
        FROM {$wpdb->prefix}cfp_activity_log
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
    ");
    
    $top_active = $wpdb->get_results("
        SELECT user_id, COUNT(*) as activity_count,
               (SELECT username FROM " . CFP_TABLE_USERS . " WHERE id = user_id) as username
        FROM {$wpdb->prefix}cfp_activity_log
        WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
        GROUP BY user_id ORDER BY activity_count DESC LIMIT 10
    ");
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">📜</span>
            <h1>📜 User Activity Log</h1>
            <button onclick="cfpExportActivityLog()" class="cfp-btn cfp-btn-ghost" style="margin-left:auto">📥 Export</button>
        </div>

        <!-- STATS OVERVIEW -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(5, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card">
                <div class="label">📊 30-Day Activities</div>
                <div class="value"><?=number_format($stats->total ?? 0)?></div>
            </div>
            <div class="cfp-stat-card green">
                <div class="label">🔐 Logins</div>
                <div class="value"><?=number_format($stats->logins ?? 0)?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">🎁 Claims</div>
                <div class="value"><?=number_format($stats->claims ?? 0)?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">🎮 Games</div>
                <div class="value"><?=number_format($stats->games ?? 0)?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">💸 Withdrawals</div>
                <div class="value"><?=number_format($stats->withdrawals ?? 0)?></div>
            </div>
        </div>

        <!-- FILTER -->
        <div class="cfp-card" style="margin-bottom:24px">
            <div style="display:flex;gap:16px;align-items:end">
                <div class="cfp-field" style="flex:1">
                    <label>Filter by User ID</label>
                    <input type="number" id="cfp-activity-user-id" placeholder="Enter User ID">
                </div>
                <div class="cfp-field">
                    <label>Activity Type</label>
                    <select id="cfp-activity-type">
                        <option value="all">All Types</option>
                        <option value="login">Login</option>
                        <option value="claim">Claim</option>
                        <option value="game">Game</option>
                        <option value="withdraw">Withdrawal</option>
                        <option value="deposit">Deposit</option>
                        <option value="register">Registration</option>
                    </select>
                </div>
                <button onclick="cfpFilterActivity()" class="cfp-btn cfp-btn-gold">Filter</button>
                <button onclick="cfpClearFilters()" class="cfp-btn cfp-btn-ghost">Clear</button>
            </div>
        </div>

        <!-- ACTIVITY LOG TABLE -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>📋 Recent Activities</h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>Activity</th>
                            <th>Details</th>
                            <th>IP Address</th>
                            <th>Time</th>
                        </tr>
                    </thead>
                    <tbody id="cfp-activity-tbody">
                        <?php foreach($recent_logs as $log): 
                            $type_colors = ['login' => 'green', 'claim' => 'blue', 'game' => 'purple', 'withdraw' => 'orange', 'deposit' => 'active', 'register' => 'drawn'];
                        ?>
                        <tr>
                            <td>
                                <strong><?=esc_html($log->username ?? 'User #'.$log->user_id)?></strong>
                                <br><span style="color:#555;font-size:.7rem">ID: <?=$log->user_id?></span>
                            </td>
                            <td><span class="cfp-badge <?=$type_colors[$log->activity_type] ?? ''?>"><?=esc_html($log->activity_type)?></span></td>
                            <td style="color:#888;font-size:.85rem;max-width:200px;overflow:hidden;text-overflow:ellipsis"><?=esc_html($log->details ?? '-')?></td>
                            <td style="font-family:monospace;color:#555"><?=esc_html($log->ip_address ?? '-')?></td>
                            <td style="color:#555;font-size:.8rem"><?=human_time_diff(strtotime($log->created_at), current_time('timestamp'))?> ago</td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="cfp-pagination" id="cfp-activity-pagination"></div>
        </div>

        <!-- TOP ACTIVE USERS -->
        <div class="cfp-card">
            <h2>🔥 Most Active Users (7 Days)</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px">
                <?php foreach($top_active as $u): ?>
                <div style="background:#0d0d0d;padding:14px;border-radius:10px;display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div style="font-weight:700;color:#fff"><?=esc_html($u->username ?? 'User #'.$u->user_id)?></div>
                        <div style="font-size:.75rem;color:#555">ID: <?=$u->user_id?></div>
                    </div>
                    <div style="text-align:right">
                        <div style="font-size:1.4rem;font-weight:800;color:#f7931a"><?=number_format($u->activity_count)?></div>
                        <div style="font-size:.65rem;color:#555">activities</div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php if(empty($top_active)): ?>
                <div style="grid-column:1/-1;text-align:center;padding:20px;color:#555">No activity data</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
    let currentActivityPage = 1;
    let currentUserId = 0;
    let currentType = 'all';

    document.addEventListener('DOMContentLoaded', function() {
        cfpLoadActivityLog(1);
    });

    function cfpLoadActivityLog(page) {
        currentActivityPage = page;
        const fd = new FormData();
        fd.append('action', 'cfp_activity_log_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'list');
        fd.append('page', page);
        fd.append('user_id', currentUserId);
        fd.append('type', currentType);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    cfpRenderActivityLog(d.data);
                }
            });
    }

    function cfpRenderActivityLog(data) {
        const tbody = document.getElementById('cfp-activity-tbody');
        if(data.logs.length === 0) {
            tbody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#555;padding:40px">No activity logs found</td></tr>';
            return;
        }

        const typeColors = { login: 'green', claim: 'blue', game: 'purple', withdraw: 'orange', deposit: 'active', register: 'drawn' };

        tbody.innerHTML = data.logs.map(l => `
            <tr>
                <td><strong>${l.username || 'User #' + l.user_id}</strong><br><span style="color:#555;font-size:.7rem">ID: ${l.user_id}</span></td>
                <td><span class="cfp-badge ${typeColors[l.activity_type] || ''}">${l.activity_type}</span></td>
                <td style="color:#888;font-size:.85rem;max-width:200px;overflow:hidden;text-overflow:ellipsis">${l.details || '-'}</td>
                <td style="font-family:monospace;color:#555">${l.ip_address || '-'}</td>
                <td style="color:#555;font-size:.8rem">${cfpTimeAgo(l.created_at)}</td>
            </tr>
        `).join('');

        // Pagination
        const pag = document.getElementById('cfp-activity-pagination');
        if(data.pages > 1) {
            let html = '';
            for(let i=1; i<=Math.min(data.pages, 5); i++) {
                html += `<a href="#" onclick="cfpLoadActivityLog(${i});return false" class="${i === data.current_page ? 'current' : ''}">${i}</a>`;
            }
            pag.innerHTML = html;
        } else {
            pag.innerHTML = '';
        }
    }

    function cfpFilterActivity() {
        currentUserId = document.getElementById('cfp-activity-user-id').value || 0;
        currentType = document.getElementById('cfp-activity-type').value;
        cfpLoadActivityLog(1);
    }

    function cfpClearFilters() {
        document.getElementById('cfp-activity-user-id').value = '';
        document.getElementById('cfp-activity-type').value = 'all';
        currentUserId = 0;
        currentType = 'all';
        cfpLoadActivityLog(1);
    }

    function cfpExportActivityLog() {
        alert('Export functionality - would generate CSV of activity logs');
    }

    function cfpTimeAgo(dateStr) {
        const date = new Date(dateStr);
        const now = new Date();
        const secs = Math.floor((now - date) / 1000);
        if(secs < 60) return secs + 's ago';
        if(secs < 3600) return Math.floor(secs/60) + 'm ago';
        if(secs < 86400) return Math.floor(secs/3600) + 'h ago';
        return Math.floor(secs/86400) + 'd ago';
    }
    </script>
    <?php
}