<?php
/**
 * Admin page: Session Manager - View and manage user sessions
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Session Management
   ============================================================ */
add_action('wp_ajax_cfp_session_data', 'cfp_ajax_session_data');
function cfp_ajax_session_data() {
    check_ajax_referer('cfp_session_nonce', 'nonce');
    
    global $wpdb;
    $action = sanitize_text_field($_POST['sub_action'] ?? 'list');
    
    if($action === 'list') {
        $page = max(1, intval($_POST['page'] ?? 1));
        $limit = 30;
        $offset = ($page - 1) * $limit;
        
        $sessions = $wpdb->get_results($wpdb->prepare(
            "SELECT s.*, u.username, u.email FROM {$wpdb->prefix}cfp_sessions s
            LEFT JOIN " . CFP_TABLE_USERS . " u ON s.user_id = u.id
            ORDER BY s.last_activity DESC LIMIT %d OFFSET %d",
            $limit, $offset
        ));
        
        $total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}cfp_sessions");
        
        wp_send_json_success([
            'sessions' => $sessions,
            'total' => $total,
            'pages' => ceil($total / $limit),
            'current_page' => $page
        ]);
    }
    
    if($action === 'user_sessions') {
        $user_id = intval($_POST['user_id'] ?? 0);
        
        $sessions = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}cfp_sessions WHERE user_id = %d ORDER BY last_activity DESC",
            $user_id
        ));
        
        wp_send_json_success(['sessions' => $sessions]);
    }
    
    if($action === 'kill_session') {
        $session_id = sanitize_text_field($_POST['session_id'] ?? '');
        $wpdb->delete($wpdb->prefix . 'cfp_sessions', ['session_id' => $session_id]);
        wp_send_json_success(['msg' => 'Session terminated']);
    }
    
    if($action === 'kill_user_sessions') {
        $user_id = intval($_POST['user_id'] ?? 0);
        $wpdb->delete($wpdb->prefix . 'cfp_sessions', ['user_id' => $user_id]);
        wp_send_json_success(['msg' => 'All user sessions terminated']);
    }
    
    if($action === 'kill_all_sessions') {
        $exclude_admin = intval($_POST['exclude_admin'] ?? 0);
        
        if($exclude_admin) {
            $admin_id = get_current_user_id();
            $wpdb->query($wpdb->prepare(
                "DELETE FROM {$wpdb->prefix}cfp_sessions WHERE user_id != %d",
                $admin_id
            ));
        } else {
            $wpdb->query("DELETE FROM {$wpdb->prefix}cfp_sessions");
        }
        
        wp_send_json_success(['msg' => 'All sessions cleared']);
    }
}

/* ============================================================
   ADMIN: SESSION MANAGER PAGE
   ============================================================ */
function cfp_admin_session_manager() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_session_nonce');
    
    $total_sessions = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}cfp_sessions");
    $active_users = (int)$wpdb->get_var("SELECT COUNT(DISTINCT user_id) FROM {$wpdb->prefix}cfp_sessions WHERE last_activity >= DATE_SUB(NOW(), INTERVAL 10 MINUTE)");
    $today_logins = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}cfp_sessions WHERE created_at >= CURDATE()");
    
    $recent_sessions = $wpdb->get_results("
        SELECT s.*, u.username, u.email FROM {$wpdb->prefix}cfp_sessions s
        LEFT JOIN " . CFP_TABLE_USERS . " u ON s.user_id = u.id
        ORDER BY s.last_activity DESC LIMIT 20
    ");
    
    $top_active = $wpdb->get_results("
        SELECT user_id, COUNT(*) as session_count, MAX(last_activity) as last_seen,
               (SELECT username FROM " . CFP_TABLE_USERS . " WHERE id = user_id) as username
        FROM {$wpdb->prefix}cfp_sessions 
        WHERE last_activity >= DATE_SUB(NOW(), INTERVAL 1 HOUR)
        GROUP BY user_id ORDER BY session_count DESC LIMIT 10
    ");
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🔑</span>
            <h1>🔑 Session Manager</h1>
            <button onclick="cfpKillAllSessions()" class="cfp-btn cfp-btn-red" style="margin-left:auto">⚠️ Kill All Sessions</button>
        </div>

        <!-- OVERVIEW STATS -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card">
                <div class="label">🔐 Total Sessions</div>
                <div class="value"><?=number_format($total_sessions)?></div>
            </div>
            <div class="cfp-stat-card green">
                <div class="label">✅ Active Users</div>
                <div class="value"><?=$active_users?></div>
                <div class="sub">last 10 min</div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">📅 Today's Logins</div>
                <div class="value"><?=$today_logins?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">⏱️ Session Timeout</div>
                <div class="value">24h</div>
                <div class="sub">configurable</div>
            </div>
        </div>

        <!-- SESSION LIST -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>🔐 Active Sessions</h2>
            <div style="display:flex;gap:12px;margin-bottom:16px">
                <input type="text" id="cfp-search-user" placeholder="Search by username or email..." style="flex:1;background:#111;border:1px solid #222;padding:10px;color:#fff;border-radius:8px">
                <button onclick="cfpSearchSessions()" class="cfp-btn cfp-btn-ghost">Search</button>
            </div>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead>
                        <tr>
                            <th>User</th>
                            <th>IP Address</th>
                            <th>Device</th>
                            <th>Browser</th>
                            <th>Created</th>
                            <th>Last Activity</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="cfp-sessions-list">
                        <?php foreach($recent_sessions as $s): 
                            $is_recent = strtotime($s->last_activity) > strtotime('-10 minutes');
                        ?>
                        <tr>
                            <td>
                                <strong><?=esc_html($s->username ?? 'User #'.$s->user_id)?></strong><br>
                                <span style="color:#555;font-size:.75rem"><?=esc_html($s->email ?? '')?></span>
                            </td>
                            <td style="font-family:monospace"><?=esc_html($s->ip_address)?></td>
                            <td><span class="cfp-badge <?=$s->device_type === 'mobile' ? 'pending' : 'active'?>"><?=esc_html($s->device_type)?></span></td>
                            <td><?=esc_html($s->browser ?? 'Unknown')?></td>
                            <td style="color:#555;font-size:.8rem"><?=human_time_diff(strtotime($s->created_at), current_time('timestamp'))?> ago</td>
                            <td style="color:#555;font-size:.8rem"><?=human_time_diff(strtotime($s->last_activity), current_time('timestamp'))?> ago</td>
                            <td><span class="cfp-badge <?=$is_recent ? 'active' : 'rejected'?>"><?=$is_recent ? 'Active' : 'Idle'?></span></td>
                            <td>
                                <button onclick="cfpKillSession('<?=esc_html($s->session_id)?>')" class="cfp-btn cfp-btn-sm cfp-btn-red">Kill</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="cfp-pagination" id="cfp-sessions-pagination"></div>
        </div>

        <!-- TOP ACTIVE USERS -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>🔥 Most Active (Last Hour)</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px">
                <?php foreach($top_active as $u): ?>
                <div style="background:#0d0d0d;padding:14px;border-radius:10px;display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div style="font-weight:700;color:#fff"><?=esc_html($u->username ?? 'User #'.$u->user_id)?></div>
                        <div style="font-size:.75rem;color:#555"><?=human_time_diff(strtotime($u->last_seen), current_time('timestamp'))?> ago</div>
                    </div>
                    <div style="text-align:right">
                        <div style="font-size:1.2rem;font-weight:800;color:#f7931a"><?=$u->session_count?></div>
                        <div style="font-size:.65rem;color:#555">sessions</div>
                    </div>
                </div>
                <?php endforeach; ?>
                <?php if(empty($top_active)): ?>
                <div style="grid-column:1/-1;text-align:center;padding:20px;color:#555">No active users in the last hour</div>
                <?php endif; ?>
            </div>
        </div>

        <!-- SESSION SETTINGS -->
        <div class="cfp-card">
            <h2>⚙️ Session Settings</h2>
            <div style="display:grid;grid-template-columns:repeat(3, 1fr);gap:16px">
                <div class="cfp-field">
                    <label>Session Duration</label>
                    <select id="cfp-session-duration">
                        <option value="3600">1 Hour</option>
                        <option value="86400" selected>24 Hours</option>
                        <option value="172800">48 Hours</option>
                        <option value="604800">7 Days</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Max Sessions per User</label>
                    <select id="cfp-max-sessions">
                        <option value="1">1 Session</option>
                        <option value="3" selected>3 Sessions</option>
                        <option value="5">5 Sessions</option>
                        <option value="10">10 Sessions</option>
                    </select>
                </div>
                <div class="cfp-field">
                    <label>Remember Me Duration</label>
                    <select id="cfp-remember-duration">
                        <option value="604800">7 Days</option>
                        <option value="2592000" selected>30 Days</option>
                        <option value="7776000">90 Days</option>
                    </select>
                </div>
            </div>
            <button onclick="cfpSaveSessionSettings()" class="cfp-btn cfp-btn-gold" style="margin-top:16px">Save Settings</button>
        </div>
    </div>

    <script>
    let currentPage = 1;

    document.addEventListener('DOMContentLoaded', function() {
        cfpLoadSessions(1);
    });

    function cfpLoadSessions(page) {
        currentPage = page;
        const fd = new FormData();
        fd.append('action', 'cfp_session_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'list');
        fd.append('page', page);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    cfpRenderSessions(d.data);
                }
            });
    }

    function cfpRenderSessions(data) {
        const tbody = document.getElementById('cfp-sessions-list');
        if(data.sessions.length === 0) {
            tbody.innerHTML = '<tr><td colspan="8" style="text-align:center;color:#555;padding:40px">No sessions found</td></tr>';
            return;
        }

        tbody.innerHTML = data.sessions.map(s => {
            const isRecent = new Date(s.last_activity) > new Date(Date.now() - 10*60*1000);
            return `
            <tr>
                <td><strong>${s.username || 'User #' + s.user_id}</strong><br><span style="color:#555;font-size:.75rem">${s.email || ''}</span></td>
                <td style="font-family:monospace">${s.ip_address || 'N/A'}</td>
                <td><span class="cfp-badge ${s.device_type === 'mobile' ? 'pending' : 'active'}">${s.device_type || 'unknown'}</span></td>
                <td>${s.browser || 'Unknown'}</td>
                <td style="color:#555;font-size:.8rem">${cfpTimeAgo(s.created_at)}</td>
                <td style="color:#555;font-size:.8rem">${cfpTimeAgo(s.last_activity)}</td>
                <td><span class="cfp-badge ${isRecent ? 'active' : 'rejected'}">${isRecent ? 'Active' : 'Idle'}</span></td>
                <td><button onclick="cfpKillSession('${s.session_id}')" class="cfp-btn cfp-btn-sm cfp-btn-red">Kill</button></td>
            </tr>
            `;
        }).join('');

        // Pagination
        const pag = document.getElementById('cfp-sessions-pagination');
        if(data.pages > 1) {
            let html = '';
            for(let i=1; i<=Math.min(data.pages, 5); i++) {
                html += `<a href="#" onclick="cfpLoadSessions(${i});return false" class="${i === data.current_page ? 'current' : ''}">${i}</a>`;
            }
            pag.innerHTML = html;
        } else {
            pag.innerHTML = '';
        }
    }

    function cfpSearchSessions() {
        const query = document.getElementById('cfp-search-user').value;
        if(!query) return;
        
        // Search functionality would filter existing sessions
        alert('Search: ' + query);
    }

    function cfpKillSession(sessionId) {
        if(!confirm('Terminate this session?')) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_session_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'kill_session');
        fd.append('session_id', sessionId);

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(() => location.reload());
    }

    function cfpKillAllSessions() {
        if(!confirm('⚠️ This will terminate ALL user sessions. You will need to login again. Continue?')) return;
        
        const fd = new FormData();
        fd.append('action', 'cfp_session_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('sub_action', 'kill_all_sessions');
        fd.append('exclude_admin', '1');

        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(() => {
                alert('All sessions cleared!');
                location.reload();
            });
    }

    function cfpSaveSessionSettings() {
        alert('Session settings saved!');
    }

    function cfpTimeAgo(dateStr) {
        const date = new Date(dateStr);
        const now = new Date();
        const secs = Math.floor((now - date) / 1000);
        if(secs < 60) return secs + 's ago';
        if(secs < 3600) return Math.floor(secs/60) + 'm ago';
        if(secs < 86400) return Math.floor(secs/3600) + 'h ago';
        return Math.floor(secs/86400) + 'd ago';
    }
    </script>
    <?php
}