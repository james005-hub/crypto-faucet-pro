<?php
/**
 * Admin menu registration and admin-area enqueued styles
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

add_action('admin_menu', 'cfp_admin_menu');
function cfp_admin_menu() {
    add_menu_page('Crypto Faucet Pro','Crypto Faucet','manage_options','cfp-dashboard','cfp_admin_dashboard','dashicons-money-alt',25);
    add_submenu_page('cfp-dashboard','Dashboard','Dashboard','manage_options','cfp-dashboard','cfp_admin_dashboard');
    add_submenu_page('cfp-dashboard','Admin Wallet','💰 Admin Wallet','manage_options','cfp-wallet','cfp_admin_wallet');
    add_submenu_page('cfp-dashboard','Fees & Rates','💲 Fees &amp; Rates','manage_options','cfp-fees','cfp_admin_fees');
    add_submenu_page('cfp-dashboard','Users','Users','manage_options','cfp-users','cfp_admin_users');
    add_submenu_page('cfp-dashboard','Balance Adjustor','💰 Balance Adjustor','manage_options','cfp-balance-adjust','cfp_admin_balance_adjust');
    add_submenu_page('cfp-dashboard','Claims','Claims','manage_options','cfp-claims','cfp_admin_claims');
    add_submenu_page('cfp-dashboard','Withdrawals','Withdrawals','manage_options','cfp-withdrawals','cfp_admin_withdrawals');
    add_submenu_page('cfp-dashboard','NOWPayments','💸 NOWPayments','manage_options','cfp-nowpayments','cfp_admin_nowpayments');
    add_submenu_page('cfp-dashboard','Web3 Wallets','🦊 Web3 Wallets','manage_options','cfp-web3-wallets','cfp_admin_web3_wallets');
    add_submenu_page('cfp-dashboard','Lottery','Lottery','manage_options','cfp-lottery','cfp_admin_lottery');
    add_submenu_page('cfp-dashboard','P2P Events','P2P Events','manage_options','cfp-p2p','cfp_admin_p2p');
    add_submenu_page('cfp-dashboard','Games','🎮 Games','manage_options','cfp-games','cfp_admin_games');
    add_submenu_page('cfp-dashboard','Currency Editor','🪙 Currency Editor','manage_options','cfp-currency','cfp_admin_currency');
    add_submenu_page('cfp-dashboard','Currencies','Currencies','manage_options','cfp-currencies','cfp_admin_currencies');
    add_submenu_page('cfp-dashboard','Settings','Settings','manage_options','cfp-settings','cfp_admin_settings');
    add_submenu_page('cfp-dashboard','KYC','🪪 KYC Verify','manage_options','cfp-kyc','cfp_admin_kyc');
    add_submenu_page('cfp-dashboard','Security','🛡️ Security','manage_options','cfp-security','cfp_admin_security');
    add_submenu_page('cfp-dashboard','Monthly Contest','🏆 Monthly Contest','manage_options','cfp-contest','cfp_admin_monthly_contest');
    add_submenu_page('cfp-dashboard','PWA & App','📱 PWA / App','manage_options','cfp-pwa','cfp_admin_pwa_settings');
    add_submenu_page('cfp-dashboard','Multi-Crypto','🪙 Multi-Crypto','manage_options','cfp-multicrypto','cfp_admin_multicurrency');

    add_submenu_page(
        'cfp-dashboard',
        'Audit Log',
        '📋 Audit Log',
        'manage_options',
        'cfp-audit-log',
        'cfp_admin_audit_log'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Analytics',
        '📊 Analytics',
        'manage_options',
        'cfp-analytics',
        'cfp_admin_analytics'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Email Alerts',
        '🔔 Email Alerts',
        'manage_options',
        'cfp-email-alerts',
        'cfp_admin_email_alerts'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Referral Stats',
        '🔗 Referral Stats',
        'manage_options',
        'cfp-referral-stats',
        'cfp_admin_referral_stats'
    );

    add_submenu_page(
        'cfp-dashboard',
        'VPN/Tor Blocking',
        '🚫 Geo-Block',
        'manage_options',
        'cfp-geo-block',
        'cfp_admin_geo_block'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Anti-Fraud',
        '🛡️ Anti-Fraud',
        'manage_options',
        'cfp-anti-fraud',
        'cfp_admin_anti_fraud'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Branding',
        '🎨 Branding',
        'manage_options',
        'cfp-branding',
        'cfp_admin_branding'
    );

    add_submenu_page(
        'cfp-dashboard',
        'API Access',
        '🔑 API Access',
        'manage_options',
        'cfp-api-access',
        'cfp_admin_api_access'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Backup/Restore',
        '💾 Backup',
        'manage_options',
        'cfp-backup',
        'cfp_admin_backup'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Demo Mode',
        '🎮 Demo Mode',
        'manage_options',
        'cfp-demo-mode',
        'cfp_admin_demo_mode'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Promotions',
        '🏆 Promotions',
        'manage_options',
        'cfp-promotions',
        'cfp_admin_promotions'
    );

    add_submenu_page(
        'cfp-dashboard',
        'System Status',
        '🖥️ System Status',
        'manage_options',
        'cfp-system-status',
        'cfp_admin_system_status'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Traffic Analytics',
        '📈 Traffic',
        'manage_options',
        'cfp-traffic-analytics',
        'cfp_admin_traffic_analytics'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Cron Manager',
        '⏰ Cron',
        'manage_options',
        'cfp-cron-manager',
        'cfp_admin_cron_manager'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Ad Manager',
        '📺 Ads',
        'manage_options',
        'cfp-ad-manager',
        'cfp_admin_ad_manager'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Reports & Export',
        '📊 Reports',
        'manage_options',
        'cfp-reports-export',
        'cfp_admin_reports_export'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Betting Analytics',
        '🎰 Betting',
        'manage_options',
        'cfp-betting-analytics',
        'cfp_admin_betting_analytics'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Jackpot Manager',
        '💰 Jackpots',
        'manage_options',
        'cfp-jackpot-manager',
        'cfp_admin_jackpot_manager'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Fee Calculator',
        '🧮 Fees',
        'manage_options',
        'cfp-fee-calculator',
        'cfp_admin_fee_calculator'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Session Manager',
        '🔑 Sessions',
        'manage_options',
        'cfp-session-manager',
        'cfp_admin_session_manager'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Activity Log',
        '📜 Activity',
        'manage_options',
        'cfp-activity-log',
        'cfp_admin_activity_log'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Price Alerts',
        '🔔 Alerts',
        'manage_options',
        'cfp-price-alerts',
        'cfp_admin_price_alerts'
    );

    add_submenu_page(
        'cfp-dashboard',
        'API Keys',
        '🔐 API Keys',
        'manage_options',
        'cfp-api-key-manager',
        'cfp_admin_api_key_manager'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Bet Limits',
        '🎯 Bet Limits',
        'manage_options',
        'cfp-bet-limits',
        'cfp_admin_bet_limits_manager'
    );

    add_submenu_page(
        'cfp-dashboard',
        'Referral Tiers',
        '🏆 Referral Tiers',
        'manage_options',
        'cfp-referral-tiers',
        'cfp_admin_referral_tiers'
    );

}

add_action('admin_enqueue_scripts','cfp_admin_styles');
function cfp_admin_styles($hook) {
    if(strpos($hook,'cfp-')===false) return;
    echo '<style>
    :root{--g:#f7931a;--dk:#0d0d0d;--pn:#161616;--br:#2a2a2a;--tx:#e8e8e8;--mt:#888;--gr:#22c55e;--rd:#ef4444;--bl:#3b82f6;}
    #wpcontent,#wpbody-content{background:#0a0a0a!important;}
    .cfp-wrap{padding:20px;font-family:"Segoe UI",sans-serif;color:var(--tx);max-width:1400px;}
    .cfp-header{display:flex;align-items:center;gap:14px;margin-bottom:28px;padding-bottom:18px;border-bottom:1px solid var(--br);}
    .cfp-header h1{font-size:1.7rem;font-weight:800;color:#fff;margin:0;}
    .cfp-logo-badge{background:var(--g);color:#000;font-weight:900;padding:6px 12px;border-radius:8px;font-size:.82rem;letter-spacing:1px;}
    .cfp-stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:26px;}
    .cfp-stat-card{background:var(--pn);border:1px solid var(--br);border-radius:12px;padding:20px;position:relative;overflow:hidden;}
    .cfp-stat-card::before{content:"";position:absolute;top:0;left:0;right:0;height:3px;background:var(--g);}
    .cfp-stat-card.green::before{background:var(--gr);}
    .cfp-stat-card.blue::before{background:var(--bl);}
    .cfp-stat-card.red::before{background:var(--rd);}
    .cfp-stat-card.purple::before{background:#a855f7;}
    .cfp-stat-card .label{font-size:.72rem;text-transform:uppercase;letter-spacing:1.5px;color:var(--mt);margin-bottom:7px;}
    .cfp-stat-card .value{font-size:1.9rem;font-weight:800;color:#fff;}
    .cfp-stat-card .sub{font-size:.78rem;color:var(--mt);margin-top:3px;}
    .cfp-card{background:var(--pn);border:1px solid var(--br);border-radius:12px;padding:22px;margin-bottom:22px;}
    .cfp-card h2{font-size:1.05rem;font-weight:700;color:#fff;margin:0 0 18px;padding-bottom:12px;border-bottom:1px solid var(--br);}
    .cfp-table-wrap{overflow-x:auto;}
    table.cfp-table{width:100%;border-collapse:collapse;font-size:.86rem;}
    table.cfp-table th{background:#111;color:var(--mt);text-transform:uppercase;font-size:.68rem;letter-spacing:1px;padding:10px 13px;text-align:left;border-bottom:1px solid var(--br);}
    table.cfp-table td{padding:11px 13px;border-bottom:1px solid #1a1a1a;color:var(--tx);vertical-align:middle;}
    table.cfp-table tr:hover td{background:#1c1c1c;}
    .cfp-badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:.7rem;font-weight:600;text-transform:uppercase;letter-spacing:.5px;}
    .cfp-badge.pending{background:#2a2000;color:#f7931a;border:1px solid #f7931a44;}
    .cfp-badge.approved,.cfp-badge.active,.cfp-badge.open{background:#052e16;color:#22c55e;border:1px solid #22c55e44;}
    .cfp-badge.rejected,.cfp-badge.banned,.cfp-badge.closed{background:#2d0a0a;color:#ef4444;border:1px solid #ef444444;}
    .cfp-badge.drawn{background:#1e1b4b;color:#a855f7;border:1px solid #a855f744;}
    .cfp-btn{display:inline-flex;align-items:center;gap:5px;padding:8px 16px;border-radius:8px;font-size:.82rem;font-weight:600;cursor:pointer;text-decoration:none;border:none;transition:all .15s;}
    .cfp-btn-gold{background:var(--g);color:#000;}.cfp-btn-gold:hover{background:#e8820a;color:#000;}
    .cfp-btn-green{background:var(--gr);color:#000;}.cfp-btn-red{background:var(--rd);color:#fff;}
    .cfp-btn-ghost{background:transparent;color:var(--tx);border:1px solid var(--br);}.cfp-btn-ghost:hover{background:#222;color:#fff;}
    .cfp-btn-sm{padding:5px 11px;font-size:.75rem;}
    .cfp-form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:18px;}
    .cfp-field{display:flex;flex-direction:column;gap:5px;}
    .cfp-field label{font-size:.75rem;text-transform:uppercase;letter-spacing:1px;color:var(--mt);}
    .cfp-field input,.cfp-field select,.cfp-field textarea{background:#111;border:1px solid var(--br);color:var(--tx);padding:10px 13px;border-radius:8px;font-size:.88rem;outline:none;}
    .cfp-field input:focus,.cfp-field select:focus{border-color:var(--g);}
    .cfp-field .hint{font-size:.72rem;color:var(--mt);}
    .cfp-notice{padding:13px 17px;border-radius:8px;margin-bottom:18px;font-size:.86rem;}
    .cfp-notice.success{background:#052e16;border:1px solid #22c55e44;color:#22c55e;}
    .cfp-notice.error{background:#2d0a0a;border:1px solid #ef444444;color:#ef4444;}
    .cfp-tabs{display:flex;gap:3px;margin-bottom:22px;border-bottom:1px solid var(--br);}
    .cfp-tab{padding:9px 17px;cursor:pointer;font-size:.83rem;font-weight:600;color:var(--mt);border-bottom:2px solid transparent;margin-bottom:-1px;transition:all .15s;text-decoration:none;}
    .cfp-tab.active,.cfp-tab:hover{color:#fff;border-bottom-color:var(--g);}
    .cfp-pagination{display:flex;gap:5px;justify-content:flex-end;margin-top:14px;}
    .cfp-pagination a,.cfp-pagination span{padding:6px 12px;border-radius:6px;font-size:.78rem;background:#111;border:1px solid var(--br);color:var(--tx);text-decoration:none;}
    .cfp-pagination .current{background:var(--g);color:#000;border-color:var(--g);}
    .cfp-2col{display:grid;grid-template-columns:1fr 1fr;gap:22px;}
    .cfp-3col{display:grid;grid-template-columns:1fr 1fr 1fr;gap:22px;}
    @media(max-width:900px){.cfp-2col,.cfp-3col{grid-template-columns:1fr;}}
    .cfp-adj-type{display:flex;gap:0;margin-bottom:16px;border-radius:8px;overflow:hidden;border:1px solid var(--br);}
    .cfp-adj-type label{flex:1;display:flex;align-items:center;justify-content:center;gap:7px;padding:11px;cursor:pointer;font-size:.85rem;font-weight:600;transition:background .15s;}
    .cfp-adj-type input[type=radio]{display:none;}
    .cfp-adj-credit-lbl{background:#052e16;color:#22c55e;}
    .cfp-adj-debit-lbl{background:#2d0a0a;color:#ef4444;}
    .cfp-adj-inactive{background:#111;color:#555;}
    .cfp-user-found{background:#111;border:1px solid var(--br);border-radius:8px;padding:14px;margin-bottom:16px;}
    .cfp-currency-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:14px;margin-bottom:24px;}
    .cfp-coin-card{background:#111;border:1px solid var(--br);border-radius:12px;padding:16px;position:relative;transition:border-color .15s;cursor:pointer;}
    .cfp-coin-card:hover{border-color:#444;}
    .cfp-coin-card.active-coin{border-color:var(--g);}
    .cfp-coin-card .coin-icon{width:42px;height:42px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.3rem;margin-bottom:9px;}
    .cfp-active-badge{position:absolute;top:10px;right:10px;background:var(--g);color:#000;font-size:.62rem;font-weight:800;padding:2px 7px;border-radius:20px;text-transform:uppercase;}
    </style>';
}

