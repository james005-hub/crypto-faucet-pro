<?php
/**
 * Admin page: Email Alerts & Notifications
 * Part of Crypto Faucet Pro plugin.
 */
if ( ! defined( 'ABSPATH' ) ) exit;

function cfp_admin_email_alerts() {
    global $wpdb;
    $notice = '';

    if ( isset($_POST['cfp_save_email_alerts']) && check_admin_referer('cfp_email_alerts') ) {
        $fields = [
            'email_alerts_enabled',
            'email_large_withdrawal_threshold',
            'email_suspicious_activity_alert',
            'email_new_user_alert',
            'email_daily_report',
            'email_daily_report_time',
            'email_weekly_report',
            'email_kyc_review_alert',
            'email_withdrawal_request_alert',
            'email_game_win_alert_threshold',
            'email_lottery_draw_alert',
            'email_low_balance_alert_threshold',
            'email_alert_address',
        ];
        foreach ( $fields as $f ) {
            if ( isset($_POST[$f]) ) {
                $val = sanitize_text_field($_POST[$f]);
                if ( $f === 'email_alert_address' ) {
                    $val = sanitize_email($val);
                }
                cfp_update_setting($f, $val);
            }
        }
        $notice = "<div class='cfp-notice success'>✅ Email alert settings saved!</div>";
    }

    $gs = function($k,$d='') { return cfp_get_setting($k,$d); };
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🔔</span>
            <h1>🔔 Email Alerts & Notifications</h1>
        </div>
        <?=$notice?>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4,1fr);margin-bottom:24px">
            <div class="cfp-stat-card <?=$gs('email_alerts_enabled','1') === '1' ? 'green' : 'red'?>">
                <div class="label">Email Alerts</div>
                <div class="value"><?=$gs('email_alerts_enabled','1') === '1' ? 'ON' : 'OFF'?></div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">Large WD Threshold</div>
                <div class="value"><?=number_format($gs('email_large_withdrawal_threshold',100000))?></div>
                <div class="sub">sat</div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">Daily Reports</div>
                <div class="value"><?=$gs('email_daily_report','0') === '1' ? 'ON' : 'OFF'?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">Alert Email</div>
                <div class="value" style="font-size:.9rem"><?=esc_html($gs('email_alert_address',get_option('admin_email')))?></div>
            </div>
        </div>

        <form method="post">
            <?php wp_nonce_field('cfp_email_alerts'); ?>
            
            <div class="cfp-card" style="margin-bottom:22px">
                <h2>📧 Master Settings</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Email Alerts Enabled</label>
                        <select name="email_alerts_enabled">
                            <option value="1" <?=selected($gs('email_alerts_enabled','1'),'1',false)?>>✅ Enabled</option>
                            <option value="0" <?=selected($gs('email_alerts_enabled','1'),'0',false)?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Alert Destination Email</label>
                        <input type="email" name="email_alert_address" value="<?=esc_attr($gs('email_alert_address',get_option('admin_email')))?>" placeholder="admin@example.com">
                        <span class="hint">Where to send admin alerts</span>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>💰 Withdrawal & Financial Alerts</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Large Withdrawal Alert Threshold (sat)</label>
                        <input type="number" name="email_large_withdrawal_threshold" value="<?=esc_attr($gs('email_large_withdrawal_threshold',100000))?>" min="0">
                        <span class="hint">Alert when withdrawal exceeds this amount</span>
                    </div>
                    <div class="cfp-field">
                        <label>Withdrawal Request Alert</label>
                        <select name="email_withdrawal_request_alert">
                            <option value="1" <?=selected($gs('email_withdrawal_request_alert','0'),'1',false)?>>✅ Yes - email on every request</option>
                            <option value="0" <?=selected($gs('email_withdrawal_request_alert','0'),'0',false)?>>⏸ No - large only</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Low Balance Alert (Faucet Wallet)</label>
                        <input type="number" name="email_low_balance_alert_threshold" value="<?=esc_attr($gs('email_low_balance_alert_threshold',50000))?>" min="0">
                        <span class="hint">Alert when faucet balance drops below</span>
                    </div>
                    <div class="cfp-field">
                        <label>Game Win Alert Threshold (sat)</label>
                        <input type="number" name="email_game_win_alert_threshold" value="<?=esc_attr($gs('email_game_win_alert_threshold',100000))?>" min="0">
                        <span class="hint">Alert on big wins above this amount</span>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>👥 User Activity Alerts</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>New User Registration Alert</label>
                        <select name="email_new_user_alert">
                            <option value="1" <?=selected($gs('email_new_user_alert','0'),'1',false)?>>✅ Yes - email on each registration</option>
                            <option value="0" <?=selected($gs('email_new_user_alert','0'),'0',false)?>>⏸ No</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Suspicious Activity Alert</label>
                        <select name="email_suspicious_activity_alert">
                            <option value="1" <?=selected($gs('email_suspicious_activity_alert','1'),'1',false)?>>✅ Yes - alert on detected suspicious activity</option>
                            <option value="0" <?=selected($gs('email_suspicious_activity_alert','1'),'0',false)?>>⏸ No</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>KYC Review Alert</label>
                        <select name="email_kyc_review_alert">
                            <option value="1" <?=selected($gs('email_kyc_review_alert','1'),'1',false)?>>✅ Yes - new KYC submissions</option>
                            <option value="0" <?=selected($gs('email_kyc_review_alert','1'),'0',false)?>>⏸ No</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="cfp-card" style="margin-bottom:22px">
                <h2>📊 Scheduled Reports</h2>
                <div class="cfp-form-grid">
                    <div class="cfp-field">
                        <label>Daily Summary Report</label>
                        <select name="email_daily_report">
                            <option value="1" <?=selected($gs('email_daily_report','0'),'1',false)?>>✅ Enabled</option>
                            <option value="0" <?=selected($gs('email_daily_report','0'),'0',false)?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Daily Report Time (UTC)</label>
                        <input type="time" name="email_daily_report_time" value="<?=esc_attr($gs('email_daily_report_time','08:00'))?>">
                        <span class="hint">When to send daily summary</span>
                    </div>
                    <div class="cfp-field">
                        <label>Weekly Summary Report</label>
                        <select name="email_weekly_report">
                            <option value="1" <?=selected($gs('email_weekly_report','0'),'1',false)?>>✅ Enabled</option>
                            <option value="0" <?=selected($gs('email_weekly_report','0'),'0',false)?>>⏸ Disabled</option>
                        </select>
                    </div>
                    <div class="cfp-field">
                        <label>Lottery Draw Alert</label>
                        <select name="email_lottery_draw_alert">
                            <option value="1" <?=selected($gs('email_lottery_draw_alert','1'),'1',false)?>>✅ Yes - notify on draw</option>
                            <option value="0" <?=selected($gs('email_lottery_draw_alert','1'),'0',false)?>>⏸ No</option>
                        </select>
                    </div>
                </div>
            </div>

            <button type="submit" name="cfp_save_email_alerts" class="cfp-btn cfp-btn-gold">💾 Save Email Alert Settings</button>
        </form>
    </div>
    <?php
}