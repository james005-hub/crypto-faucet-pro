<?php
/**
 * Admin page: Bet Limits Manager - Configure betting limits per user level
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Bet Limits Management
   ============================================================ */
add_action('wp_ajax_cfp_bet_limits_data', 'cfp_ajax_bet_limits_data');
function cfp_ajax_bet_limits_data() {
    check_ajax_referer('cfp_bet_limits_nonce', 'nonce');
    
    global $wpdb;
    $action = sanitize_text_field($_POST['sub_action'] ?? 'list');
    
    if($action === 'list') {
        $limits = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cfp_bet_limits ORDER BY level ASC");
        wp_send_json_success(['limits' => $limits]);
    }
    
    if($action === 'save') {
        $id = intval($_POST['id'] ?? 0);
        $data = [
            'level' => intval($_POST['level']),
            'level_name' => sanitize_text_field($_POST['level_name']),
            'min_bet' => intval($_POST['min_bet']),
            'max_bet' => intval($_POST['max_bet']),
            'max_daily_loss' => intval($_POST['max_daily_loss']),
            'max_daily_bets' => intval($_POST['max_daily_bets']),
            'max_winning' => intval($_POST['max_winning']),
            'require_kyc' => isset($_POST['require_kyc']) ? 1 : 0,
            'is_active' => isset($_POST['is_active']) ? 1 : 0
        ];
        
        if($id > 0) {
            $wpdb->update($wpdb->prefix . 'cfp_bet_limits', $data, ['id' => $id]);
        } else {
            $wpdb->insert($wpdb->prefix . 'cfp_bet_limits', $data);
        }
        wp_send_json_success(['msg' => 'Saved']);
    }
    
    if($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $wpdb->delete($wpdb->prefix . 'cfp_bet_limits', ['id' => $id]);
        wp_send_json_success(['msg' => 'Deleted']);
    }
    
    if($action === 'apply_default') {
        $defaults = [
            ['level' => 1, 'level_name' => 'New User', 'min_bet' => 1, 'max_bet' => 1000, 'max_daily_loss' => 10000, 'max_daily_bets' => 50, 'max_winning' => 5000, 'require_kyc' => 0, 'is_active' => 1],
            ['level' => 2, 'level_name' => 'Regular', 'min_bet' => 10, 'max_bet' => 5000, 'max_daily_loss' => 50000, 'max_daily_bets' => 100, 'max_winning' => 25000, 'require_kyc' => 0, 'is_active' => 1],
            ['level' => 3, 'level_name' => 'VIP', 'min_bet' => 100, 'max_bet' => 25000, 'max_daily_loss' => 250000, 'max_daily_bets' => 200, 'max_winning' => 100000, 'require_kyc' => 1, 'is_active' => 1],
            ['level' => 4, 'level_name' => 'Premium', 'min_bet' => 500, 'max_bet' => 100000, 'max_daily_loss' => 1000000, 'max_daily_bets' => 500, 'max_winning' => 500000, 'require_kyc' => 1, 'is_active' => 1],
            ['level' => 5, 'level_name' => 'Whale', 'min_bet' => 1000, 'max_bet' => 500000, 'max_daily_loss' => 5000000, 'max_daily_bets' => 1000, 'max_winning' => 2000000, 'require_kyc' => 1, 'is_active' => 1]
        ];
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}cfp_bet_limits");
        foreach($defaults as $d) { $wpdb->insert($wpdb->prefix . 'cfp_bet_limits', $d); }
        wp_send_json_success(['msg' => 'Defaults applied']);
    }
}

/* ============================================================
   ADMIN: BET LIMITS PAGE
   ============================================================ */
function cfp_admin_bet_limits_manager() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_bet_limits_nonce');
    $limits = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cfp_bet_limits ORDER BY level ASC");
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🎯</span>
            <h1>🎯 Bet Limits Manager</h1>
            <button onclick="cfpShowLimitModal()" class="cfp-btn cfp-btn-gold" style="margin-left:auto">➕ Add Level</button>
        </div>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card"><div class="label">📊 Total Levels</div><div class="value"><?=count($limits)?></div></div>
            <div class="cfp-stat-card green"><div class="label">✅ Active</div><div class="value"><?=count(array_filter($limits, function($l){return $l->is_active;}))?></div></div>
            <div class="cfp-stat-card blue"><div class="label">💰 Max Bet</div><div class="value"><?=number_format(max(array_column($limits,'max_bet')?:[0]))?></div></div>
            <div class="cfp-stat-card"><div class="label">🛡️ KYC Required</div><div class="value"><?=count(array_filter($limits,function($l){return $l->require_kyc;}))?></div></div>
        </div>

        <div class="cfp-card">
            <div style="display:flex;justify-content:space-between;margin-bottom:16px">
                <h2>📋 User Level Bet Limits</h2>
                <button onclick="cfpApplyDefaults()" class="cfp-btn cfp-btn-ghost">⚙️ Apply Defaults</button>
            </div>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <thead><tr><th>Level</th><th>Name</th><th>Min Bet</th><th>Max Bet</th><th>Max Daily Loss</th><th>Max Bets</th><th>Max Win</th><th>KYC</th><th>Status</th><th>Actions</th></tr></thead>
                    <tbody>
                    <?php foreach($limits as $l): ?>
                    <tr>
                        <td><span class="cfp-badge <?=$l->level<=2?'active':($l->level<=3?'pending':'drawn')?>">Lv.<?=$l->level?></span></td>
                        <td><strong><?=esc_html($l->level_name)?></strong></td>
                        <td><?=number_format($l->min_bet)?></td>
                        <td style="color:#f7931a;font-weight:700"><?=number_format($l->max_bet)?></td>
                        <td><?=number_format($l->max_daily_loss)?></td>
                        <td><?=$l->max_daily_bets?></td>
                        <td style="color:#22c55e"><?=number_format($l->max_winning)?></td>
                        <td><span class="cfp-badge <?=$l->require_kyc?'rejected':'active'?>"><?=$l->require_kyc?'Yes':'No'?></span></td>
                        <td><span class="cfp-badge <?=$l->is_active?'active':'rejected'?>"><?=$l->is_active?'Active':'Disabled'?></span></td>
                        <td><button onclick="cfpDeleteLimit(<?=$l->id?>)" class="cfp-btn cfp-btn-sm cfp-btn-red">Delete</button></td>
                    </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div id="cfp-limit-modal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.8);z-index:9999;align-items:center;justify-content:center">
        <div style="background:#161616;border:1px solid #2a2a2a;border-radius:16px;padding:28px;max-width:500px;width:90%">
            <h2 style="color:#fff;margin-bottom:20px">Add Level</h2>
            <form id="cfp-limit-form">
                <div class="cfp-field"><label>Level</label><input type="number" id="cfp-lvl" value="1"></div>
                <div class="cfp-field"><label>Name</label><input type="text" id="cfp-name" required></div>
                <div class="cfp-field"><label>Min Bet</label><input type="number" id="cfp-min" value="1"></div>
                <div class="cfp-field"><label>Max Bet</label><input type="number" id="cfp-max" value="1000"></div>
                <div class="cfp-field"><label>Max Daily Loss</label><input type="number" id="cfp-loss" value="10000"></div>
                <div class="cfp-field"><label>Max Daily Bets</label><input type="number" id="cfp-bets" value="50"></div>
                <div class="cfp-field"><label>Max Winning</label><input type="number" id="cfp-win" value="5000"></div>
                <div class="cfp-field"><label><input type="checkbox" id="cfp-kyc"> Require KYC</label></div>
                <div class="cfp-field"><label><input type="checkbox" id="cfp-act" checked> Active</label></div>
                <div style="display:flex;gap:12px;margin-top:20px">
                    <button type="submit" class="cfp-btn cfp-btn-gold">Save</button>
                    <button type="button" onclick="document.getElementById('cfp-limit-modal').style.display='none'" class="cfp-btn cfp-btn-ghost">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function cfpShowLimitModal(){document.getElementById('cfp-limit-modal').style.display='flex';}
    document.getElementById('cfp-limit-form').addEventListener('submit',function(e){
        e.preventDefault();
        var fd=new FormData();
        fd.append('action','cfp_bet_limits_data');fd.append('nonce','<?=$nonce?>');fd.append('sub_action','save');
        fd.append('level',document.getElementById('cfp-lvl').value);
        fd.append('level_name',document.getElementById('cfp-name').value);
        fd.append('min_bet',document.getElementById('cfp-min').value);
        fd.append('max_bet',document.getElementById('cfp-max').value);
        fd.append('max_daily_loss',document.getElementById('cfp-loss').value);
        fd.append('max_daily_bets',document.getElementById('cfp-bets').value);
        fd.append('max_winning',document.getElementById('cfp-win').value);
        fd.append('require_kyc',document.getElementById('cfp-kyc').checked?'1':'0');
        fd.append('is_active',document.getElementById('cfp-act').checked?'1':'0');
        fetch(ajaxurl,{method:'POST',body:fd}).then(()=>location.reload());
    });
    function cfpDeleteLimit(id){if(confirm('Delete?')){var fd=new FormData();fd.append('action','cfp_bet_limits_data');fd.append('nonce','<?=$nonce?>');fd.append('sub_action','delete');fd.append('id',id);fetch(ajaxurl,{method:'POST',body:fd}).then(()=>location.reload());}}
    function cfpApplyDefaults(){if(confirm('Apply defaults?')){var fd=new FormData();fd.append('action','cfp_bet_limits_data');fd.append('nonce','<?=$nonce?>');fd.append('sub_action','apply_default');fetch(ajaxurl,{method:'POST',body:fd}).then(()=>location.reload());}}
    </script>
    <?php
}