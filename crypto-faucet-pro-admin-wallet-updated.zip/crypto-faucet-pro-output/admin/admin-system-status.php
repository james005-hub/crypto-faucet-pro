<?php
/**
 * Admin page: System Status - Real-time server stats, memory, database queries
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Get live system stats
   ============================================================ */
add_action('wp_ajax_cfp_system_status_data', 'cfp_ajax_system_status_data');
function cfp_ajax_system_status_data() {
    check_ajax_referer('cfp_system_nonce', 'nonce');
    
    global $wpdb;
    
    $start = microtime(true);
    $wpdb->get_results("SELECT 1");
    $db_time = round((microtime(true) - $start) * 1000, 2);
    
    $db_size = $wpdb->get_var("
        SELECT SUM(data_length + index_length) 
        FROM information_schema.tables 
        WHERE table_schema = DATABASE()
    ") ?? 0;
    
    $table_count = (int)$wpdb->get_var("
        SELECT COUNT(*) FROM information_schema.tables 
        WHERE table_schema = DATABASE()
    ");
    
    $transient_count = (int)$wpdb->get_var("
        SELECT COUNT(*) FROM {$wpdb->options} 
        WHERE option_name LIKE '_transient_%'
    ");
    
    $cron_count = (int)$wpdb->get_var("
        SELECT COUNT(*) FROM {$wpdb->options} 
        WHERE option_name LIKE 'cron'
    ");
    
    $recent_crons = $wpdb->get_results("
        SELECT option_name, option_value FROM {$wpdb->options}
        WHERE option_name LIKE 'cron'
        LIMIT 5
    ");
    
    $uploads_dir = wp_upload_dir();
    $upload_size = 0;
    if(is_dir($uploads_dir['basedir'])) {
        $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($uploads_dir['basedir']));
        foreach($it as $file) {
            if($file->isFile()) $upload_size += $file->getSize();
        }
    }
    
    $wp_version = get_bloginfo('version');
    $php_version = PHP_VERSION;
    $memory_limit = ini_get('memory_limit');
    $memory_usage = memory_get_usage(true);
    $memory_peak = memory_get_peak_usage(true);
    
    $server_software = $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown';
    $server_time = current_time('mysql');
    $server_tz = wp_timezone_string();
    
    wp_send_json_success([
        'db' => [
            'time_ms' => $db_time,
            'size_bytes' => $db_size,
            'size_formatted' => size_format($db_size),
            'tables' => $table_count,
            'transients' => $transient_count
        ],
        'php' => [
            'version' => $php_version,
            'memory_limit' => $memory_limit,
            'memory_usage' => $memory_usage,
            'memory_peak' => $memory_peak,
            'memory_usage_fmt' => size_format($memory_usage),
            'memory_peak_fmt' => size_format($memory_peak),
            'max_execution_time' => ini_get('max_execution_time'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'post_max_size' => ini_get('post_max_size')
        ],
        'wp' => [
            'version' => $wp_version,
            'locale' => get_bloginfo('language'),
            'site_url' => get_site_url(),
            'home_url' => get_home_url()
        ],
        'server' => [
            'software' => $server_software,
            'time' => $server_time,
            'timezone' => $server_tz,
            'uploads_size' => $upload_size,
            'uploads_size_fmt' => size_format($upload_size)
        ],
        'cron' => [
            'count' => $cron_count,
            'recent' => $recent_crons
        ]
    ]);
}

/* ============================================================
   ADMIN: SYSTEM STATUS DASHBOARD
   ============================================================ */
function cfp_admin_system_status() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_system_nonce');
    
    $db_version = $wpdb->get_var("SELECT VERSION()");
    $wp_version = get_bloginfo('version');
    $php_version = PHP_VERSION;
    $server = $_SERVER['SERVER_SOFTWARE'] ?? 'N/A';
    $user_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_USERS);
    $claim_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_CLAIMS);
    $tx_count = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_TRANSACTIONS);
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🖥️</span>
            <h1>🖥️ System Status</h1>
            <button onclick="cfpRefreshSystemStatus()" class="cfp-btn cfp-btn-ghost" style="margin-left:auto">🔄 Refresh</button>
        </div>

        <!-- HEALTH OVERVIEW -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4, 1fr)">
            <div class="cfp-stat-card green">
                <div class="label">⚡ PHP Status</div>
                <div class="value"><?=PHP_VERSION?></div>
                <div class="sub">Running normally</div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">🗄️ Database</div>
                <div class="value">Connected</div>
                <div class="sub"><?=$db_version?></div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">🧩 WordPress</div>
                <div class="value"><?=$wp_version?></div>
                <div class="sub">Core active</div>
            </div>
            <div class="cfp-stat-card">
                <div class="label">📊 WP Cron</div>
                <div class="value">Active</div>
                <div class="sub">Scheduler working</div>
            </div>
        </div>

        <!-- PHP & MEMORY -->
        <div class="cfp-2col" style="margin-bottom:24px">
            <div class="cfp-card">
                <h2>🐘 PHP Configuration</h2>
                <div class="cfp-table-wrap">
                    <table class="cfp-table">
                        <tr><td><strong>PHP Version</strong></td><td><span class="cfp-badge active"><?=PHP_VERSION?></span></td></tr>
                        <tr><td><strong>Memory Limit</strong></td><td><?=ini_get('memory_limit')?></td></tr>
                        <tr><td><strong>Max Execution Time</strong></td><td><?=ini_get('max_execution_time')?> seconds</td></tr>
                        <tr><td><strong>Upload Max Filesize</strong></td><td><?=ini_get('upload_max_filesize')?></td></tr>
                        <tr><td><strong>Post Max Size</strong></td><td><?=ini_get('post_max_size')?></td></tr>
                        <tr><td><strong>cURL</strong></td><td><?=function_exists('curl_version') ? '<span class="cfp-badge active">Enabled</span>' : '<span class="cfp-badge rejected">Disabled</span>'?></td></tr>
                        <tr><td><strong>JSON</strong></td><td><?=function_exists('json_encode') ? '<span class="cfp-badge active">Enabled</span>' : '<span class="cfp-badge rejected">Disabled</span>'?></td></tr>
                        <tr><td><strong>OpenSSL</strong></td><td><?=defined('OPENSSL_VERSION_TEXT') ? '<span class="cfp-badge active">Enabled</span>' : '<span class="cfp-badge rejected">Disabled</span>'?></td></tr>
                    </table>
                </div>
            </div>
            <div class="cfp-card">
                <h2>💾 Memory Usage</h2>
                <div style="margin-bottom:20px">
                    <div style="display:flex;justify-content:space-between;margin-bottom:8px">
                        <span style="color:#888">Current Usage</span>
                        <span style="font-weight:700" id="mem-usage"><?=size_format(memory_get_usage(true))?></span>
                    </div>
                    <div style="background:#1a1a1a;border-radius:8px;height:24px;overflow:hidden">
                        <div id="mem-bar" style="width:0%;background:linear-gradient(90deg,#22c55e,#4ade80);height:100%;transition:width .5s"></div>
                    </div>
                </div>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                    <div style="background:#0d0d0d;padding:14px;border-radius:10px;text-align:center">
                        <div style="font-size:.68rem;text-transform:uppercase;color:#555;margin-bottom:6px">Current</div>
                        <div style="font-size:1.3rem;font-weight:700;color:#fff" id="mem-current"><?=size_format(memory_get_usage(true))?></div>
                    </div>
                    <div style="background:#0d0d0d;padding:14px;border-radius:10px;text-align:center">
                        <div style="font-size:.68rem;text-transform:uppercase;color:#555;margin-bottom:6px">Peak</div>
                        <div style="font-size:1.3rem;font-weight:700;color:#f7931a" id="mem-peak"><?=size_format(memory_get_peak_usage(true))?></div>
                    </div>
                </div>
                <div style="margin-top:14px;padding:12px;background:#1a1208;border-radius:8px;border:1px solid #f7931a33">
                    <div style="display:flex;align-items:center;gap:8px">
                        <span style="font-size:1.2rem">💡</span>
                        <span style="color:#888;font-size:.8rem">Memory limit is <?=ini_get('memory_limit')?>. Current usage is safe.</span>
                    </div>
                </div>
            </div>
        </div>

        <!-- DATABASE -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>🗄️ Database Overview</h2>
            <div style="display:grid;grid-template-columns:repeat(5, 1fr);gap:16px;margin-bottom:20px">
                <div style="background:#0d0d0d;padding:16px;border-radius:12px;text-align:center">
                    <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:8px">Tables</div>
                    <div style="font-size:1.6rem;font-weight:800;color:#fff" id="db-tables">-</div>
                </div>
                <div style="background:#0d0d0d;padding:16px;border-radius:12px;text-align:center">
                    <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:8px">Size</div>
                    <div style="font-size:1.6rem;font-weight:800;color:#fff" id="db-size">-</div>
                </div>
                <div style="background:#0d0d0d;padding:16px;border-radius:12px;text-align:center">
                    <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:8px">Query Time</div>
                    <div style="font-size:1.6rem;font-weight:800;color:#22c55e" id="db-time">-</div>
                </div>
                <div style="background:#0d0d0d;padding:16px;border-radius:12px;text-align:center">
                    <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:8px">Transients</div>
                    <div style="font-size:1.6rem;font-weight:800;color:#a855f7" id="db-transients">-</div>
                </div>
                <div style="background:#0d0d0d;padding:16px;border-radius:12px;text-align:center">
                    <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:8px">Uploads</div>
                    <div style="font-size:1.6rem;font-weight:800;color:#3b82f6" id="db-uploads">-</div>
                </div>
            </div>
            <h3 style="font-size:.9rem;color:#888;margin-bottom:12px">Database Connection Test</h3>
            <div id="db-test-result" style="padding:14px;background:#1a1a1a;border-radius:8px;font-family:monospace;font-size:.85rem">
                Loading...
            </div>
        </div>

        <!-- PLUGIN STATS -->
        <div class="cfp-card" style="margin-bottom:24px">
            <h2>📈 Crypto Faucet Pro - Data Statistics</h2>
            <div style="display:grid;grid-template-columns:repeat(4, 1fr);gap:16px">
                <div style="background:#0d0d0d;padding:18px;border-radius:12px;border-left:3px solid #f7931a">
                    <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:8px">Total Users</div>
                    <div style="font-size:1.8rem;font-weight:800;color:#fff"><?=number_format($user_count)?></div>
                </div>
                <div style="background:#0d0d0d;padding:18px;border-radius:12px;border-left:3px solid #22c55e">
                    <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:8px">Total Claims</div>
                    <div style="font-size:1.8rem;font-weight:800;color:#fff"><?=number_format($claim_count)?></div>
                </div>
                <div style="background:#0d0d0d;padding:18px;border-radius:12px;border-left:3px solid #a855f7">
                    <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:8px">Transactions</div>
                    <div style="font-size:1.8rem;font-weight:800;color:#fff"><?=number_format($tx_count)?></div>
                </div>
                <div style="background:#0d0d0d;padding:18px;border-radius:12px;border-left:3px solid #3b82f6">
                    <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:8px">Plugin Version</div>
                    <div style="font-size:1.4rem;font-weight:800;color:#fff"><?=CFP_VERSION?></div>
                </div>
            </div>
        </div>

        <!-- SERVER INFO -->
        <div class="cfp-card">
            <h2>🌐 Server Information</h2>
            <div class="cfp-table-wrap">
                <table class="cfp-table">
                    <tr><td style="width:200px"><strong>Server Software</strong></td><td><?=esc_html($server)?></td></tr>
                    <tr><td><strong>PHP Version</strong></td><td><?=PHP_VERSION?></td></tr>
                    <tr><td><strong>Database Version</strong></td><td><?=esc_html($db_version)?></td></tr>
                    <tr><td><strong>WordPress Version</strong></td><td><?=$wp_version?></td></tr>
                    <tr><td><strong>Server Time</strong></td><td id="server-time"><?=current_time('mysql')?></td></tr>
                    <tr><td><strong>Timezone</strong></td><td><?=wp_timezone_string()?></td></tr>
                    <tr><td><strong>Site URL</strong></td><td><a href="<?=get_site_url()?>" target="_blank" style="color:#3b82f6"><?=get_site_url()?></a></td></tr>
                    <tr><td><strong>Home URL</strong></td><td><a href="<?=get_home_url()?>" target="_blank" style="color:#3b82f6"><?=get_home_url()?></a></td></tr>
                </table>
            </div>
        </div>
    </div>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        cfpLoadSystemData();
        setInterval(cfpLoadSystemData, 30000);
    });
    
    function cfpRefreshSystemStatus() {
        cfpLoadSystemData();
    }
    
    function cfpLoadSystemData() {
        const fd = new FormData();
        fd.append('action', 'cfp_system_status_data');
        fd.append('nonce', '<?=$nonce?>');
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(data => {
                if(data.success) {
                    cfpUpdateSystemUI(data.data);
                }
            });
    }
    
    function cfpUpdateSystemUI(d) {
        // Database
        document.getElementById('db-tables').textContent = d.db.tables;
        document.getElementById('db-size').textContent = d.db.size_formatted;
        document.getElementById('db-time').textContent = d.db.time_ms + 'ms';
        document.getElementById('db-transients').textContent = d.db.transients;
        document.getElementById('db-uploads').textContent = d.server.uploads_size_fmt;
        
        // Memory
        const memLimit = parsePHPMemory(d.php.memory_limit);
        const memPct = Math.min(100, (d.php.memory_usage / memLimit) * 100);
        document.getElementById('mem-bar').style.width = memPct + '%';
        document.getElementById('mem-current').textContent = d.php.memory_usage_fmt;
        document.getElementById('mem-peak').textContent = d.php.memory_peak_fmt;
        document.getElementById('mem-usage').textContent = d.php.memory_usage_fmt;
        
        // Server time
        document.getElementById('server-time').textContent = d.server.time;
        
        // DB test
        const testDiv = document.getElementById('db-test-result');
        testDiv.innerHTML = '<span style="color:#22c55e">✓ Database connection successful</span> | Tables: ' + d.db.tables + ' | Query time: ' + d.db.time_ms + 'ms';
        testDiv.style.borderLeft = '3px solid #22c55e';
    }
    
    function parsePHPMemory(mem) {
        if(!mem) return 128 * 1024 * 1024;
        mem = mem.toUpperCase();
        const val = parseFloat(mem);
        if(mem.includes('G')) return val * 1024 * 1024 * 1024;
        if(mem.includes('M')) return val * 1024 * 1024;
        if(mem.includes('K')) return val * 1024;
        return val;
    }
    </script>
    <?php
}