<?php
/**
 * Admin page: Betting Analytics - Detailed betting history and game analytics
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Betting Analytics Data
   ============================================================ */
add_action('wp_ajax_cfp_betting_analytics_data', 'cfp_ajax_betting_analytics_data');
function cfp_ajax_betting_analytics_data() {
    check_ajax_referer('cfp_betting_nonce', 'nonce');
    
    global $wpdb;
    $period = sanitize_text_field($_POST['period'] ?? '7days');
    $game_filter = sanitize_text_field($_POST['game'] ?? 'all');
    $page = max(1, intval($_POST['page'] ?? 1));
    $limit = 50;
    $offset = ($page - 1) * $limit;
    
    switch($period) {
        case '24hours': $date_cond = "played_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)"; break;
        case '30days': $date_cond = "played_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)"; break;
        case '90days': $date_cond = "played_at >= DATE_SUB(NOW(), INTERVAL 90 DAY)"; break;
        default: $date_cond = "played_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
    }
    
    $tables = [
        'hilo' => ['Hi-Lo Multiply', '🎲', CFP_TABLE_MULTIPLY],
        'slots' => ['Slots', '🎰', CFP_TABLE_SLOTS],
        'coinflip' => ['Coin Flip', '🪙', CFP_TABLE_COINFLIP],
        'dice' => ['Dice Roll', '🎲', CFP_TABLE_DICE],
        'crash' => ['Crash', '📈', CFP_TABLE_CRASH],
        'wheel' => ['Wheel', '🎡', CFP_TABLE_WHEEL],
    ];
    
    $total_stats = [];
    $total_wagered = 0;
    $total_paid = 0;
    $total_plays = 0;
    
    foreach($tables as $key => [$label, $icon, $tbl]) {
        if($game_filter !== 'all' && $key !== $game_filter) continue;
        
        $stats = $wpdb->get_row($wpdb->prepare(
            "SELECT 
                COUNT(*) as plays,
                COALESCE(SUM(bet_sat), 0) as wagered,
                COALESCE(SUM(payout_sat), 0) as paid,
                COALESCE(AVG(bet_sat), 0) as avg_bet,
                COALESCE(AVG(payout_sat), 0) as avg_payout
             FROM {$tbl}
             WHERE {$date_cond}"
        ));
        
        if($stats) {
            $total_stats[$key] = [
                'label' => $label,
                'icon' => $icon,
                'plays' => (int)$stats->plays,
                'wagered' => (int)$stats->wagered,
                'paid' => (int)$stats->paid,
                'ggr' => (int)$stats->wagered - (int)$stats->paid,
                'avg_bet' => (int)$stats->avg_bet,
                'avg_payout' => (int)$stats->avg_payout,
                'rtp' => $stats->wagered > 0 ? round(($stats->paid / $stats->wagered) * 100, 2) : 0
            ];
            $total_wagered += (int)$stats->wagered;
            $total_paid += (int)$stats->paid;
            $total_plays += (int)$stats->plays;
        }
    }
    
    $recent_bets = [];
    foreach($tables as $key => [$label, $icon, $tbl]) {
        $bets = $wpdb->get_results($wpdb->prepare(
            "SELECT id, user_id, bet_sat, payout_sat, played_at FROM {$tbl} WHERE {$date_cond} ORDER BY played_at DESC LIMIT 20"
        ));
        foreach($bets as $b) {
            $recent_bets[] = [
                'game' => $key,
                'label' => $label,
                'id' => $b->id,
                'user_id' => $b->user_id,
                'bet' => $b->bet_sat,
                'payout' => $b->payout_sat,
                'profit' => $b->bet_sat - $b->payout_sat,
                'time' => $b->played_at
            ];
        }
    }
    
    usort($recent_bets, function($a, $b) {
        return strtotime($b['time']) - strtotime($a['time']);
    });
    $recent_bets = array_slice($recent_bets, 0, 50);
    
    $top_betters = $wpdb->get_results("
        SELECT user_id, SUM(bet_sat) as total_wagered, COUNT(*) as bets 
        FROM " . CFP_TABLE_MULTIPLY . " WHERE {$date_cond} GROUP BY user_id 
        ORDER BY total_wagered DESC LIMIT 10
    ");
    
    wp_send_json_success([
        'stats' => $total_stats,
        'total_wagered' => $total_wagered,
        'total_paid' => $total_paid,
        'total_plays' => $total_plays,
        'total_ggr' => $total_wagered - $total_paid,
        'recent_bets' => $recent_bets,
        'top_betters' => $top_betters
    ]);
}

/* ============================================================
   ADMIN: BETTING ANALYTICS PAGE
   ============================================================ */
function cfp_admin_betting_analytics() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_betting_nonce');
    
    $tables = [
        'hilo' => ['Hi-Lo Multiply', '🎲', CFP_TABLE_MULTIPLY],
        'slots' => ['Slots', '🎰', CFP_TABLE_SLOTS],
        'coinflip' => ['Coin Flip', '🪙', CFP_TABLE_COINFLIP],
        'dice' => ['Dice Roll', '🎲', CFP_TABLE_DICE],
        'crash' => ['Crash', '📈', CFP_TABLE_CRASH],
        'wheel' => ['Wheel', '🎡', CFP_TABLE_WHEEL],
    ];
    
    $overall = $wpdb->get_row("
        SELECT 
            COUNT(*) as total_plays,
            COALESCE(SUM(bet_sat), 0) as total_wagered,
            COALESCE(SUM(payout_sat), 0) as total_paid
        FROM " . CFP_TABLE_MULTIPLY
    );
    
    $today = $wpdb->get_row("
        SELECT 
            COUNT(*) as plays,
            COALESCE(SUM(bet_sat), 0) as wagered,
            COALESCE(SUM(payout_sat), 0) as paid
        FROM " . CFP_TABLE_MULTIPLY . " WHERE DATE(played_at) = CURDATE()"
    );
    
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🎰</span>
            <h1>🎰 Betting Analytics</h1>
            <button onclick="cfpExportBetting('csv')" class="cfp-btn cfp-btn-ghost" style="margin-left:auto">📥 Export CSV</button>
        </div>

        <!-- PERIOD TABS -->
        <div class="cfp-tabs" style="margin-bottom:20px">
            <button class="cfp-tab active" onclick="cfpChangeBettingPeriod('7days', this)">7 Days</button>
            <button class="cfp-tab" onclick="cfpChangeBettingPeriod('24hours', this)">24 Hours</button>
            <button class="cfp-tab" onclick="cfpChangeBettingPeriod('30days', this)">30 Days</button>
            <button class="cfp-tab" onclick="cfpChangeBettingPeriod('90days', this)">90 Days</button>
        </div>

        <!-- OVERVIEW STATS -->
        <div class="cfp-stats-grid" style="grid-template-columns:repeat(5, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card green">
                <div class="label">🎮 Today's Plays</div>
                <div class="value"><?=number_format($today->plays ?? 0)?></div>
            </div>
            <div class="cfp-stat-card blue">
                <div class="label">💰 Today's Wagered</div>
                <div class="value"><?=number_format($today->wagered ?? 0)?></div>
                <div class="sub">satoshis</div>
            </div>
            <div class="cfp-stat-card purple">
                <div class="label">📊 Total Plays</div>
                <div class="value"><?=number_format($overall->total_plays ?? 0)?></div>
            </div>
            <div class="cfp-stat-card" style="border-top:3px solid #f7931a">
                <div class="label">💵 Total Wagered</div>
                <div class="value" style="color:#f7931a"><?=number_format($overall->total_wagered ?? 0)?></div>
                <div class="sub">satoshis</div>
            </div>
            <div class="cfp-stat-card" style="border-top:3px solid <?=($overall->total_wagered - $overall->total_paid) >= 0 ? '#22c55e' : '#ef4444'?>">
                <div class="label">📈 Total GGR</div>
                <div class="value" style="color:<?=($overall->total_wagered - $overall->total_paid) >= 0 ? '#22c55e' : '#ef4444'?>">
                    <?=number_format(($overall->total_wagered ?? 0) - ($overall->total_paid ?? 0))?>
                </div>
                <div class="sub">satoshis</div>
            </div>
        </div>

        <!-- GAME BREAKDOWN -->
        <div class="cfp-card" style="margin-bottom:30px">
            <h2>🎰 Game Performance Breakdown</h2>
            <div id="cfp-game-stats" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:16px;margin-top:16px">
                <?php foreach($tables as $key => [$label, $icon, $tbl]): 
                    $stats = $wpdb->get_row("
                        SELECT 
                            COUNT(*) as plays,
                            COALESCE(SUM(bet_sat), 0) as wagered,
                            COALESCE(SUM(payout_sat), 0) as paid
                        FROM {$tbl} WHERE played_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                    ");
                    $ggr = ($stats->wagered ?? 0) - ($stats->paid ?? 0);
                    $rtp = ($stats->wagered ?? 0) > 0 ? round(($stats->paid / $stats->wagered) * 100, 1) : 0;
                ?>
                <div style="background:#0d0d0d;border:1px solid #1a1a1a;border-radius:12px;padding:18px">
                    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
                        <span style="font-size:1.4rem"><?=$icon?></span>
                        <span style="font-weight:700;color:#fff"><?=$label?></span>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
                        <div>
                            <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:4px">7-Day Plays</div>
                            <div style="font-size:1.2rem;font-weight:700;color:#fff"><?=number_format($stats->plays ?? 0)?></div>
                        </div>
                        <div>
                            <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:4px">7-Day Wagered</div>
                            <div style="font-size:1rem;font-weight:600;color:#f7931a"><?=number_format($stats->wagered ?? 0)?></div>
                        </div>
                        <div>
                            <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:4px">RTP</div>
                            <div style="font-size:1rem;font-weight:700;color:<?=$rtp > 95 ? '#22c55e' : '#ef4444'?>"><?=$rtp?>%</div>
                        </div>
                        <div>
                            <div style="font-size:.65rem;text-transform:uppercase;color:#555;margin-bottom:4px">7-Day GGR</div>
                            <div style="font-size:1rem;font-weight:700;color:<?=$ggr >= 0 ? '#22c55e' : '#ef4444'?>">
                                <?=number_format($ggr)?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- TOP BETTERS & RECENT BETS -->
        <div class="cfp-2col" style="margin-bottom:30px">
            <div class="cfp-card">
                <h2>🏆 Top Bettors (7 Days)</h2>
                <table class="cfp-table">
                    <thead><tr><th>#</th><th>User ID</th><th>Total Wagered</th><th>Bets</th></tr></thead>
                    <tbody id="cfp-top-betters">
                        <?php 
                        $top_betters = $wpdb->get_results("
                            SELECT user_id, SUM(bet_sat) as total_wagered, COUNT(*) as bets 
                            FROM " . CFP_TABLE_MULTIPLY . " 
                            WHERE played_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                            GROUP BY user_id ORDER BY total_wagered DESC LIMIT 10
                        ");
                        foreach($top_betters as $i => $tb): 
                        ?>
                        <tr>
                            <td><?=($i + 1)?></td>
                            <td><strong><?=$tb->user_id?></strong></td>
                            <td style="color:#f7931a;font-weight:700"><?=number_format($tb->total_wagered)?></td>
                            <td><?=number_format($tb->bets)?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <div class="cfp-card">
                <h2>📜 Recent Bets</h2>
                <div style="max-height:400px;overflow-y:auto">
                    <table class="cfp-table">
                        <thead><tr><th>Game</th><th>Bet</th><th>Payout</th><th>Profit</th><th>Time</th></tr></thead>
                        <tbody id="cfp-recent-bets">
                            <tr><td colspan="5" style="text-align:center;color:#555">Loading...</td></tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- RTP BY GAME -->
        <div class="cfp-card">
            <h2>📊 Return to Player (RTP) Analysis</h2>
            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin-top:16px">
                <?php foreach($tables as $key => [$label, $icon, $tbl]): 
                    $rtp_all = $wpdb->get_var("
                        SELECT COALESCE(SUM(payout_sat), 0) / NULLIF(SUM(bet_sat), 0) * 100 
                        FROM {$tbl} WHERE bet_sat > 0
                    ");
                    $rtp_7d = $wpdb->get_var("
                        SELECT COALESCE(SUM(payout_sat), 0) / NULLIF(SUM(bet_sat), 0) * 100 
                        FROM {$tbl} WHERE bet_sat > 0 AND played_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)
                    ");
                ?>
                <div style="background:#0d0d0d;padding:16px;border-radius:10px;text-align:center">
                    <div style="font-size:1.5rem;margin-bottom:8px"><?=$icon?></div>
                    <div style="font-weight:700;color:#fff;margin-bottom:8px"><?=$label?></div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:.8rem">
                        <div>
                            <div style="color:#555">All Time</div>
                            <div style="font-weight:700;color:<?=$rtp_all >= 95 ? '#22c55e' : '#ef4444'?>"><?=round($rtp_all ?? 0, 1)?>%</div>
                        </div>
                        <div>
                            <div style="color:#555">7 Days</div>
                            <div style="font-weight:700;color:<?=$rtp_7d >= 95 ? '#22c55e' : '#ef4444'?>"><?=round($rtp_7d ?? 0, 1)?>%</div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <script>
    let currentBettingPeriod = '7days';
    let bettingData = null;

    document.addEventListener('DOMContentLoaded', function() {
        cfpLoadBettingData();
    });

    function cfpChangeBettingPeriod(period, btn) {
        document.querySelectorAll('.cfp-tabs .cfp-tab').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        currentBettingPeriod = period;
        cfpLoadBettingData();
    }

    function cfpLoadBettingData() {
        const fd = new FormData();
        fd.append('action', 'cfp_betting_analytics_data');
        fd.append('nonce', '<?=$nonce?>');
        fd.append('period', currentBettingPeriod);
        
        fetch(ajaxurl, {method: 'POST', body: fd})
            .then(r => r.json())
            .then(d => {
                if(d.success) {
                    bettingData = d.data;
                    cfpUpdateBettingUI(d.data);
                }
            });
    }

    function cfpUpdateBettingUI(d) {
        // Update top betters
        const tbody = document.getElementById('cfp-top-betters');
        if(d.top_betters.length === 0) {
            tbody.innerHTML = '<tr><td colspan="4" style="text-align:center;color:#555">No data</td></tr>';
        } else {
            tbody.innerHTML = d.top_betters.map((tb, i) => `
                <tr>
                    <td>${i + 1}</td>
                    <td><strong>${tb.user_id}</strong></td>
                    <td style="color:#f7931a;font-weight:700">${Number(tb.total_wagered).toLocaleString()}</td>
                    <td>${Number(tb.bets).toLocaleString()}</td>
                </tr>
            `).join('');
        }

        // Update recent bets
        const betsBody = document.getElementById('cfp-recent-bets');
        if(d.recent_bets.length === 0) {
            betsBody.innerHTML = '<tr><td colspan="5" style="text-align:center;color:#555">No recent bets</td></tr>';
        } else {
            const gameIcons = { hilo: '🎲', slots: '🎰', coinflip: '🪙', dice: '🎲', crash: '📈', wheel: '🎡' };
            betsBody.innerHTML = d.recent_bets.map(b => `
                <tr>
                    <td><span style="font-size:1rem">${gameIcons[b.game] || '🎮'}</span> ${b.label}</td>
                    <td>${Number(b.bet).toLocaleString()}</td>
                    <td style="color:${b.payout >= b.bet ? '#22c55e' : '#ef4444'}">${Number(b.payout).toLocaleString()}</td>
                    <td style="color:${b.profit >= 0 ? '#22c55e' : '#ef4444'}">${Number(b.profit).toLocaleString()}</td>
                    <td style="color:#555;font-size:.75rem">${cfpTimeAgo(b.time)}</td>
                </tr>
            `).join('');
        }
    }

    function cfpTimeAgo(dateStr) {
        const date = new Date(dateStr);
        const now = new Date();
        const secs = Math.floor((now - date) / 1000);
        if(secs < 60) return secs + 's ago';
        if(secs < 3600) return Math.floor(secs/60) + 'm ago';
        if(secs < 86400) return Math.floor(secs/3600) + 'h ago';
        return Math.floor(secs/86400) + 'd ago';
    }

    function cfpExportBetting(format) {
        if(!bettingData) {
            alert('Please wait for data to load');
            return;
        }
        
        const rows = [['Game', 'Plays', 'Wagered', 'Paid', 'GGR', 'RTP']];
        Object.values(bettingData.stats).forEach(s => {
            rows.push([s.label, s.plays, s.wagered, s.paid, s.ggr, s.rtp + '%']);
        });
        
        const content = rows.map(r => r.join(',')).join('\n');
        const blob = new Blob([content], {type: 'text/csv'});
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'betting_analytics_' + new Date().toISOString().split('T')[0] + '.csv';
        a.click();
    }
    </script>
    <?php
}