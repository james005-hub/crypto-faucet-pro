<?php
/**
 * Admin page: Referral Tiers - Manage referral tiers and bonuses
 *
 * Part of Crypto Faucet Pro plugin.
 * @package CryptoFaucetPro
 */

if ( ! defined( 'ABSPATH' ) ) exit;

/* ============================================================
   AJAX: Referral Tiers Management
   ============================================================ */
add_action('wp_ajax_cfp_referral_tiers_data', 'cfp_ajax_referral_tiers_data');
function cfp_ajax_referral_tiers_data() {
    check_ajax_referer('cfp_referral_tiers_nonce', 'nonce');
    
    global $wpdb;
    $action = sanitize_text_field($_POST['sub_action'] ?? 'list');
    
    if($action === 'list') {
        $tiers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cfp_referral_tiers ORDER BY tier_level ASC");
        wp_send_json_success(['tiers' => $tiers]);
    }
    
    if($action === 'save') {
        $id = intval($_POST['id'] ?? 0);
        $data = [
            'tier_level' => intval($_POST['tier_level']),
            'tier_name' => sanitize_text_field($_POST['tier_name']),
            'min_referrals' => intval($_POST['min_referrals']),
            'min_total_earn' => intval($_POST['min_total_earn']),
            'commission_percent' => floatval($_POST['commission_percent']),
            'bonus_satoshis' => intval($_POST['bonus_satoshis']),
            'extra_benefits' => sanitize_textarea_field($_POST['extra_benefits'] ?? ''),
            'is_active' => isset($_POST['is_active']) ? 1 : 0
        ];
        
        if($id > 0) {
            $wpdb->update($wpdb->prefix . 'cfp_referral_tiers', $data, ['id' => $id]);
        } else {
            $wpdb->insert($wpdb->prefix . 'cfp_referral_tiers', $data);
        }
        wp_send_json_success(['msg' => 'Saved']);
    }
    
    if($action === 'delete') {
        $id = intval($_POST['id'] ?? 0);
        $wpdb->delete($wpdb->prefix . 'cfp_referral_tiers', ['id' => $id]);
        wp_send_json_success(['msg' => 'Deleted']);
    }
    
    if($action === 'apply_default') {
        $defaults = [
            ['tier_level' => 1, 'tier_name' => 'Bronze', 'min_referrals' => 0, 'min_total_earn' => 0, 'commission_percent' => 10, 'bonus_satoshis' => 0, 'extra_benefits' => 'Basic support', 'is_active' => 1],
            ['tier_level' => 2, 'tier_name' => 'Silver', 'min_referrals' => 5, 'min_total_earn' => 50000, 'commission_percent' => 15, 'bonus_satoshis' => 1000, 'extra_benefits' => 'Priority support', 'is_active' => 1],
            ['tier_level' => 3, 'tier_name' => 'Gold', 'min_referrals' => 15, 'min_total_earn' => 200000, 'commission_percent' => 20, 'bonus_satoshis' => 5000, 'extra_benefits' => 'VIP support + bonus claims', 'is_active' => 1],
            ['tier_level' => 4, 'tier_name' => 'Platinum', 'min_referrals' => 30, 'min_total_earn' => 1000000, 'commission_percent' => 25, 'bonus_satoshis' => 20000, 'extra_benefits' => 'Dedicated manager + exclusive rewards', 'is_active' => 1],
            ['tier_level' => 5, 'tier_name' => 'Diamond', 'min_referrals' => 50, 'min_total_earn' => 5000000, 'commission_percent' => 30, 'bonus_satoshis' => 100000, 'extra_benefits' => 'All benefits + revenue share', 'is_active' => 1]
        ];
        $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}cfp_referral_tiers");
        foreach($defaults as $d) { $wpdb->insert($wpdb->prefix . 'cfp_referral_tiers', $d); }
        wp_send_json_success(['msg' => 'Defaults applied']);
    }
}

/* ============================================================
   ADMIN: REFERRAL TIERS PAGE
   ============================================================ */
function cfp_admin_referral_tiers() {
    global $wpdb;
    $nonce = wp_create_nonce('cfp_referral_tiers_nonce');
    $tiers = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cfp_referral_tiers ORDER BY tier_level ASC");
    $default_commission = get_option('referral_percent', 10);
    $total_referrals = (int)$wpdb->get_var("SELECT COUNT(*) FROM " . CFP_TABLE_REFERRALS);
    ?>
    <div class="cfp-wrap">
        <div class="cfp-header">
            <span class="cfp-logo-badge">🏆</span>
            <h1>🏆 Referral Tiers</h1>
            <button onclick="cfpShowTierModal()" class="cfp-btn cfp-btn-gold" style="margin-left:auto">➕ Add Tier</button>
        </div>

        <div class="cfp-stats-grid" style="grid-template-columns:repeat(4, 1fr); margin-bottom:30px">
            <div class="cfp-stat-card"><div class="label">🏅 Total Tiers</div><div class="value"><?=count($tiers)?></div></div>
            <div class="cfp-stat-card green"><div class="label">💰 Default Commission</div><div class="value"><?=$default_commission?>%</div></div>
            <div class="cfp-stat-card blue"><div class="label">👥 Total Referrals</div><div class="value"><?=number_format($total_referrals)?></div></div>
            <div class="cfp-stat-card purple"><div class="label">⭐ Highest Commission</div><div class="value"><?=max(array_column($tiers,'commission_percent')?:[0])?>%</div></div>
        </div>

        <div class="cfp-card">
            <div style="display:flex;justify-content:space-between;margin-bottom:16px">
                <h2>📋 Referral Tier Levels</h2>
                <button onclick="cfpApplyDefaults()" class="cfp-btn cfp-btn-ghost">⚙️ Apply Defaults</button>
            </div>
            <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(300px,1fr));gap:16px">
            <?php foreach($tiers as $t): ?>
                <div style="background:#0d0d0d;padding:20px;border-radius:12px;border-left:4px solid <?=$t->tier_level<=2?'#cd7f32':($t->tier_level<=3?'#c0c0c0':($t->tier_level<=4?'#e5e4e2':'#b9f2ff') )?>">
                    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
                        <span style="font-weight:800;font-size:1.3rem;color:#fff"><?=esc_html($t->tier_name)?></span>
                        <span class="cfp-badge <?=$t->is_active?'active':'rejected'?>"><?=$t->is_active?'Active':'Disabled'?></span>
                    </div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;font-size:.85rem">
                        <div><span style="color:#555">Min Referrals</span><br><span style="color:#fff;font-weight:700"><?=$t->min_referrals?></span></div>
                        <div><span style="color:#555">Min Earnings</span><br><span style="color:#fff;font-weight:700"><?=number_format($t->min_total_earn)?></span></div>
                        <div><span style="color:#555">Commission</span><br><span style="color:#22c55e;font-weight:700"><?=$t->commission_percent?>%</span></div>
                        <div><span style="color:#555">Bonus</span><br><span style="color:#f7931a;font-weight:700"><?=number_format($t->bonus_satoshis)?> sat</span></div>
                    </div>
                    <?php if($t->extra_benefits): ?>
                    <div style="margin-top:12px;padding:10px;background:#111;border-radius:8px;font-size:.75rem;color:#888">
                        <strong>Benefits:</strong> <?=esc_html($t->extra_benefits)?>
                    </div>
                    <?php endif; ?>
                    <div style="margin-top:12px;display:flex;gap:8px">
                        <button onclick="cfpDeleteTier(<?=$t->id?>)" class="cfp-btn cfp-btn-sm cfp-btn-red">Delete</button>
                    </div>
                </div>
            <?php endforeach; ?>
            <?php if(empty($tiers)): ?>
                <div style="grid-column:1/-1;text-align:center;padding:40px;color:#555">No tiers configured. Click "Add Tier" or "Apply Defaults".</div>
            <?php endif; ?>
            </div>
        </div>

        <div class="cfp-card" style="margin-top:24px">
            <h2>💡 How Referral Tiers Work</h2>
            <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:24px">
                <div style="background:#0d0d0d;padding:20px;border-radius:12px">
                    <h3 style="color:#22c55e;margin-bottom:12px">📈 Tier Progression</h3>
                    <p style="color:#888;font-size:.85rem;line-height:1.6">Users automatically move up tiers based on their referral count and total earnings. Higher tiers = higher commission rates.</p>
                </div>
                <div style="background:#0d0d0d;padding:20px;border-radius:12px">
                    <h3 style="color:#f7931a;margin-bottom:12px">🎁 Bonus Rewards</h3>
                    <p style="color:#888;font-size:.85rem;line-height:1.6">Each tier can have a bonus satoshi reward and extra benefits like priority support, exclusive rewards, or revenue share.</p>
                </div>
            </div>
        </div>
    </div>

    <div id="cfp-tier-modal" style="display:none;position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,0.8);z-index:9999;align-items:center;justify-content:center">
        <div style="background:#161616;border:1px solid #2a2a2a;border-radius:16px;padding:28px;max-width:500px;width:90%">
            <h2 style="color:#fff;margin-bottom:20px">Add Tier</h2>
            <form id="cfp-tier-form">
                <div class="cfp-field"><label>Tier Level</label><input type="number" id="cfp-tier-lvl" value="1"></div>
                <div class="cfp-field"><label>Tier Name</label><input type="text" id="cfp-tier-name" required></div>
                <div class="cfp-field"><label>Min Referrals</label><input type="number" id="cfp-tier-refs" value="0"></div>
                <div class="cfp-field"><label>Min Total Earnings (sat)</label><input type="number" id="cfp-tier-earn" value="0"></div>
                <div class="cfp-field"><label>Commission %</label><input type="number" id="cfp-tier-comm" value="10" step="0.5"></div>
                <div class="cfp-field"><label>Bonus Satoshis</label><input type="number" id="cfp-tier-bonus" value="0"></div>
                <div class="cfp-field"><label>Extra Benefits</label><textarea id="cfp-tier-benefits" rows="2"></textarea></div>
                <div class="cfp-field"><label><input type="checkbox" id="cfp-tier-active" checked> Active</label></div>
                <div style="display:flex;gap:12px;margin-top:20px">
                    <button type="submit" class="cfp-btn cfp-btn-gold">Save</button>
                    <button type="button" onclick="document.getElementById('cfp-tier-modal').style.display='none'" class="cfp-btn cfp-btn-ghost">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
    function cfpShowTierModal(){document.getElementById('cfp-tier-modal').style.display='flex';}
    document.getElementById('cfp-tier-form').addEventListener('submit',function(e){
        e.preventDefault();
        var fd=new FormData();
        fd.append('action','cfp_referral_tiers_data');fd.append('nonce','<?=$nonce?>');fd.append('sub_action','save');
        fd.append('tier_level',document.getElementById('cfp-tier-lvl').value);
        fd.append('tier_name',document.getElementById('cfp-tier-name').value);
        fd.append('min_referrals',document.getElementById('cfp-tier-refs').value);
        fd.append('min_total_earn',document.getElementById('cfp-tier-earn').value);
        fd.append('commission_percent',document.getElementById('cfp-tier-comm').value);
        fd.append('bonus_satoshis',document.getElementById('cfp-tier-bonus').value);
        fd.append('extra_benefits',document.getElementById('cfp-tier-benefits').value);
        fd.append('is_active',document.getElementById('cfp-tier-active').checked?'1':'0');
        fetch(ajaxurl,{method:'POST',body:fd}).then(()=>location.reload());
    });
    function cfpDeleteTier(id){if(confirm('Delete?')){var fd=new FormData();fd.append('action','cfp_referral_tiers_data');fd.append('nonce','<?=$nonce?>');fd.append('sub_action','delete');fd.append('id',id);fetch(ajaxurl,{method:'POST',body:fd}).then(()=>location.reload());}}
    function cfpApplyDefaults(){if(confirm('Apply defaults?')){var fd=new FormData();fd.append('action','cfp_referral_tiers_data');fd.append('nonce','<?=$nonce?>');fd.append('sub_action','apply_default');fetch(ajaxurl,{method:'POST',body:fd}).then(()=>location.reload());}}
    </script>
    <?php
}